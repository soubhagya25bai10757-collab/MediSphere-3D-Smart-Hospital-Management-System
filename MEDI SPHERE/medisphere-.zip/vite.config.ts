import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import fs from 'fs';
import path from 'path';
import net from 'net';
import { spawn } from 'child_process';
import { defineConfig, Plugin } from 'vite';

// LINT.IfChange(aistudio_media_plugin)
function aistudioMediaPlugin(): Plugin {
  return {
    name: 'vite-plugin-aistudio-media',
    configureServer(server) {
      server.middlewares.use((req, res, next) => {
        if (req.url && req.url.startsWith('/assets/aistudio/')) {
          const rawPath = req.url.split('?')[0].split('#')[0];
          try {
            const decodedPath = decodeURIComponent(rawPath);
            const relativePath = decodedPath.replace(/^\//, '');
            const aistudioDir = path.resolve(
              __dirname,
              'public',
              'assets',
              'aistudio',
            );
            const filePath = path.resolve(__dirname, 'public', relativePath);
            if (
              filePath.startsWith(aistudioDir + path.sep) &&
              fs.existsSync(filePath) &&
              fs.statSync(filePath).isFile()
            ) {
              const ext = path.extname(filePath).toLowerCase();
              const mimeMap: Record<string, string> = {
                '.jpg': 'image/jpeg',
                '.jpeg': 'image/jpeg',
                '.png': 'image/png',
                '.gif': 'image/gif',
                '.webp': 'image/webp',
                '.svg': 'image/svg+xml',
                '.bmp': 'image/bmp',
                '.ico': 'image/x-icon',
                '.mp4': 'video/mp4',
                '.webm': 'video/webm',
                '.ogv': 'video/ogg',
                '.mp3': 'audio/mpeg',
                '.wav': 'audio/wav',
                '.ogg': 'audio/ogg',
                '.pdf': 'application/pdf',
              };
              res.setHeader(
                'Content-Type',
                mimeMap[ext] || 'application/octet-stream',
              );
              res.setHeader('Cache-Control', 'no-cache');
              fs.createReadStream(filePath).pipe(res);
              return;
            }
          } catch {
            // Fall through if URI decoding or file access fails
          }
        }
        next();
      });
    },
  };
}
// LINT.ThenChange(//depot/google3/java/com/google/alkali/boq/makersuite/applet_dev_service/templates/initializers/react_theme/vite.config.ts:aistudio_media_plugin)

/**
 * Plugin to automatically maintain and supervise the MediSphere Java SE Backend
 */
function javaBackendSupervisorPlugin(): Plugin {
  let javaProc: any = null;
  return {
    name: 'medisphere-java-supervisor',
    configureServer(server) {
      const javaDir = path.resolve(__dirname, 'java');
      const targetPort = 8085;

      const checkAndLaunch = () => {
        const client = new net.Socket();
        client.setTimeout(350);
        client.on('connect', () => {
          client.destroy();
          console.log(`[Java Supervisor] MediSphere Java SE Backend detected active on port ${targetPort}`);
        });
        client.on('error', () => {
          client.destroy();
          console.log(`[Java Supervisor] Starting MediSphere Java SE Backend on port ${targetPort}...`);
          javaProc = spawn('java', ['-cp', 'bin', 'Main'], {
            cwd: javaDir,
            stdio: 'inherit',
          });
          javaProc.on('error', (err: any) => {
            console.error('[Java Supervisor] Process spawn error:', err);
          });
        });
        client.connect(targetPort, '127.0.0.1');
      };

      checkAndLaunch();

      server.httpServer?.on('close', () => {
        if (javaProc) {
          try {
            javaProc.kill();
          } catch (e) {}
        }
      });
    },
  };
}

export default defineConfig(() => {
  return {
    plugins: [react(), tailwindcss(), aistudioMediaPlugin(), javaBackendSupervisorPlugin()],
    resolve: {
      alias: {
        '@': path.resolve(__dirname, '.'),
      },
    },
    server: {
      proxy: {
        '/api': {
          target: 'http://127.0.0.1:8085',
          changeOrigin: true,
        },
      },
      // HMR is disabled in AI Studio via DISABLE_HMR env var.
      // Do not modify—file watching is disabled to prevent flickering during agent edits.
      hmr: process.env.DISABLE_HMR !== 'true',
      // Disable file watching when DISABLE_HMR is true to save CPU during agent edits.
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});
