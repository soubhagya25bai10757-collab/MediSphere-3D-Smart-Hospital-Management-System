import React, { useState, useEffect } from 'react';
import {
  Code2,
  Box,
  ShieldCheck,
  GitBranch,
  Layers,
  AlertOctagon,
  Database,
  CheckCircle2,
  Copy,
  Check,
  ChevronDown,
  ChevronUp,
  FileCode,
  Terminal,
  ArrowDown,
  Sparkles,
  Play,
  RotateCw,
  Server,
  Activity,
  Cpu,
  Lock,
  FileText,
  FolderTree,
} from 'lucide-react';

export const JavaImplementationPanel: React.FC = () => {
  const [copiedCmd, setCopiedCmd] = useState<boolean>(false);
  const [selectedFile, setSelectedFile] = useState<string>('Main.java');
  const [showCodeViewer, setShowCodeViewer] = useState<boolean>(false);
  const [copiedCode, setCopiedCode] = useState<boolean>(false);

  // Live REST API Tester State
  const [activeEndpoint, setActiveEndpoint] = useState<string>('/api/health');
  const [apiResponse, setApiResponse] = useState<string | null>(null);
  const [apiStatus, setApiStatus] = useState<number | null>(null);
  const [isLoadingApi, setIsLoadingApi] = useState<boolean>(false);
  const [apiLatency, setApiLatency] = useState<number | null>(null);

  const compileCommand = 'javac -d bin src/model/*.java src/exception/*.java src/service/*.java src/Main.java && java -cp bin Main';

  const copyToClipboard = (text: string, isCode = false) => {
    navigator.clipboard.writeText(text);
    if (isCode) {
      setCopiedCode(true);
      setTimeout(() => setCopiedCode(false), 2000);
    } else {
      setCopiedCmd(true);
      setTimeout(() => setCopiedCmd(false), 2000);
    }
  };

  const handleTestEndpoint = async (endpoint: string, method = 'GET', payload?: any) => {
    setActiveEndpoint(endpoint);
    setIsLoadingApi(true);
    const start = performance.now();
    try {
      const options: RequestInit = {
        method,
        headers: {
          'Content-Type': 'application/json',
        },
      };
      if (payload) {
        options.body = JSON.stringify(payload);
      }
      const res = await fetch(endpoint, options);
      const elapsed = Math.round(performance.now() - start);
      setApiLatency(elapsed);
      setApiStatus(res.status);
      const text = await res.text();
      try {
        const json = JSON.parse(text);
        setApiResponse(JSON.stringify(json, null, 2));
      } catch {
        setApiResponse(text);
      }
    } catch (err: any) {
      const elapsed = Math.round(performance.now() - start);
      setApiLatency(elapsed);
      setApiStatus(500);
      setApiResponse(JSON.stringify({ error: true, message: err.message || 'Request failed' }, null, 2));
    } finally {
      setIsLoadingApi(false);
    }
  };

  // Auto-fetch health on mount
  useEffect(() => {
    handleTestEndpoint('/api/health');
  }, []);

  const concepts = [
    {
      id: 'classes',
      num: 1,
      title: 'CLASSES & OBJECTS',
      summary: 'Patient, Doctor and Appointment entities with constructors and methods.',
      details: 'Instantiated using constructors with real hospital parameters (e.g. patientId, bloodGroup, specialization, consultationFee).',
      icon: Box,
      tag: 'model.Patient / Doctor / Appointment',
      badgeColor: 'border-cyan-500/40 text-cyan-300 bg-cyan-500/10',
      borderColor: 'border-cyan-500/30',
      iconBg: 'bg-cyan-500/15 text-cyan-400',
    },
    {
      id: 'encapsulation',
      num: 2,
      title: 'ENCAPSULATION',
      summary: 'Private member variables protected by validated getters and setters.',
      details: 'Defensive validation in setters: age strictly 0–140, name cannot be empty, consultation fees and IDs cannot be negative.',
      icon: ShieldCheck,
      tag: 'private fields + validated setters',
      badgeColor: 'border-indigo-500/40 text-indigo-300 bg-indigo-500/10',
      borderColor: 'border-indigo-500/30',
      iconBg: 'bg-indigo-500/15 text-indigo-400',
    },
    {
      id: 'inheritance',
      num: 3,
      title: 'INHERITANCE',
      summary: 'Specialized doctors inherit common properties from Doctor.',
      details: 'Cardiologist, Dentist, Neurologist, and OrthopedicDoctor extend Doctor via "extends Doctor" and constructor chaining with super(...).',
      icon: GitBranch,
      tag: 'extends Doctor + super(...)',
      badgeColor: 'border-purple-500/40 text-purple-300 bg-purple-500/10',
      borderColor: 'border-purple-500/30',
      iconBg: 'bg-purple-500/15 text-purple-400',
    },
    {
      id: 'polymorphism',
      num: 4,
      title: 'POLYMORPHISM',
      summary: 'Specialist doctors override consultationDetails() dynamically.',
      details: 'Runtime method dispatch: Invoking consultationDetails() on a Doctor reference executes Cardiology, Dental, or Neurology specifics at runtime.',
      icon: Layers,
      tag: 'Dynamic Method Overriding',
      badgeColor: 'border-amber-500/40 text-amber-300 bg-amber-500/10',
      borderColor: 'border-amber-500/30',
      iconBg: 'bg-amber-500/15 text-amber-400',
    },
    {
      id: 'collections',
      num: 5,
      title: 'COLLECTIONS / ARRAYLIST',
      summary: 'Dynamic in-memory hospital registries using ArrayList.',
      details: 'HospitalService manages ArrayList<Patient>, ArrayList<Doctor>, and ArrayList<Appointment> with add, remove, search, and display operations.',
      icon: Database,
      tag: 'ArrayList<T> in HospitalService',
      badgeColor: 'border-emerald-500/40 text-emerald-300 bg-emerald-500/10',
      borderColor: 'border-emerald-500/30',
      iconBg: 'bg-emerald-500/15 text-emerald-400',
    },
    {
      id: 'exceptions',
      num: 6,
      title: 'EXCEPTION HANDLING',
      summary: 'Custom checked AppointmentException enforces clinical rules.',
      details: 'Uses try, catch, throw, and throws to reject unavailable slots (double booking), unregistered patients, unassigned doctors, and null payloads.',
      icon: AlertOctagon,
      tag: 'AppointmentException + try-catch',
      badgeColor: 'border-rose-500/40 text-rose-300 bg-rose-500/10',
      borderColor: 'border-rose-500/30',
      iconBg: 'bg-rose-500/15 text-rose-400',
    },
    {
      id: 'packages',
      num: 7,
      title: 'USER-DEFINED PACKAGES',
      summary: 'Modular organization across model, service, and exception packages.',
      details: 'Source code structured cleanly into model (entities), service (business logic & collections), and exception (custom checked exceptions).',
      icon: FolderTree,
      tag: 'package model / service / exception',
      badgeColor: 'border-sky-500/40 text-sky-300 bg-sky-500/10',
      borderColor: 'border-sky-500/30',
      iconBg: 'bg-sky-500/15 text-sky-400',
    },
    {
      id: 'multithreading',
      num: 8,
      title: 'MULTITHREADING',
      summary: 'HospitalMonitor background daemon task implementing Runnable.',
      details: 'Runs inside a dedicated Thread(HospitalMonitor, "MediSphere-HospitalMonitor-Worker") executing continuous telemetry and census monitoring.',
      icon: Cpu,
      tag: 'Thread + Runnable HospitalMonitor',
      badgeColor: 'border-teal-500/40 text-teal-300 bg-teal-500/10',
      borderColor: 'border-teal-500/30',
      iconBg: 'bg-teal-500/15 text-teal-400',
    },
    {
      id: 'synchronization',
      num: 9,
      title: 'JAVA SYNCHRONIZATION',
      summary: 'Thread-safe synchronized methods and critical monitor blocks.',
      details: 'Guarantees thread safety when concurrent background threads read and mutate shared ArrayList<Patient> and ArrayList<Appointment>.',
      icon: Lock,
      tag: 'synchronized methods & blocks',
      badgeColor: 'border-violet-500/40 text-violet-300 bg-violet-500/10',
      borderColor: 'border-violet-500/30',
      iconBg: 'bg-violet-500/15 text-violet-400',
    },
    {
      id: 'streams',
      num: 10,
      title: 'JAVA I/O STREAMS',
      summary: 'Hospital audit logs written and read using BufferedReader/Writer.',
      details: 'Exports appointment audits to disk using FileWriter + BufferedWriter and streams them back into memory using FileReader + BufferedReader.',
      icon: FileText,
      tag: 'BufferedWriter & BufferedReader',
      badgeColor: 'border-orange-500/40 text-orange-300 bg-orange-500/10',
      borderColor: 'border-orange-500/30',
      iconBg: 'bg-orange-500/15 text-orange-400',
    },
  ];

  const javaSourceSnippets: Record<string, { desc: string; code: string }> = {
    'Main.java': {
      desc: 'Driver program testing all 10 concepts and starting embedded Java SE HTTP server',
      code: `// File: java/src/Main.java
import model.*;
import exception.AppointmentException;
import service.HospitalService;
import com.sun.net.httpserver.HttpServer;

public class Main {
    public static void main(String[] args) {
        HospitalService hospital = new HospitalService("MediSphere 3D Central Command");

        // 1 & 2. CLASSES, OBJECTS & ENCAPSULATION
        Patient p1 = new Patient(101, "Eleanor Vance", 34, "A+", "+1-555-0192");
        Doctor cardio = new Cardiologist(201, "Aria Thorne", 14, 250.00, true, 310);

        // 3 & 4. INHERITANCE & RUNTIME POLYMORPHISM
        Doctor docRef = cardio;
        System.out.println(docRef.consultationDetails()); // Dynamic dispatch

        // 5. COLLECTIONS FRAMEWORK (ArrayList add, remove, search)
        hospital.addPatient(p1);
        hospital.addDoctor(cardio);

        // 6. EXCEPTION HANDLING (Custom checked AppointmentException)
        try {
            Appointment appt = new Appointment(501, p1, cardio, "2026-09-15", "10:00 AM", "Cardiology");
            hospital.bookAppointment(appt);
            hospital.bookAppointment(appt); // Slot conflict -> throws AppointmentException
        } catch (AppointmentException ex) {
            System.out.println("Caught: " + ex.getMessage());
        }

        // 8 & 9. MULTITHREADING & SYNCHRONIZATION
        hospital.startHospitalMonitor(); // Daemon worker thread with synchronized collection access

        // 10. JAVA I/O STREAMS
        hospital.exportAppointmentReport("logs/appointment_audit.log"); // BufferedWriter
        String report = hospital.readAppointmentReport("logs/appointment_audit.log"); // BufferedReader

        // HTTP REST SERVER (Java SE HttpServer on port 8080/8085)
        startHttpServer(hospital);
    }
}`,
    },
    'HospitalService.java': {
      desc: 'Central coordinator managing ArrayList collections, Threading, Synchronization, and I/O Streams',
      code: `// File: java/src/service/HospitalService.java
package service;

import model.*;
import exception.AppointmentException;
import java.io.*;
import java.util.ArrayList;

public class HospitalService {
    private final ArrayList<Patient> patients = new ArrayList<>();
    private final ArrayList<Doctor> doctors = new ArrayList<>();
    private final ArrayList<Appointment> appointments = new ArrayList<>();
    private Thread monitorThread;

    // 5 & 9. Synchronized ArrayList operations
    public synchronized void addPatient(Patient p) { patients.add(p); }
    public synchronized boolean removePatient(int id) {
        return patients.removeIf(p -> p.getPatientId() == id);
    }
    public synchronized Patient searchPatient(int id) {
        return patients.stream().filter(p -> p.getPatientId() == id).findFirst().orElse(null);
    }

    // 6. Checked Exception validation
    public synchronized void bookAppointment(Appointment appt) throws AppointmentException {
        if (appt == null) throw new AppointmentException("APPT_NULL", "Appointment cannot be null.");
        if (searchPatient(appt.getPatient().getPatientId()) == null) {
            throw new AppointmentException("PATIENT_UNREGISTERED", "Patient not registered.");
        }
        for (Appointment existing : appointments) {
            if (existing.getDoctor().getDoctorId() == appt.getDoctor().getDoctorId()
                && existing.getDate().equals(appt.getDate()) && existing.getTime().equals(appt.getTime())) {
                throw new AppointmentException("SLOT_UNAVAILABLE", "Doctor already booked at this slot.");
            }
        }
        appointments.add(appt);
    }

    // 8 & 9. Multithreading & Synchronization
    public static class HospitalMonitor implements Runnable {
        private final HospitalService service;
        public HospitalMonitor(HospitalService s) { this.service = s; }
        public void run() {
            while (true) {
                try {
                    Thread.sleep(10000);
                    synchronized (service) { // Critical synchronization block
                        System.out.println("Census: " + service.patients.size() + " patients");
                    }
                } catch (InterruptedException e) { break; }
            }
        }
    }

    // 10. Java I/O Streams
    public synchronized void exportAppointmentReport(String path) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(path))) {
            writer.write("MEDISPHERE AUDIT REPORT: " + appointments.size() + " bookings");
        }
    }
}`,
    },
    'Patient.java': {
      desc: 'Patient entity demonstrating Encapsulation with private fields and validation',
      code: `// File: java/src/model/Patient.java
package model;

public class Patient {
    private int patientId;
    private String name;
    private int age;
    private String bloodGroup;
    private String phone;

    public Patient(int patientId, String name, int age, String bloodGroup, String phone) {
        setPatientId(patientId);
        setName(name);
        setAge(age);
        setBloodGroup(bloodGroup);
        setPhone(phone);
    }

    // Encapsulation: Validated Setters
    public void setAge(int age) {
        if (age < 0 || age > 140) {
            throw new IllegalArgumentException("Patient age must be between 0 and 140. Given: " + age);
        }
        this.age = age;
    }

    public void setName(String name) {
        if (name == null || name.trim().isEmpty()) {
            throw new IllegalArgumentException("Patient name cannot be null or empty.");
        }
        this.name = name.trim();
    }

    public String toJson() {
        return String.format("{\\"patientId\\":%d,\\"name\\":\\"%s\\",\\"age\\":%d,\\"bloodGroup\\":\\"%s\\"}",
                patientId, name, age, bloodGroup);
    }

    public int getPatientId() { return patientId; }
    public String getName() { return name; }
    public int getAge() { return age; }
    public String getBloodGroup() { return bloodGroup; }
}`,
    },
    'Doctor.java': {
      desc: 'Superclass demonstrating base fields, encapsulation, and polymorphic base method',
      code: `// File: java/src/model/Doctor.java
package model;

public class Doctor {
    private int doctorId;
    private String name;
    private String specialization;
    private int experience;
    private double consultationFee;

    public Doctor(int doctorId, String name, String specialization, int experience, double consultationFee) {
        setDoctorId(doctorId);
        setName(name);
        setSpecialization(specialization);
        setExperience(experience);
        setConsultationFee(consultationFee);
    }

    // Polymorphic method to be overridden in specialist subclasses
    public String consultationDetails() {
        return String.format("[General Medical Consultation] Dr. %s conducts standard vitals triage. Fee: $%.2f",
                name, consultationFee);
    }

    public int getDoctorId() { return doctorId; }
    public String getName() { return name; }
    public String getSpecialization() { return specialization; }
    public double getConsultationFee() { return consultationFee; }
}`,
    },
    'Cardiologist.java': {
      desc: 'Subclass demonstrating Inheritance (extends Doctor, super(...)) and Polymorphism',
      code: `// File: java/src/model/Cardiologist.java
package model;

public class Cardiologist extends Doctor {
    private boolean ecgCertified;
    private int cardiacSurgeriesPerformed;

    public Cardiologist(int doctorId, String name, int experience, double consultationFee,
                        boolean ecgCertified, int cardiacSurgeriesPerformed) {
        super(doctorId, name, "Cardiology", experience, consultationFee);
        this.ecgCertified = ecgCertified;
        this.cardiacSurgeriesPerformed = cardiacSurgeriesPerformed;
    }

    // Method Overriding (Polymorphism)
    @Override
    public String consultationDetails() {
        return String.format(
            "[Cardiology Consultation] Dr. %s conducts 12-lead ECG & echocardiogram (Surgeries: %d). Fee: $%.2f",
            getName(), cardiacSurgeriesPerformed, getConsultationFee()
        );
    }
}`,
    },
    'AppointmentException.java': {
      desc: 'Custom checked exception for hospital clinical rule validation',
      code: `// File: java/src/exception/AppointmentException.java
package exception;

public class AppointmentException extends Exception {
    private String errorCode;

    public AppointmentException(String message) {
        super(message);
        this.errorCode = "APPT_ERR";
    }

    public AppointmentException(String errorCode, String message) {
        super(String.format("[%s] %s", errorCode, message));
        this.errorCode = errorCode;
    }

    public String getErrorCode() {
        return errorCode;
    }
}`,
    },
  };

  const endpoints = [
    { method: 'GET', path: '/api/health', desc: 'Backend health, Java version & syllabus telemetry' },
    { method: 'GET', path: '/api/patients', desc: 'Registered patients from ArrayList<Patient>' },
    { method: 'GET', path: '/api/doctors', desc: 'Specialist doctors with polymorphic consultation details' },
    { method: 'GET', path: '/api/appointments', desc: 'Active appointments from ArrayList<Appointment>' },
    { method: 'GET', path: '/api/report', desc: 'Demonstrates Java I/O Streams (FileWriter & BufferedReader)' },
    { method: 'GET', path: '/api/threads', desc: 'Status of HospitalMonitor daemon thread & synchronization' },
  ];

  return (
    <div
      id="java-implementation-panel"
      className="p-5 sm:p-6 rounded-3xl bg-[rgba(10,25,60,0.75)] border border-cyan-500/30 backdrop-blur-xl shadow-[0_0_30px_rgba(6,182,212,0.15)] space-y-6 animate-in fade-in duration-300"
    >
      {/* Panel Header */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-4 border-b border-cyan-500/20">
        <div className="space-y-1">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-[10px] uppercase font-bold tracking-widest text-cyan-300 px-2.5 py-0.5 rounded-full bg-cyan-500/15 border border-cyan-400/40 flex items-center gap-1.5 shadow-sm">
              <Code2 className="w-3.5 h-3.5 text-cyan-400" />
              VIT Bhopal &bull; Programming in Java
            </span>
            <span className="text-[10px] font-mono text-emerald-300 bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/30 flex items-center gap-1">
              <CheckCircle2 className="w-3 h-3 text-emerald-400" />
              Compilable Java Module (/java/src)
            </span>
            <span className="text-[10px] font-mono text-purple-300 bg-purple-500/10 px-2 py-0.5 rounded-full border border-purple-500/30 flex items-center gap-1">
              <Server className="w-3 h-3 text-purple-400" />
              10 Syllabus Concepts &bull; Embedded HTTP Backend
            </span>
          </div>
          <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight flex items-center gap-2.5">
            <span className="bg-gradient-to-r from-cyan-300 via-indigo-200 to-purple-300 bg-clip-text text-transparent">
              Java Implementation & REST Backend
            </span>
          </h2>
          <p className="text-xs text-slate-300 max-w-3xl leading-relaxed">
            Genuine Java SE codebase implementing 10 fundamental concepts of Object-Oriented Programming and Java SE
            for hospital clinical workflows. Compilable standalone from the <code className="text-cyan-300 bg-slate-900/80 px-1 py-0.5 rounded border border-cyan-500/30 font-mono text-[11px]">java/</code> directory
            and serving real HTTP REST endpoints.
          </p>
        </div>

        {/* Quick Compilation Terminal Box */}
        <div className="p-3 rounded-2xl bg-slate-950/80 border border-cyan-500/25 shadow-inner flex flex-col gap-1.5 max-w-md w-full shrink-0">
          <div className="flex items-center justify-between text-[11px] font-mono text-slate-400">
            <span className="flex items-center gap-1 text-cyan-300 font-bold">
              <Terminal className="w-3.5 h-3.5 text-cyan-400" />
              Terminal Compilation & Execution
            </span>
            <button
              onClick={() => copyToClipboard(compileCommand)}
              className="inline-flex items-center gap-1 text-[10px] text-slate-300 hover:text-white px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 transition cursor-pointer"
              title="Copy compile command"
            >
              {copiedCmd ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
              <span>{copiedCmd ? 'Copied' : 'Copy'}</span>
            </button>
          </div>
          <div className="text-[10px] font-mono text-cyan-200 bg-slate-900/90 p-2 rounded-lg border border-cyan-500/20 overflow-x-auto whitespace-nowrap">
            {compileCommand}
          </div>
        </div>
      </div>

      {/* LIVE JAVA SE REST BACKEND TESTER CARD */}
      <div className="p-4 sm:p-5 rounded-2xl bg-slate-950/80 border border-emerald-500/30 shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center">
              <Server className="w-4 h-4 text-emerald-400" />
            </div>
            <div>
              <h3 className="text-sm font-extrabold text-white flex items-center gap-2">
                Live Java SE HTTP Backend Console
                <span className="text-[10px] font-mono font-normal px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 animate-pulse">
                  ONLINE &bull; Port 8080/8085
                </span>
              </h3>
              <p className="text-[11px] text-slate-400">
                Click any endpoint to send live requests directly to the running Java SE server via Vite proxy.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 self-start sm:self-auto">
            {apiLatency !== null && (
              <span className="text-[10px] font-mono text-cyan-300 bg-cyan-950/60 px-2 py-1 rounded border border-cyan-500/30">
                {apiLatency}ms latency
              </span>
            )}
            {apiStatus !== null && (
              <span className={`text-[10px] font-mono font-bold px-2 py-1 rounded border ${
                apiStatus === 200 || apiStatus === 201
                  ? 'bg-emerald-950/60 text-emerald-300 border-emerald-500/40'
                  : 'bg-red-950/60 text-red-300 border-red-500/40'
              }`}>
                HTTP {apiStatus}
              </span>
            )}
          </div>
        </div>

        {/* Endpoint Action Buttons */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2">
          {endpoints.map((ep) => {
            const isSelected = activeEndpoint === ep.path;
            return (
              <button
                key={ep.path}
                onClick={() => handleTestEndpoint(ep.path, ep.method)}
                disabled={isLoadingApi}
                className={`p-2.5 rounded-xl text-left font-mono text-xs transition cursor-pointer flex flex-col justify-between gap-1 border ${
                  isSelected
                    ? 'bg-emerald-500/20 border-emerald-400 text-white shadow-[0_0_12px_rgba(16,185,129,0.3)]'
                    : 'bg-slate-900/90 border-slate-800 text-slate-300 hover:text-white hover:border-emerald-500/40'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-[9px] font-bold text-emerald-400">{ep.method}</span>
                  {isLoadingApi && isSelected ? (
                    <RotateCw className="w-3 h-3 text-emerald-300 animate-spin" />
                  ) : (
                    <Play className="w-3 h-3 text-slate-500 group-hover:text-emerald-400" />
                  )}
                </div>
                <span className="font-bold text-[11px] truncate">{ep.path}</span>
                <span className="text-[9px] text-slate-400 truncate">{ep.desc}</span>
              </button>
            );
          })}
        </div>

        {/* Live Response Viewer */}
        <div className="relative rounded-xl bg-black/80 border border-cyan-500/30 p-3 overflow-hidden shadow-inner">
          <div className="flex items-center justify-between text-[11px] font-mono text-slate-400 pb-2 border-b border-slate-800 mb-2">
            <span className="text-cyan-300 flex items-center gap-1.5 font-bold">
              <Activity className="w-3.5 h-3.5 text-cyan-400" />
              Live Output from Java Server &bull; {activeEndpoint}
            </span>
            <span className="text-[10px] text-slate-500">
              Response format: JSON / Plaintext
            </span>
          </div>
          <pre className="font-mono text-[11px] text-emerald-300 max-h-48 overflow-y-auto whitespace-pre-wrap leading-relaxed">
            {isLoadingApi ? 'Fetching live response from Java SE Backend...' : apiResponse || 'No response yet.'}
          </pre>
        </div>
      </div>

      {/* 10 Syllabus Concept Cards */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <span className="text-xs uppercase font-extrabold tracking-wider text-slate-300 flex items-center gap-2">
            <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
            10 Core Java Concepts Implemented in MediSphere 3D
          </span>
          <span className="text-[11px] font-mono text-slate-400">
            Click &ldquo;Inspect .java Source Code&rdquo; below to view source files
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
          {concepts.map((concept) => {
            const Icon = concept.icon;
            return (
              <div
                key={concept.id}
                className={`p-3.5 rounded-2xl bg-[rgba(6,18,45,0.7)] border ${concept.borderColor} shadow-lg hover:shadow-[0_0_15px_rgba(6,182,212,0.2)] transition-all flex flex-col justify-between group relative overflow-hidden`}
              >
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <div className={`w-7 h-7 rounded-lg flex items-center justify-center ${concept.iconBg} shadow-inner`}>
                      <Icon className="w-3.5 h-3.5" />
                    </div>
                    <span className="text-[10px] font-mono font-bold text-slate-400">
                      #{concept.num}
                    </span>
                  </div>

                  <h3 className="text-xs font-black text-white tracking-wide uppercase">
                    {concept.title}
                  </h3>

                  <p className="text-[11px] font-semibold text-cyan-200/90 leading-snug">
                    {concept.summary}
                  </p>

                  <p className="text-[10px] text-slate-300 leading-relaxed font-normal">
                    {concept.details}
                  </p>
                </div>

                <div className="pt-2 mt-2 border-t border-slate-800">
                  <span className={`text-[9px] font-mono font-bold px-2 py-0.5 rounded-full border ${concept.badgeColor} block truncate text-center`}>
                    {concept.tag}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Java Architecture View & Component Diagram */}
      <div className="p-4 sm:p-5 rounded-2xl bg-slate-950/70 border border-cyan-500/25 shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <h3 className="text-sm font-extrabold text-white flex items-center gap-2">
              <Layers className="w-4 h-4 text-cyan-400" />
              Java Architecture View & Component Diagram
            </h3>
            <span className="text-[11px] text-slate-400">
              Clean visual schema demonstrating model association, collection containers, threading, and exception flow.
            </span>
          </div>

          <button
            onClick={() => setShowCodeViewer(!showCodeViewer)}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 hover:text-white border border-cyan-500/40 text-xs font-bold transition shadow-sm cursor-pointer self-start sm:self-auto"
          >
            <FileCode className="w-3.5 h-3.5 text-cyan-400" />
            <span>{showCodeViewer ? 'Hide Java Source Inspector' : 'Inspect .java Source Code'}</span>
            {showCodeViewer ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
          </button>
        </div>

        {/* Compact Glass Architecture Diagram Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 pt-1">
          {/* Column 1: Doctor Inheritance Hierarchy */}
          <div className="p-4 rounded-xl bg-[rgba(6,18,45,0.65)] border border-purple-500/20 shadow-md flex flex-col items-center text-center">
            <span className="text-[10px] font-mono uppercase tracking-wider text-purple-300 font-bold mb-3 px-2 py-0.5 rounded bg-purple-950/60 border border-purple-800">
              Doctor Inheritance Hierarchy
            </span>

            <div className="w-full space-y-2 text-xs font-mono font-bold">
              <div className="p-2.5 rounded-lg bg-slate-900 border border-purple-500/50 text-purple-200 shadow-sm">
                Doctor (Parent Superclass)
                <span className="block text-[9px] text-slate-400 font-normal">doctorId, name, specialization, fee</span>
              </div>
              <ArrowDown className="w-4 h-4 text-purple-400 mx-auto" />

              <div className="grid grid-cols-2 gap-1.5 text-[10px]">
                <div className="p-1.5 rounded-md bg-purple-950/30 border border-purple-500/30 text-purple-300">
                  Cardiologist
                </div>
                <div className="p-1.5 rounded-md bg-purple-950/30 border border-purple-500/30 text-purple-300">
                  Dentist
                </div>
                <div className="p-1.5 rounded-md bg-purple-950/30 border border-purple-500/30 text-purple-300">
                  Neurologist
                </div>
                <div className="p-1.5 rounded-md bg-purple-950/30 border border-purple-500/30 text-purple-300">
                  OrthopedicDoctor
                </div>
              </div>
              <div className="text-[9px] text-slate-400 font-normal italic pt-1">
                Overrides consultationDetails() via dynamic method dispatch
              </div>
            </div>
          </div>

          {/* Column 2: HospitalService ArrayList Collections */}
          <div className="p-4 rounded-xl bg-[rgba(6,18,45,0.65)] border border-emerald-500/20 shadow-md flex flex-col items-center text-center">
            <span className="text-[10px] font-mono uppercase tracking-wider text-emerald-300 font-bold mb-3 px-2 py-0.5 rounded bg-emerald-950/60 border border-emerald-800">
              Collections & Threading
            </span>

            <div className="w-full space-y-2 text-xs font-mono font-bold">
              <div className="p-2.5 rounded-lg bg-slate-900 border border-emerald-500/50 text-emerald-200 shadow-sm">
                HospitalService (Synchronized)
                <span className="block text-[9px] text-slate-400 font-normal">Thread-Safe Collection Manager</span>
              </div>

              <ArrowDown className="w-4 h-4 text-emerald-400 mx-auto" />

              <div className="space-y-1.5 text-[11px]">
                <div className="p-1.5 rounded-md bg-emerald-950/30 border border-emerald-500/40 text-emerald-200">
                  ArrayList&lt;Patient&gt; &bull; ArrayList&lt;Doctor&gt;
                </div>
                <div className="p-1.5 rounded-md bg-emerald-950/30 border border-emerald-500/40 text-emerald-200">
                  ArrayList&lt;Appointment&gt;
                </div>
                <div className="p-1.5 rounded-md bg-teal-950/40 border border-teal-500/40 text-teal-200 text-[10px]">
                  Thread: HospitalMonitor (Runnable)
                </div>
              </div>
              <div className="text-[9px] text-slate-400 font-normal italic pt-1">
                Managed via synchronized add, remove, search, and export
              </div>
            </div>
          </div>

          {/* Column 3: Exception Handling Separate Flow */}
          <div className="p-4 rounded-xl bg-[rgba(6,18,45,0.65)] border border-rose-500/20 shadow-md flex flex-col items-center text-center">
            <span className="text-[10px] font-mono uppercase tracking-wider text-rose-300 font-bold mb-3 px-2 py-0.5 rounded bg-rose-950/60 border border-rose-800">
              Exception Handling Flow
            </span>

            <div className="w-full space-y-2 text-xs font-mono font-bold">
              <div className="p-2.5 rounded-lg bg-slate-900 border border-indigo-500/40 text-white shadow-sm">
                Appointment Booking
                <span className="block text-[9px] text-slate-400 font-normal">Hospital Scheduling Operation</span>
              </div>

              <ArrowDown className="w-4 h-4 text-rose-400 mx-auto" />

              <div className="p-2 rounded-lg bg-rose-950/40 border border-rose-500/60 text-rose-200 shadow-sm">
                AppointmentException
                <span className="block text-[9px] text-rose-300/80 font-normal">
                  Slot unavailable, null payload, unregistered patient
                </span>
              </div>

              <ArrowDown className="w-4 h-4 text-rose-400 mx-auto" />

              <div className="p-2 rounded-lg bg-slate-900 border border-rose-400/40 text-amber-200 shadow-sm">
                try / catch
                <span className="block text-[9px] text-slate-300 font-normal">
                  Safe recovery, graceful validation reporting
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Interactive Source Code Viewer Accordion */}
        {showCodeViewer && (
          <div className="mt-4 pt-4 border-t border-cyan-500/20 space-y-3 animate-in fade-in">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0">
                {Object.keys(javaSourceSnippets).map((filename) => (
                  <button
                    key={filename}
                    onClick={() => setSelectedFile(filename)}
                    className={`px-2.5 py-1 rounded-lg font-mono text-xs font-bold transition whitespace-nowrap cursor-pointer ${
                      selectedFile === filename
                        ? 'bg-cyan-500/25 text-cyan-200 border border-cyan-400/50 shadow-sm'
                        : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
                    }`}
                  >
                    {filename}
                  </button>
                ))}
              </div>

              <div className="flex items-center gap-2">
                <span className="text-[11px] text-slate-400 font-mono hidden sm:inline">
                  {javaSourceSnippets[selectedFile].desc}
                </span>
                <button
                  onClick={() => copyToClipboard(javaSourceSnippets[selectedFile].code, true)}
                  className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-mono transition cursor-pointer"
                >
                  {copiedCode ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedCode ? 'Copied' : 'Copy Code'}</span>
                </button>
              </div>
            </div>

            <div className="relative rounded-xl bg-slate-950 border border-cyan-500/25 p-3.5 overflow-x-auto font-mono text-xs text-cyan-100 max-h-72 overflow-y-auto leading-relaxed shadow-inner">
              <pre className="whitespace-pre">
                <code>{javaSourceSnippets[selectedFile].code}</code>
              </pre>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
