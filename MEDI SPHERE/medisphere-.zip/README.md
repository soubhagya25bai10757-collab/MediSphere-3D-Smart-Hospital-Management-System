# MediSphere 3D — Smart Hospital Management System

MediSphere 3D is a next-generation hospital management system featuring a 3D clinical interface, real-time hospital telemetry, and a **genuine, compilable Java SE backend module** demonstrating 10 core object-oriented programming concepts.

---

## ☕ Java Implementation

MediSphere 3D integrates a standalone, fully compilable **Java SE Backend and Clinical Core Module** located in the [`java/`](./java) directory. It demonstrates 10 syllabus concepts from *Programming in Java*:

| # | Concept | Implementation Details | Key Files |
|---|---|---|---|
| **1** | **Java Classes & Objects** | Real hospital entities (`Patient`, `Doctor`, `Appointment`, `EmergencyCase`) with constructors, state fields, and domain methods. | `java/src/model/Patient.java`<br>`java/src/model/Doctor.java`<br>`java/src/model/Appointment.java` |
| **2** | **Encapsulation** | Strict private fields with defensive validation in public getters and setters (e.g., negative ages or fees rejected, empty names prevented). | `java/src/model/Patient.java`<br>`java/src/model/Doctor.java` |
| **3** | **Inheritance** | Base superclass `Doctor` is extended by specialist classes (`Cardiologist`, `Dentist`, `Neurologist`, `OrthopedicDoctor`) via `extends Doctor` and `super(...)` constructor chaining. | `java/src/model/Doctor.java`<br>`java/src/model/Cardiologist.java`<br>`java/src/model/Dentist.java`<br>`java/src/model/Neurologist.java`<br>`java/src/model/OrthopedicDoctor.java` |
| **4** | **Polymorphism** | Superclass `consultationDetails()` is overridden across specialist doctor classes and invoked dynamically at runtime via `Doctor` references. | `java/src/model/Doctor.java`<br>Specialist subclasses<br>`java/src/service/HospitalService.java` |
| **5** | **Collections Framework / ArrayList** | In-memory registries using `ArrayList<Patient>`, `ArrayList<Doctor>`, and `ArrayList<Appointment>` with `add`, `remove`, `search`, and `display` operations. | `java/src/service/HospitalService.java` |
| **6** | **Exception Handling** | Custom checked `AppointmentException` enforces clinical rules with `try`, `catch`, `throw`, and `throws` (rejects double bookings, unregistered patients, unavailable doctors, null data). | `java/src/exception/AppointmentException.java`<br>`java/src/service/HospitalService.java` |
| **7** | **User-Defined Packages** | Organized cleanly into `model`, `service`, and `exception` packages with standard package declarations and imports. | `java/src/model/*`<br>`java/src/service/*`<br>`java/src/exception/*` |
| **8** | **Multithreading** | Background daemon worker task `HospitalMonitor` implementing `Runnable` running in a dedicated `Thread` performing scheduled census and queue audits. | `java/src/service/HospitalService.java`<br>`java/src/Main.java` |
| **9** | **Java Synchronization** | Synchronized methods and critical synchronized blocks in `HospitalService` guaranteeing thread-safe access when background threads access shared hospital collections. | `java/src/service/HospitalService.java` |
| **10** | **Java I/O Streams** | File audit reports written to disk using `FileWriter` & `BufferedWriter` and read back using `FileReader` & `BufferedReader`. | `java/src/service/HospitalService.java`<br>`java/src/Main.java` |

---

### 🌐 Java SE HTTP REST Backend

`Main.java` starts an embedded Java HTTP server exposing standard REST endpoints:

- `GET  /api/health` — Checks server health, active threads, and syllabus concepts
- `GET  /api/patients` — Returns registered patients from `ArrayList<Patient>`
- `POST /api/patients` — Registers a new patient with validation
- `GET  /api/doctors` — Returns medical specialists with polymorphic consultation descriptions
- `GET  /api/appointments` — Returns scheduled appointments from `ArrayList<Appointment>`
- `POST /api/appointments` — Books appointment with `AppointmentException` validation
- `GET  /api/report` — Demonstrates Java I/O Streams by generating and reading an audit log
- `GET  /api/threads` — Telemetry of the background `HospitalMonitor` worker thread

---

### 🛠️ Compiling & Running the Java Module

#### Method 1: From the `java/` directory
```bash
cd java
mkdir -p bin
javac -d bin src/model/*.java src/exception/*.java src/service/*.java src/Main.java
java -cp bin Main
```

#### Method 2: From the project root
```bash
mkdir -p java/bin
javac -d java/bin java/src/model/*.java java/src/exception/*.java java/src/service/*.java java/src/Main.java
java -cp java/bin Main
```

---

## 🖥️ Web Frontend Architecture

The web application is built with modern React 19, TypeScript, Tailwind CSS, and Three.js for interactive 3D visualizations:
- **Interactive 3D Hospital View**: Digital twin hospital navigation and patient room status.
- **Java Implementation Panel**: Built-in interactive code viewer, architecture breakdown, concept guides, and live HTTP endpoint testing.
- **Thread & Synchronization Monitor**: Live visualization of Java threads, locks, and concurrency.
- **Clinical Modules**: Patient management, doctor management, appointments, ICU telemetry, pharmacy, and laboratory.
