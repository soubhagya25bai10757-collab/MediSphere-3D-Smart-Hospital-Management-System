# MediSphere 3D - Java SE Core Module & REST Backend

> **Programming in Java — 10 Core Syllabus Concepts Implementation**  
> MediSphere 3D Smart Hospital Management System  
> Vit Bhopal University Syllabus Alignment

---

## 📋 Overview

This module provides a **genuine, compilable Java SE backend and OOP core module** for the MediSphere 3D Smart Hospital Management System. It implements **10 fundamental concepts of Object-Oriented Programming and Java SE** without requiring heavyweight external frameworks or databases, while embedding an in-memory HTTP server exposing real REST endpoints.

---

## ☕ Java Technologies Used

| Technology / API | Purpose in MediSphere 3D |
|---|---|
| **Java SE (JDK 11 / 17 / 21 compatible)** | Core language runtime — no external frameworks or build tools required. |
| **`java.util.ArrayList` / Collections Framework** | Dynamic in-memory registries for patients, doctors, appointments, and emergency cases. |
| **`java.lang.Thread` / `Runnable`** | Background `HospitalMonitor` daemon worker for live hospital telemetry. |
| **`synchronized` methods & blocks** | Thread-safe access to shared collections between the HTTP request thread(s) and the monitor thread. |
| **Custom checked Exceptions (`extends Exception`)** | `AppointmentException` enforces clinical booking rules with structured error codes. |
| **`java.io.FileWriter` / `BufferedWriter`** | Writes the clinical appointment audit report to disk. |
| **`java.io.FileReader` / `BufferedReader`** | Reads the audit report back from disk. |
| **`com.sun.net.httpserver.HttpServer`** (JDK built-in) | Lightweight embedded HTTP server exposing REST endpoints — no Spring/Tomcat dependency. |
| **`java.util.regex`** | Minimal JSON field extraction for incoming POST request bodies. |
| **User-defined Packages (`model`, `service`, `exception`)** | Standard Java package organization for separation of concerns. |

---

## 🏛️ 10 Core Java Concepts Implemented

| # | Java Concept | MediSphere 3D Implementation | Key Source Files |
|---|---|---|---|
| **1** | **Classes & Objects** | Real hospital domain entities (`Patient`, `Doctor`, `Appointment`, `EmergencyCase`) with constructors, state fields, and business behavior. | `src/model/Patient.java`<br>`src/model/Doctor.java`<br>`src/model/Appointment.java` |
| **2** | **Encapsulation** | Private member variables protected by public getters and setters featuring strict defensive data validation (prevents negative ages, fees, empty names, or illegal states). | `src/model/Patient.java`<br>`src/model/Doctor.java`<br>`src/model/Appointment.java` |
| **3** | **Inheritance** | Superclass `Doctor` is extended by specialist medical subclasses (`Cardiologist`, `Dentist`, `Neurologist`, `OrthopedicDoctor`) leveraging `extends Doctor` and constructor chaining via `super(...)`. | `src/model/Doctor.java`<br>`src/model/Cardiologist.java`<br>`src/model/Dentist.java`<br>`src/model/Neurologist.java`<br>`src/model/OrthopedicDoctor.java` |
| **4** | **Polymorphism** | Superclass method `consultationDetails()` is dynamically overridden by every specialist subclass. At runtime, calls to `doctorRef.consultationDetails()` resolve via dynamic method dispatch. | `src/model/Doctor.java`<br>Specialist subclasses<br>`src/service/HospitalService.java` |
| **5** | **Collections Framework / ArrayList** | Dynamic in-memory registries using `ArrayList<Patient>`, `ArrayList<Doctor>`, and `ArrayList<Appointment>` implementing full `add`, `remove`, `search`, and `display` operations. | `src/service/HospitalService.java` |
| **6** | **Exception Handling** | Custom checked exception `AppointmentException` enforces clinical rules with `try`, `catch`, `throw`, and `throws` (rejects slot conflicts, unregistered patients, unassigned doctors, null payloads). | `src/exception/AppointmentException.java`<br>`src/service/HospitalService.java` |
| **7** | **User-defined Packages** | Structured across standard Java packages: `model` (entities), `service` (business logic & collections), and `exception` (checked exceptions). | `src/model/*`<br>`src/service/*`<br>`src/exception/*` |
| **8** | **Multithreading** | Dedicated background daemon task `HospitalMonitor` implementing `Runnable` running inside a dedicated `Thread` performing periodic hospital telemetry and queue integrity audits. | `src/service/HospitalService.java`<br>`src/Main.java` |
| **9** | **Java Synchronization** | Synchronized methods and critical synchronized blocks (`synchronized (this)`) in `HospitalService` ensuring thread-safe access when background threads access shared hospital collections. | `src/service/HospitalService.java` |
| **10** | **Java I/O Streams** | File audit reports written using `FileWriter` & `BufferedWriter` and parsed back into memory using `FileReader` & `BufferedReader`. | `src/service/HospitalService.java`<br>`src/Main.java` |

---

## 📂 Package & File Structure

```
java/
├── README.md                              # Comprehensive module documentation
└── src/
    ├── Main.java                          # Verification test runner & embedded HTTP REST backend
    ├── model/
    │   ├── Patient.java                   # Patient entity with defensive validation & JSON serialization
    │   ├── Doctor.java                    # Base doctor superclass with polymorphism hook
    │   ├── Cardiologist.java              # Subclass extending Doctor (Inheritance)
    │   ├── Dentist.java                   # Subclass extending Doctor (Inheritance)
    │   ├── Neurologist.java               # Subclass extending Doctor (Inheritance)
    │   ├── OrthopedicDoctor.java          # Subclass extending Doctor (Inheritance)
    │   ├── Appointment.java               # Composite appointment linking Patient & Doctor
    │   └── EmergencyCase.java             # Acute triage emergency case entity
    │
    ├── exception/
    │   └── AppointmentException.java      # Custom checked exception (Exception Handling)
    │
    └── service/
        └── HospitalService.java           # Central coordinator with ArrayLists, Multithreading & Synchronization
```

---

## 🌐 Java SE HTTP REST Endpoints

The embedded Java HTTP Server (`com.sun.net.httpserver.HttpServer`) runs on `http://localhost:8080` (or `8085` if 8080 is reserved) and provides the following REST API:

| Method | Endpoint | Description | Sample Output |
|---|---|---|---|
| `GET` | `/api/health` | Healthcheck returning JVM status, thread status, and demonstrated syllabus concepts | `{"status":"UP","javaVersion":"17.0.20.1",...}` |
| `GET` | `/api/patients` | Retrieves all registered patients from `ArrayList<Patient>` | `[{"patientId":101,"name":"Eleanor Vance",...}]` |
| `POST` | `/api/patients` | Registers a new patient with encapsulation validation | Returns HTTP 201 Created with JSON |
| `GET` | `/api/doctors` | Retrieves specialist doctors with polymorphic details | `[{"doctorId":201,"specialization":"Cardiology",...}]` |
| `GET` | `/api/appointments` | Retrieves all scheduled appointments | `[{"appointmentId":501,...}]` |
| `POST` | `/api/appointments` | Books appointment with `AppointmentException` validation | Returns HTTP 201 or 400 with exception code |
| `GET` | `/api/report` | Demonstrates Java I/O streams (`BufferedWriter`/`BufferedReader`) | Returns exported text audit log |
| `GET` | `/api/threads` | Live status of the `HospitalMonitor` background thread | `{"threadName":"MediSphere-HospitalMonitor-Worker","alive":true,...}` |

---

## 🚀 How to Compile and Run

### Prerequisites
- JDK 17 (or JDK 11 / 21) installed and available in `PATH` (`javac -version` and `java -version`)

### Compilation
From the `java/` directory:
```bash
mkdir -p bin
javac -d bin src/model/*.java src/exception/*.java src/service/*.java src/Main.java
```

Or from the project root:
```bash
mkdir -p java/bin
javac -d java/bin java/src/model/*.java java/src/exception/*.java java/src/service/*.java java/src/Main.java
```

### Execution
From the `java/` directory:
```bash
java -cp bin Main
```

Or from the project root:
```bash
java -cp java/bin Main
```

---

## 🧪 Terminal Output Preview

Upon running `Main`, you will see:
1. Formatted verification sections confirming all 10 concepts.
2. The background monitor worker thread active.
3. The file write and read operations via `BufferedWriter` and `BufferedReader`.
4. The running server announcement with test endpoints:

```text
================================================================================
=== MEDISPHERE 3D SMART HOSPITAL MANAGEMENT SYSTEM ===
Programming in Java - 10 Core Syllabus Concepts Verification & SE Backend
================================================================================

--- [CONCEPT 1 & 2] Patient Objects Creation & Encapsulation Validation ---
  Created Patient: Eleanor Vance (Age: 34, Blood: A+)
  ...
--- [CONCEPT 3] Specialist Doctors (Inheritance: extends Doctor) ---
  Created Cardiologist (Dr. Aria Thorne)       [extends Doctor]
  ...
--- [CONCEPT 4] Runtime Polymorphism (consultationDetails() dynamic dispatch) ---
  [Cardiology Consultation] Dr. Aria Thorne conducts 12-lead ECG analysis...
  ...
--- [CONCEPT 5] Collections Framework (ArrayList Operations) ---
  [Registry] Patient registered successfully: Eleanor Vance (ID: 101)
  ...
--- [CONCEPT 1 & 6] Appointment Booking & Exception Handling ---
  ✓ CAUGHT EXPECTED AppointmentException [SLOT_UNAVAILABLE]: ...
  ✓ CAUGHT EXPECTED AppointmentException [PATIENT_UNREGISTERED]: ...
  ...
--- [CONCEPT 8 & 9] Multithreading & Java Synchronization ---
  [Multithreading] Started background thread: MediSphere-HospitalMonitor-Worker (Thread ID: 12)
  ...
--- [CONCEPT 10] Java I/O Streams (Report Generation & Reading) ---
  [Java I/O Streams] Appointment report written successfully using BufferedWriter to: logs/appointment_audit.log
  [Java I/O Streams] Appointment report read successfully using BufferedReader from: logs/appointment_audit.log
  ...
================================================================================
MediSphere Java Backend running on http://localhost:8080
================================================================================
Test endpoints:
  - http://localhost:8080/api/health
  - http://localhost:8080/api/patients
  - http://localhost:8080/api/doctors
  - http://localhost:8080/api/appointments
  - http://localhost:8080/api/report
  - http://localhost:8080/api/threads
================================================================================
```
