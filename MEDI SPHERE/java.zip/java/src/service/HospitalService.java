package service;

import model.Patient;
import model.Doctor;
import model.Appointment;
import model.EmergencyCase;
import exception.AppointmentException;

import java.io.File;
import java.io.FileWriter;
import java.io.FileReader;
import java.io.BufferedWriter;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.FileNotFoundException;
import java.util.ArrayList;

/**
 * HospitalService Implementation
 * Demonstrates:
 * Concept 1. Java Classes and Objects: Central service manager coordinating hospital entities
 * Concept 2. Encapsulation: Private collection state with public synchronized accessor workflows
 * Concept 4. Polymorphism: Polymorphic execution of consultationDetails() across specialist doctors
 * Concept 5. Java Collections Framework / List / ArrayList: Managing dynamic patient, doctor, and appointment registries
 *            with add, remove, search, and display operations.
 * Concept 6. Exception Handling: Custom checked AppointmentException thrown for invalid appointment operations
 * Concept 7. User-defined Packages: Resides in package 'service' and imports from 'model' and 'exception'
 * Concept 8. Multithreading: HospitalMonitor background task implementing Runnable running in a dedicated Thread
 * Concept 9. Java Synchronization: Synchronized methods and synchronized blocks guarding shared collections across threads
 * Concept 10. Java I/O Streams: Report export via FileWriter/BufferedWriter and reading via FileReader/BufferedReader
 */
public class HospitalService {
    private String hospitalName;
    private final ArrayList<Patient> patients;
    private final ArrayList<Doctor> doctors;
    private final ArrayList<Appointment> appointments;
    private final ArrayList<EmergencyCase> emergencyCases;

    // Multithreading & Synchronization references
    private Thread monitorThread;
    private HospitalMonitor monitorRunnable;

    // Constructor initializing collections
    public HospitalService(String hospitalName) {
        this.hospitalName = (hospitalName != null) ? hospitalName : "MediSphere 3D Smart Hospital";
        this.patients = new ArrayList<>();
        this.doctors = new ArrayList<>();
        this.appointments = new ArrayList<>();
        this.emergencyCases = new ArrayList<>();
    }

    public synchronized String getHospitalName() {
        return hospitalName;
    }

    // ==========================================================
    // 5. COLLECTIONS / ARRAYLIST: PATIENT OPERATIONS (add, remove, search, display)
    // Synchronized to guarantee thread safety across concurrent requests
    // ==========================================================

    /**
     * Adds a new patient into the hospital registry.
     */
    public synchronized void addPatient(Patient patient) {
        if (patient == null) {
            throw new IllegalArgumentException("Cannot register null patient.");
        }
        for (Patient p : patients) {
            if (p.getPatientId() == patient.getPatientId()) {
                throw new IllegalArgumentException("Patient with ID " + patient.getPatientId() + " already exists.");
            }
        }
        patients.add(patient);
        System.out.println("  [Registry] Patient registered successfully: " + patient.getName() + " (ID: " + patient.getPatientId() + ")");
    }

    /**
     * Removes a patient by ID from the ArrayList collection.
     */
    public synchronized boolean removePatient(int patientId) {
        for (int i = 0; i < patients.size(); i++) {
            if (patients.get(i).getPatientId() == patientId) {
                Patient removed = patients.remove(i);
                System.out.println("  [Registry] Patient removed from census: " + removed.getName() + " (ID: " + patientId + ")");
                return true;
            }
        }
        return false;
    }

    /**
     * Searches patient by ID using iteration over ArrayList.
     */
    public synchronized Patient searchPatient(int patientId) {
        for (int i = 0; i < patients.size(); i++) {
            Patient p = patients.get(i);
            if (p.getPatientId() == patientId) {
                return p;
            }
        }
        return null;
    }

    /**
     * Searches patient by Name (case-insensitive substring match).
     */
    public synchronized Patient searchPatientByName(String name) {
        if (name == null) return null;
        for (Patient p : patients) {
            if (p.getName().equalsIgnoreCase(name.trim())) {
                return p;
            }
        }
        return null;
    }

    /**
     * Displays all registered patients using an enhanced for-loop.
     */
    public synchronized void displayPatients() {
        System.out.println("\n=== PATIENT DIRECTORY (" + patients.size() + " Records) ===");
        if (patients.isEmpty()) {
            System.out.println("  No patients currently registered.");
            return;
        }
        for (int i = 0; i < patients.size(); i++) {
            System.out.println("  " + (i + 1) + ". " + patients.get(i).toString());
        }
    }

    public synchronized void showPatients() {
        displayPatients();
    }

    // ==========================================================
    // 5. COLLECTIONS / ARRAYLIST: DOCTOR OPERATIONS (add, remove, search, display)
    // ==========================================================

    /**
     * Adds a doctor into the medical specialist directory.
     */
    public synchronized void addDoctor(Doctor doctor) {
        if (doctor == null) {
            throw new IllegalArgumentException("Cannot register null doctor.");
        }
        for (Doctor d : doctors) {
            if (d.getDoctorId() == doctor.getDoctorId()) {
                throw new IllegalArgumentException("Doctor with ID " + doctor.getDoctorId() + " already registered.");
            }
        }
        doctors.add(doctor);
        System.out.println("  [Staffing] Doctor enlisted: Dr. " + doctor.getName() + " (" + doctor.getSpecialization() + ")");
    }

    /**
     * Removes a doctor by ID from the ArrayList collection.
     */
    public synchronized boolean removeDoctor(int doctorId) {
        for (int i = 0; i < doctors.size(); i++) {
            if (doctors.get(i).getDoctorId() == doctorId) {
                Doctor removed = doctors.remove(i);
                System.out.println("  [Staffing] Doctor removed from roster: Dr. " + removed.getName() + " (ID: " + doctorId + ")");
                return true;
            }
        }
        return false;
    }

    /**
     * Searches doctor by ID using iteration over ArrayList.
     */
    public synchronized Doctor searchDoctor(int doctorId) {
        for (Doctor d : doctors) {
            if (d.getDoctorId() == doctorId) {
                return d;
            }
        }
        return null;
    }

    /**
     * Searches doctor by Name.
     */
    public synchronized Doctor searchDoctorByName(String name) {
        if (name == null) return null;
        for (Doctor d : doctors) {
            if (d.getName().equalsIgnoreCase(name.trim())) {
                return d;
            }
        }
        return null;
    }

    /**
     * Displays all registered doctors using an enhanced for-loop.
     */
    public synchronized void displayDoctors() {
        System.out.println("\n=== DOCTOR DIRECTORY (" + doctors.size() + " Specialists) ===");
        if (doctors.isEmpty()) {
            System.out.println("  No doctors currently on roster.");
            return;
        }
        for (int i = 0; i < doctors.size(); i++) {
            System.out.println("  " + (i + 1) + ". " + doctors.get(i).toString());
        }
    }

    public synchronized void showDoctors() {
        displayDoctors();
    }

    // ==========================================================
    // 6. EXCEPTION HANDLING: APPOINTMENT BOOKING WITH VALIDATION
    // Checked Exception: throws AppointmentException
    // ==========================================================

    /**
     * Books an appointment with rigorous clinical validation.
     * Demonstrates checked exception throwing: throws AppointmentException
     */
    public synchronized void bookAppointment(Appointment appointment) throws AppointmentException {
        // Validation 1: Null check / invalid appointment data
        if (appointment == null) {
            throw new AppointmentException("APPT_NULL", "Appointment payload cannot be null.");
        }

        // Validation 2: Patient validation
        if (appointment.getPatient() == null) {
            throw new AppointmentException("PATIENT_MISSING", "Appointment rejected: Patient information cannot be null.");
        }

        Patient registeredPatient = searchPatient(appointment.getPatient().getPatientId());
        if (registeredPatient == null) {
            throw new AppointmentException("PATIENT_UNREGISTERED",
                "Patient ID " + appointment.getPatient().getPatientId() + " is not registered in the MediSphere EHR census.");
        }

        // Validation 3: Doctor validation & availability
        if (appointment.getDoctor() == null) {
            throw new AppointmentException("DOCTOR_UNASSIGNED", "Appointment rejected: Specialist doctor must be assigned.");
        }

        Doctor assignedDoc = searchDoctor(appointment.getDoctor().getDoctorId());
        if (assignedDoc == null) {
            throw new AppointmentException("DOCTOR_UNAVAILABLE",
                "Doctor ID " + appointment.getDoctor().getDoctorId() + " is not currently active on the hospital medical roster.");
        }

        // Validation 4: Date & time format validation (invalid appointment data)
        if (appointment.getDate() == null || appointment.getDate().trim().isEmpty()) {
            throw new AppointmentException("INVALID_DATE", "Appointment scheduling requires a valid non-empty calendar date.");
        }
        if (appointment.getTime() == null || appointment.getTime().trim().isEmpty()) {
            throw new AppointmentException("INVALID_TIME", "Appointment scheduling requires a valid time slot.");
        }

        // Validation 5: Slot conflict detection across ArrayList<Appointment> (unavailable appointment slot)
        for (Appointment existing : appointments) {
            boolean sameDoctor = existing.getDoctor().getDoctorId() == appointment.getDoctor().getDoctorId();
            boolean sameDate = existing.getDate().equalsIgnoreCase(appointment.getDate());
            boolean sameTime = existing.getTime().equalsIgnoreCase(appointment.getTime());

            if (sameDoctor && sameDate && sameTime && !"CANCELLED".equalsIgnoreCase(existing.getStatus())) {
                throw new AppointmentException("SLOT_UNAVAILABLE",
                    String.format("Consultation slot conflict: Dr. %s is already scheduled on %s at %s (#%d).",
                        existing.getDoctor().getName(), existing.getDate(), existing.getTime(), existing.getAppointmentId())
                );
            }
        }

        // All clinical checks satisfied: record into ArrayList
        appointments.add(appointment);
        System.out.println("  [Scheduling] Appointment #" + appointment.getAppointmentId() + " successfully booked for "
                + appointment.getPatient().getName() + " with Dr. " + appointment.getDoctor().getName()
                + " on " + appointment.getDate() + " at " + appointment.getTime());
    }

    /**
     * Cancels an appointment by ID from the ArrayList collection.
     */
    public synchronized boolean cancelAppointment(int appointmentId) {
        for (Appointment a : appointments) {
            if (a.getAppointmentId() == appointmentId) {
                a.setStatus("CANCELLED");
                System.out.println("  [Scheduling] Appointment #" + appointmentId + " marked as CANCELLED.");
                return true;
            }
        }
        return false;
    }

    /**
     * Searches appointment by ID using iteration over ArrayList.
     */
    public synchronized Appointment searchAppointment(int appointmentId) {
        for (Appointment a : appointments) {
            if (a.getAppointmentId() == appointmentId) {
                return a;
            }
        }
        return null;
    }

    /**
     * Displays all scheduled appointments.
     */
    public synchronized void displayAppointments() {
        System.out.println("\n=== APPOINTMENT DIRECTORY (" + appointments.size() + " Bookings) ===");
        if (appointments.isEmpty()) {
            System.out.println("  No appointments currently booked.");
            return;
        }
        for (int i = 0; i < appointments.size(); i++) {
            System.out.println("  " + (i + 1) + ". " + appointments.get(i).toString());
        }
    }

    public synchronized void showAppointments() {
        displayAppointments();
    }

    // ==========================================================
    // 4. POLYMORPHISM DEMONSTRATION
    // ==========================================================

    /**
     * Demonstrates runtime polymorphism (dynamic method dispatch).
     * Iterates through Doctor references and invokes overridden consultationDetails().
     */
    public synchronized void conductAllConsultations() {
        System.out.println("\n--- [Runtime Polymorphism in Action: Dynamic Consultation Dispatch] ---");
        for (Doctor doc : doctors) {
            System.out.println("  * " + doc.consultationDetails());
        }
    }

    // ==========================================================
    // 8 & 9. MULTITHREADING & SYNCHRONIZATION: HOSPITAL MONITOR
    // ==========================================================

    /**
     * Background task implementing Runnable.
     * Continuously monitors hospital census and queue integrity.
     * Accesses shared collections inside a synchronized block for thread safety.
     */
    public static class HospitalMonitor implements Runnable {
        private final HospitalService service;
        private volatile boolean running = true;
        private int cycleCount = 0;
        private String lastHeartbeat = "Initialized";

        public HospitalMonitor(HospitalService service) {
            this.service = service;
        }

        @Override
        public void run() {
            System.out.println("  [Thread: " + Thread.currentThread().getName() + "] HospitalMonitor daemon worker thread active.");
            while (running) {
                try {
                    Thread.sleep(10000); // 10-second polling interval
                    // Concept 9: Java Synchronization block guarding shared hospital service collections
                    synchronized (service) {
                        cycleCount++;
                        int pCount = service.getPatients().size();
                        int dCount = service.getDoctors().size();
                        int aCount = service.getAppointments().size();
                        lastHeartbeat = String.format("Telemetry Cycle #%d | Census: %d Patients, %d Doctors, %d Appointments",
                                cycleCount, pCount, dCount, aCount);
                        System.out.println("  [Thread: " + Thread.currentThread().getName() + " | SYNCHRONIZED] " + lastHeartbeat);
                    }
                } catch (InterruptedException e) {
                    System.out.println("  [Thread: " + Thread.currentThread().getName() + "] HospitalMonitor worker interrupted.");
                    Thread.currentThread().interrupt();
                    break;
                }
            }
        }

        public void stop() {
            this.running = false;
        }

        public int getCycleCount() {
            return cycleCount;
        }

        public String getLastHeartbeat() {
            return lastHeartbeat;
        }
    }

    /**
     * Concept 8: Multithreading - Starts the HospitalMonitor background thread.
     */
    public synchronized void startHospitalMonitor() {
        if (monitorThread == null || !monitorThread.isAlive()) {
            monitorRunnable = new HospitalMonitor(this);
            monitorThread = new Thread(monitorRunnable, "MediSphere-HospitalMonitor-Worker");
            monitorThread.setDaemon(true); // Allows JVM to exit cleanly when main finishes
            monitorThread.start();
            System.out.println("  [Multithreading] Started background thread: " + monitorThread.getName()
                    + " (Thread ID: " + monitorThread.getId() + ")");
        }
    }

    public synchronized String getMonitorHeartbeat() {
        return (monitorRunnable != null) ? monitorRunnable.getLastHeartbeat() : "Monitor Not Started";
    }

    public synchronized int getMonitorCycleCount() {
        return (monitorRunnable != null) ? monitorRunnable.getCycleCount() : 0;
    }

    public synchronized boolean isMonitorRunning() {
        return (monitorThread != null && monitorThread.isAlive());
    }

    // ==========================================================
    // 10. JAVA I/O STREAMS: FILE WRITING & READING
    // Demonstrates FileWriter/BufferedWriter and FileReader/BufferedReader
    // ==========================================================

    /**
     * Exports appointment information to a text report using FileWriter and BufferedWriter.
     */
    public synchronized void exportAppointmentReport(String filePath) throws IOException {
        File file = new File(filePath);
        if (file.getParentFile() != null) {
            file.getParentFile().mkdirs();
        }

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
            writer.write("================================================================================");
            writer.newLine();
            writer.write("MEDISPHERE 3D SMART HOSPITAL - CLINICAL APPOINTMENT AUDIT REPORT");
            writer.newLine();
            writer.write("Hospital: " + hospitalName);
            writer.newLine();
            writer.write("Generated Timestamp: " + new java.util.Date());
            writer.newLine();
            writer.write("Total Registered Appointments: " + appointments.size());
            writer.newLine();
            writer.write("================================================================================");
            writer.newLine();
            writer.newLine();

            for (Appointment appt : appointments) {
                String line = String.format("Appt ID: %-5d | Date: %-10s | Time: %-8s | Patient: %-18s (ID:%d) | Doctor: Dr. %-15s (%-12s) | Status: %-9s | Type: %s",
                        appt.getAppointmentId(),
                        appt.getDate(),
                        appt.getTime(),
                        (appt.getPatient() != null) ? appt.getPatient().getName() : "N/A",
                        (appt.getPatient() != null) ? appt.getPatient().getPatientId() : 0,
                        (appt.getDoctor() != null) ? appt.getDoctor().getName() : "N/A",
                        (appt.getDoctor() != null) ? appt.getDoctor().getSpecialization() : "N/A",
                        appt.getStatus(),
                        appt.getConsultationType()
                );
                writer.write(line);
                writer.newLine();
            }

            writer.write("================================================================================");
            writer.newLine();
            writer.write("END OF AUDIT STREAM - Written using java.io.BufferedWriter & FileWriter");
            writer.newLine();
            writer.flush();
        }
        System.out.println("  [Java I/O Streams] Appointment report written successfully using BufferedWriter to: " + filePath);
    }

    /**
     * Reads the appointment report back from disk using FileReader and BufferedReader.
     */
    public synchronized String readAppointmentReport(String filePath) throws IOException {
        File file = new File(filePath);
        if (!file.exists()) {
            throw new FileNotFoundException("Audit log file does not exist at: " + filePath);
        }

        StringBuilder content = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                content.append(line).append("\n");
            }
        }
        System.out.println("  [Java I/O Streams] Appointment report read successfully using BufferedReader from: " + filePath);
        return content.toString();
    }

    // ==========================================================
    // EMERGENCY CASE OPERATIONS
    // ==========================================================

    public synchronized void registerEmergencyCase(EmergencyCase emergencyCase) {
        if (emergencyCase == null) {
            throw new IllegalArgumentException("Emergency case cannot be null.");
        }
        emergencyCases.add(emergencyCase);
        System.out.println("  [Emergency Triage] Case #" + emergencyCase.getCaseId() + " triaged for "
                + emergencyCase.getPatient().getName() + " -> " + emergencyCase.getSeverityLevel());
    }

    public synchronized void showEmergencyCases() {
        System.out.println("\n--- [MediSphere 3D Emergency & Trauma Cases] (" + emergencyCases.size() + " cases) ---");
        for (EmergencyCase ec : emergencyCases) {
            System.out.println("  " + ec.toString());
        }
    }

    // Synchronized getters for collections
    public synchronized ArrayList<Patient> getPatients() {
        return new ArrayList<>(patients);
    }

    public synchronized ArrayList<Doctor> getDoctors() {
        return new ArrayList<>(doctors);
    }

    public synchronized ArrayList<Appointment> getAppointments() {
        return new ArrayList<>(appointments);
    }

    public synchronized ArrayList<EmergencyCase> getEmergencyCases() {
        return new ArrayList<>(emergencyCases);
    }
}
