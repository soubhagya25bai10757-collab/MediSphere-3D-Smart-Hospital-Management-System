package model;

/**
 * Doctor Superclass
 * Demonstrates:
 * Concept 1. Java Classes and Objects: Base entity representing medical specialists
 * Concept 2. Encapsulation with private fields and validated getters/setters
 * Concept 3. Inheritance: Base class extended by Cardiologist, Dentist, Neurologist, OrthopedicDoctor
 * Concept 4. Polymorphism: Provides default consultationDetails() overridden by specialist subclasses
 * Concept 7. User-defined Packages: Resides in package 'model'
 */
public class Doctor {
    private int doctorId;
    private String name;
    private String specialization;
    private int experience; // in years
    private double consultationFee;

    // Parameterized Constructor
    public Doctor(int doctorId, String name, String specialization, int experience, double consultationFee) {
        setDoctorId(doctorId);
        setName(name);
        setSpecialization(specialization);
        setExperience(experience);
        setConsultationFee(consultationFee);
    }

    // Encapsulation: Getters and Setters with Validation
    public int getDoctorId() {
        return doctorId;
    }

    public void setDoctorId(int doctorId) {
        if (doctorId <= 0) {
            throw new IllegalArgumentException("Doctor ID must be a positive integer. Given: " + doctorId);
        }
        this.doctorId = doctorId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        if (name == null || name.trim().isEmpty()) {
            throw new IllegalArgumentException("Doctor name cannot be null or empty.");
        }
        this.name = name.trim();
    }

    public String getSpecialization() {
        return specialization;
    }

    public void setSpecialization(String specialization) {
        if (specialization == null || specialization.trim().isEmpty()) {
            throw new IllegalArgumentException("Specialization cannot be null or empty.");
        }
        this.specialization = specialization.trim();
    }

    public int getExperience() {
        return experience;
    }

    public void setExperience(int experience) {
        if (experience < 0 || experience > 75) {
            throw new IllegalArgumentException("Doctor experience years cannot be negative or over 75.");
        }
        this.experience = experience;
    }

    public double getConsultationFee() {
        return consultationFee;
    }

    public void setConsultationFee(double consultationFee) {
        if (consultationFee < 0.0) {
            throw new IllegalArgumentException("Consultation fee cannot be negative. Given: " + consultationFee);
        }
        this.consultationFee = consultationFee;
    }

    /**
     * Polymorphic method to be overridden in specialist child classes.
     * Demonstrates runtime polymorphism when invoked via Doctor reference.
     */
    public String consultationDetails() {
        return String.format(
            "[General Medical Consultation] Dr. %s conducts standard vitals triage, differential diagnosis, and basic prescription regimen. Fee: $%.2f",
            name, consultationFee
        );
    }

    /**
     * Serializes Doctor to JSON for REST endpoints.
     */
    public String toJson() {
        return String.format("{\"doctorId\":%d,\"name\":\"%s\",\"specialization\":\"%s\",\"experience\":%d,\"consultationFee\":%.2f,\"consultationDetails\":\"%s\"}",
                doctorId, escapeJson(name), escapeJson(specialization), experience, consultationFee, escapeJson(consultationDetails()));
    }

    protected static String escapeJson(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n").replace("\r", "\\r");
    }

    @Override
    public String toString() {
        return String.format("Doctor [ID=%d, Name='%s', Specialization='%s', Experience=%d yrs, Fee=$%.2f]",
                doctorId, name, specialization, experience, consultationFee);
    }
}
