import model.Patient;
import model.Doctor;
import model.Cardiologist;
import model.Dentist;
import model.Neurologist;
import model.OrthopedicDoctor;
import model.Appointment;
import model.EmergencyCase;
import exception.AppointmentException;
import service.HospitalService;

import com.sun.net.httpserver.HttpServer;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpExchange;

import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

/**
 * Main Demonstration Driver & HTTP REST Backend for MediSphere 3D Smart Hospital
 * 
 * Demonstrates 10 Java Concepts from the Syllabus:
 * 1. Java Classes and Objects (Patient, Doctor, Appointment entities with constructors, fields, methods)
 * 2. Encapsulation (Private fields with validated getters and setters)
 * 3. Inheritance (Cardiologist, Dentist, Neurologist, OrthopedicDoctor extending Doctor)
 * 4. Polymorphism (Overridden consultationDetails() with dynamic runtime dispatch)
 * 5. Java Collections Framework / List / ArrayList (add, remove, search, display operations in HospitalService)
 * 6. Exception Handling (Custom checked AppointmentException with try-catch and throw/throws)
 * 7. User-defined Packages (Organized across 'model', 'service', and 'exception' packages)
 * 8. Multithreading (HospitalMonitor daemon task implementing Runnable running in background Thread)
 * 9. Java Synchronization (Synchronized methods and synchronized blocks guarding shared collections)
 * 10. Java I/O Streams (Appointment report export via FileWriter/BufferedWriter and read via FileReader/BufferedReader)
 *
 * Starts a lightweight Java SE HTTP Server on http://localhost:8080 (with fallback to 8085 if 8080 is reserved)
 * exposing REST endpoints:
 *   GET  /api/health
 *   GET  /api/patients
 *   POST /api/patients
 *   GET  /api/doctors
 *   GET  /api/appointments
 *   POST /api/appointments
 *   GET  /api/report
 *   GET  /api/threads
 */
public class Main {
    private static final int DEFAULT_PORT = 8080;

    public static void main(String[] args) {
        System.out.println("================================================================================");
        System.out.println("=== MEDISPHERE 3D SMART HOSPITAL MANAGEMENT SYSTEM ===");
        System.out.println("Programming in Java - 10 Core Syllabus Concepts Verification & SE Backend");
        System.out.println("================================================================================\n");

        HospitalService hospital = new HospitalService("MediSphere 3D Central Hospital Command");

        // ====================================================================
        // CONCEPT 1 & 2: CLASSES & OBJECTS, ENCAPSULATION
        // ====================================================================
        System.out.println("--- [CONCEPT 1 & 2] Patient Objects Creation & Encapsulation Validation ---");
        Patient p1 = new Patient(101, "Eleanor Vance", 34, "A+", "+1-555-0192");
        Patient p2 = new Patient(102, "Marcus Sterling", 58, "O-", "+1-555-0144");
        Patient p3 = new Patient(103, "Sophia Chen", 27, "B+", "+1-555-0188");
        Patient p4 = new Patient(104, "Devon Miller", 45, "AB+", "+1-555-0177");

        System.out.println("  Created Patient: " + p1.getName() + " (Age: " + p1.getAge() + ", Blood: " + p1.getBloodGroup() + ")");
        System.out.println("  Created Patient: " + p2.getName() + " (Age: " + p2.getAge() + ", Blood: " + p2.getBloodGroup() + ")");
        System.out.println("  Created Patient: " + p3.getName() + " (Age: " + p3.getAge() + ", Blood: " + p3.getBloodGroup() + ")");
        System.out.println("  Created Patient: " + p4.getName() + " (Age: " + p4.getAge() + ", Blood: " + p4.getBloodGroup() + ")");

        // Encapsulation defensive setter test
        System.out.println("\n  [Encapsulation Test] Defensive validation in setter (attempting negative age):");
        try {
            System.out.print("  Attempting p1.setAge(-15) -> ");
            p1.setAge(-15);
        } catch (IllegalArgumentException ex) {
            System.out.println("CAUGHT EXPECTED EXCEPTION: " + ex.getMessage());
        }

        // ====================================================================
        // CONCEPT 3: INHERITANCE (Specialized Doctors extending Doctor)
        // ====================================================================
        System.out.println("\n--- [CONCEPT 3] Specialist Doctors (Inheritance: extends Doctor) ---");
        Doctor doctor1 = new Cardiologist(201, "Aria Thorne", 14, 250.00, true, 310);
        Doctor doctor2 = new Dentist(202, "Julian Ross", 9, 140.00, "Maxillofacial Prosthodontics", true);
        Doctor doctor3 = new Neurologist(203, "Samantha Reed", 18, 300.00, true, "Neurovascular Stroke Intervention");
        Doctor doctor4 = new OrthopedicDoctor(204, "David Kalu", 12, 220.00, true, "Joint Replacement & Arthroplasty");

        System.out.println("  Created Cardiologist (Dr. Aria Thorne)       [extends Doctor]");
        System.out.println("  Created Dentist (Dr. Julian Ross)            [extends Doctor]");
        System.out.println("  Created Neurologist (Dr. Samantha Reed)      [extends Doctor]");
        System.out.println("  Created OrthopedicDoctor (Dr. David Kalu)    [extends Doctor]");

        // ====================================================================
        // CONCEPT 4: POLYMORPHISM (Dynamic Method Dispatch)
        // ====================================================================
        System.out.println("\n--- [CONCEPT 4] Runtime Polymorphism (consultationDetails() dynamic dispatch) ---");
        System.out.println("  " + doctor1.consultationDetails());
        System.out.println("  " + doctor2.consultationDetails());
        System.out.println("  " + doctor3.consultationDetails());
        System.out.println("  " + doctor4.consultationDetails());

        // ====================================================================
        // CONCEPT 5: COLLECTIONS FRAMEWORK (ArrayList add, remove, search, display)
        // ====================================================================
        System.out.println("\n--- [CONCEPT 5] Collections Framework (ArrayList Operations) ---");
        // Add operations
        hospital.addPatient(p1);
        hospital.addPatient(p2);
        hospital.addPatient(p3);
        hospital.addPatient(p4);

        hospital.addDoctor(doctor1);
        hospital.addDoctor(doctor2);
        hospital.addDoctor(doctor3);
        hospital.addDoctor(doctor4);

        // Search operations
        Patient foundP = hospital.searchPatient(102);
        System.out.println("  [ArrayList Search] Query Patient ID 102: " + (foundP != null ? foundP.getName() : "Not found"));
        Doctor foundD = hospital.searchDoctorByName("Aria Thorne");
        System.out.println("  [ArrayList Search] Query Doctor 'Aria Thorne': " + (foundD != null ? foundD.getSpecialization() : "Not found"));

        // Temporary patient to demonstrate remove operation
        Patient tempP = new Patient(199, "Temporary Guest", 22, "O+", "+1-555-0999");
        hospital.addPatient(tempP);
        System.out.println("  [ArrayList Add] Added temp patient: " + tempP.getName());
        boolean removed = hospital.removePatient(199);
        System.out.println("  [ArrayList Remove] Removed temp patient (ID: 199): " + (removed ? "SUCCESS" : "FAILED"));

        // ====================================================================
        // CONCEPT 1 & 6: APPOINTMENTS & CUSTOM EXCEPTION HANDLING
        // ====================================================================
        System.out.println("\n--- [CONCEPT 1 & 6] Appointment Booking & Exception Handling ---");
        try {
            System.out.println("  Booking valid appointment for Eleanor Vance with Dr. Aria Thorne...");
            Appointment a1 = new Appointment(501, p1, doctor1, "2026-09-15", "10:00 AM", "Cardiology Screening");
            hospital.bookAppointment(a1);

            System.out.println("  Booking valid appointment for Marcus Sterling with Dr. Samantha Reed...");
            Appointment a2 = new Appointment(502, p2, doctor3, "2026-09-15", "11:30 AM", "Neuro-Vascular Consult");
            hospital.bookAppointment(a2);
        } catch (AppointmentException ex) {
            System.out.println("  Unexpected AppointmentException: " + ex.getMessage());
        }

        // Exception Test 6A: Unavailable appointment slot (conflict / double booking)
        try {
            System.out.println("\n  Test 6A: Attempting double-booking on Dr. Aria Thorne on 2026-09-15 at 10:00 AM...");
            Appointment conflictingAppt = new Appointment(503, p3, doctor1, "2026-09-15", "10:00 AM", "Cardiology Checkup");
            hospital.bookAppointment(conflictingAppt);
            System.out.println("  FAILED: Slot conflict was not caught!");
        } catch (AppointmentException ex) {
            System.out.println("  ✓ CAUGHT EXPECTED AppointmentException [" + ex.getErrorCode() + "]: " + ex.getMessage());
        }

        // Exception Test 6B: Unregistered patient
        try {
            System.out.println("\n  Test 6B: Attempting booking for unregistered patient (ID: 999)...");
            Patient unregisteredPatient = new Patient(999, "Phantom Guest", 42, "O+", "+1-555-0999");
            Appointment ghostAppt = new Appointment(504, unregisteredPatient, doctor2, "2026-09-16", "02:00 PM", "Dental Scaling");
            hospital.bookAppointment(ghostAppt);
            System.out.println("  FAILED: Unregistered patient was not caught!");
        } catch (AppointmentException ex) {
            System.out.println("  ✓ CAUGHT EXPECTED AppointmentException [" + ex.getErrorCode() + "]: " + ex.getMessage());
        }

        // Exception Test 6C: Unregistered doctor
        try {
            System.out.println("\n  Test 6C: Attempting booking with unregistered doctor (ID: 888)...");
            Doctor ghostDoctor = new Doctor(888, "Dr. Invisible", "General Medicine", 5, 100.0);
            Appointment ghostDocAppt = new Appointment(505, p1, ghostDoctor, "2026-09-16", "03:00 PM", "Checkup");
            hospital.bookAppointment(ghostDocAppt);
            System.out.println("  FAILED: Unregistered doctor was not caught!");
        } catch (AppointmentException ex) {
            System.out.println("  ✓ CAUGHT EXPECTED AppointmentException [" + ex.getErrorCode() + "]: " + ex.getMessage());
        }

        // Exception Test 6D: Invalid appointment data (null payload)
        try {
            System.out.println("\n  Test 6D: Attempting booking with null appointment payload...");
            hospital.bookAppointment(null);
            System.out.println("  FAILED: Null appointment was not caught!");
        } catch (AppointmentException ex) {
            System.out.println("  ✓ CAUGHT EXPECTED AppointmentException [" + ex.getErrorCode() + "]: " + ex.getMessage());
        }

        // ====================================================================
        // CONCEPT 7: USER-DEFINED PACKAGES
        // ====================================================================
        System.out.println("\n--- [CONCEPT 7] User-defined Packages ---");
        System.out.println("  Package 'model'     : " + Patient.class.getPackageName() + " (" + Patient.class.getSimpleName() + ", " + Doctor.class.getSimpleName() + ", " + Appointment.class.getSimpleName() + ")");
        System.out.println("  Package 'service'   : " + HospitalService.class.getPackageName() + " (" + HospitalService.class.getSimpleName() + ")");
        System.out.println("  Package 'exception' : " + AppointmentException.class.getPackageName() + " (" + AppointmentException.class.getSimpleName() + ")");

        // ====================================================================
        // CONCEPT 8 & 9: MULTITHREADING & SYNCHRONIZATION
        // ====================================================================
        System.out.println("\n--- [CONCEPT 8 & 9] Multithreading & Java Synchronization ---");
        System.out.println("  Starting HospitalMonitor background worker thread...");
        hospital.startHospitalMonitor();
        System.out.println("  Thread execution confirmed. Shared collection accesses are synchronized.");

        // ====================================================================
        // CONCEPT 10: JAVA I/O STREAMS (FileWriter/BufferedWriter & FileReader/BufferedReader)
        // ====================================================================
        System.out.println("\n--- [CONCEPT 10] Java I/O Streams (Report Generation & Reading) ---");
        String auditReportPath = "logs/appointment_audit.log";
        try {
            // Write using FileWriter & BufferedWriter
            hospital.exportAppointmentReport(auditReportPath);

            // Read using FileReader & BufferedReader
            String readBack = hospital.readAppointmentReport(auditReportPath);
            System.out.println("  [Audit Report Content Preview from Disk]:\n" + readBack.trim());
        } catch (IOException e) {
            System.out.println("  I/O Stream Error: " + e.getMessage());
        }

        // Display directory snapshots
        hospital.displayPatients();
        hospital.displayDoctors();
        hospital.displayAppointments();

        System.out.println("\n================================================================================");
        System.out.println("  ALL 10 JAVA SYLLABUS CONCEPTS VERIFIED SUCCESSFULLY IN MEDISPHERE 3D");
        System.out.println("================================================================================\n");

        // ====================================================================
        // HTTP BACKEND INITIALIZATION (Java SE HttpServer)
        // ====================================================================
        startHttpServer(hospital);
    }

    /**
     * Starts lightweight Java SE HTTP Server.
     * Checks preferred port 8080, and falls back to 8085 if 8080 is reserved.
     */
    private static void startHttpServer(HospitalService hospital) {
        int preferredPort = DEFAULT_PORT; // 8080
        String customPort = System.getProperty("port", System.getenv("MEDISPHERE_PORT"));
        if (customPort != null) {
            try { preferredPort = Integer.parseInt(customPort); } catch (Exception ignored) {}
        }

        int[] candidatePorts = (preferredPort == 8080)
            ? new int[]{ 8080, 8085, 8088, 8090 }
            : new int[]{ preferredPort, 8080, 8085, 8088 };

        HttpServer server = null;
        int activePort = 0;

        for (int candidate : candidatePorts) {
            try {
                server = HttpServer.create(new InetSocketAddress("0.0.0.0", candidate), 0);
                activePort = candidate;
                break;
            } catch (IOException ex) {
                // Try next candidate port
            }
        }

        if (server == null) {
            System.err.println("Failed to bind Java HTTP server to any available port.");
            return;
        }

        final int serverPort = activePort;

        // GET /api/health
        server.createContext("/api/health", new HttpHandler() {
            @Override
            public void handle(HttpExchange exchange) throws IOException {
                if (handleCors(exchange)) return;
                if (!"GET".equalsIgnoreCase(exchange.getRequestMethod())) {
                    sendResponse(exchange, 405, "{\"error\":\"Method Not Allowed\"}");
                    return;
                }
                String json = String.format(
                    "{\"status\":\"UP\",\"system\":\"MediSphere 3D Java SE Backend\",\"javaVersion\":\"%s\"," +
                    "\"port\":%d,\"patientsCount\":%d,\"doctorsCount\":%d,\"appointmentsCount\":%d," +
                    "\"monitorThread\":\"%s\",\"monitorHeartbeat\":\"%s\"," +
                    "\"conceptsDemonstrated\":[\"Classes and Objects\",\"Encapsulation\",\"Inheritance\"," +
                    "\"Polymorphism\",\"Collections Framework / ArrayList\",\"Exception Handling\"," +
                    "\"User-defined Packages\",\"Multithreading\",\"Java Synchronization\",\"Java I/O Streams\"]}",
                    System.getProperty("java.version"),
                    serverPort,
                    hospital.getPatients().size(),
                    hospital.getDoctors().size(),
                    hospital.getAppointments().size(),
                    hospital.isMonitorRunning() ? "RUNNING" : "STOPPED",
                    escapeJson(hospital.getMonitorHeartbeat())
                );
                sendResponse(exchange, 200, json);
            }
        });

        // GET & POST /api/patients
        server.createContext("/api/patients", new HttpHandler() {
            @Override
            public void handle(HttpExchange exchange) throws IOException {
                if (handleCors(exchange)) return;
                String method = exchange.getRequestMethod();

                if ("GET".equalsIgnoreCase(method)) {
                    ArrayList<Patient> list = hospital.getPatients();
                    StringBuilder sb = new StringBuilder("[");
                    for (int i = 0; i < list.size(); i++) {
                        sb.append(list.get(i).toJson());
                        if (i < list.size() - 1) sb.append(",");
                    }
                    sb.append("]");
                    sendResponse(exchange, 200, sb.toString());
                } else if ("POST".equalsIgnoreCase(method)) {
                    try {
                        String body = readRequestBody(exchange);
                        int patientId = extractInt(body, "patientId", (int)(System.currentTimeMillis() % 10000) + 100);
                        String name = extractString(body, "name", "New Patient");
                        int age = extractInt(body, "age", 30);
                        String bloodGroup = extractString(body, "bloodGroup", "O+");
                        String phone = extractString(body, "phone", "N/A");

                        Patient newP = new Patient(patientId, name, age, bloodGroup, phone);
                        hospital.addPatient(newP);
                        sendResponse(exchange, 201, newP.toJson());
                    } catch (IllegalArgumentException ex) {
                        sendResponse(exchange, 400, "{\"error\":true,\"message\":\"" + escapeJson(ex.getMessage()) + "\"}");
                    } catch (Exception ex) {
                        sendResponse(exchange, 500, "{\"error\":true,\"message\":\"" + escapeJson(ex.getMessage()) + "\"}");
                    }
                } else {
                    sendResponse(exchange, 405, "{\"error\":\"Method Not Allowed\"}");
                }
            }
        });

        // GET /api/doctors
        server.createContext("/api/doctors", new HttpHandler() {
            @Override
            public void handle(HttpExchange exchange) throws IOException {
                if (handleCors(exchange)) return;
                if (!"GET".equalsIgnoreCase(exchange.getRequestMethod())) {
                    sendResponse(exchange, 405, "{\"error\":\"Method Not Allowed\"}");
                    return;
                }
                ArrayList<Doctor> list = hospital.getDoctors();
                StringBuilder sb = new StringBuilder("[");
                for (int i = 0; i < list.size(); i++) {
                    sb.append(list.get(i).toJson());
                    if (i < list.size() - 1) sb.append(",");
                }
                sb.append("]");
                sendResponse(exchange, 200, sb.toString());
            }
        });

        // GET & POST /api/appointments
        server.createContext("/api/appointments", new HttpHandler() {
            @Override
            public void handle(HttpExchange exchange) throws IOException {
                if (handleCors(exchange)) return;
                String method = exchange.getRequestMethod();

                if ("GET".equalsIgnoreCase(method)) {
                    ArrayList<Appointment> list = hospital.getAppointments();
                    StringBuilder sb = new StringBuilder("[");
                    for (int i = 0; i < list.size(); i++) {
                        sb.append(list.get(i).toJson());
                        if (i < list.size() - 1) sb.append(",");
                    }
                    sb.append("]");
                    sendResponse(exchange, 200, sb.toString());
                } else if ("POST".equalsIgnoreCase(method)) {
                    try {
                        String body = readRequestBody(exchange);
                        int appointmentId = extractInt(body, "appointmentId", (int)(System.currentTimeMillis() % 10000) + 500);
                        int patientId = extractInt(body, "patientId", 0);
                        int doctorId = extractInt(body, "doctorId", 0);
                        String date = extractString(body, "date", "");
                        String time = extractString(body, "time", "");
                        String consultationType = extractString(body, "consultationType", "Standard Consultation");

                        Patient patient = hospital.searchPatient(patientId);
                        Doctor doctor = hospital.searchDoctor(doctorId);

                        Appointment newAppt = new Appointment(appointmentId, patient, doctor, date, time, consultationType);
                        hospital.bookAppointment(newAppt);
                        sendResponse(exchange, 201, newAppt.toJson());
                    } catch (AppointmentException ex) {
                        sendResponse(exchange, 400, String.format(
                            "{\"error\":true,\"code\":\"%s\",\"message\":\"%s\"}",
                            escapeJson(ex.getErrorCode()), escapeJson(ex.getMessage())
                        ));
                    } catch (IllegalArgumentException ex) {
                        sendResponse(exchange, 400, "{\"error\":true,\"message\":\"" + escapeJson(ex.getMessage()) + "\"}");
                    } catch (Exception ex) {
                        sendResponse(exchange, 500, "{\"error\":true,\"message\":\"" + escapeJson(ex.getMessage()) + "\"}");
                    }
                } else {
                    sendResponse(exchange, 405, "{\"error\":\"Method Not Allowed\"}");
                }
            }
        });

        // GET /api/report
        server.createContext("/api/report", new HttpHandler() {
            @Override
            public void handle(HttpExchange exchange) throws IOException {
                if (handleCors(exchange)) return;
                if (!"GET".equalsIgnoreCase(exchange.getRequestMethod())) {
                    sendResponse(exchange, 405, "{\"error\":\"Method Not Allowed\"}");
                    return;
                }
                try {
                    String filePath = "logs/appointment_audit.log";
                    hospital.exportAppointmentReport(filePath);
                    String reportText = hospital.readAppointmentReport(filePath);
                    String json = String.format(
                        "{\"status\":\"SUCCESS\",\"method\":\"FileWriter/BufferedWriter & FileReader/BufferedReader\"," +
                        "\"filePath\":\"%s\",\"report\":%s}",
                        filePath, quoteJsonString(reportText)
                    );
                    sendResponse(exchange, 200, json);
                } catch (Exception ex) {
                    sendResponse(exchange, 500, "{\"error\":true,\"message\":\"" + escapeJson(ex.getMessage()) + "\"}");
                }
            }
        });

        // GET /api/threads
        server.createContext("/api/threads", new HttpHandler() {
            @Override
            public void handle(HttpExchange exchange) throws IOException {
                if (handleCors(exchange)) return;
                if (!"GET".equalsIgnoreCase(exchange.getRequestMethod())) {
                    sendResponse(exchange, 405, "{\"error\":\"Method Not Allowed\"}");
                    return;
                }
                String json = String.format(
                    "{\"threadName\":\"MediSphere-HospitalMonitor-Worker\",\"alive\":%b," +
                    "\"cycleCount\":%d,\"heartbeat\":\"%s\",\"synchronizationPolicy\":\"synchronized methods + critical blocks\"}",
                    hospital.isMonitorRunning(),
                    hospital.getMonitorCycleCount(),
                    escapeJson(hospital.getMonitorHeartbeat())
                );
                sendResponse(exchange, 200, json);
            }
        });

        server.setExecutor(null); // Default executor
        server.start();

        System.out.println("================================================================================");
        System.out.println("MediSphere Java Backend running on http://localhost:" + serverPort);
        System.out.println("================================================================================");
        System.out.println("Test endpoints:");
        System.out.println("  - http://localhost:" + serverPort + "/api/health");
        System.out.println("  - http://localhost:" + serverPort + "/api/patients");
        System.out.println("  - http://localhost:" + serverPort + "/api/doctors");
        System.out.println("  - http://localhost:" + serverPort + "/api/appointments");
        System.out.println("  - http://localhost:" + serverPort + "/api/report");
        System.out.println("  - http://localhost:" + serverPort + "/api/threads");
        System.out.println("================================================================================\n");
    }

    // ====================================================================
    // HTTP UTILITIES: CORS, REQUEST READING, JSON ESCAPING
    // ====================================================================

    private static boolean handleCors(HttpExchange exchange) throws IOException {
        exchange.getResponseHeaders().set("Access-Control-Allow-Origin", "*");
        exchange.getResponseHeaders().set("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
        exchange.getResponseHeaders().set("Access-Control-Allow-Headers", "Content-Type, Authorization");
        exchange.getResponseHeaders().set("Content-Type", "application/json; charset=UTF-8");

        if ("OPTIONS".equalsIgnoreCase(exchange.getRequestMethod())) {
            exchange.sendResponseHeaders(204, -1);
            exchange.close();
            return true;
        }
        return false;
    }

    private static void sendResponse(HttpExchange exchange, int statusCode, String responseText) throws IOException {
        byte[] bytes = responseText.getBytes(StandardCharsets.UTF_8);
        exchange.sendResponseHeaders(statusCode, bytes.length);
        try (OutputStream os = exchange.getResponseBody()) {
            os.write(bytes);
        }
    }

    private static String readRequestBody(HttpExchange exchange) throws IOException {
        try (InputStream is = exchange.getRequestBody()) {
            return new String(is.readAllBytes(), StandardCharsets.UTF_8);
        }
    }

    private static String extractString(String json, String key, String defaultVal) {
        if (json == null) return defaultVal;
        String pattern = "\"" + key + "\"\\s*:\\s*\"([^\"]*)\"";
        java.util.regex.Pattern p = java.util.regex.Pattern.compile(pattern);
        java.util.regex.Matcher m = p.matcher(json);
        if (m.find()) {
            return m.group(1);
        }
        return defaultVal;
    }

    private static int extractInt(String json, String key, int defaultVal) {
        if (json == null) return defaultVal;
        String pattern = "\"" + key + "\"\\s*:\\s*(\\d+)";
        java.util.regex.Pattern p = java.util.regex.Pattern.compile(pattern);
        java.util.regex.Matcher m = p.matcher(json);
        if (m.find()) {
            try {
                return Integer.parseInt(m.group(1));
            } catch (NumberFormatException ignored) {}
        }
        return defaultVal;
    }

    private static String escapeJson(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n").replace("\r", "\\r");
    }

    private static String quoteJsonString(String text) {
        if (text == null) return "\"\"";
        return "\"" + escapeJson(text) + "\"";
    }
}
