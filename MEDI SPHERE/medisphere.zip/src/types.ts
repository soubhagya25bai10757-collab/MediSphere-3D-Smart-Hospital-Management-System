export type UserRole = 
  | 'Administrator' 
  | 'Doctor' 
  | 'Receptionist' 
  | 'Laboratory Staff' 
  | 'Pharmacy Staff';

export interface User {
  id: string;
  username: string;
  name: string;
  role: UserRole;
  avatar?: string;
  department?: string;
}

export type PatientStatus = 
  | 'Active'
  | 'Admitted' 
  | 'Discharged' 
  | 'Emergency' 
  | 'Scheduled'
  | 'ICU' 
  | 'Outpatient';

export interface Patient {
  id: string;
  name: string;
  age: number;
  gender: 'Male' | 'Female' | 'Other';
  bloodGroup: 'A+' | 'A-' | 'B+' | 'B-' | 'AB+' | 'AB-' | 'O+' | 'O-';
  contact: string;
  email: string;
  address: string;
  emergencyContact: string;
  registeredDate: string;
  currentStatus: PatientStatus;
  patientCategory?: 'Active' | 'Admitted' | 'Discharged' | 'Emergency' | 'Scheduled';
  assignedDoctorId?: string;
  assignedDoctorName?: string;
  department?: string;
  lastVisit?: string;
  nextAppointment?: string;
  assignedBedId?: string;
  allergies?: string[];
  uhid?: string;
}

export type DoctorSpecialization =
  | 'General Medicine'
  | 'Cardiology'
  | 'Neurology'
  | 'Orthopedics'
  | 'Dermatology'
  | 'Ophthalmology'
  | 'ENT'
  | 'Dentistry'
  | 'Pediatrics'
  | 'Gynecology'
  | 'Gastroenterology'
  | 'Pulmonology'
  | 'Urology'
  | 'Nephrology'
  | 'Oncology'
  | 'Psychiatry'
  | 'Radiology'
  | 'Anesthesiology'
  | 'Endocrinology'
  | 'Rheumatology'
  | 'Emergency Medicine'
  | 'Neurosurgery'
  | 'Cardiothoracic Surgery'
  | 'General Surgery'
  | 'General Surgeon'
  | 'Physiotherapy'
  | 'Hematology'
  | 'Immunology'
  | 'Plastic Surgery'
  | 'Vascular Surgery'
  | 'General Physician'
  | 'Dentist'
  | 'Orthopedic'
  | 'Cardiologist'
  | 'Ophthalmologist'
  | 'ENT Specialist'
  | 'Dermatologist'
  | 'Neurologist'
  | 'Nephrologist'
  | 'Urologist'
  | 'Gastroenterologist'
  | 'Pulmonologist'
  | 'Endocrinologist'
  | 'Gynecologist'
  | 'Pediatrician'
  | 'Psychiatrist'
  | 'Oncologist'
  | 'Hematologist'
  | 'Rheumatologist'
  | 'Neurosurgeon'
  | 'Plastic Surgeon'
  | 'Physiotherapist'
  | 'Allergist / Immunologist';

export type MedicalSpecialization = DoctorSpecialization;

export type DoctorStatus = 'Available' | 'In Consultation' | 'Unavailable' | 'On Leave' | 'Emergency Duty';

export interface Doctor {
  id: string;
  name: string;
  specialization: DoctorSpecialization;
  experienceYears: number;
  availability: string; // e.g. "09:00 AM - 04:00 PM"
  consultationFee: number; // in ₹
  status: DoctorStatus;
  rating: number;
  phone: string;
  email: string;
  roomNumber: string;
  department?: string;
  contact?: string;
  availableDays?: string[];
  availableTimeSlot?: string;
  qualification?: string;
  description?: string;
  appointmentStatus?: 'Available for Booking' | 'Slots Full Today' | 'On Call';
  activeConsultationsCount?: number;
}

export type AppointmentType =
  | 'In-Person'
  | 'Follow-up'
  | 'Online Consultation'
  | 'Emergency Consultation'
  | 'New Consultation'
  | 'General Check-up'
  | 'Specialist Consultation'
  | 'Diagnostic Check-up'
  | 'Emergency Appointment'
  | 'Health Screening'
  | 'Vaccination'
  | 'Physiotherapy'
  | 'Pre-Surgery Consultation'
  | 'Post-Surgery Follow-up'
  | 'General Consultation'
  | 'Specialist Review'
  | 'Emergency Screening'
  | 'Routine Checkup';

export type AppointmentStatus =
  | 'Confirmed'
  | 'Waiting'
  | 'Completed'
  | 'Cancelled'
  | 'Scheduled'
  | 'In Consultation';

export interface Appointment {
  id: string;
  patientId: string;
  patientName: string;
  doctorId: string;
  doctorName: string;
  specialization: DoctorSpecialization;
  department?: string;
  appointmentType: AppointmentType;
  date: string; // YYYY-MM-DD
  timeSlot: string; // e.g. "10:30 AM"
  status: AppointmentStatus;
  notes?: string;
  fee: number;
}

export type EmergencyPriority = 'Critical' | 'High' | 'Medium' | 'Low';
export type EmergencyStatus = 'Triage' | 'Assigned' | 'In Treatment' | 'Stabilized' | 'Transferred' | 'Discharged';

export interface EmergencyCase {
  id: string;
  patientId?: string;
  patientName: string;
  age: number;
  gender: string;
  priority: EmergencyPriority;
  chiefComplaint: string;
  assignedDepartment: string;
  assignedDoctorId?: string;
  assignedDoctorName?: string;
  assignedBedId?: string;
  assignedBedNumber?: string;
  arrivalTime: string;
  waitingMinutes: number;
  status: EmergencyStatus;
  vitals: {
    bloodPressure: string;
    heartRate: number;
    oxygenSaturation: number;
    temperature: number;
    respiratoryRate?: number;
  };
  emergencyType?: string;
  treatmentStatus?: 'Awaiting Assessment' | 'Under Treatment' | 'Observation' | 'Stabilized' | 'Ready for Transfer' | 'Discharged';
  durationMinutes?: number;
}

export interface EmergencyHistoryRecord {
  id: string;
  patientName: string;
  patientId: string;
  emergencyType: string;
  priority: EmergencyPriority;
  arrivalTime: string;
  treatmentStart: string;
  treatmentEnd: string;
  assignedDoctor: string;
  doctorId?: string;
  finalStatus: 'Stabilized' | 'Discharged' | 'Admitted' | 'Transferred' | 'Referred';
  disposition: string;
  date: string;
  summary: string;
  dischargeVitals?: {
    bloodPressure: string;
    heartRate: number;
    oxygenSaturation: number;
    temperature: number;
    respiratoryRate?: number;
  };
  interventions: string[];
}

export interface MedicalRecord {
  id: string;
  patientId: string;
  patientName: string;
  date: string;
  doctorId: string;
  doctorName: string;
  department: string;
  symptoms: string[];
  diagnosis: string;
  doctorNotes: string;
  clinicalNotes?: string;
  treatmentSummary: string;
  prescriptions: (PrescriptionItem | string)[];
  labTestIds: string[];
  followUpDate?: string;
}

export interface PrescriptionItem {
  id: string;
  medicineName: string;
  dosage: string; // e.g. "500mg"
  frequency: string; // e.g. "1-0-1 (Twice daily)"
  duration: string; // e.g. "5 Days"
  instructions: string; // e.g. "After food"
}

export type TreatmentStatus = 'Ongoing' | 'Completed' | 'Suspended' | 'Paused';

export interface Treatment {
  id: string;
  patientId: string;
  patientName: string;
  doctorId: string;
  doctorName: string;
  diagnosis: string;
  treatmentName: string;
  startDate: string;
  endDate?: string;
  status: TreatmentStatus;
  medicines: PrescriptionItem[];
  prescriptions?: PrescriptionItem[];
  instructions: string;
  followUpDate?: string;
}

export type LabTestType =
  | 'CBC'
  | 'Blood Sugar'
  | 'Lipid Profile'
  | 'Liver Function Test'
  | 'Kidney Function Test'
  | 'Urine Test'
  | 'X-Ray'
  | 'ECG'
  | 'Ultrasound';

export type LabTestStatus = 'Pending' | 'Processing' | 'Completed' | 'Cancelled' | 'Requested' | 'In Progress';

export interface LabTest {
  id: string;
  patientId: string;
  patientName: string;
  doctorId: string;
  doctorName: string;
  testType: LabTestType | string;
  requestDate: string;
  status: LabTestStatus;
  urgency: 'Routine' | 'Urgent' | 'Stat (Emergency)';
  sampleType?: string;
  requestedByDoctor?: string;
  fee?: number;
  results?: {
    parameter: string;
    value: string;
    normalRange: string;
    referenceRange?: string;
    status: 'Normal' | 'High' | 'Low' | 'Critical';
    isAbnormal?: boolean;
  }[];
  technicianNotes?: string;
  completedDate?: string;
}

export type DiagnosticLabTest = LabTest;

export type MedicineCategory =
  | 'Antibiotics'
  | 'Analgesics'
  | 'Antihypertensives'
  | 'Antidiabetics'
  | 'Antihistamines'
  | 'Cardiovascular'
  | 'Respiratory'
  | 'Emergency Drugs'
  | 'Vitamins & Supplements'
  | string;

export type MedicineStatus = 'Available' | 'Low Stock' | 'Out of Stock';

export interface Medicine {
  id: string;
  name: string;
  genericName?: string;
  category: MedicineCategory;
  availableStock: number;
  minimumStock: number;
  stockQuantity?: number;
  minThreshold?: number;
  unitPrice?: number;
  dosageForm?: string;
  unit: string; // e.g. "Tablets", "Vials", "Syrups"
  status: MedicineStatus;
  expiryDate: string;
  pricePerUnit: number; // in ₹
  manufacturer: string;
  batchNumber: string;
}

export type BedSection = 'ICU' | 'Emergency' | 'General Ward' | 'Private Room' | 'Semi-Private' | 'Private';
export type WardType = BedSection | string;
export type BedStatus = 'Available' | 'Occupied' | 'Reserved' | 'Maintenance';

export interface Bed {
  id: string;
  code: string; // e.g. "ICU-01", "GW-12"
  bedNumber?: string;
  wardType?: string;
  patientName?: string;
  admissionDate?: string;
  section: BedSection;
  floor: number;
  status: BedStatus;
  occupiedByPatientId?: string;
  occupiedByPatientName?: string;
  admittedDate?: string;
  dailyCharge: number;
}

export interface BillItem {
  id?: string;
  category: 'Consultation' | 'Laboratory' | 'Pharmacy' | 'Bed Charge' | 'Surgery / Procedures' | 'Other' | 'Bed' | 'Lab';
  description: string;
  quantity?: number;
  unitPrice?: number;
  totalPrice?: number;
  amount?: number;
}

export type PaymentStatus = 'Paid' | 'Partially Paid' | 'Pending';

export type PaymentMethod =
  | 'UPI'
  | 'Credit Card'
  | 'Cash'
  | 'Insurance Claim'
  | 'UPI / QR'
  | 'Health Insurance'
  | 'Net Banking';

export interface Bill {
  id: string;
  patientId: string;
  patientName: string;
  invoiceDate: string;
  items: BillItem[];
  subtotal: number;
  discountPercent: number;
  discountAmount: number;
  taxPercent: number; // e.g. 5%
  taxAmount: number;
  totalAmount: number;
  paidAmount: number;
  dueAmount: number;
  paymentStatus: PaymentStatus;
  paymentMethod?: PaymentMethod;
  transactionId?: string;
}

export type JavaThreadState = 'NEW' | 'RUNNABLE' | 'RUNNING' | 'TIMED_WAITING' | 'WAITING' | 'BLOCKED' | 'TERMINATED';

export interface SystemThreadInfo {
  id: string;
  threadName: string;
  name?: string;
  javaClass: string;
  state: JavaThreadState;
  priority: number; // 1 to 10
  currentTask: string;
  taskName?: string;
  processedCount: number;
  progress?: number;
  cpuUsagePercent: number;
  cpuUsage?: number;
  synchronizationLock?: string;
  isDaemon: boolean;
  latencyMs?: number; // Measured execution / queue dispatch latency in milliseconds
  latencyThresholdMs?: number; // Safety SLA threshold before automated alerts trigger
  latencyStatus?: 'NORMAL' | 'ELEVATED' | 'CRITICAL';
  lastAlertTimestamp?: string;
}

export type JavaThreadInfo = SystemThreadInfo;

export interface SystemLogEntry {
  id: string;
  timestamp: string;
  type: 'INFO' | 'WARN' | 'ERROR';
  message: string;
}

export interface ToastMessage {
  id: string;
  title: string;
  message: string;
  type: 'success' | 'error' | 'warning' | 'info';
  javaExceptionClass?: string;
  timestamp: string;
}

export type MainNavigationTab =
  | 'dashboard'
  | 'patients'
  | 'doctors'
  | 'appointments'
  | 'emergency'
  | 'operations'
  | 'hospital-operations'
  | 'analytics';

export type NavigationTab =
  | MainNavigationTab
  | 'medical-records'
  | 'treatments'
  | 'laboratory'
  | 'pharmacy'
  | 'beds'
  | 'billing'
  | 'reports'
  | 'threads'
  | 'java-architecture'
  | 'settings';
