import React, { useState, useEffect } from 'react';
import { useHospital } from '../context/HospitalContext';
import { MainNavigationTab, UserRole } from '../types';
import {
  LayoutDashboard,
  Users,
  UserCheck,
  Calendar,
  Flame,
  Building2,
  BarChart3,
  ChevronDown,
  ChevronRight,
  ChevronLeft,
  Search,
  Menu,
  X,
  Activity,
  Clock,
  Home,
  Bell,
} from 'lucide-react';
import { GlobalSearchDropdown } from './GlobalSearchDropdown';
import { NotificationDropdown } from './NotificationDropdown';

interface SubOption {
  id: string;
  label: string;
  badge?: string;
}

interface MainTabConfig {
  id: MainNavigationTab;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  badge?: string;
  badgeColor?: string;
  subOptions?: SubOption[];
  roles: UserRole[];
}

export const MAIN_NAV_TABS: MainTabConfig[] = [
  {
    id: 'dashboard',
    label: 'Dashboard',
    icon: LayoutDashboard,
    roles: ['Administrator', 'Doctor', 'Receptionist', 'Laboratory Staff', 'Pharmacy Staff'],
  },
  {
    id: 'patients',
    label: 'Patient Management',
    icon: Users,
    roles: ['Administrator', 'Doctor', 'Receptionist'],
    subOptions: [
      { id: 'list', label: 'Patient List' },
      { id: 'register', label: 'Register Patient' },
      { id: 'profile', label: 'Patient Profile' },
      { id: 'history', label: 'Medical History' },
      { id: 'prescriptions', label: 'Prescriptions & Records' },
    ],
  },
  {
    id: 'doctors',
    label: 'Doctor Management',
    icon: UserCheck,
    roles: ['Administrator', 'Doctor'],
    subOptions: [
      { id: 'directory', label: 'Doctor Directory' },
      { id: 'specializations', label: 'Specializations', badge: '25' },
      { id: 'availability', label: 'Doctor Availability' },
      { id: 'schedule', label: 'Doctor Schedule' },
      { id: 'assigned', label: 'Assigned Patients' },
    ],
  },
  {
    id: 'appointments',
    label: 'Appointments',
    icon: Calendar,
    roles: ['Administrator', 'Doctor', 'Receptionist'],
    subOptions: [
      { id: 'today', label: "Today's Appointments" },
      { id: 'upcoming', label: 'Upcoming Appointments' },
      { id: 'book', label: 'Book Appointment' },
      { id: 'history', label: 'Appointment History' },
      { id: 'schedule', label: 'Doctor Schedule' },
    ],
  },
  {
    id: 'emergency',
    label: 'Emergency Command',
    icon: Flame,
    badge: 'LIVE',
    badgeColor: 'bg-red-500/20 text-red-400 border-red-500/40 animate-pulse',
    roles: ['Administrator', 'Doctor'],
    subOptions: [
      { id: 'dashboard', label: 'Emergency Dashboard' },
      { id: 'queue', label: 'Priority Queue' },
      { id: 'active', label: 'Active Cases' },
      { id: 'doctors', label: 'Available Emergency Doctors' },
      { id: 'history', label: 'Emergency History' },
    ],
  },
  {
    id: 'operations',
    label: 'Hospital Operations',
    icon: Building2,
    roles: ['Administrator', 'Laboratory Staff', 'Pharmacy Staff', 'Receptionist'],
    subOptions: [
      { id: 'laboratory', label: 'Laboratory' },
      { id: 'pharmacy', label: 'Pharmacy' },
      { id: 'beds', label: 'Bed Management' },
      { id: 'billing', label: 'Billing & Invoices' },
      { id: 'threads', label: 'Thread Activity Monitor' },
    ],
  },
  {
    id: 'analytics',
    label: 'Analytics & System',
    icon: BarChart3,
    roles: ['Administrator'],
    subOptions: [
      { id: 'analytics', label: 'Hospital Analytics' },
      { id: 'reports', label: 'Reports' },
      { id: 'threads', label: 'System Monitor' },
      { id: 'activity', label: 'System Activity' },
    ],
  },
];

export const Navigation: React.FC = () => {
  const {
    activeMainTab,
    activeSubTab,
    setActiveNavigation,
    setShowLandingPage,
    searchQuery,
    setSearchQuery,
    isSidebarExpanded,
    toggleSidebar,
  } = useHospital();

  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState<boolean>(false);
  const [isNotificationOpen, setIsNotificationOpen] = useState<boolean>(false);
  const [timeString, setTimeString] = useState<string>(() =>
    new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
  );

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeString(new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }));
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Accordion state for expanded drawer mode
  const [expandedTabs, setExpandedTabs] = useState<Record<string, boolean>>({
    [activeMainTab]: true,
  });

  // Auto-expand current active section if it has suboptions
  useEffect(() => {
    setExpandedTabs((prev) => ({
      ...prev,
      [activeMainTab]: true,
    }));
  }, [activeMainTab]);

  const toggleTabExpansion = (tabId: MainNavigationTab, hasSubOptions: boolean) => {
    if (!hasSubOptions) {
      setActiveNavigation(tabId);
      setIsMobileMenuOpen(false);
      return;
    }

    setExpandedTabs((prev) => {
      const isCurrentlyOpen = !!prev[tabId];
      const next: Record<string, boolean> = {};
      if (!isCurrentlyOpen) {
        next[tabId] = true;
      }
      return next;
    });

    if (activeMainTab !== tabId) {
      const targetConfig = MAIN_NAV_TABS.find((t) => t.id === tabId);
      const defaultSub = targetConfig?.subOptions?.[0]?.id;
      setActiveNavigation(tabId, defaultSub);
    }
  };

  const handleSubOptionClick = (mainTabId: MainNavigationTab, subOptionId: string) => {
    setActiveNavigation(mainTabId, subOptionId);
    setIsMobileMenuOpen(false);
  };

  const handleHamburgerClick = () => {
    if (window.innerWidth >= 1024) {
      toggleSidebar();
    } else {
      setIsMobileMenuOpen((prev) => !prev);
    }
  };

  const visibleTabs = MAIN_NAV_TABS;

  return (
    <>
      {/* Top Clean Command Header */}
      <header className="sticky top-0 z-40 w-full h-16 border-b border-cyan-500/25 bg-[rgba(3,10,26,0.72)] backdrop-blur-2xl px-4 lg:px-6 flex items-center justify-between shadow-[0_4px_30px_rgba(0,0,0,0.5)]">
        {/* Left: Hamburger & Brand Logo */}
        <div className="flex items-center gap-3">
          {/* Universal Hamburger Button */}
          <button
            onClick={handleHamburgerClick}
            className="p-2 rounded-xl text-slate-300 hover:text-cyan-300 bg-[rgba(5,15,35,0.6)] hover:bg-[rgba(7,22,50,0.75)] border border-cyan-500/20 hover:border-cyan-500/40 backdrop-blur-md transition-all duration-200 flex items-center justify-center group shadow-sm active:scale-95"
            title={isSidebarExpanded ? 'Collapse sidebar' : 'Expand sidebar'}
            aria-label="Toggle navigation drawer"
          >
            <Menu className="w-5 h-5 group-hover:scale-105 transition-transform" />
          </button>

          {/* Brand Logo */}
          <button
            onClick={() => setShowLandingPage(true)}
            className="flex items-center gap-2.5 text-left group"
            title="Return to MediSphere 3D Landing Page"
            aria-label="Return to MediSphere 3D Landing Page"
          >
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-cyan-500 via-blue-600 to-indigo-600 p-[1.5px] shadow-lg shadow-cyan-500/25 group-hover:scale-105 transition-transform">
              <div className="w-full h-full bg-slate-950 rounded-[10px] flex items-center justify-center">
                <Activity className="w-5 h-5 text-cyan-400 animate-pulse" />
              </div>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="text-base sm:text-lg font-extrabold tracking-tight text-white">
                MediSphere
              </span>
              <span className="text-xs font-black px-1.5 py-0.2 rounded bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-[0_0_10px_rgba(6,182,212,0.3)]">
                3D
              </span>
            </div>
          </button>

          {/* Quick Home / Landing Page Button */}
          <button
            onClick={() => setShowLandingPage(true)}
            className="hidden sm:flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-[rgba(5,15,35,0.6)] hover:bg-[rgba(7,22,50,0.85)] border border-cyan-500/20 hover:border-cyan-500/45 text-xs text-slate-300 hover:text-cyan-300 backdrop-blur-md transition-all shadow-sm active:scale-95 ml-1"
            title="Return to MediSphere 3D Landing Page"
            aria-label="Return to MediSphere 3D Landing Page"
          >
            <Home className="w-3.5 h-3.5 text-cyan-400" />
            <span className="font-semibold">Home</span>
          </button>
        </div>

        {/* Center: Global Search Input */}
        <div className="hidden md:flex items-center flex-1 max-w-xl mx-8 relative">
          <div className="relative w-full">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-cyan-400/70" />
            <input
              type="text"
              placeholder="Search patients, doctors, appointments, triage, departments..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-4 py-2 text-xs rounded-xl glass-input placeholder-slate-400 transition"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white text-xs"
              >
                ✕
              </button>
            )}
          </div>
          {searchQuery.trim().length > 0 && (
            <GlobalSearchDropdown
              query={searchQuery}
              onClose={() => setSearchQuery('')}
            />
          )}
        </div>

        {/* Right: Hospital Status, Notifications & Clock */}
        <div className="flex items-center gap-2.5">
          {/* Notifications Dropdown Trigger */}
          <div className="relative">
            <button
              onClick={() => setIsNotificationOpen((prev) => !prev)}
              className="relative p-2 rounded-xl bg-[rgba(5,15,35,0.6)] hover:bg-[rgba(7,22,50,0.85)] border border-cyan-500/20 hover:border-cyan-500/40 text-slate-300 hover:text-cyan-300 backdrop-blur-md transition-all shadow-sm flex items-center justify-center cursor-pointer active:scale-95"
              title="Hospital Notifications"
              aria-label="Hospital Notifications"
            >
              <Bell className="w-4 h-4" />
              <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-red-400 animate-pulse shadow-[0_0_8px_#f87171]" />
            </button>
            <NotificationDropdown
              isOpen={isNotificationOpen}
              onClose={() => setIsNotificationOpen(false)}
            />
          </div>

          <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-xl bg-[rgba(5,15,35,0.6)] backdrop-blur-md border border-cyan-500/20 text-xs shadow-inner">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse shadow-[0_0_8px_#34d399]" />
            <span className="text-slate-300 font-medium">Status:</span>
            <span className="text-emerald-400 font-semibold font-mono">98.4% Operational</span>
          </div>

          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[rgba(5,15,35,0.6)] backdrop-blur-md border border-cyan-500/20 text-xs text-slate-200 font-mono shadow-inner">
            <Clock className="w-3.5 h-3.5 text-cyan-400" />
            <span>{timeString}</span>
          </div>
        </div>
      </header>

      {/* VTOP COLLAPSIBLE DRAWER / SIDEBAR (Desktop) */}
      <aside
        className={`hidden lg:flex fixed left-0 top-16 bottom-0 ${
          isSidebarExpanded ? 'w-72 p-3' : 'w-[72px] p-2'
        } flex-col border-r border-cyan-500/20 bg-[rgba(3,10,26,0.72)] backdrop-blur-2xl z-30 justify-between overflow-x-hidden overflow-y-auto shadow-2xl transition-all duration-300 ease-in-out select-none`}
      >
        {/* Top: Header & 7 Modules */}
        <div>
          {/* Expanded Drawer Header */}
          {isSidebarExpanded ? (
            <div className="flex items-center justify-between px-3 py-2.5 mb-2 rounded-xl bg-gradient-to-r from-slate-900/90 to-slate-950 border border-slate-800/80 shadow-inner">
              <button
                onClick={() => setShowLandingPage(true)}
                className="flex items-center gap-2.5 overflow-hidden text-left hover:opacity-85 transition group"
                title="Return to MediSphere 3D Landing Page"
                aria-label="Return to MediSphere 3D Landing Page"
              >
                <span className="text-red-400 font-black text-sm flex-shrink-0">✚</span>
                <div className="truncate">
                  <span className="text-xs font-black text-white tracking-wider block leading-tight group-hover:text-cyan-300 transition">
                    MEDISPHERE 3D
                  </span>
                  <span className="text-[9px] font-bold text-slate-400 tracking-wider uppercase block truncate">
                    SMART HOSPITAL MANAGEMENT SYSTEM
                  </span>
                </div>
              </button>

              <button
                onClick={toggleSidebar}
                className="p-1.5 rounded-lg text-slate-400 hover:text-cyan-300 hover:bg-slate-800/80 transition flex-shrink-0"
                title="Collapse sidebar"
                aria-label="Collapse sidebar"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
            </div>
          ) : (
            /* Collapsed Drawer Top Icon */
            <div className="flex flex-col items-center justify-center py-2 mb-2 border-b border-slate-900">
              <button
                onClick={toggleSidebar}
                className="w-10 h-10 rounded-xl bg-gradient-to-tr from-cyan-500/15 to-blue-600/15 hover:from-cyan-500/25 hover:to-blue-600/25 border border-cyan-500/30 hover:border-cyan-400 flex items-center justify-center text-cyan-300 hover:text-white transition shadow-sm group relative"
                title="Expand sidebar"
                aria-label="Expand sidebar"
              >
                <span className="text-red-400 font-black text-sm group-hover:scale-110 transition-transform">✚</span>
                <div className="absolute left-full ml-3 px-2.5 py-1.5 rounded-lg bg-slate-900/95 border border-cyan-500/40 text-cyan-200 text-xs font-semibold whitespace-nowrap opacity-0 pointer-events-none group-hover:opacity-100 scale-95 group-hover:scale-100 transition-all duration-150 z-50 shadow-xl shadow-cyan-950/50">
                  Expand Sidebar
                </div>
              </button>
            </div>
          )}

          {/* Section Subheading (Expanded only) */}
          {isSidebarExpanded && (
            <div className="px-3 py-1 mb-1">
              <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">
                PORTAL NAVIGATION &bull; 7 MODULES
              </span>
            </div>
          )}

          {/* EXACTLY 7 MODULES */}
          <div className="flex flex-col gap-1.5">
            {visibleTabs.map((tab) => {
              const Icon = tab.icon;
              const hasSub = !!tab.subOptions && tab.subOptions.length > 0;
              const isExpanded = !!expandedTabs[tab.id];
              const isParentActive = activeMainTab === tab.id;

              /* COLLAPSED MODE ITEM */
              if (!isSidebarExpanded) {
                return (
                  <div key={tab.id} className="relative flex justify-center py-0.5">
                    <button
                      onClick={() => setActiveNavigation(tab.id)}
                      className={`w-11 h-11 rounded-xl flex items-center justify-center relative transition-all duration-200 group ${
                        isParentActive
                          ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/50 shadow-[0_0_12px_rgba(6,182,212,0.35)] font-semibold'
                          : 'text-slate-400 hover:text-white hover:bg-slate-900/80 border border-transparent'
                      }`}
                      aria-label={tab.label}
                    >
                      {/* Active Left Indicator */}
                      {isParentActive && (
                        <span className="absolute left-0 top-2 bottom-2 w-1 rounded-r-full bg-cyan-400 shadow-[0_0_8px_#00f0ff]" />
                      )}

                      <Icon
                        className={`w-5 h-5 transition-transform duration-200 group-hover:scale-110 ${
                          isParentActive ? 'text-cyan-400' : 'text-slate-400 group-hover:text-slate-200'
                        }`}
                      />

                      {/* Small Subtle Live Indicator for Emergency Module */}
                      {tab.id === 'emergency' && (
                        <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-red-500 border border-slate-950 animate-ping" />
                      )}
                      {tab.id === 'emergency' && (
                        <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-red-500 border border-slate-950" />
                      )}

                      {/* Accessible Floating Glass Tooltip */}
                      <div className="absolute left-full ml-3 px-2.5 py-1.5 rounded-lg bg-slate-900/95 border border-cyan-500/40 text-white text-xs font-semibold whitespace-nowrap opacity-0 pointer-events-none group-hover:opacity-100 group-hover:scale-100 scale-95 transition-all duration-150 z-50 shadow-xl shadow-cyan-950/50 flex items-center gap-2">
                        <span>{tab.label}</span>
                        {tab.id === 'emergency' && (
                          <span className="text-[9px] font-bold px-1.5 py-0.2 rounded bg-red-500/30 text-red-300 border border-red-500/40">
                            LIVE
                          </span>
                        )}
                      </div>
                    </button>
                  </div>
                );
              }

              /* EXPANDED MODE ITEM */
              return (
                <div key={tab.id} className="flex flex-col">
                  {/* Parent Tab Button */}
                  <button
                    onClick={() => toggleTabExpansion(tab.id, hasSub)}
                    className={`group flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-semibold transition-all duration-200 ${
                      isParentActive
                        ? 'bg-gradient-to-r from-cyan-500/20 via-blue-600/10 to-transparent text-cyan-300 border border-cyan-500/40 shadow-sm shadow-cyan-500/10'
                        : 'text-slate-300 hover:text-white hover:bg-slate-900/70 border border-transparent'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <Icon
                        className={`w-4 h-4 transition-colors ${
                          isParentActive
                            ? 'text-cyan-400'
                            : 'text-slate-400 group-hover:text-slate-200'
                        }`}
                      />
                      <span className="tracking-tight">{tab.label}</span>
                    </div>

                    <div className="flex items-center gap-2">
                      {tab.badge && (
                        <span
                          className={`text-[9px] font-bold px-1.5 py-0.5 rounded uppercase tracking-wider ${
                            tab.badgeColor || 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30'
                          }`}
                        >
                          {tab.badge}
                        </span>
                      )}

                      {hasSub && (
                        <span className="text-slate-500 group-hover:text-slate-300 transition-transform duration-200">
                          {isExpanded ? (
                            <ChevronDown className="w-3.5 h-3.5 text-cyan-400" />
                          ) : (
                            <ChevronRight className="w-3.5 h-3.5" />
                          )}
                        </span>
                      )}
                    </div>
                  </button>

                  {/* Expandable Submenu for this Parent Tab */}
                  {hasSub && isExpanded && (
                    <div className="mt-1 ml-4 pl-3 border-l border-cyan-500/25 flex flex-col gap-0.5 animate-in fade-in slide-in-from-top-1 duration-200">
                      {tab.subOptions?.map((sub) => {
                        const isSubActive = isParentActive && activeSubTab === sub.id;
                        return (
                          <button
                            key={sub.id}
                            onClick={() => handleSubOptionClick(tab.id, sub.id)}
                            className={`flex items-center justify-between py-1.5 px-2.5 rounded-lg text-xs font-medium transition-all ${
                              isSubActive
                                ? 'bg-cyan-500/15 text-cyan-300 border border-cyan-500/40 font-semibold'
                                : 'text-slate-400 hover:text-white hover:bg-slate-900/50 border border-transparent'
                            }`}
                          >
                            <div className="flex items-center gap-2">
                              <span
                                className={`w-1.5 h-1.5 rounded-full transition-all ${
                                  isSubActive
                                    ? 'bg-cyan-400 shadow-[0_0_8px_#00f0ff]'
                                    : 'bg-slate-700'
                                }`}
                              />
                              <span className="truncate">{sub.label}</span>
                            </div>

                            {sub.badge && (
                              <span className="text-[9px] font-mono px-1.5 py-0.2 rounded bg-slate-800 text-slate-300 border border-slate-700">
                                {sub.badge}
                              </span>
                            )}
                          </button>
                        );
                      })}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Drawer Footer: Collapse / Expand Control */}
        <div className="pt-2 border-t border-slate-900 mt-2">
          {isSidebarExpanded ? (
            <button
              onClick={toggleSidebar}
              className="w-full flex items-center justify-between px-3 py-2 rounded-xl bg-slate-900/70 hover:bg-slate-900 border border-slate-800 hover:border-cyan-500/40 text-slate-400 hover:text-cyan-300 text-xs font-semibold transition group shadow-sm active:scale-95"
              title="Collapse to compact icon mode"
            >
              <div className="flex items-center gap-2">
                <ChevronLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform text-cyan-400" />
                <span>Collapse</span>
              </div>
              <span className="text-[10px] font-mono text-slate-500">Compact</span>
            </button>
          ) : (
            <div className="flex justify-center">
              <button
                onClick={toggleSidebar}
                className="w-11 h-11 rounded-xl bg-slate-900/70 hover:bg-slate-900 border border-slate-800 hover:border-cyan-500/40 text-slate-400 hover:text-cyan-300 flex items-center justify-center transition shadow-sm group relative active:scale-95"
                title="Expand sidebar"
                aria-label="Expand sidebar"
              >
                <ChevronRight className="w-4 h-4 group-hover:translate-x-0.5 transition-transform text-cyan-400" />
                <div className="absolute left-full ml-3 px-2.5 py-1.5 rounded-lg bg-slate-900/95 border border-cyan-500/40 text-cyan-200 text-xs font-semibold whitespace-nowrap opacity-0 pointer-events-none group-hover:opacity-100 scale-95 group-hover:scale-100 transition-all duration-150 z-50 shadow-xl shadow-cyan-950/50">
                  Expand Sidebar
                </div>
              </button>
            </div>
          )}
        </div>
      </aside>

      {/* MOBILE SLIDE-OUT DRAWER (Overlay) */}
      {isMobileMenuOpen && (
        <div
          className="lg:hidden fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex animate-in fade-in duration-200"
          onClick={() => setIsMobileMenuOpen(false)}
        >
          <div
            className="w-72 max-w-[85vw] bg-slate-950 border-r border-cyan-500/30 p-4 flex flex-col justify-between overflow-y-auto shadow-2xl animate-in slide-in-from-left duration-250"
            onClick={(e) => e.stopPropagation()}
          >
            <div>
              {/* Drawer Top Header */}
              <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-3">
                <button
                  onClick={() => {
                    setShowLandingPage(true);
                    setIsMobileMenuOpen(false);
                  }}
                  className="flex items-center gap-2 text-left"
                  title="Return to MediSphere 3D Landing Page"
                  aria-label="Return to MediSphere 3D Landing Page"
                >
                  <span className="text-red-400 font-black text-base">✚</span>
                  <div>
                    <span className="text-sm font-black text-white block leading-none">
                      MediSphere 3D
                    </span>
                    <span className="text-[9px] font-bold text-slate-400 tracking-wider uppercase block mt-0.5">
                      SMART HOSPITAL MANAGEMENT
                    </span>
                  </div>
                </button>
                <button
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-900"
                  aria-label="Close drawer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* 7 Main Tabs */}
              <div className="flex flex-col gap-1">
                {visibleTabs.map((tab) => {
                  const Icon = tab.icon;
                  const hasSub = !!tab.subOptions && tab.subOptions.length > 0;
                  const isExpanded = !!expandedTabs[tab.id];
                  const isParentActive = activeMainTab === tab.id;

                  return (
                    <div key={tab.id} className="flex flex-col">
                      <button
                        onClick={() => toggleTabExpansion(tab.id, hasSub)}
                        className={`flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-semibold transition ${
                          isParentActive
                            ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                            : 'text-slate-300 hover:text-white hover:bg-slate-900/70'
                        }`}
                      >
                        <div className="flex items-center gap-2.5">
                          <Icon className={`w-4 h-4 ${isParentActive ? 'text-cyan-400' : 'text-slate-400'}`} />
                          <span>{tab.label}</span>
                        </div>

                        <div className="flex items-center gap-2">
                          {tab.badge && (
                            <span className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-red-500/20 text-red-400 border border-red-500/40">
                              {tab.badge}
                            </span>
                          )}
                          {hasSub && (
                            <span>
                              {isExpanded ? (
                                <ChevronDown className="w-3.5 h-3.5 text-cyan-400" />
                              ) : (
                                <ChevronRight className="w-3.5 h-3.5 text-slate-500" />
                              )}
                            </span>
                          )}
                        </div>
                      </button>

                      {hasSub && isExpanded && (
                        <div className="mt-1 ml-4 pl-3 border-l border-cyan-500/25 flex flex-col gap-1">
                          {tab.subOptions?.map((sub) => {
                            const isSubActive = isParentActive && activeSubTab === sub.id;
                            return (
                              <button
                                key={sub.id}
                                onClick={() => handleSubOptionClick(tab.id, sub.id)}
                                className={`flex items-center gap-2 py-1.5 px-2 text-xs rounded-lg transition ${
                                  isSubActive
                                    ? 'bg-cyan-500/15 text-cyan-300 font-semibold'
                                    : 'text-slate-400 hover:text-white'
                                }`}
                              >
                                <span
                                  className={`w-1.5 h-1.5 rounded-full ${
                                    isSubActive ? 'bg-cyan-400' : 'bg-slate-700'
                                  }`}
                                />
                                <span>{sub.label}</span>
                              </button>
                            );
                          })}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Mobile Drawer Close button */}
            <div className="pt-3 border-t border-slate-900 mt-4">
              <button
                onClick={() => setIsMobileMenuOpen(false)}
                className="w-full flex items-center justify-center gap-2 py-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-400 hover:text-white text-xs font-semibold"
              >
                <X className="w-4 h-4" />
                <span>Close Menu</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
