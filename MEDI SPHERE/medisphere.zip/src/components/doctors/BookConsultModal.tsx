import React, { useState, useEffect, useMemo } from 'react';
import {
  Calendar,
  Clock,
  User,
  Stethoscope,
  MapPin,
  IndianRupee,
  X,
  CheckCircle2,
  AlertCircle,
  Star,
  RefreshCw,
  ShieldCheck,
} from 'lucide-react';
import { Doctor, Patient, Appointment, AppointmentType } from '../../types';

interface BookConsultModalProps {
  isOpen: boolean;
  doctor: Doctor | null;
  patients: Patient[];
  existingAppointments: Appointment[];
  onClose: () => void;
  onBook: (data: {
    patientId: string;
    doctorId: string;
    appointmentType: AppointmentType;
    date: string;
    timeSlot: string;
    notes?: string;
  }) => Appointment | null | Promise<Appointment | null>;
  onSuccess: (appointment: Appointment) => void;
}

// Helper to convert time strings like "08:30 AM" to total minutes from midnight
function parseTimeToMinutes(timeStr: string): number {
  const match = timeStr.trim().match(/(\d{1,2}):(\d{2})\s*(AM|PM)/i);
  if (!match) return 9 * 60; // 09:00 AM fallback
  let hours = parseInt(match[1], 10);
  const minutes = parseInt(match[2], 10);
  const period = match[3].toUpperCase();
  if (period === 'PM' && hours !== 12) hours += 12;
  if (period === 'AM' && hours === 12) hours = 0;
  return hours * 60 + minutes;
}

// Helper to format minutes to "hh:mm A"
function formatMinutesToTime(totalMinutes: number): string {
  let hours = Math.floor(totalMinutes / 60);
  const mins = totalMinutes % 60;
  const period = hours >= 12 ? 'PM' : 'AM';
  if (hours > 12) hours -= 12;
  if (hours === 0) hours = 12;
  const hStr = String(hours).padStart(2, '0');
  const mStr = String(mins).padStart(2, '0');
  return `${hStr}:${mStr} ${period}`;
}

// Generate 30-minute slots from doctor's actual time window
function generateSlotsFromWindow(timeWindow: string): string[] {
  if (!timeWindow || typeof timeWindow !== 'string') {
    return [
      '08:30 AM',
      '09:00 AM',
      '09:30 AM',
      '10:00 AM',
      '10:30 AM',
      '11:00 AM',
      '11:30 AM',
      '12:00 PM',
      '12:30 PM',
      '01:00 PM',
      '01:30 PM',
      '02:00 PM',
    ];
  }

  // Handle separators like - or – or — or "to"
  const parts = timeWindow.split(/[-–—]|to/i);
  if (parts.length < 2) {
    return [
      '08:30 AM',
      '09:00 AM',
      '09:30 AM',
      '10:00 AM',
      '10:30 AM',
      '11:00 AM',
      '11:30 AM',
      '12:00 PM',
      '12:30 PM',
      '01:00 PM',
      '01:30 PM',
      '02:00 PM',
    ];
  }

  const startMin = parseTimeToMinutes(parts[0]);
  const endMin = parseTimeToMinutes(parts[1]);

  if (endMin <= startMin) {
    return [
      '08:30 AM',
      '09:00 AM',
      '09:30 AM',
      '10:00 AM',
      '10:30 AM',
      '11:00 AM',
      '11:30 AM',
      '12:00 PM',
      '12:30 PM',
      '01:00 PM',
      '01:30 PM',
      '02:00 PM',
    ];
  }

  const slots: string[] = [];
  for (let m = startMin; m < endMin; m += 30) {
    slots.push(formatMinutesToTime(m));
  }

  return slots.length > 0
    ? slots
    : [
        '08:30 AM',
        '09:00 AM',
        '09:30 AM',
        '10:00 AM',
        '10:30 AM',
        '11:00 AM',
        '11:30 AM',
        '12:00 PM',
        '12:30 PM',
        '01:00 PM',
        '01:30 PM',
        '02:00 PM',
      ];
}

export const BookConsultModal: React.FC<BookConsultModalProps> = ({
  isOpen,
  doctor,
  patients,
  existingAppointments,
  onClose,
  onBook,
  onSuccess,
}) => {
  // Safe defaults
  const todayStr = useMemo(() => new Date().toISOString().split('T')[0], []);

  // Form states
  const [selectedPatientId, setSelectedPatientId] = useState<string>('');
  const [selectedDate, setSelectedDate] = useState<string>(todayStr);
  const [selectedTimeSlot, setSelectedTimeSlot] = useState<string>('');
  const [appointmentType, setAppointmentType] = useState<AppointmentType>('New Consultation');
  const [notes, setNotes] = useState<string>('');

  // UI state
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Doctor safe fields
  const doctorName = doctor?.name || 'Medical Specialist';
  const doctorId = doctor?.id || '';
  const specialization = doctor?.specialization || 'General Medicine';
  const qualification = doctor?.qualification || 'MBBS, MD';
  const cabinWing = doctor?.roomNumber || 'OPD-101';
  const fee = doctor?.consultationFee || 800;
  const timeWindow = doctor?.availableTimeSlot || doctor?.availability || '08:30 AM - 02:30 PM';
  const rating = doctor?.rating || 4.9;
  const experienceYears = doctor?.experienceYears || 15;

  // Generated time slots based on doctor's schedule
  const availableSlots = useMemo(() => {
    return generateSlotsFromWindow(timeWindow);
  }, [timeWindow]);

  // Pre-select first available slot and patient when doctor changes
  useEffect(() => {
    if (isOpen && doctor) {
      if (patients.length > 0 && !selectedPatientId) {
        setSelectedPatientId(patients[0].id);
      }
      if (availableSlots.length > 0) {
        setSelectedTimeSlot(availableSlots[0]);
      }
      setErrorMessage(null);
    }
  }, [isOpen, doctor, patients, availableSlots]);

  // Close on ESC key press
  useEffect(() => {
    if (!isOpen) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  // Prevent background scrolling when open
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isOpen]);

  if (!isOpen || !doctor) return null;

  // Check booked slots for this doctor on selected date
  const bookedSlotsOnDate = new Set(
    existingAppointments
      .filter(
        (apt) =>
          apt.doctorId === doctorId &&
          apt.date === selectedDate &&
          apt.status !== 'Cancelled'
      )
      .map((apt) => apt.timeSlot)
  );

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    // 1. Validate required fields
    if (!selectedPatientId) {
      setErrorMessage('Please select a registered patient to book consultation.');
      return;
    }

    if (!selectedDate) {
      setErrorMessage('Please select an appointment date.');
      return;
    }

    if (!selectedTimeSlot) {
      setErrorMessage('Please select a valid consultation time slot.');
      return;
    }

    if (bookedSlotsOnDate.has(selectedTimeSlot)) {
      setErrorMessage(
        `The time slot ${selectedTimeSlot} is already booked for Dr. ${doctorName}. Please select another time slot.`
      );
      return;
    }

    // 2. Prevent duplicate submission
    if (isSubmitting) return;

    setIsSubmitting(true);
    setErrorMessage(null);

    try {
      // 3. Save the appointment via callback
      const result = await onBook({
        patientId: selectedPatientId,
        doctorId,
        appointmentType,
        date: selectedDate,
        timeSlot: selectedTimeSlot,
        notes: notes.trim(),
      });

      if (result) {
        // 4. Close modal and trigger success callback
        setIsSubmitting(false);
        onClose();
        onSuccess(result);
      } else {
        setIsSubmitting(false);
        setErrorMessage('Unable to book appointment. Please try again.');
      }
    } catch (err: any) {
      setIsSubmitting(false);
      setErrorMessage(
        err?.message || 'Unable to book appointment. Please try again.'
      );
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-2xl animate-in fade-in"
      onClick={(e) => {
        if (e.target === e.currentTarget) {
          onClose();
        }
      }}
    >
      <div className="relative w-full max-w-xl rounded-3xl glass-modal border-cyan-500/40 p-6 sm:p-7 shadow-[0_25px_60px_rgba(0,0,0,0.9),0_0_40px_rgba(6,182,212,0.2)] overflow-y-auto max-h-[92vh] text-white">
        {/* Close Button ✕ */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-xl text-slate-300 hover:text-white hover:bg-slate-800/60 border border-cyan-500/20 transition flex items-center gap-1 text-xs"
          title="Close (ESC)"
        >
          <X className="w-4 h-4" />
          <span className="hidden sm:inline text-[11px] font-mono">Close</span>
        </button>

        {/* Modal Header */}
        <div className="flex items-center gap-3.5 mb-5 pr-16">
          <div className="w-12 h-12 rounded-2xl bg-cyan-500/20 border border-cyan-500/40 flex items-center justify-center text-cyan-300 shrink-0 shadow-[0_0_15px_rgba(6,182,212,0.3)]">
            <Calendar className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-lg font-black text-white tracking-tight">
                Book Consultation
              </h2>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 font-bold">
                OPD SCHEDULER
              </span>
            </div>
            <p className="text-xs text-slate-300 font-medium mt-0.5">
              Select patient, date, and doctor schedule slot to confirm booking.
            </p>
          </div>
        </div>

        {/* Automatically Populated Doctor Info Banner */}
        <div className="p-4 rounded-2xl bg-[rgba(6,18,45,0.7)] border border-cyan-500/30 mb-5 shadow-lg space-y-3">
          <div className="flex items-start justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-cyan-600 to-blue-700 flex items-center justify-center text-white font-black text-sm shadow-[0_0_10px_rgba(6,182,212,0.3)] border border-cyan-400/30">
                {doctorName.replace('Dr. ', '').charAt(0)}
              </div>
              <div>
                <h3 className="text-sm font-extrabold text-white flex items-center gap-1.5">
                  <span>{doctorName}</span>
                  <span className="text-[10px] font-mono text-cyan-300 font-normal">
                    ({doctorId})
                  </span>
                </h3>
                <span className="text-xs text-cyan-300 font-bold block">
                  {specialization}
                </span>
                <span className="text-[10px] text-slate-300 block font-mono">
                  {qualification}
                </span>
              </div>
            </div>

            <div className="text-right shrink-0">
              <span className="text-[10px] text-slate-400 block font-medium">
                Consultation Fee
              </span>
              <span className="font-mono text-base font-black text-emerald-300 flex items-center justify-end gap-0.5">
                <span>₹{fee.toLocaleString('en-IN')}</span>
              </span>
            </div>
          </div>

          <div className="pt-2 border-t border-cyan-500/15 grid grid-cols-2 sm:grid-cols-3 gap-2 text-xs text-slate-300">
            <div className="flex items-center gap-1.5">
              <MapPin className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
              <span className="truncate">
                Cabin: <strong className="text-white font-mono">{cabinWing}</strong>
              </span>
            </div>

            <div className="flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
              <span className="truncate" title={timeWindow}>
                Time: <strong className="text-cyan-200 font-mono text-[11px]">{timeWindow}</strong>
              </span>
            </div>

            <div className="flex items-center gap-1.5">
              <Star className="w-3.5 h-3.5 text-amber-400 fill-current shrink-0" />
              <span>
                Rating: <strong className="text-white">{rating}</strong> ({experienceYears} yrs)
              </span>
            </div>
          </div>
        </div>

        {/* Error Message with Retry */}
        {errorMessage && (
          <div className="p-3.5 rounded-2xl bg-red-950/60 border border-red-500/50 text-red-200 mb-5 flex items-start justify-between gap-3 text-xs animate-in fade-in">
            <div className="flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
              <div>
                <span className="font-bold block">Booking Error</span>
                <span className="text-[11px] opacity-90">{errorMessage}</span>
              </div>
            </div>
            <button
              type="button"
              onClick={handleSubmit}
              className="px-3 py-1 rounded-xl bg-red-500/30 hover:bg-red-500/40 border border-red-400/50 text-white text-xs font-bold transition flex items-center gap-1 shrink-0 active:scale-95"
            >
              <RefreshCw className="w-3 h-3" />
              <span>Retry</span>
            </button>
          </div>
        )}

        {/* Booking Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          {/* 1. Patient Selection */}
          <div>
            <label className="text-xs font-bold text-slate-200 block mb-1.5 flex items-center justify-between">
              <span className="flex items-center gap-1.5">
                <User className="w-3.5 h-3.5 text-cyan-400" />
                <span>Patient</span>
              </span>
              <span className="text-[10px] text-slate-400 font-mono">
                {patients.length} Registered
              </span>
            </label>
            <select
              value={selectedPatientId}
              onChange={(e) => setSelectedPatientId(e.target.value)}
              required
              className="w-full px-3.5 py-2.5 rounded-xl glass-input text-xs text-white cursor-pointer"
            >
              <option value="" disabled className="bg-slate-950 text-slate-400">
                -- Choose Registered Patient --
              </option>
              {patients.map((p) => (
                <option key={p.id} value={p.id} className="bg-slate-950 text-white">
                  {p.name} ({p.id}) &bull; {p.age} yrs &bull; {p.gender} &bull; {p.currentStatus}
                </option>
              ))}
            </select>
          </div>

          {/* 2. Date and Appointment Type Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            <div>
              <label className="text-xs font-bold text-slate-200 block mb-1.5 flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5 text-cyan-400" />
                <span>Consultation Date</span>
              </label>
              <input
                type="date"
                required
                min={todayStr}
                value={selectedDate}
                onChange={(e) => setSelectedDate(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl glass-input text-xs text-white"
              />
            </div>

            <div>
              <label className="text-xs font-bold text-slate-200 block mb-1.5 flex items-center gap-1.5">
                <Stethoscope className="w-3.5 h-3.5 text-cyan-400" />
                <span>Appointment Type</span>
              </label>
              <div className="grid grid-cols-2 gap-2">
                {(['New Consultation', 'Follow-up'] as AppointmentType[]).map((type) => {
                  const isSelected = appointmentType === type;
                  return (
                    <button
                      type="button"
                      key={type}
                      onClick={() => setAppointmentType(type)}
                      className={`py-2 px-2.5 rounded-xl text-xs font-bold transition border text-center ${
                        isSelected
                          ? 'bg-cyan-500/25 text-white border-cyan-400 shadow-[0_0_12px_rgba(6,182,212,0.3)]'
                          : 'glass-input text-slate-300 hover:text-white border-cyan-500/20'
                      }`}
                    >
                      {type}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          {/* 3. Available Time Slots */}
          <div>
            <label className="text-xs font-bold text-slate-200 block mb-1.5 flex items-center justify-between">
              <span className="flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-cyan-400" />
                <span>Available Time Slots ({timeWindow})</span>
              </span>
              <span className="text-[10px] text-cyan-300 font-mono">
                {availableSlots.length} Slots Generated
              </span>
            </label>

            <div className="grid grid-cols-3 sm:grid-cols-4 gap-2 max-h-48 overflow-y-auto p-2 rounded-xl bg-slate-900/60 border border-cyan-500/20">
              {availableSlots.map((slot) => {
                const isBooked = bookedSlotsOnDate.has(slot);
                const isSelected = selectedTimeSlot === slot;

                return (
                  <button
                    key={slot}
                    type="button"
                    disabled={isBooked}
                    onClick={() => setSelectedTimeSlot(slot)}
                    className={`py-2 px-2 rounded-xl text-xs font-mono font-bold transition text-center border relative ${
                      isBooked
                        ? 'opacity-35 cursor-not-allowed bg-slate-950 border-slate-800 text-slate-500 line-through'
                        : isSelected
                        ? 'bg-cyan-500/30 text-white border-cyan-400 shadow-[0_0_14px_rgba(6,182,212,0.4)]'
                        : 'bg-slate-900/80 hover:bg-cyan-500/15 text-slate-200 hover:text-white border-cyan-500/20'
                    }`}
                  >
                    <span>{slot}</span>
                    {isBooked && (
                      <span className="block text-[8px] uppercase tracking-wider text-red-400">
                        Booked
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          {/* 4. Optional Clinical Notes */}
          <div>
            <label className="text-xs font-bold text-slate-200 block mb-1">
              Chief Symptoms / Clinical Notes (Optional)
            </label>
            <input
              type="text"
              placeholder="e.g., Routine health checkup, mild chest tightness, prescription renewal..."
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="w-full px-3.5 py-2 rounded-xl glass-input text-xs text-white"
            />
          </div>

          {/* Modal Footer / Actions */}
          <div className="pt-4 border-t border-cyan-500/20 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl glass-btn-secondary text-xs font-bold text-slate-200 hover:text-white transition"
            >
              Cancel
            </button>

            <button
              type="submit"
              disabled={isSubmitting || !selectedTimeSlot || !selectedPatientId}
              className="px-6 py-2.5 rounded-xl glass-btn text-white text-xs font-extrabold shadow-[0_0_20px_rgba(6,182,212,0.35)] flex items-center gap-2 active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isSubmitting ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>Booking...</span>
                </>
              ) : (
                <>
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span>Confirm Appointment</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
