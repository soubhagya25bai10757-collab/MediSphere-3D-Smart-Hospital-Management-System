import React, { useEffect, useRef, useState } from 'react';
import {
  Heart,
  Activity,
  Zap,
  Shield,
  Dna,
  Brain,
  Thermometer,
  Radio,
  Sparkles,
} from 'lucide-react';

export const HolographicHuman: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [pulseRate, setPulseRate] = useState(74);
  const [spo2, setSpo2] = useState(99);
  const [bpSys, setBpSys] = useState(120);
  const [bpDia, setBpDia] = useState(80);
  const [scanProgress, setScanProgress] = useState(0);

  // Animate ECG waveform on canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationId: number;
    let offset = 0;

    const render = () => {
      const w = canvas.width;
      const h = canvas.height;
      ctx.clearRect(0, 0, w, h);

      // Background subtle grid
      ctx.strokeStyle = 'rgba(6, 182, 212, 0.08)';
      ctx.lineWidth = 1;
      const gridSize = 16;
      for (let x = 0; x < w; x += gridSize) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, h);
        ctx.stroke();
      }
      for (let y = 0; y < h; y += gridSize) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(w, y);
        ctx.stroke();
      }

      // ECG Waveform path
      ctx.beginPath();
      ctx.strokeStyle = '#00f0ff';
      ctx.lineWidth = 2;
      ctx.shadowColor = '#00f0ff';
      ctx.shadowBlur = 8;

      const baseline = h / 2;
      offset += 1.8;

      for (let x = 0; x < w; x++) {
        const cycle = (x + offset) % 180;
        let y = baseline;

        if (cycle > 40 && cycle < 50) {
          // P wave
          y -= Math.sin(((cycle - 40) / 10) * Math.PI) * 7;
        } else if (cycle > 60 && cycle < 65) {
          // Q dip
          y += 5;
        } else if (cycle >= 65 && cycle < 75) {
          // R spike
          y -= Math.sin(((cycle - 65) / 10) * Math.PI) * 28;
        } else if (cycle >= 75 && cycle < 82) {
          // S dip
          y += 9;
        } else if (cycle > 95 && cycle < 115) {
          // T wave
          y -= Math.sin(((cycle - 95) / 20) * Math.PI) * 11;
        }

        if (x === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.stroke();

      // Sweeping pulse dot
      const leadX = (offset * 1.5) % w;
      ctx.beginPath();
      ctx.arc(leadX, baseline - 4, 3, 0, Math.PI * 2);
      ctx.fillStyle = '#ffffff';
      ctx.shadowColor = '#00f0ff';
      ctx.shadowBlur = 12;
      ctx.fill();

      animationId = requestAnimationFrame(render);
    };

    render();

    return () => cancelAnimationFrame(animationId);
  }, []);

  // Subtle natural biometric telemetry fluctuations
  useEffect(() => {
    const timer = setInterval(() => {
      setPulseRate(72 + Math.floor(Math.random() * 5));
      setScanProgress((prev) => (prev + 3) % 100);
      setSpo2(98 + (Math.random() > 0.6 ? 1 : 0));
    }, 2400);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="relative w-full max-w-lg mx-auto p-6 rounded-3xl bg-gradient-to-b from-slate-900/90 via-slate-950/95 to-slate-900/90 border border-cyan-500/30 backdrop-blur-2xl shadow-2xl overflow-hidden group">
      {/* Ambient background glow */}
      <div className="absolute -top-24 -right-24 w-64 h-64 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute -bottom-24 -left-24 w-64 h-64 bg-blue-600/10 rounded-full blur-3xl pointer-events-none" />

      {/* Header Telemetry Bar */}
      <div className="flex items-center justify-between pb-4 border-b border-cyan-500/20 mb-4">
        <div className="flex items-center gap-2">
          <div className="w-2.5 h-2.5 rounded-full bg-cyan-400 animate-ping" />
          <span className="text-xs font-bold text-cyan-300 tracking-wider uppercase">
            Holographic Patient Telemetry
          </span>
        </div>
        <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-cyan-950/80 text-cyan-400 border border-cyan-500/40">
          SCAN ACTIVE &bull; 99.4% INTEGRITY
        </span>
      </div>

      {/* Main Hologram Stage: Human Silhouette & Floating HUD */}
      <div className="relative flex items-center justify-center py-4 min-h-[300px]">
        {/* Scanning Laser Line */}
        <div
          className="absolute left-4 right-4 h-[2px] bg-gradient-to-r from-transparent via-cyan-400 to-transparent shadow-[0_0_12px_#00f0ff] pointer-events-none transition-all duration-700 ease-linear"
          style={{ top: `${15 + scanProgress * 0.7}%` }}
        />

        {/* Central Futuristic Anatomical SVG Wireframe */}
        <div className="relative w-48 h-72 flex items-center justify-center">
          <svg
            viewBox="0 0 200 360"
            className="w-full h-full text-cyan-400 filter drop-shadow-[0_0_12px_rgba(0,240,255,0.4)]"
            fill="none"
            stroke="currentColor"
          >
            {/* Hologram Head */}
            <circle cx="100" cy="40" r="22" strokeWidth="1.5" strokeDasharray="3 2" />
            <circle cx="100" cy="40" r="16" strokeWidth="1" strokeOpacity="0.4" />
            <circle cx="100" cy="38" r="3" fill="#00f0ff" />

            {/* Brain Neural Nodes */}
            <path
              d="M92,34 Q100,28 108,34 Q100,46 92,34"
              stroke="#38bdf8"
              strokeWidth="1.2"
              fill="rgba(56, 189, 248, 0.15)"
            />

            {/* Neck */}
            <line x1="95" y1="62" x2="95" y2="76" strokeWidth="1.5" strokeOpacity="0.6" />
            <line x1="105" y1="62" x2="105" y2="76" strokeWidth="1.5" strokeOpacity="0.6" />

            {/* Torso Outline */}
            <path
              d="M70,80 L130,80 L122,180 L78,180 Z"
              strokeWidth="1.5"
              strokeDasharray="4 2"
              fill="rgba(6, 182, 212, 0.05)"
            />

            {/* Ribcage Structure Lines */}
            <path d="M78,100 Q100,110 122,100" strokeWidth="1" strokeOpacity="0.6" />
            <path d="M80,116 Q100,126 120,116" strokeWidth="1" strokeOpacity="0.6" />
            <path d="M82,132 Q100,142 118,132" strokeWidth="1" strokeOpacity="0.6" />

            {/* Spine Axis */}
            <line x1="100" y1="76" x2="100" y2="180" strokeWidth="1.5" strokeDasharray="2 3" stroke="#38bdf8" />

            {/* Glowing Heart Organ Node */}
            <g className="animate-pulse">
              <circle cx="108" cy="112" r="7" fill="#ef4444" fillOpacity="0.85" />
              <circle cx="108" cy="112" r="12" stroke="#ef4444" strokeWidth="1" strokeOpacity="0.5" />
              <circle cx="108" cy="112" r="18" stroke="#ef4444" strokeWidth="0.8" strokeDasharray="2 2" strokeOpacity="0.3" />
            </g>

            {/* Arms & Hands */}
            <path d="M70,80 L42,140 L34,200" strokeWidth="1.5" strokeOpacity="0.7" />
            <path d="M130,80 L158,140 L166,200" strokeWidth="1.5" strokeOpacity="0.7" />
            <circle cx="34" cy="200" r="3" fill="#38bdf8" />
            <circle cx="166" cy="200" r="3" fill="#38bdf8" />

            {/* Pelvis & Legs */}
            <path d="M78,180 L70,265 L66,340" strokeWidth="1.5" strokeOpacity="0.8" />
            <path d="M122,180 L130,265 L134,340" strokeWidth="1.5" strokeOpacity="0.8" />
            <circle cx="66" cy="340" r="3.5" fill="#00f0ff" />
            <circle cx="134" cy="340" r="3.5" fill="#00f0ff" />

            {/* Concentric Holo-Rings Under Feet */}
            <ellipse cx="100" cy="345" rx="55" ry="12" stroke="#00f0ff" strokeWidth="1" strokeOpacity="0.4" />
            <ellipse cx="100" cy="345" rx="35" ry="7" stroke="#38bdf8" strokeWidth="1" strokeOpacity="0.6" strokeDasharray="3 2" />
          </svg>
        </div>

        {/* Floating Biomarker Callout 1: Heart Telemetry */}
        <div className="absolute top-6 left-0 sm:-left-2 p-2.5 rounded-xl bg-slate-950/85 border border-red-500/40 backdrop-blur-md shadow-lg shadow-red-500/10 flex items-center gap-2.5 animate-pulse">
          <div className="w-7 h-7 rounded-lg bg-red-500/20 border border-red-500/50 flex items-center justify-center text-red-400">
            <Heart className="w-3.5 h-3.5" />
          </div>
          <div>
            <div className="flex items-center gap-1">
              <span className="text-xs font-black text-white">{pulseRate}</span>
              <span className="text-[9px] text-red-300">BPM</span>
            </div>
            <span className="text-[9px] text-slate-400 block">Normal Sinus</span>
          </div>
        </div>

        {/* Floating Biomarker Callout 2: Brain Neural Activity */}
        <div className="absolute top-4 right-0 sm:-right-2 p-2.5 rounded-xl bg-slate-950/85 border border-cyan-500/40 backdrop-blur-md shadow-lg shadow-cyan-500/10 flex items-center gap-2.5">
          <div className="w-7 h-7 rounded-lg bg-cyan-500/20 border border-cyan-500/50 flex items-center justify-center text-cyan-400">
            <Brain className="w-3.5 h-3.5" />
          </div>
          <div>
            <div className="flex items-center gap-1">
              <span className="text-xs font-black text-white">99.8%</span>
              <span className="text-[9px] text-cyan-300">NEURAL</span>
            </div>
            <span className="text-[9px] text-slate-400 block">Alpha Synchrony</span>
          </div>
        </div>

        {/* Floating Biomarker Callout 3: SpO2 Oxygenation */}
        <div className="absolute bottom-16 left-0 sm:-left-2 p-2.5 rounded-xl bg-slate-950/85 border border-blue-500/40 backdrop-blur-md shadow-lg shadow-blue-500/10 flex items-center gap-2.5">
          <div className="w-7 h-7 rounded-lg bg-blue-500/20 border border-blue-500/50 flex items-center justify-center text-blue-400">
            <Activity className="w-3.5 h-3.5" />
          </div>
          <div>
            <div className="flex items-center gap-1">
              <span className="text-xs font-black text-white">{spo2}%</span>
              <span className="text-[9px] text-blue-300">SpO2</span>
            </div>
            <span className="text-[9px] text-slate-400 block">O2 Saturation</span>
          </div>
        </div>

        {/* Floating Biomarker Callout 4: Blood Pressure */}
        <div className="absolute bottom-14 right-0 sm:-right-2 p-2.5 rounded-xl bg-slate-950/85 border border-emerald-500/40 backdrop-blur-md shadow-lg shadow-emerald-500/10 flex items-center gap-2.5">
          <div className="w-7 h-7 rounded-lg bg-emerald-500/20 border border-emerald-500/50 flex items-center justify-center text-emerald-400">
            <Zap className="w-3.5 h-3.5" />
          </div>
          <div>
            <div className="flex items-center gap-1">
              <span className="text-xs font-black text-white">{bpSys}/{bpDia}</span>
              <span className="text-[9px] text-emerald-300">mmHg</span>
            </div>
            <span className="text-[9px] text-slate-400 block">Hemodynamic</span>
          </div>
        </div>
      </div>

      {/* Live ECG Canvas Monitor */}
      <div className="mt-4 pt-3 border-t border-cyan-500/20">
        <div className="flex items-center justify-between mb-1.5 px-1">
          <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider flex items-center gap-1">
            <Radio className="w-3 h-3 text-cyan-400 animate-pulse" />
            Lead II Telemetric Cardiac Monitor
          </span>
          <span className="text-[10px] font-mono text-cyan-400">25 mm/s &bull; 10 mm/mV</span>
        </div>
        <div className="rounded-xl bg-slate-950/90 border border-cyan-500/30 p-1">
          <canvas ref={canvasRef} width={420} height={52} className="w-full h-12 block" />
        </div>
      </div>
    </div>
  );
};
