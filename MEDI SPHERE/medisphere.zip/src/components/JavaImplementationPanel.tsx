import React, { useState } from 'react';
import {
  Code2,
  Box,
  ShieldCheck,
  GitBranch,
  Layers,
  AlertOctagon,
  Database,
  CheckCircle2,
  Copy,
  Check,
  ChevronDown,
  ChevronUp,
  FileCode,
  Terminal,
  ArrowDown,
  Sparkles,
} from 'lucide-react';

export const JavaImplementationPanel: React.FC = () => {
  const [copiedCmd, setCopiedCmd] = useState<boolean>(false);
  const [selectedFile, setSelectedFile] = useState<string>('Main.java');
  const [showCodeViewer, setShowCodeViewer] = useState<boolean>(false);
  const [copiedCode, setCopiedCode] = useState<boolean>(false);

  const compileCommand = 'javac -d bin src/model/*.java src/exception/*.java src/service/*.java src/Main.java && java -cp bin Main';

  const copyToClipboard = (text: string, isCode = false) => {
    navigator.clipboard.writeText(text);
    if (isCode) {
      setCopiedCode(true);
      setTimeout(() => setCopiedCode(false), 2000);
    } else {
      setCopiedCmd(true);
      setTimeout(() => setCopiedCmd(false), 2000);
    }
  };

  const concepts = [
    {
      id: 'classes',
      title: 'CLASSES & OBJECTS',
      summary: 'Patient, Doctor and Appointment are represented as Java classes.',
      details: 'Instantiated using constructors with real hospital parameters (e.g. patientId, bloodGroup, specialization, consultationFee).',
      icon: Box,
      tag: 'model.Patient / Doctor / Appointment',
      badgeColor: 'border-cyan-500/40 text-cyan-300 bg-cyan-500/10',
      borderColor: 'border-cyan-500/30',
      iconBg: 'bg-cyan-500/15 text-cyan-400',
    },
    {
      id: 'encapsulation',
      title: 'ENCAPSULATION',
      summary: 'Patient and doctor information is protected using private fields.',
      details: 'Getters and setters enforce validation: age cannot be negative, name cannot be empty, consultation fee cannot be negative.',
      icon: ShieldCheck,
      tag: 'private fields + defensive setters',
      badgeColor: 'border-indigo-500/40 text-indigo-300 bg-indigo-500/10',
      borderColor: 'border-indigo-500/30',
      iconBg: 'bg-indigo-500/15 text-indigo-400',
    },
    {
      id: 'inheritance',
      title: 'INHERITANCE',
      summary: 'Specialized doctors inherit common properties from Doctor.',
      details: 'Cardiologist, Dentist, Neurologist, and OrthopedicDoctor extend Doctor using "extends Doctor" and constructor chaining with super(...).',
      icon: GitBranch,
      tag: 'extends Doctor + super(...)',
      badgeColor: 'border-purple-500/40 text-purple-300 bg-purple-500/10',
      borderColor: 'border-purple-500/30',
      iconBg: 'bg-purple-500/15 text-purple-400',
    },
    {
      id: 'polymorphism',
      title: 'POLYMORPHISM',
      summary: 'Different specialists override consultationDetails().',
      details: 'Dynamic method dispatch: Doctor references call overridden consultationDetails() yielding Cardiology, Dental, or Neurology specifics at runtime.',
      icon: Layers,
      tag: 'Dynamic Method Overriding',
      badgeColor: 'border-amber-500/40 text-amber-300 bg-amber-500/10',
      borderColor: 'border-amber-500/30',
      iconBg: 'bg-amber-500/15 text-amber-400',
    },
    {
      id: 'exceptions',
      title: 'EXCEPTION HANDLING',
      summary: 'Invalid appointment operations are handled using custom exceptions.',
      details: 'Custom checked AppointmentException handles clinical violations (slot conflict, unregistered patient, unassigned doctor) via try-catch-throw-throws.',
      icon: AlertOctagon,
      tag: 'AppointmentException + try-catch',
      badgeColor: 'border-rose-500/40 text-rose-300 bg-rose-500/10',
      borderColor: 'border-rose-500/30',
      iconBg: 'bg-rose-500/15 text-rose-400',
    },
    {
      id: 'collections',
      title: 'ARRAYLIST COLLECTIONS',
      summary: 'Hospital records are managed using ArrayList.',
      details: 'HospitalService manages ArrayList<Patient>, ArrayList<Doctor>, and ArrayList<Appointment> with search, filter, and display loops.',
      icon: Database,
      tag: 'ArrayList<T> in HospitalService',
      badgeColor: 'border-emerald-500/40 text-emerald-300 bg-emerald-500/10',
      borderColor: 'border-emerald-500/30',
      iconBg: 'bg-emerald-500/15 text-emerald-400',
    },
  ];

  const javaSourceSnippets: Record<string, { desc: string; code: string }> = {
    'Main.java': {
      desc: 'Driver program orchestrating and testing all six Java concepts',
      code: `// File: java/src/Main.java
import model.*;
import exception.AppointmentException;
import service.HospitalService;

public class Main {
    public static void main(String[] args) {
        HospitalService hospital = new HospitalService("MediSphere 3D Central Command");

        // 1. CLASSES & OBJECTS: Object creation using constructors
        Patient p1 = new Patient(101, "Eleanor Vance", 34, "A+", "+1-555-0192");
        Doctor cardio = new Cardiologist(201, "Dr. Aria Thorne", 14, 250.00, true, 310);

        // 2. ENCAPSULATION: Validation in setters
        try {
            p1.setAge(-15); // Rejects negative age
        } catch (IllegalArgumentException ex) {
            System.out.println("Validation Handled: " + ex.getMessage());
        }

        // 3. INHERITANCE: Cardiologist is-a Doctor (extends Doctor)
        // 4. POLYMORPHISM: Dynamic dispatch via Doctor reference
        Doctor docRef = cardio;
        System.out.println(docRef.consultationDetails()); // Calls overridden Cardiologist method

        // 6. COLLECTIONS: Storing entities in ArrayList
        hospital.addPatient(p1);
        hospital.addDoctor(cardio);

        // 5. EXCEPTION HANDLING: Checked exception enforcement
        try {
            Appointment appt = new Appointment(501, p1, cardio, "2026-09-15", "10:00 AM", "Cardio Screening");
            hospital.bookAppointment(appt);
            // Attempting duplicate booking throws AppointmentException
            hospital.bookAppointment(appt);
        } catch (AppointmentException e) {
            System.out.println("Caught Expected Clinical Exception: " + e.getMessage());
        }
    }
}`,
    },
    'Patient.java': {
      desc: 'Entity demonstrating Encapsulation with private fields and validation',
      code: `// File: java/src/model/Patient.java
package model;

public class Patient {
    private int patientId;
    private String name;
    private int age;
    private String bloodGroup;
    private String phone;

    public Patient(int patientId, String name, int age, String bloodGroup, String phone) {
        setPatientId(patientId);
        setName(name);
        setAge(age);
        setBloodGroup(bloodGroup);
        setPhone(phone);
    }

    // Encapsulation: Validated Setters
    public void setAge(int age) {
        if (age < 0 || age > 140) {
            throw new IllegalArgumentException("Patient age must be between 0 and 140. Given: " + age);
        }
        this.age = age;
    }

    public void setName(String name) {
        if (name == null || name.trim().isEmpty()) {
            throw new IllegalArgumentException("Patient name cannot be null or empty.");
        }
        this.name = name.trim();
    }

    public int getPatientId() { return patientId; }
    public String getName() { return name; }
    public int getAge() { return age; }
    public String getBloodGroup() { return bloodGroup; }
    public String getPhone() { return phone; }
}`,
    },
    'Doctor.java': {
      desc: 'Superclass demonstrating base fields, encapsulation, and polymorphic base method',
      code: `// File: java/src/model/Doctor.java
package model;

public class Doctor {
    private int doctorId;
    private String name;
    private String specialization;
    private int experience;
    private double consultationFee;

    public Doctor(int doctorId, String name, String specialization, int experience, double consultationFee) {
        setDoctorId(doctorId);
        setName(name);
        setSpecialization(specialization);
        setExperience(experience);
        setConsultationFee(consultationFee);
    }

    // Polymorphic method overridden by subclasses
    public String consultationDetails() {
        return String.format("[General Consultation] Dr. %s conducts standard triage. Fee: $%.2f", name, consultationFee);
    }

    public int getDoctorId() { return doctorId; }
    public String getName() { return name; }
    public String getSpecialization() { return specialization; }
    public int getExperience() { return experience; }
    public double getConsultationFee() { return consultationFee; }
}`,
    },
    'Cardiologist.java': {
      desc: 'Subclass demonstrating Inheritance (extends Doctor, super(...)) and Polymorphism',
      code: `// File: java/src/model/Cardiologist.java
package model;

public class Cardiologist extends Doctor {
    private boolean ecgCertified;
    private int cardiacSurgeriesPerformed;

    public Cardiologist(int doctorId, String name, int experience, double consultationFee,
                        boolean ecgCertified, int cardiacSurgeriesPerformed) {
        super(doctorId, name, "Cardiology", experience, consultationFee);
        this.ecgCertified = ecgCertified;
        this.cardiacSurgeriesPerformed = cardiacSurgeriesPerformed;
    }

    // Method Overriding (Polymorphism)
    @Override
    public String consultationDetails() {
        return String.format(
            "[Cardiology Consultation] Dr. %s conducts 12-lead ECG & echocardiogram (Surgeries: %d). Fee: $%.2f",
            getName(), cardiacSurgeriesPerformed, getConsultationFee()
        );
    }
}`,
    },
    'AppointmentException.java': {
      desc: 'Custom checked exception for hospital clinical rule validation',
      code: `// File: java/src/exception/AppointmentException.java
package exception;

public class AppointmentException extends Exception {
    private String errorCode;

    public AppointmentException(String message) {
        super(message);
        this.errorCode = "APPT_ERR";
    }

    public AppointmentException(String errorCode, String message) {
        super(String.format("[%s] %s", errorCode, message));
        this.errorCode = errorCode;
    }

    public String getErrorCode() {
        return errorCode;
    }
}`,
    },
    'HospitalService.java': {
      desc: 'Central service using Collections (ArrayList) and Exception Handling',
      code: `// File: java/src/service/HospitalService.java
package service;

import model.*;
import exception.AppointmentException;
import java.util.ArrayList;

public class HospitalService {
    private ArrayList<Patient> patients = new ArrayList<>();
    private ArrayList<Doctor> doctors = new ArrayList<>();
    private ArrayList<Appointment> appointments = new ArrayList<>();

    // 6. ArrayList operations
    public void addPatient(Patient p) { patients.add(p); }
    public void addDoctor(Doctor d) { doctors.add(d); }

    // 5. Checked Exception validation
    public void bookAppointment(Appointment appt) throws AppointmentException {
        if (appt == null) throw new AppointmentException("APPT_NULL", "Appointment cannot be null.");
        if (appt.getPatient() == null) throw new AppointmentException("INVALID_PATIENT", "Patient required.");
        
        // Slot conflict check across ArrayList
        for (Appointment existing : appointments) {
            if (existing.getDoctor().getDoctorId() == appt.getDoctor().getDoctorId()
                && existing.getDate().equals(appt.getDate())
                && existing.getTime().equals(appt.getTime())) {
                throw new AppointmentException("SLOT_UNAVAILABLE", "Doctor already booked at this slot.");
            }
        }
        appointments.add(appt);
    }
}`,
    },
  };

  return (
    <div
      id="java-implementation-panel"
      className="p-5 sm:p-6 rounded-3xl bg-[rgba(10,25,60,0.75)] border border-cyan-500/30 backdrop-blur-xl shadow-[0_0_30px_rgba(6,182,212,0.15)] space-y-6 animate-in fade-in duration-300"
    >
      {/* Panel Header */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-4 border-b border-cyan-500/20">
        <div className="space-y-1">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-[10px] uppercase font-bold tracking-widest text-cyan-300 px-2.5 py-0.5 rounded-full bg-cyan-500/15 border border-cyan-400/40 flex items-center gap-1.5 shadow-sm">
              <Code2 className="w-3.5 h-3.5 text-cyan-400" />
              VIT Bhopal &bull; Programming in Java
            </span>
            <span className="text-[10px] font-mono text-emerald-300 bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/30 flex items-center gap-1">
              <CheckCircle2 className="w-3 h-3 text-emerald-400" />
              Compilable Java Module (/java/src)
            </span>
          </div>
          <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight flex items-center gap-2.5">
            <span className="bg-gradient-to-r from-cyan-300 via-indigo-200 to-purple-300 bg-clip-text text-transparent">
              Java Implementation
            </span>
          </h2>
          <p className="text-xs text-slate-300 max-w-3xl leading-relaxed">
            Genuine Java SE codebase implementing the six syllabus concepts for hospital clinical workflows.
            Real <code className="text-cyan-300 bg-slate-900/80 px-1 py-0.5 rounded border border-cyan-500/30 font-mono text-[11px]">.java</code> source
            files are organized in <code className="text-indigo-300 bg-slate-900/80 px-1 py-0.5 rounded border border-indigo-500/30 font-mono text-[11px]">model</code>, <code className="text-rose-300 bg-slate-900/80 px-1 py-0.5 rounded border border-rose-500/30 font-mono text-[11px]">exception</code>, and <code className="text-emerald-300 bg-slate-900/80 px-1 py-0.5 rounded border border-emerald-500/30 font-mono text-[11px]">service</code> packages inside the repository.
          </p>
        </div>

        {/* Quick Compilation Terminal Box */}
        <div className="p-3 rounded-2xl bg-slate-950/80 border border-cyan-500/25 shadow-inner flex flex-col gap-1.5 max-w-md w-full shrink-0">
          <div className="flex items-center justify-between text-[11px] font-mono text-slate-400">
            <span className="flex items-center gap-1 text-cyan-300 font-bold">
              <Terminal className="w-3.5 h-3.5 text-cyan-400" />
              Terminal Compilation
            </span>
            <button
              onClick={() => copyToClipboard(compileCommand)}
              className="inline-flex items-center gap-1 text-[10px] text-slate-300 hover:text-white px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 transition cursor-pointer"
              title="Copy compile command"
            >
              {copiedCmd ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
              <span>{copiedCmd ? 'Copied' : 'Copy'}</span>
            </button>
          </div>
          <div className="text-[10px] font-mono text-cyan-200 bg-slate-900/90 p-2 rounded-lg border border-cyan-500/20 overflow-x-auto whitespace-nowrap">
            {compileCommand}
          </div>
        </div>
      </div>

      {/* Six Compact Cards */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <span className="text-xs uppercase font-extrabold tracking-wider text-slate-300 flex items-center gap-2">
            <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
            Six Major Java Concepts in MediSphere
          </span>
          <span className="text-[11px] font-mono text-slate-400">
            Click &ldquo;View Source Code&rdquo; below to inspect compilable .java files
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
          {concepts.map((concept) => {
            const Icon = concept.icon;
            return (
              <div
                key={concept.id}
                className={`p-4 rounded-2xl bg-[rgba(6,18,45,0.7)] border ${concept.borderColor} shadow-lg hover:shadow-[0_0_15px_rgba(6,182,212,0.2)] transition-all flex flex-col justify-between group relative overflow-hidden`}
              >
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <div className={`w-8 h-8 rounded-xl flex items-center justify-center ${concept.iconBg} shadow-inner`}>
                      <Icon className="w-4 h-4" />
                    </div>
                    <span className={`text-[9px] font-mono font-bold px-2 py-0.5 rounded-full border ${concept.badgeColor}`}>
                      {concept.tag}
                    </span>
                  </div>

                  <h3 className="text-xs font-black text-white tracking-wide uppercase">
                    {concept.title}
                  </h3>

                  <p className="text-xs font-semibold text-cyan-200/90 leading-snug">
                    {concept.summary}
                  </p>

                  <p className="text-[11px] text-slate-300 leading-relaxed font-normal">
                    {concept.details}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* ========================================================
          JAVA ARCHITECTURE VIEW (Compact Glass Architecture Diagram)
          ======================================================== */}
      <div className="p-4 sm:p-5 rounded-2xl bg-slate-950/70 border border-cyan-500/25 shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <h3 className="text-sm font-extrabold text-white flex items-center gap-2">
              <Layers className="w-4 h-4 text-cyan-400" />
              Java Architecture View & Component Diagram
            </h3>
            <span className="text-[11px] text-slate-400">
              Clean visual schema demonstrating model association, collection containers, and exception flow.
            </span>
          </div>

          <button
            onClick={() => setShowCodeViewer(!showCodeViewer)}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 hover:text-white border border-cyan-500/40 text-xs font-bold transition shadow-sm cursor-pointer self-start sm:self-auto"
          >
            <FileCode className="w-3.5 h-3.5 text-cyan-400" />
            <span>{showCodeViewer ? 'Hide Java Source Inspector' : 'Inspect .java Source Code'}</span>
            {showCodeViewer ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
          </button>
        </div>

        {/* Compact Glass Architecture Diagram Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 pt-1">
          {/* Column 1: Doctor Inheritance Hierarchy */}
          <div className="p-4 rounded-xl bg-[rgba(6,18,45,0.65)] border border-purple-500/20 shadow-md flex flex-col items-center text-center">
            <span className="text-[10px] font-mono uppercase tracking-wider text-purple-300 font-bold mb-3 px-2 py-0.5 rounded bg-purple-950/60 border border-purple-800">
              Doctor Inheritance Hierarchy
            </span>

            <div className="w-full space-y-2 text-xs font-mono font-bold">
              <div className="p-2.5 rounded-lg bg-slate-900 border border-purple-500/50 text-purple-200 shadow-sm">
                Doctor (Parent Superclass)
                <span className="block text-[9px] text-slate-400 font-normal">doctorId, name, specialization, fee</span>
              </div>
              <ArrowDown className="w-4 h-4 text-purple-400 mx-auto" />

              <div className="grid grid-cols-2 gap-1.5 text-[10px]">
                <div className="p-1.5 rounded-md bg-purple-950/30 border border-purple-500/30 text-purple-300">
                  Cardiologist
                </div>
                <div className="p-1.5 rounded-md bg-purple-950/30 border border-purple-500/30 text-purple-300">
                  Dentist
                </div>
                <div className="p-1.5 rounded-md bg-purple-950/30 border border-purple-500/30 text-purple-300">
                  Neurologist
                </div>
                <div className="p-1.5 rounded-md bg-purple-950/30 border border-purple-500/30 text-purple-300">
                  OrthopedicDoctor
                </div>
              </div>
              <div className="text-[9px] text-slate-400 font-normal italic pt-1">
                Overrides consultationDetails() via dynamic method dispatch
              </div>
            </div>
          </div>

          {/* Column 2: HospitalService ArrayList Collections */}
          <div className="p-4 rounded-xl bg-[rgba(6,18,45,0.65)] border border-emerald-500/20 shadow-md flex flex-col items-center text-center">
            <span className="text-[10px] font-mono uppercase tracking-wider text-emerald-300 font-bold mb-3 px-2 py-0.5 rounded bg-emerald-950/60 border border-emerald-800">
              Collections Storage
            </span>

            <div className="w-full space-y-2 text-xs font-mono font-bold">
              <div className="p-2.5 rounded-lg bg-slate-900 border border-emerald-500/50 text-emerald-200 shadow-sm">
                HospitalService
                <span className="block text-[9px] text-slate-400 font-normal">Central Service & Storage Coordinator</span>
              </div>

              <ArrowDown className="w-4 h-4 text-emerald-400 mx-auto" />

              <div className="space-y-1.5 text-[11px]">
                <div className="p-1.5 rounded-md bg-emerald-950/30 border border-emerald-500/40 text-emerald-200">
                  ArrayList&lt;Patient&gt;
                </div>
                <div className="p-1.5 rounded-md bg-emerald-950/30 border border-emerald-500/40 text-emerald-200">
                  ArrayList&lt;Doctor&gt;
                </div>
                <div className="p-1.5 rounded-md bg-emerald-950/30 border border-emerald-500/40 text-emerald-200">
                  ArrayList&lt;Appointment&gt;
                </div>
              </div>
              <div className="text-[9px] text-slate-400 font-normal italic pt-1">
                Managed via addPatient(), addDoctor(), bookAppointment()
              </div>
            </div>
          </div>

          {/* Column 3: Exception Handling Separate Flow */}
          <div className="p-4 rounded-xl bg-[rgba(6,18,45,0.65)] border border-rose-500/20 shadow-md flex flex-col items-center text-center">
            <span className="text-[10px] font-mono uppercase tracking-wider text-rose-300 font-bold mb-3 px-2 py-0.5 rounded bg-rose-950/60 border border-rose-800">
              Exception Handling Flow
            </span>

            <div className="w-full space-y-2 text-xs font-mono font-bold">
              <div className="p-2.5 rounded-lg bg-slate-900 border border-indigo-500/40 text-white shadow-sm">
                Appointment
                <span className="block text-[9px] text-slate-400 font-normal">Hospital Booking Operation</span>
              </div>

              <ArrowDown className="w-4 h-4 text-rose-400 mx-auto" />

              <div className="p-2 rounded-lg bg-rose-950/40 border border-rose-500/60 text-rose-200 shadow-sm">
                AppointmentException
                <span className="block text-[9px] text-rose-300/80 font-normal">
                  Slot unavailable, null data, unregistered patient
                </span>
              </div>

              <ArrowDown className="w-4 h-4 text-rose-400 mx-auto" />

              <div className="p-2 rounded-lg bg-slate-900 border border-rose-400/40 text-amber-200 shadow-sm">
                try / catch
                <span className="block text-[9px] text-slate-300 font-normal">
                  Safe recovery, graceful validation reporting
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Interactive Source Code Viewer Accordion */}
        {showCodeViewer && (
          <div className="mt-4 pt-4 border-t border-cyan-500/20 space-y-3 animate-in fade-in">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0">
                {Object.keys(javaSourceSnippets).map((filename) => (
                  <button
                    key={filename}
                    onClick={() => setSelectedFile(filename)}
                    className={`px-2.5 py-1 rounded-lg font-mono text-xs font-bold transition whitespace-nowrap cursor-pointer ${
                      selectedFile === filename
                        ? 'bg-cyan-500/25 text-cyan-200 border border-cyan-400/50 shadow-sm'
                        : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
                    }`}
                  >
                    {filename}
                  </button>
                ))}
              </div>

              <div className="flex items-center gap-2">
                <span className="text-[11px] text-slate-400 font-mono hidden sm:inline">
                  {javaSourceSnippets[selectedFile].desc}
                </span>
                <button
                  onClick={() => copyToClipboard(javaSourceSnippets[selectedFile].code, true)}
                  className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-mono transition cursor-pointer"
                >
                  {copiedCode ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedCode ? 'Copied' : 'Copy Code'}</span>
                </button>
              </div>
            </div>

            <div className="relative rounded-xl bg-slate-950 border border-cyan-500/25 p-3.5 overflow-x-auto font-mono text-xs text-cyan-100 max-h-72 overflow-y-auto leading-relaxed shadow-inner">
              <pre className="whitespace-pre">
                <code>{javaSourceSnippets[selectedFile].code}</code>
              </pre>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
