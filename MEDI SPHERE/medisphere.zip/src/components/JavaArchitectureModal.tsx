import React, { useState } from 'react';
import { useHospital } from '../context/HospitalContext';
import {
  X,
  Code2,
  Cpu,
  Database,
  Layers,
  FileText,
  AlertTriangle,
  Lock,
  GitBranch,
  Boxes,
  CheckCircle2,
  Copy,
  Check,
} from 'lucide-react';

export const JavaArchitectureModal: React.FC = () => {
  const { showJavaArchitectureModal, setShowJavaArchitectureModal } = useHospital();
  const [activeTab, setActiveTab] = useState<'oop' | 'threads' | 'exceptions' | 'collections' | 'jdbc'>('oop');
  const [copied, setCopied] = useState<boolean>(false);

  if (!showJavaArchitectureModal) return null;

  const codeSnippets = {
    oop: `// === JAVA OOP DOMAIN MODEL & INHERITANCE HIERARCHY ===
package org.medisphere.models;

import java.io.Serializable;
import java.time.LocalDate;

// Abstract Base Entity encapsulating common properties & telemetry
public abstract class BaseEntity implements Serializable {
    private static final long serialVersionUID = 1L;
    protected String id;
    protected LocalDate createdAt;
    
    public BaseEntity(String id) {
        this.id = id;
        this.createdAt = LocalDate.now();
    }
    public String getId() { return id; }
    public abstract String getAuditTelemetry();
}

// Concrete Patient Model demonstrating Encapsulation & Polymorphism
public class Patient extends BaseEntity {
    private String name;
    private int age;
    private BloodGroup bloodGroup;
    private String contact;
    private PatientStatus currentStatus;

    public Patient(String id, String name, int age, BloodGroup bloodGroup) {
        super(id);
        this.name = name;
        this.age = age;
        this.bloodGroup = bloodGroup;
        this.currentStatus = PatientStatus.OUTPATIENT;
    }

    @Override
    public String getAuditTelemetry() {
        return String.format("[PATIENT_ID: %s] %s | Age: %d | Status: %s", id, name, age, currentStatus);
    }
    // Getters and Setters...
}`,
    threads: `// === JAVA MULTITHREADING & SYNCHRONIZATION SPECIFICATION ===
package org.medisphere.threads;

import java.util.concurrent.locks.ReentrantLock;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.PriorityBlockingQueue;

public class EmergencyTriageEngine implements Runnable {
    // Thread-safe Priority Queue sorted by vital triage severity
    private final PriorityBlockingQueue<EmergencyCase> emergencyHeap;
    private final ReentrantLock bedAllocationMutex = new ReentrantLock(true); // Fair Lock
    private volatile boolean running = true;

    public EmergencyTriageEngine(PriorityBlockingQueue<EmergencyCase> heap) {
        this.emergencyHeap = heap;
    }

    @Override
    public void run() {
        System.out.println("Thread started: " + Thread.currentThread().getName());
        while (running) {
            try {
                // Blocks until a patient is ingested into the PriorityQueue
                EmergencyCase urgentPatient = emergencyHeap.take();
                processTriageSafely(urgentPatient);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                break;
            }
        }
    }

    // Critical Section guarded by ReentrantLock to prevent concurrent bed double-allocation
    public void processTriageSafely(EmergencyCase urgentCase) {
        bedAllocationMutex.lock();
        try {
            System.out.println("Acquired Lock for Bed Allocation: " + urgentCase.getId());
            // Mutex-protected bed assignment & doctor dispatch...
        } finally {
            bedAllocationMutex.unlock();
        }
    }
}`,
    exceptions: `// === CUSTOM CHECKED & UNCHECKED EXCEPTION HIERARCHY ===
package org.medisphere.exceptions;

// Root Custom Checked Exception
public class HospitalException extends Exception {
    private final String errorCode;

    public HospitalException(String message, String errorCode) {
        super(message);
        this.errorCode = errorCode;
    }
    public String getErrorCode() { return errorCode; }
}

// Checked: Thrown when an appointment slot has an existing booking
public class AppointmentSlotBookedException extends HospitalException {
    public AppointmentSlotBookedException(String doctorName, String slot) {
        super(String.format("Dr. %s already has a confirmed booking at %s.", doctorName, slot), "ERR_SLOT_OCCUPIED");
    }
}

// Checked: Thrown when requested pharmacy quantity exceeds available units
public class InsufficientMedicineStockException extends HospitalException {
    public InsufficientMedicineStockException(String drugName, int requested, int available) {
        super(String.format("Insufficient stock for %s. Requested: %d, Available: %d", drugName, requested, available), "ERR_INSUFFICIENT_STOCK");
    }
}

// Unchecked Runtime Exception: Entity not found in repository
public class PatientNotFoundException extends RuntimeException {
    public PatientNotFoundException(String patientId) {
        super(String.format("Patient with ID %s does not exist in the database.", patientId));
    }
}`,
    collections: `// === JAVA COLLECTIONS FRAMEWORK UTILIZATION ===
package org.medisphere.services;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class HospitalRegistryManager {
    // 1. ConcurrentHashMap: Thread-safe doctor schedule lookups
    private final Map<String, Doctor> doctorRegistry = new ConcurrentHashMap<>();

    // 2. PriorityQueue with Custom Comparator: O(log N) triage ordering
    private final PriorityQueue<EmergencyCase> triageQueue = new PriorityQueue<>(
        Comparator.comparingInt(EmergencyCase::getSeverityRank)
    );

    // 3. LinkedHashMap: Preserves insertion order for patient audit logs
    private final Map<String, MedicalRecord> chronologicalRecords = new LinkedHashMap<>();

    // 4. HashSet: Fast O(1) duplicate allergy checking
    private final Set<String> contraindications = new HashSet<>();

    public synchronized void enqueueEmergency(EmergencyCase eCase) {
        triageQueue.offer(eCase); // Synchronized insertion into Min-Heap
    }
}`,
    jdbc: `// === JDBC CONNECTION POOLING & TRANSACTION ISOLATION ===
package org.medisphere.database;

import java.sql.*;

public class PatientRepositoryJDBC {
    private final ConnectionPool pool;

    public PatientRepositoryJDBC(ConnectionPool pool) {
        this.pool = pool;
    }

    public void persistPatientWithTransaction(Patient patient, Bill bill) throws SQLException {
        Connection conn = null;
        try {
            conn = pool.getConnection();
            conn.setAutoCommit(false); // Begin ACID Transaction
            conn.setTransactionIsolation(Connection.TRANSACTION_SERIALIZABLE);

            String sqlPatient = "INSERT INTO patients (id, name, age, blood_group, status) VALUES (?, ?, ?, ?, ?)";
            try (PreparedStatement ps1 = conn.prepareStatement(sqlPatient)) {
                ps1.setString(1, patient.getId());
                ps1.setString(2, patient.getName());
                ps1.setInt(3, patient.getAge());
                ps1.setString(4, patient.getBloodGroup().name());
                ps1.setString(5, patient.getCurrentStatus().name());
                ps1.executeUpdate();
            }

            conn.commit(); // Commit atomic transaction
        } catch (SQLException ex) {
            if (conn != null) conn.rollback(); // Rollback on error
            throw ex;
        } finally {
            if (conn != null) conn.close();
        }
    }
}`,
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(codeSnippets[activeTab]);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-2xl animate-in fade-in">
      <div className="relative w-full max-w-4xl max-h-[90vh] rounded-3xl bg-slate-900 border border-cyan-500/30 shadow-2xl flex flex-col overflow-hidden">
        {/* Header */}
        <div className="p-6 border-b border-slate-800 flex items-center justify-between bg-slate-950/50">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-indigo-500/20 border border-indigo-500/40 flex items-center justify-center text-indigo-400">
              <Cpu className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-bold text-white">
                  Programming in Java &bull; Backend Architecture Blueprint
                </h3>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                  Course Syllabus Mapping
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Detailed structural representation of OOP Models, Threads, PriorityQueues, Exceptions & JDBC.
              </p>
            </div>
          </div>
          <button
            onClick={() => setShowJavaArchitectureModal(false)}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Controls */}
        <div className="flex items-center gap-2 px-6 pt-4 border-b border-slate-800 bg-slate-950/40 overflow-x-auto">
          {[
            { id: 'oop', label: '1. OOP & Inheritance', icon: Boxes },
            { id: 'threads', label: '2. Multithreading & Locks', icon: Cpu },
            { id: 'exceptions', label: '3. Exception Hierarchy', icon: AlertTriangle },
            { id: 'collections', label: '4. Collections & PriorityQueue', icon: Layers },
            { id: 'jdbc', label: '5. JDBC & Transactions', icon: Database },
          ].map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center gap-2 px-4 py-2.5 text-xs font-semibold rounded-t-xl transition border-b-2 whitespace-nowrap ${
                  activeTab === tab.id
                    ? 'border-cyan-400 text-cyan-300 bg-slate-900'
                    : 'border-transparent text-slate-400 hover:text-slate-200'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                {tab.label}
              </button>
            );
          })}
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto flex-1 bg-slate-950">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-mono text-cyan-400">
              Source: org/medisphere/{activeTab}.java
            </span>
            <button
              onClick={handleCopy}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800 transition"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              {copied ? 'Copied' : 'Copy Java Code'}
            </button>
          </div>

          <pre className="p-4 rounded-xl bg-slate-900/90 border border-slate-800 font-mono text-xs text-slate-200 overflow-x-auto leading-relaxed shadow-inner">
            <code>{codeSnippets[activeTab]}</code>
          </pre>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-800 bg-slate-950/60 flex items-center justify-between text-xs text-slate-400">
          <span className="flex items-center gap-1.5">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            Backend architecture maps directly to core Java curriculum concepts.
          </span>
          <button
            onClick={() => setShowJavaArchitectureModal(false)}
            className="px-4 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-semibold transition"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
