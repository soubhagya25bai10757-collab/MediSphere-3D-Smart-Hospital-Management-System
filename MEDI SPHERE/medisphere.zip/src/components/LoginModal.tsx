import React, { useState } from 'react';
import { useHospital } from '../context/HospitalContext';
import { UserRole } from '../types';
import {
  Activity,
  Lock,
  User,
  Shield,
  ArrowRight,
  CheckCircle2,
  X,
  Sparkles,
  KeyRound,
} from 'lucide-react';

export const LoginModal: React.FC = () => {
  const { showLoginModal, setShowLoginModal, login } = useHospital();

  const [username, setUsername] = useState<string>('admin');
  const [password, setPassword] = useState<string>('••••••••');
  const [role, setRole] = useState<UserRole>('Administrator');
  const [rememberSession, setRememberSession] = useState<boolean>(true);

  if (!showLoginModal) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    login(username, role);
  };

  const quickRoles: { role: UserRole; label: string; desc: string }[] = [
    { role: 'Administrator', label: 'Administrator', desc: 'Full system control & telemetry' },
    { role: 'Doctor', label: 'Dr. Rajesh Sharma', desc: 'Patients, records, & treatments' },
    { role: 'Receptionist', label: 'Pooja Verma', desc: 'Admissions, bookings, & billing' },
    { role: 'Laboratory Staff', label: 'Anil Sengupta', desc: 'Diagnostics & test queue' },
    { role: 'Pharmacy Staff', label: 'Deepika Nair', desc: 'Formulary & prescription dispensing' },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-2xl animate-in fade-in">
      {/* Background glowing orbs */}
      <div className="absolute w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none -top-20 -left-20" />
      <div className="absolute w-96 h-96 bg-blue-600/10 rounded-full blur-3xl pointer-events-none -bottom-20 -right-20" />

      <div className="relative w-full max-w-lg rounded-3xl bg-slate-900/90 border border-cyan-500/30 p-8 shadow-2xl backdrop-blur-xl">
        {/* Close button */}
        <button
          onClick={() => setShowLoginModal(false)}
          className="absolute top-5 right-5 p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header & Logo */}
        <div className="text-center mb-8">
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-cyan-500 via-blue-600 to-indigo-600 p-[2px] shadow-xl shadow-cyan-500/30 mx-auto mb-4">
            <div className="w-full h-full bg-slate-950 rounded-[14px] flex items-center justify-center">
              <Activity className="w-7 h-7 text-cyan-400 animate-pulse" />
            </div>
          </div>
          <div className="flex items-center justify-center gap-2">
            <h2 className="text-2xl font-black tracking-tight text-white">MediSphere 3D</h2>
            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/40">
              PRO
            </span>
          </div>
          <p className="text-xs text-slate-400 font-medium mt-1">
            Smart Hospital Management System &bull; Java Security Context
          </p>
        </div>

        {/* Quick Demo Switcher Buttons */}
        <div className="mb-6">
          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-2">
            Quick Demo Login by Role:
          </span>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5">
            {quickRoles.map((item) => (
              <button
                key={item.role}
                type="button"
                onClick={() => {
                  setRole(item.role);
                  setUsername(item.label.toLowerCase().replace(/[^a-z0-9]/g, '_'));
                }}
                className={`p-2 rounded-xl text-left border transition text-[11px] ${
                  role === item.role
                    ? 'bg-cyan-500/20 border-cyan-500/50 text-cyan-300'
                    : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:text-white hover:bg-slate-800/80'
                }`}
              >
                <span className="font-bold block truncate text-white">{item.role}</span>
                <span className="text-[9px] text-slate-400 block truncate">{item.label}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="text-xs font-semibold text-slate-300 block mb-1.5">Username</label>
            <div className="relative">
              <User className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input
                type="text"
                required
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="Enter authorized username"
                className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-slate-950/80 border border-slate-800 focus:border-cyan-500/60 text-xs text-white placeholder-slate-500 outline-none"
              />
            </div>
          </div>

          <div>
            <label className="text-xs font-semibold text-slate-300 block mb-1.5">Password</label>
            <div className="relative">
              <KeyRound className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Enter password"
                className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-slate-950/80 border border-slate-800 focus:border-cyan-500/60 text-xs text-white placeholder-slate-500 outline-none"
              />
            </div>
          </div>

          <div>
            <label className="text-xs font-semibold text-slate-300 block mb-1.5">Security Role</label>
            <div className="relative">
              <Shield className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <select
                value={role}
                onChange={(e) => setRole(e.target.value as UserRole)}
                className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-slate-950/80 border border-slate-800 focus:border-cyan-500/60 text-xs text-white outline-none"
              >
                <option value="Administrator">Administrator (Full Access)</option>
                <option value="Doctor">Doctor (Clinical & Patients)</option>
                <option value="Receptionist">Receptionist (Admissions & Billing)</option>
                <option value="Laboratory Staff">Laboratory Staff (Pathology & Tests)</option>
                <option value="Pharmacy Staff">Pharmacy Staff (Formulary & Drugs)</option>
              </select>
            </div>
          </div>

          <div className="flex items-center justify-between pt-1">
            <label className="flex items-center gap-2 cursor-pointer text-xs text-slate-400 select-none">
              <input
                type="checkbox"
                checked={rememberSession}
                onChange={(e) => setRememberSession(e.target.checked)}
                className="w-4 h-4 rounded bg-slate-950 border-slate-800 text-cyan-500 focus:ring-0 focus:ring-offset-0"
              />
              Remember active session
            </label>
            <span className="text-[11px] text-cyan-400 hover:underline cursor-pointer">
              Forgot credentials?
            </span>
          </div>

          <button
            type="submit"
            className="w-full py-3 rounded-xl text-xs font-bold text-white bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 transition shadow-lg shadow-cyan-500/25 flex items-center justify-center gap-2 mt-4"
          >
            <Lock className="w-4 h-4" />
            Secure Login
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </form>

        <div className="mt-6 text-center text-[10px] text-slate-500">
          TLS 1.3 End-to-End Encryption &bull; Enterprise Secure Session Verified
        </div>
      </div>
    </div>
  );
};
