import React from 'react';
import { X, Activity, ShieldCheck, Mail, Phone, MapPin } from 'lucide-react';

interface AboutContactModalProps {
  type: 'about' | 'contact' | null;
  onClose: () => void;
}

export const AboutContactModal: React.FC<AboutContactModalProps> = ({ type, onClose }) => {
  if (!type) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="w-full max-w-xl rounded-2xl bg-slate-900 border border-cyan-500/30 p-6 shadow-2xl relative">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition"
        >
          <X className="w-5 h-5" />
        </button>

        {type === 'about' ? (
          <div>
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-xl bg-cyan-500/20 border border-cyan-500/40 flex items-center justify-center text-cyan-400">
                <Activity className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-lg font-black text-white">About MediSphere 3D</h3>
                <span className="text-xs text-cyan-400 font-semibold">Next-Gen Smart Hospital Operating System</span>
              </div>
            </div>

            <div className="space-y-3 text-xs text-slate-300 leading-relaxed">
              <p>
                <strong>MediSphere 3D</strong> is an enterprise clinical platform uniting emergency triage, inpatient ward bed management, specialist scheduling, bio-diagnostic laboratories, robotic pharmacy dispensing, and financial billing into a unified ecosystem.
              </p>
              <p>
                Engineered for real-time healthcare telemetry, the system provides high-reliability clinical workflows, algorithmic triage classification, instant specialist coordination, and zero-latency operational metrics across all hospital wings.
              </p>
            </div>

            <div className="mt-6 pt-4 border-t border-slate-800 flex items-center justify-end">
              <button
                onClick={onClose}
                className="px-5 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold transition"
              >
                Close
              </button>
            </div>
          </div>
        ) : (
          <div>
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-xl bg-blue-500/20 border border-blue-500/40 flex items-center justify-center text-blue-400">
                <Phone className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-lg font-black text-white">MediSphere 3D Control Center</h3>
                <span className="text-xs text-blue-400 font-semibold">24/7 Clinical Helpdesk & System Administration</span>
              </div>
            </div>

            <div className="space-y-3 text-xs text-slate-300">
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center gap-3">
                <Phone className="w-4 h-4 text-cyan-400" />
                <div>
                  <span className="text-[10px] text-slate-400 uppercase font-bold block">Trauma & Emergency Hotline</span>
                  <span className="text-xs font-mono font-bold text-white">+91 (080) 4122-9999 &bull; Toll-Free 108</span>
                </div>
              </div>

              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center gap-3">
                <Mail className="w-4 h-4 text-blue-400" />
                <div>
                  <span className="text-[10px] text-slate-400 uppercase font-bold block">Hospital Informatics & IT Support</span>
                  <span className="text-xs font-mono font-bold text-white">ops@medisphere3d.health.internal</span>
                </div>
              </div>

              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 flex items-center gap-3">
                <MapPin className="w-4 h-4 text-purple-400" />
                <div>
                  <span className="text-[10px] text-slate-400 uppercase font-bold block">Campus Location</span>
                  <span className="text-xs text-white">MediSphere Super Specialty Medical Center & Research Park, Block 4, Digital Twin Sector</span>
                </div>
              </div>
            </div>

            <div className="mt-6 pt-4 border-t border-slate-800 flex justify-end">
              <button
                onClick={onClose}
                className="px-5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold transition"
              >
                Close
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
