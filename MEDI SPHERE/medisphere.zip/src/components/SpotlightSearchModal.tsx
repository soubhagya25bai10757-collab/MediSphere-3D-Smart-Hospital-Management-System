import React, { useState } from 'react';
import {
  Search,
  X,
  User,
  Stethoscope,
  Flame,
  BedDouble,
  Microscope,
  Pill,
  ArrowRight,
} from 'lucide-react';
import { useHospital } from '../context/HospitalContext';

interface SpotlightSearchModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SpotlightSearchModal: React.FC<SpotlightSearchModalProps> = ({
  isOpen,
  onClose,
}) => {
  const {
    patients,
    doctors,
    emergencyCases,
    beds,
    setShowLandingPage,
    navigateToSection,
  } = useHospital();
  const [query, setQuery] = useState('');

  if (!isOpen) return null;

  const filteredPatients = patients
    .filter(
      (p) =>
        p.name.toLowerCase().includes(query.toLowerCase()) ||
        (p.uhid || p.id || '').toLowerCase().includes(query.toLowerCase())
    )
    .slice(0, 3);

  const filteredDoctors = doctors
    .filter(
      (d) =>
        d.name.toLowerCase().includes(query.toLowerCase()) ||
        d.specialization.toLowerCase().includes(query.toLowerCase())
    )
    .slice(0, 3);

  const filteredEmergency = emergencyCases
    .filter(
      (e) =>
        e.patientName.toLowerCase().includes(query.toLowerCase()) ||
        e.chiefComplaint.toLowerCase().includes(query.toLowerCase())
    )
    .slice(0, 2);

  const handleSelectPatient = (_id: string) => {
    setShowLandingPage(false);
    navigateToSection('patients');
    onClose();
  };

  const handleSelectDoctor = () => {
    setShowLandingPage(false);
    navigateToSection('doctors');
    onClose();
  };

  const handleSelectEmergency = () => {
    setShowLandingPage(false);
    navigateToSection('emergency');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center p-4 sm:pt-20 bg-slate-950/80 backdrop-blur-2xl animate-in fade-in duration-200">
      <div className="w-full max-w-2xl rounded-2xl glass-modal border border-cyan-500/40 shadow-2xl overflow-hidden flex flex-col">
        {/* Search Input Bar */}
        <div className="flex items-center px-4 py-3.5 border-b border-cyan-500/20 bg-[rgba(6,18,45,0.75)]">
          <Search className="w-5 h-5 text-cyan-400 mr-3" />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search patients by name or UHID, doctors, emergency triage..."
            className="flex-1 bg-transparent text-sm text-white placeholder-slate-400 focus:outline-none"
            autoFocus
          />
          {query && (
            <button
              onClick={() => setQuery('')}
              className="p-1 text-slate-400 hover:text-white mr-2"
            >
              <X className="w-4 h-4" />
            </button>
          )}
          <button
            onClick={onClose}
            className="px-2.5 py-1 text-xs text-slate-400 hover:text-white bg-slate-800 rounded-lg"
          >
            ESC
          </button>
        </div>

        {/* Results Body */}
        <div className="p-4 max-h-[60vh] overflow-y-auto space-y-4">
          {/* Quick Department Nav shortcuts */}
          {!query && (
            <div>
              <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider block mb-2 px-1">
                Quick Department Direct Access
              </span>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-xs">
                <button
                  onClick={() => {
                    setShowLandingPage(false);
                    navigateToSection('emergency');
                    onClose();
                  }}
                  className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 hover:border-red-500/40 flex items-center gap-2 text-left text-slate-300 hover:text-white transition"
                >
                  <Flame className="w-4 h-4 text-red-400" />
                  <span>Emergency Trauma</span>
                </button>
                <button
                  onClick={() => {
                    setShowLandingPage(false);
                    navigateToSection('beds');
                    onClose();
                  }}
                  className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 hover:border-cyan-500/40 flex items-center gap-2 text-left text-slate-300 hover:text-white transition"
                >
                  <BedDouble className="w-4 h-4 text-cyan-400" />
                  <span>ICU & Bed Grid</span>
                </button>
                <button
                  onClick={() => {
                    setShowLandingPage(false);
                    navigateToSection('pharmacy');
                    onClose();
                  }}
                  className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 hover:border-emerald-500/40 flex items-center gap-2 text-left text-slate-300 hover:text-white transition"
                >
                  <Pill className="w-4 h-4 text-emerald-400" />
                  <span>Smart Pharmacy</span>
                </button>
              </div>
            </div>
          )}

          {/* Patients */}
          {filteredPatients.length > 0 && (
            <div>
              <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider block mb-2 px-1">
                Patients
              </span>
              <div className="space-y-1.5">
                {filteredPatients.map((p) => (
                  <div
                    key={p.id}
                    onClick={() => handleSelectPatient(p.id)}
                    className="p-3 rounded-xl bg-slate-950/80 border border-slate-800/80 hover:border-cyan-500/40 hover:bg-slate-800/50 flex items-center justify-between cursor-pointer transition"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-7 h-7 rounded-lg bg-cyan-500/20 text-cyan-400 flex items-center justify-center">
                        <User className="w-4 h-4" />
                      </div>
                      <div>
                        <span className="text-xs font-bold text-white block">{p.name}</span>
                        <span className="text-[10px] text-slate-400">{p.uhid} &bull; {p.age}y/{p.gender} &bull; Blood: {p.bloodGroup}</span>
                      </div>
                    </div>
                    <ArrowRight className="w-3.5 h-3.5 text-slate-400" />
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Doctors */}
          {filteredDoctors.length > 0 && (
            <div>
              <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider block mb-2 px-1">
                Specialist Doctors
              </span>
              <div className="space-y-1.5">
                {filteredDoctors.map((d) => (
                  <div
                    key={d.id}
                    onClick={handleSelectDoctor}
                    className="p-3 rounded-xl bg-slate-950/80 border border-slate-800/80 hover:border-blue-500/40 hover:bg-slate-800/50 flex items-center justify-between cursor-pointer transition"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-7 h-7 rounded-lg bg-blue-500/20 text-blue-400 flex items-center justify-center">
                        <Stethoscope className="w-4 h-4" />
                      </div>
                      <div>
                        <span className="text-xs font-bold text-white block">{d.name}</span>
                        <span className="text-[10px] text-slate-400">{d.specialization} &bull; Room {d.roomNumber}</span>
                      </div>
                    </div>
                    <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-300 border border-emerald-500/20">
                      {d.status}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Emergency Cases */}
          {filteredEmergency.length > 0 && (
            <div>
              <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider block mb-2 px-1">
                Emergency Priority Cases
              </span>
              <div className="space-y-1.5">
                {filteredEmergency.map((e) => (
                  <div
                    key={e.id}
                    onClick={handleSelectEmergency}
                    className="p-3 rounded-xl bg-slate-950/80 border border-red-500/30 hover:border-red-500/60 flex items-center justify-between cursor-pointer transition"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-7 h-7 rounded-lg bg-red-500/20 text-red-400 flex items-center justify-center">
                        <Flame className="w-4 h-4" />
                      </div>
                      <div>
                        <span className="text-xs font-bold text-white block">{e.patientName}</span>
                        <span className="text-[10px] text-red-300">{e.priority} &bull; {e.chiefComplaint}</span>
                      </div>
                    </div>
                    <span className="text-[10px] font-mono text-cyan-400">{e.arrivalTime}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {query && filteredPatients.length === 0 && filteredDoctors.length === 0 && filteredEmergency.length === 0 && (
            <div className="py-8 text-center text-xs text-slate-400">
              No clinical records matching "{query}". Try another search keyword.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
