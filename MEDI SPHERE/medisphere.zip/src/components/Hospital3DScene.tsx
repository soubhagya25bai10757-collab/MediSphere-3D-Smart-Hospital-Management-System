import React, { useEffect, useRef, useState, useMemo } from 'react';
import * as THREE from 'three';
import { useHospital } from '../context/HospitalContext';
import {
  RotateCcw,
  ZoomIn,
  ZoomOut,
  Maximize2,
  Activity,
  Flame,
  Stethoscope,
  Pill,
  Microscope,
  BedDouble,
  Building2,
  ShieldAlert,
  Info,
  ChevronRight,
  Eye,
  Compass,
} from 'lucide-react';

interface Hospital3DSceneProps {
  compact?: boolean;
  onSelectSection?: (sectionKey: string) => void;
}

export interface HospitalSectionInfo {
  key: string;
  name: string;
  badge: string;
  statPrimary: string;
  statSecondary: string;
  color: string;
  icon: React.ComponentType<{ className?: string }>;
  description: string;
  calloutOffset: { x: number; y: number }; // 2D offset in px for the floating panel
}

export const HOSPITAL_SECTIONS: Record<string, HospitalSectionInfo> = {
  icu: {
    key: 'icu',
    name: 'ICU Tower',
    badge: 'Critical Care',
    statPrimary: '12 Occupied',
    statSecondary: '4 Available',
    color: '#06b6d4',
    icon: Activity,
    description: 'Telemetry hemodynamic monitoring, negative-pressure isolation, and rooftop aeromedical dock.',
    calloutOffset: { x: 50, y: -40 },
  },
  laboratory: {
    key: 'laboratory',
    name: 'Laboratory',
    badge: 'Diagnostics',
    statPrimary: '14 Pending',
    statSecondary: '7 Processing',
    color: '#a855f7',
    icon: Microscope,
    description: 'Automated 5-part hematology analyzers, bio-hazard containment, and robotic assay queues.',
    calloutOffset: { x: 60, y: 10 },
  },
  pharmacy: {
    key: 'pharmacy',
    name: 'Pharmacy',
    badge: 'Formulary',
    statPrimary: 'Low Stock Alerts (6)',
    statSecondary: '540 Dispensed',
    color: '#10b981',
    icon: Pill,
    description: 'Automated barcoded carousel dispensing, atomic stock ledger, and real-time replenishment.',
    calloutOffset: { x: 50, y: 50 },
  },
  emergency: {
    key: 'emergency',
    name: 'Emergency',
    badge: 'Level 1 Trauma',
    statPrimary: '7 Active Cases',
    statSecondary: '2 Critical',
    color: '#ef4444',
    icon: Flame,
    description: 'Rapid resuscitation suites, 24/7 cardiac cath readiness, and automated triage intake.',
    calloutOffset: { x: -80, y: 20 },
  },
  opd: {
    key: 'opd',
    name: 'OPD Pavilion',
    badge: 'Consultation',
    statPrimary: "Today's Appointments: 76",
    statSecondary: '18 In-Session',
    color: '#38bdf8',
    icon: Building2,
    description: 'Multi-specialist clinical suites, electronic token kiosks, and intelligent slot allocation.',
    calloutOffset: { x: -70, y: 70 },
  },
  ward: {
    key: 'ward',
    name: 'Patient Ward',
    badge: 'Inpatient Towers',
    statPrimary: '24 Occupied',
    statSecondary: '6 Available',
    color: '#3b82f6',
    icon: BedDouble,
    description: 'Twin inpatient recovery towers connected by elevated skybridge with 24/7 nursing stations.',
    calloutOffset: { x: -60, y: -60 },
  },
  reception: {
    key: 'reception',
    name: 'Reception',
    badge: 'Main Atrium',
    statPrimary: 'Open 24/7',
    statSecondary: '1,284 Registered',
    color: '#00f0ff',
    icon: ShieldAlert,
    description: 'Central multi-tier glass atrium, biometric registration turnstiles, and concierge desk.',
    calloutOffset: { x: 0, y: -90 },
  },
};

export const Hospital3DScene: React.FC<Hospital3DSceneProps> = ({
  compact = false,
  onSelectSection,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const { navigateToSection, setShowLandingPage } = useHospital();

  const [hoveredSection, setHoveredSection] = useState<string | null>(null);
  const [selectedSection, setSelectedSection] = useState<string>('emergency');
  const [cameraView, setCameraView] = useState<'overview' | 'emergency' | 'icu' | 'lab'>('overview');
  const [isDragging, setIsDragging] = useState<boolean>(false);
  const [webglError, setWebglError] = useState<boolean>(false);
  const [calloutCoords, setCalloutCoords] = useState<
    Record<string, { x: number; y: number; visible: boolean }>
  >({});

  const sceneRef = useRef<{
    scene: THREE.Scene;
    camera: THREE.PerspectiveCamera;
    renderer: THREE.WebGLRenderer;
    buildingGroup: THREE.Group;
    raycaster: THREE.Raycaster;
    mouse: THREE.Vector2;
    sectionMeshes: Map<string, THREE.Mesh[]>;
    calloutAnchors: Map<string, THREE.Vector3>;
    lightPulse: THREE.PointLight;
    emergencyBeacon: THREE.PointLight;
    ambulanceLights: THREE.Mesh[];
    helicopterRotor: THREE.Group | null;
    tailRotor: THREE.Mesh | null;
    crossMesh: THREE.Group | null;
  } | null>(null);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    let renderer: THREE.WebGLRenderer | null = null;
    let animationFrameId: number = 0;
    let resizeObserver: ResizeObserver | null = null;

    try {
      const width = container.clientWidth || 900;
      const height = container.clientHeight || (compact ? 420 : 640);

      // 1. Scene Setup with Deep Evening Sky and Atmospheric Fog
      const scene = new THREE.Scene();
      scene.background = new THREE.Color(0x040914);
      scene.fog = new THREE.FogExp2(0x050c18, 0.016);

      // 2. Camera Setup (Elevated cinematic perspective)
      const camera = new THREE.PerspectiveCamera(42, width / height, 0.1, 1000);
      camera.position.set(28, 22, 32);
      camera.lookAt(0, 3.5, 0);

      // 3. WebGL Renderer with High Precision & Soft Shadows
      renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false, powerPreference: 'high-performance' });
      renderer.setSize(width, height);
      renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
      renderer.shadowMap.enabled = true;
      renderer.shadowMap.type = THREE.PCFSoftShadowMap;
      renderer.toneMapping = THREE.ACESFilmicToneMapping;
      renderer.toneMappingExposure = 1.25;

      container.innerHTML = '';
      container.appendChild(renderer.domElement);

    // 4. Lighting Rig (Futuristic electric cyan, deep navy ambient & rim highlights)
    const ambientLight = new THREE.AmbientLight(0x0d1e38, 2.8);
    scene.add(ambientLight);

    const mainKeyLight = new THREE.DirectionalLight(0x38bdf8, 2.4);
    mainKeyLight.position.set(30, 45, 25);
    mainKeyLight.castShadow = true;
    mainKeyLight.shadow.mapSize.width = 2048;
    mainKeyLight.shadow.mapSize.height = 2048;
    mainKeyLight.shadow.camera.near = 10;
    mainKeyLight.shadow.camera.far = 100;
    mainKeyLight.shadow.camera.left = -30;
    mainKeyLight.shadow.camera.right = 30;
    mainKeyLight.shadow.camera.top = 30;
    mainKeyLight.shadow.camera.bottom = -30;
    scene.add(mainKeyLight);

    const coolRimLight = new THREE.DirectionalLight(0x818cf8, 1.9);
    coolRimLight.position.set(-30, 35, -25);
    scene.add(coolRimLight);

    const groundBounceLight = new THREE.DirectionalLight(0x06b6d4, 0.7);
    groundBounceLight.position.set(0, -10, 0);
    scene.add(groundBounceLight);

    // Dynamic Central Pulse
    const lightPulse = new THREE.PointLight(0x00f0ff, 3.2, 35);
    lightPulse.position.set(0, 9, 0);
    scene.add(lightPulse);

    // Emergency Flashing Trauma Beacon
    const emergencyBeacon = new THREE.PointLight(0xef4444, 3.0, 30);
    emergencyBeacon.position.set(-11, 4.5, 6);
    scene.add(emergencyBeacon);

    // 5. Ground & Campus Flooring
    const groundGeo = new THREE.PlaneGeometry(120, 120);
    const groundMat = new THREE.MeshStandardMaterial({
      color: 0x050c18,
      roughness: 0.85,
      metalness: 0.25,
    });
    const ground = new THREE.Mesh(groundGeo, groundMat);
    ground.rotation.x = -Math.PI / 2;
    ground.position.y = -0.05;
    ground.receiveShadow = true;
    scene.add(ground);

    // Holographic Cybernetic Floor Grid
    const gridHelper = new THREE.GridHelper(70, 50, 0x00f0ff, 0x0f2942);
    gridHelper.position.y = 0.02;
    scene.add(gridHelper);

    // Concentric Holo Radar Rings
    const ringMat = new THREE.MeshBasicMaterial({ color: 0x00f0ff, side: THREE.DoubleSide, transparent: true, opacity: 0.22 });
    const ring1 = new THREE.Mesh(new THREE.RingGeometry(18, 18.25, 64), ringMat);
    ring1.rotation.x = Math.PI / 2;
    ring1.position.y = 0.05;
    scene.add(ring1);

    const ring2 = new THREE.Mesh(new THREE.RingGeometry(28, 28.3, 64), ringMat);
    ring2.rotation.x = Math.PI / 2;
    ring2.position.y = 0.05;
    scene.add(ring2);

    // 6. Main Building Group
    const buildingGroup = new THREE.Group();
    scene.add(buildingGroup);

    const sectionMeshes = new Map<string, THREE.Mesh[]>();
    const calloutAnchors = new Map<string, THREE.Vector3>();
    const ambulanceLights: THREE.Mesh[] = [];

    // Helper to register building block with realistic glass PBR properties
    const createSectionBlock = (
      key: string,
      x: number,
      y: number,
      z: number,
      w: number,
      h: number,
      d: number,
      baseColor: number,
      edgeColor: number,
      anchorHeightOffset: number = 0
    ) => {
      const geo = new THREE.BoxGeometry(w, h, d);
      const mat = new THREE.MeshPhysicalMaterial({
        color: baseColor,
        roughness: 0.12,
        metalness: 0.75,
        transmission: 0.55,
        thickness: 1.8,
        transparent: true,
        opacity: 0.88,
        reflectivity: 0.95,
        clearcoat: 1.0,
        clearcoatRoughness: 0.1,
      });

      const mesh = new THREE.Mesh(geo, mat);
      mesh.position.set(x, y + h / 2, z);
      mesh.castShadow = true;
      mesh.receiveShadow = true;
      mesh.userData = { sectionKey: key };
      buildingGroup.add(mesh);

      // Edge contour outline
      const wireGeo = new THREE.EdgesGeometry(geo);
      const wireMat = new THREE.LineBasicMaterial({ color: edgeColor, transparent: true, opacity: 0.7 });
      const wire = new THREE.LineSegments(wireGeo, wireMat);
      mesh.add(wire);

      // Floor Bands with illuminated interior windows
      const floorCount = Math.floor(h / 1.7);
      for (let i = 1; i <= floorCount; i++) {
        const floorGeo = new THREE.BoxGeometry(w + 0.08, 0.12, d + 0.08);
        const floorMat = new THREE.MeshBasicMaterial({ color: 0x38bdf8, transparent: true, opacity: 0.45 });
        const floorBand = new THREE.Mesh(floorGeo, floorMat);
        floorBand.position.y = -h / 2 + i * 1.7;
        mesh.add(floorBand);

        // Internal warm/cyan illumination plate
        const interiorPlate = new THREE.Mesh(
          new THREE.BoxGeometry(w * 0.85, 0.02, d * 0.85),
          new THREE.MeshBasicMaterial({ color: 0x00f0ff, transparent: true, opacity: 0.25 })
        );
        interiorPlate.position.y = -h / 2 + i * 1.7 + 0.1;
        mesh.add(interiorPlate);
      }

      if (!sectionMeshes.has(key)) {
        sectionMeshes.set(key, []);
      }
      sectionMeshes.get(key)!.push(mesh);

      // Record 3D Anchor Coordinate for 2D Screen Callout Projector
      if (!calloutAnchors.has(key)) {
        calloutAnchors.set(key, new THREE.Vector3(x, y + h + anchorHeightOffset, z));
      }

      return mesh;
    };

    // --- HOSPITAL ARCHITECTURAL MODULES ---

    // 1. Central Glass Atrium & Reception (Center)
    createSectionBlock('reception', 0, 0, 0, 9, 5.8, 9, 0x062846, 0x00f0ff, 1.0);
    // Grand entrance glass canopy
    const canopyGeo = new THREE.BoxGeometry(7, 0.3, 3.5);
    const canopyMat = new THREE.MeshPhysicalMaterial({ color: 0x00f0ff, transparent: true, opacity: 0.7 });
    const canopy = new THREE.Mesh(canopyGeo, canopyMat);
    canopy.position.set(0, 2.5, 5.5);
    buildingGroup.add(canopy);

    // Glowing 3D Medical Cross on Central Atrium Facade
    const crossGroup = new THREE.Group();
    const crossMat = new THREE.MeshBasicMaterial({ color: 0x00f0ff });
    const crossV = new THREE.Mesh(new THREE.BoxGeometry(0.55, 2.4, 0.3), crossMat);
    const crossH = new THREE.Mesh(new THREE.BoxGeometry(2.4, 0.55, 0.3), crossMat);
    crossGroup.add(crossV);
    crossGroup.add(crossH);
    crossGroup.position.set(0, 5.2, 4.65);
    buildingGroup.add(crossGroup);

    // 2. Emergency Trauma Wing (West Wing Ground Level with Covered Portico)
    createSectionBlock('emergency', -11, 0, 4, 10, 4.2, 8, 0x3d0d0d, 0xef4444, 0.8);

    // Emergency Ambulance Dock Portico
    const porticoRoof = new THREE.Mesh(
      new THREE.BoxGeometry(9, 0.4, 5.5),
      new THREE.MeshStandardMaterial({ color: 0x1e293b, metalness: 0.8, roughness: 0.3 })
    );
    porticoRoof.position.set(-11, 3.2, 9);
    buildingGroup.add(porticoRoof);

    // Red neon emergency sign bar
    const emergSign = new THREE.Mesh(
      new THREE.BoxGeometry(7, 0.4, 0.2),
      new THREE.MeshBasicMaterial({ color: 0xef4444 })
    );
    emergSign.position.set(-11, 3.5, 11.8);
    buildingGroup.add(emergSign);

    // 3. ICU High-Tech Tower (North Wing High Rise)
    createSectionBlock('icu', 0, 5.8, -2, 7.8, 7.5, 6.8, 0x0a344f, 0x06b6d4, 2.5);

    // Rooftop Helipad atop ICU Tower
    const helipadDeck = new THREE.Mesh(
      new THREE.CylinderGeometry(4.2, 4.2, 0.35, 36),
      new THREE.MeshStandardMaterial({ color: 0x1e293b, metalness: 0.85, roughness: 0.25 })
    );
    helipadDeck.position.set(0, 13.5, -2);
    buildingGroup.add(helipadDeck);

    // Helipad Yellow Perimeter Ring
    const heliRing = new THREE.Mesh(
      new THREE.RingGeometry(3.2, 3.5, 36),
      new THREE.MeshBasicMaterial({ color: 0xfacc15, side: THREE.DoubleSide })
    );
    heliRing.rotation.x = Math.PI / 2;
    heliRing.position.set(0, 13.7, -2);
    buildingGroup.add(heliRing);

    // Helipad Red Cross / H Markings
    const hBar1 = new THREE.Mesh(new THREE.BoxGeometry(0.35, 0.05, 2.2), new THREE.MeshBasicMaterial({ color: 0xef4444 }));
    const hBar2 = new THREE.Mesh(new THREE.BoxGeometry(0.35, 0.05, 2.2), new THREE.MeshBasicMaterial({ color: 0xef4444 }));
    const hCross = new THREE.Mesh(new THREE.BoxGeometry(1.4, 0.05, 0.35), new THREE.MeshBasicMaterial({ color: 0xef4444 }));
    hBar1.position.set(-0.7, 13.72, -2);
    hBar2.position.set(0.7, 13.72, -2);
    hCross.position.set(0, 13.72, -2);
    buildingGroup.add(hBar1);
    buildingGroup.add(hBar2);
    buildingGroup.add(hCross);

    // 4. 3D Medical Evacuation Helicopter Model on Helipad
    const heliGroup = new THREE.Group();
    heliGroup.position.set(0, 13.9, -2);

    // Fuselage
    const heliBody = new THREE.Mesh(
      new THREE.BoxGeometry(1.6, 1.1, 3.2),
      new THREE.MeshStandardMaterial({ color: 0xffffff, metalness: 0.6, roughness: 0.3 })
    );
    heliBody.position.y = 0.7;
    heliGroup.add(heliBody);

    // Cockpit windscreen
    const cockpit = new THREE.Mesh(
      new THREE.BoxGeometry(1.4, 0.7, 1.2),
      new THREE.MeshPhysicalMaterial({ color: 0x00f0ff, transparent: true, opacity: 0.7, roughness: 0.1 })
    );
    cockpit.position.set(0, 0.85, 1.2);
    heliGroup.add(cockpit);

    // Tail boom
    const tailBoom = new THREE.Mesh(
      new THREE.BoxGeometry(0.4, 0.4, 2.6),
      new THREE.MeshStandardMaterial({ color: 0xffffff })
    );
    tailBoom.position.set(0, 0.9, -2.4);
    heliGroup.add(tailBoom);

    // Tail vertical fin
    const tailFin = new THREE.Mesh(
      new THREE.BoxGeometry(0.15, 1.0, 0.6),
      new THREE.MeshStandardMaterial({ color: 0xef4444 })
    );
    tailFin.position.set(0, 1.3, -3.6);
    heliGroup.add(tailFin);

    // Landing skids
    const skid1 = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 3.2), new THREE.MeshStandardMaterial({ color: 0x334155 }));
    const skid2 = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 3.2), new THREE.MeshStandardMaterial({ color: 0x334155 }));
    skid1.rotation.x = Math.PI / 2;
    skid2.rotation.x = Math.PI / 2;
    skid1.position.set(-0.8, 0.1, 0);
    skid2.position.set(0.8, 0.1, 0);
    heliGroup.add(skid1);
    heliGroup.add(skid2);

    // Main Rotor Blades (Rotates in animate loop)
    const rotorGroup = new THREE.Group();
    rotorGroup.position.set(0, 1.5, 0);
    const blade1 = new THREE.Mesh(new THREE.BoxGeometry(0.2, 0.04, 5.2), new THREE.MeshBasicMaterial({ color: 0x1e293b }));
    const blade2 = new THREE.Mesh(new THREE.BoxGeometry(5.2, 0.04, 0.2), new THREE.MeshBasicMaterial({ color: 0x1e293b }));
    rotorGroup.add(blade1);
    rotorGroup.add(blade2);
    heliGroup.add(rotorGroup);

    // Tail Rotor
    const tailRotor = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.9, 0.08), new THREE.MeshBasicMaterial({ color: 0x1e293b }));
    tailRotor.position.set(0.25, 1.5, -3.6);
    heliGroup.add(tailRotor);

    buildingGroup.add(heliGroup);

    // 5. Laboratory & Diagnostics (East Wing Level 1-2)
    createSectionBlock('laboratory', 10.5, 0, 3.5, 8.5, 5.0, 7.5, 0x27103d, 0xa855f7, 0.8);

    // 6. Central Pharmacy (Southeast Ground Hub)
    createSectionBlock('pharmacy', 10.5, 0, -6.5, 8.5, 3.8, 7.5, 0x0c3827, 0x10b981, 0.6);

    // 7. OPD Consultation Wing (Southwest Wing)
    createSectionBlock('opd', -10.5, 0, -6.5, 8.5, 4.6, 7.8, 0x0a2b45, 0x38bdf8, 0.6);

    // 8. Inpatient Patient Ward Towers (Twin Northwest & Northeast High Towers)
    createSectionBlock('ward', -6, 0, -12, 6.5, 10.5, 6, 0x0f2444, 0x3b82f6, 1.2);
    createSectionBlock('ward', 6, 0, -12, 6.5, 10.5, 6, 0x0f2444, 0x3b82f6, 1.2);

    // Luminous Skybridge Connecting Patient Ward Towers
    const skybridge = new THREE.Mesh(
      new THREE.BoxGeometry(5.8, 1.6, 2.2),
      new THREE.MeshPhysicalMaterial({ color: 0x00f0ff, transparent: true, opacity: 0.75, roughness: 0.1 })
    );
    skybridge.position.set(0, 7.5, -12);
    buildingGroup.add(skybridge);

    // 9. 3D Ambulances Parked at Emergency Bay & Arriving on Driveway
    const createAmbulance = (x: number, z: number, rotationY: number) => {
      const ambGroup = new THREE.Group();
      ambGroup.position.set(x, 0, z);
      ambGroup.rotation.y = rotationY;

      // Chassis
      const body = new THREE.Mesh(
        new THREE.BoxGeometry(1.6, 1.1, 3.4),
        new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.2, metalness: 0.4 })
      );
      body.position.y = 0.85;
      ambGroup.add(body);

      // Cab front windshield
      const cab = new THREE.Mesh(
        new THREE.BoxGeometry(1.5, 0.65, 0.9),
        new THREE.MeshPhysicalMaterial({ color: 0x0284c7, transparent: true, opacity: 0.8, roughness: 0.1 })
      );
      cab.position.set(0, 1.1, 1.1);
      ambGroup.add(cab);

      // Red cross decals on sides
      const sideStripe1 = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.35, 1.8), new THREE.MeshBasicMaterial({ color: 0xef4444 }));
      sideStripe1.position.set(-0.83, 0.85, -0.3);
      const sideStripe2 = new THREE.Mesh(new THREE.BoxGeometry(0.05, 0.35, 1.8), new THREE.MeshBasicMaterial({ color: 0xef4444 }));
      sideStripe2.position.set(0.83, 0.85, -0.3);
      ambGroup.add(sideStripe1);
      ambGroup.add(sideStripe2);

      // 4 Wheels
      const wheelMat = new THREE.MeshStandardMaterial({ color: 0x111827, roughness: 0.9 });
      [-0.85, 0.85].forEach((wx) => {
        [-0.9, 0.9].forEach((wz) => {
          const w = new THREE.Mesh(new THREE.CylinderGeometry(0.32, 0.32, 0.22, 16), wheelMat);
          w.rotation.z = Math.PI / 2;
          w.position.set(wx, 0.32, wz);
          ambGroup.add(w);
        });
      });

      // Flashing Emergency Light Bar (Red & Blue spheres)
      const redLight = new THREE.Mesh(new THREE.SphereGeometry(0.16, 12, 12), new THREE.MeshBasicMaterial({ color: 0xef4444 }));
      redLight.position.set(-0.35, 1.55, 0.6);
      const blueLight = new THREE.Mesh(new THREE.SphereGeometry(0.16, 12, 12), new THREE.MeshBasicMaterial({ color: 0x00f0ff }));
      blueLight.position.set(0.35, 1.55, 0.6);
      ambGroup.add(redLight);
      ambGroup.add(blueLight);
      ambulanceLights.push(redLight, blueLight);

      // Headlights projection
      const headlight1 = new THREE.Mesh(new THREE.SphereGeometry(0.12, 8, 8), new THREE.MeshBasicMaterial({ color: 0xffffff }));
      headlight1.position.set(-0.55, 0.6, 1.72);
      const headlight2 = new THREE.Mesh(new THREE.SphereGeometry(0.12, 8, 8), new THREE.MeshBasicMaterial({ color: 0xffffff }));
      headlight2.position.set(0.55, 0.6, 1.72);
      ambGroup.add(headlight1);
      ambGroup.add(headlight2);

      buildingGroup.add(ambGroup);
    };

    // Ambulance 1: Docked in Emergency Portico
    createAmbulance(-11, 9.5, 0);
    // Ambulance 2: Parked adjacent in emergency bay
    createAmbulance(-14, 9.5, 0);
    // Ambulance 3: Approaching on main driveway
    createAmbulance(-6, 16, -Math.PI / 6);

    // 10. Roads, Driveways & Directional Markings
    const roadMat = new THREE.MeshStandardMaterial({ color: 0x0a1324, roughness: 0.9 });
    // Main entrance loop road
    const mainRoad = new THREE.Mesh(new THREE.BoxGeometry(42, 0.05, 5), roadMat);
    mainRoad.position.set(0, 0.01, 15);
    scene.add(mainRoad);

    // Emergency ramp road connecting portico to main loop
    const emergRoad = new THREE.Mesh(new THREE.BoxGeometry(6, 0.05, 14), roadMat);
    emergRoad.position.set(-11, 0.01, 10);
    scene.add(emergRoad);

    // Glowing cyan road striping
    for (let x = -18; x <= 18; x += 4) {
      const stripe = new THREE.Mesh(new THREE.BoxGeometry(1.8, 0.02, 0.2), new THREE.MeshBasicMaterial({ color: 0x00f0ff }));
      stripe.position.set(x, 0.04, 15);
      scene.add(stripe);
    }

    // 11. Campus Landscaping (Stylized Trees & Modern Bollards)
    const treeMatTrunk = new THREE.MeshStandardMaterial({ color: 0x334155 });
    const treeMatFoliage = new THREE.MeshStandardMaterial({ color: 0x047857, roughness: 0.4, metalness: 0.1 });
    const createTree = (tx: number, tz: number) => {
      const trunk = new THREE.Mesh(new THREE.CylinderGeometry(0.15, 0.25, 1.2), treeMatTrunk);
      trunk.position.set(tx, 0.6, tz);
      const foliage = new THREE.Mesh(new THREE.ConeGeometry(1.0, 2.4, 8), treeMatFoliage);
      foliage.position.set(tx, 2.1, tz);
      scene.add(trunk);
      scene.add(foliage);
    };

    [
      [-19, 12], [-17, 7], [-19, 2], [18, 12], [18, 5], [19, -2],
      [-15, -15], [15, -15], [-5, 12], [5, 12],
    ].forEach(([tx, tz]) => createTree(tx, tz));

    // 12. Distant Futuristic City Skyline & Mountains
    const cityMat = new THREE.MeshStandardMaterial({
      color: 0x07152b,
      roughness: 0.7,
      metalness: 0.5,
    });
    for (let i = 0; i < 36; i++) {
      const bW = 4 + Math.random() * 6;
      const bH = 12 + Math.random() * 26;
      const bD = 4 + Math.random() * 6;
      const bX = (Math.random() - 0.5) * 110;
      const bZ = -32 - Math.random() * 45;

      const cityBuilding = new THREE.Mesh(new THREE.BoxGeometry(bW, bH, bD), cityMat);
      cityBuilding.position.set(bX, bH / 2, bZ);
      scene.add(cityBuilding);

      // Window illumination dots on skyscraper facades
      if (Math.random() > 0.4) {
        const winBand = new THREE.Mesh(
          new THREE.BoxGeometry(bW * 0.9, 0.2, bD * 0.9),
          new THREE.MeshBasicMaterial({ color: Math.random() > 0.5 ? 0x00f0ff : 0x93c5fd, transparent: true, opacity: 0.35 })
        );
        winBand.position.set(bX, bH * 0.75, bZ);
        scene.add(winBand);
      }
    }

    // 13. Floating Holographic Data Particles
    const particleCount = 180;
    const particleGeo = new THREE.BufferGeometry();
    const particlePositions = new Float32Array(particleCount * 3);
    for (let i = 0; i < particleCount * 3; i += 3) {
      particlePositions[i] = (Math.random() - 0.5) * 60;
      particlePositions[i + 1] = Math.random() * 25 + 0.5;
      particlePositions[i + 2] = (Math.random() - 0.5) * 60;
    }
    particleGeo.setAttribute('position', new THREE.BufferAttribute(particlePositions, 3));
    const particleMat = new THREE.PointsMaterial({
      color: 0x00f0ff,
      size: 0.32,
      transparent: true,
      opacity: 0.6,
    });
    const particleSystem = new THREE.Points(particleGeo, particleMat);
    scene.add(particleSystem);

    // 14. Raycaster & Coordinates
    const raycaster = new THREE.Raycaster();
    const mouse = new THREE.Vector2();

    sceneRef.current = {
      scene,
      camera,
      renderer,
      buildingGroup,
      raycaster,
      mouse,
      sectionMeshes,
      calloutAnchors,
      lightPulse,
      emergencyBeacon,
      ambulanceLights,
      helicopterRotor: rotorGroup,
      tailRotor,
      crossMesh: crossGroup,
    };

    // 15. Animation Loop with Smooth Lighting & Rotor Movement
    let animationFrameId: number;
    const clock = new THREE.Clock();

    const animate = () => {
      animationFrameId = requestAnimationFrame(animate);
      const elapsed = clock.getElapsedTime();

      // Slow cinematic orbit when user is not manually rotating
      if (!isDragging) {
        buildingGroup.rotation.y = Math.sin(elapsed * 0.08) * 0.14;
      }

      // Helicopter Rotors Spinning
      rotorGroup.rotation.y += 0.35;
      tailRotor.rotation.z += 0.55;

      // Pulse Central Atrium & Medical Cross
      const pulseIntensity = 2.4 + Math.sin(elapsed * 2.4) * 0.9;
      lightPulse.intensity = pulseIntensity;
      crossMat.color.setHex(Math.sin(elapsed * 3.0) > 0 ? 0x00f0ff : 0x7dd3fc);

      // Flashing Emergency Light Beacon & Ambulance Lightbars
      emergencyBeacon.intensity = 2.2 + Math.sin(elapsed * 4.5) * 1.6;
      const toggleFlash = Math.sin(elapsed * 8.0) > 0;
      ambulanceLights.forEach((light, idx) => {
        const isRed = idx % 2 === 0;
        const mat = light.material as THREE.MeshBasicMaterial;
        mat.opacity = (isRed ? toggleFlash : !toggleFlash) ? 1.0 : 0.15;
      });

      // Floating Particles Drift
      const positions = particleGeo.attributes.position.array as Float32Array;
      for (let i = 1; i < particleCount * 3; i += 3) {
        positions[i] += Math.sin(elapsed * 0.8 + i) * 0.015;
      }
      particleGeo.attributes.position.needsUpdate = true;

      // Update 2D Screen Callout Positions Projected from 3D World Space
      const containerRect = container.getBoundingClientRect();
      const w = containerRect.width;
      const h = containerRect.height;
      if (w > 0 && h > 0) {
        const newCoords: Record<string, { x: number; y: number; visible: boolean }> = {};
        calloutAnchors.forEach((anchor3D, key) => {
          const worldPoint = anchor3D.clone();
          worldPoint.applyMatrix4(buildingGroup.matrixWorld);
          const projected = worldPoint.clone().project(camera);
          const px = (projected.x * 0.5 + 0.5) * w;
          const py = (-(projected.y * 0.5) + 0.5) * h;
          const isFront = projected.z < 1.0;
          newCoords[key] = {
            x: px,
            y: py,
            visible: isFront && px > 10 && px < w - 10 && py > 10 && py < h - 10,
          };
        });
        setCalloutCoords(newCoords);
      }

      renderer.render(scene, camera);
    };
    animate();

    // 16. Mouse Drag, Hover & Click Handlers
    let pointerDown = false;
    let prevMouseX = 0;
    let prevMouseY = 0;

    const handlePointerDown = (e: MouseEvent) => {
      pointerDown = true;
      setIsDragging(true);
      prevMouseX = e.clientX;
      prevMouseY = e.clientY;
    };

    const handlePointerMove = (e: MouseEvent) => {
      const rect = container.getBoundingClientRect();
      mouse.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      mouse.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

      if (pointerDown) {
        const deltaX = e.clientX - prevMouseX;
        const deltaY = e.clientY - prevMouseY;
        buildingGroup.rotation.y += deltaX * 0.007;
        camera.position.y = Math.max(8, Math.min(38, camera.position.y - deltaY * 0.06));
        camera.lookAt(0, 3.5, 0);
        prevMouseX = e.clientX;
        prevMouseY = e.clientY;
        return;
      }

      // Hover Raycasting
      raycaster.setFromCamera(mouse, camera);
      const intersects = raycaster.intersectObjects(buildingGroup.children, true);

      let found: string | null = null;
      for (const hit of intersects) {
        let cur: THREE.Object3D | null = hit.object;
        while (cur && cur !== buildingGroup) {
          if (cur.userData && cur.userData.sectionKey) {
            found = cur.userData.sectionKey;
            break;
          }
          cur = cur.parent;
        }
        if (found) break;
      }
      setHoveredSection(found);
    };

    const handlePointerUp = () => {
      pointerDown = false;
      setIsDragging(false);
    };

    const handleClick = () => {
      if (hoveredSection) {
        setSelectedSection(hoveredSection);
        if (onSelectSection) {
          onSelectSection(hoveredSection);
        } else {
          navigateToSection(hoveredSection);
          setShowLandingPage(false);
        }
      }
    };

    const handleWheel = (e: WheelEvent) => {
      e.preventDefault();
      const zoom = e.deltaY * 0.025;
      const currentDist = camera.position.length();
      const newDist = currentDist + zoom;
      if (newDist > 18 && newDist < 65) {
        camera.position.multiplyScalar(newDist / currentDist);
      }
    };

    container.addEventListener('mousedown', handlePointerDown);
    window.addEventListener('mousemove', handlePointerMove);
    window.addEventListener('mouseup', handlePointerUp);
    container.addEventListener('click', handleClick);
    container.addEventListener('wheel', handleWheel, { passive: false });

    const handleResize = () => {
      if (!container || !renderer) return;
      const w = container.clientWidth;
      const h = container.clientHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };

    resizeObserver = new ResizeObserver(handleResize);
    resizeObserver.observe(container);

    return () => {
      if (animationFrameId) cancelAnimationFrame(animationFrameId);
      container.removeEventListener('mousedown', handlePointerDown);
      window.removeEventListener('mousemove', handlePointerMove);
      window.removeEventListener('mouseup', handlePointerUp);
      container.removeEventListener('click', handleClick);
      container.removeEventListener('wheel', handleWheel);
      if (resizeObserver) resizeObserver.disconnect();
      if (renderer) renderer.dispose();
    };
  } catch (err) {
    console.warn('WebGL initialization failed or unaccelerated, activating 2D HUD fallback:', err);
    setWebglError(true);
    return () => {};
  }
  }, [compact]);

  // Highlight 3D Meshes on Hover or Selection
  useEffect(() => {
    if (!sceneRef.current) return;
    const { sectionMeshes } = sceneRef.current;

    sectionMeshes.forEach((meshes, key) => {
      const isTarget = key === hoveredSection || key === selectedSection;
      meshes.forEach((mesh) => {
        const mat = mesh.material as THREE.MeshPhysicalMaterial;
        if (isTarget) {
          mat.emissive = new THREE.Color(HOSPITAL_SECTIONS[key]?.color || 0x00f0ff);
          mat.emissiveIntensity = 0.55;
          mat.opacity = 0.98;
        } else {
          mat.emissive = new THREE.Color(0x000000);
          mat.emissiveIntensity = 0;
          mat.opacity = 0.88;
        }
      });
    });
  }, [hoveredSection, selectedSection]);

  // Camera presets transition
  const setCameraPreset = (view: 'overview' | 'emergency' | 'icu' | 'lab') => {
    if (!sceneRef.current) return;
    const { camera, buildingGroup } = sceneRef.current;
    setCameraView(view);

    switch (view) {
      case 'emergency':
        camera.position.set(-24, 14, 20);
        camera.lookAt(-11, 2.5, 5);
        buildingGroup.rotation.y = 0;
        setSelectedSection('emergency');
        break;
      case 'icu':
        camera.position.set(0, 24, 22);
        camera.lookAt(0, 8.5, -2);
        buildingGroup.rotation.y = 0;
        setSelectedSection('icu');
        break;
      case 'lab':
        camera.position.set(24, 15, 18);
        camera.lookAt(10, 3.5, 3.5);
        buildingGroup.rotation.y = 0;
        setSelectedSection('laboratory');
        break;
      case 'overview':
      default:
        camera.position.set(28, 22, 32);
        camera.lookAt(0, 3.5, 0);
        buildingGroup.rotation.y = 0;
        break;
    }
  };

  const activeSectionData = useMemo(() => {
    const key = hoveredSection || selectedSection || 'emergency';
    return HOSPITAL_SECTIONS[key] || HOSPITAL_SECTIONS.emergency;
  }, [hoveredSection, selectedSection]);

  const ActiveIcon = activeSectionData.icon;

  const handleCalloutClick = (key: string) => {
    setSelectedSection(key);
    if (onSelectSection) {
      onSelectSection(key);
    } else {
      navigateToSection(key);
      setShowLandingPage(false);
    }
  };

  return (
    <div
      className={`relative w-full rounded-3xl overflow-hidden border border-cyan-500/30 bg-slate-950/90 backdrop-blur-2xl shadow-2xl transition-all ${
        compact ? 'h-[420px]' : 'h-[620px] lg:h-[680px]'
      }`}
    >
      {/* WebGL Canvas Container */}
      {!webglError ? (
        <div ref={containerRef} className="w-full h-full cursor-grab active:cursor-grabbing" />
      ) : (
        <div className="w-full h-full p-8 flex flex-col justify-between bg-gradient-to-br from-slate-950 via-slate-900 to-cyan-950/40 relative">
          <div className="flex items-center justify-between">
            <div>
              <span className="text-[10px] font-mono uppercase text-cyan-400 font-bold tracking-widest px-2.5 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/30">
                2D Telemetry Digital Twin Mode
              </span>
              <h3 className="text-xl font-bold text-white mt-2">MediSphere Campus Sectors</h3>
              <p className="text-xs text-slate-400 mt-1">Select a facility wing to inspect telemetry and routing.</p>
            </div>
            <button
              onClick={() => setWebglError(false)}
              className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs text-cyan-300 border border-slate-700 font-semibold"
            >
              Re-initialize 3D
            </button>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 my-auto">
            {Object.entries(HOSPITAL_SECTIONS).map(([key, sec]) => {
              const Icon = sec.icon;
              const isSelected = selectedSection === key;
              return (
                <button
                  key={key}
                  onClick={() => handleCalloutClick(key)}
                  className={`p-4 rounded-2xl border text-left transition backdrop-blur-xl ${
                    isSelected
                      ? 'bg-slate-900/90 border-cyan-400 shadow-lg shadow-cyan-500/20'
                      : 'bg-slate-950/70 border-slate-800 hover:border-slate-700 hover:bg-slate-900/50'
                  }`}
                >
                  <div className="w-8 h-8 rounded-xl flex items-center justify-center mb-2" style={{ backgroundColor: `${sec.color}20`, color: sec.color }}>
                    <Icon className="w-4 h-4" />
                  </div>
                  <h4 className="text-xs font-bold text-white">{sec.name}</h4>
                  <span className="text-[10px] font-mono text-cyan-300 block mt-0.5">{sec.statPrimary}</span>
                  <span className="text-[9px] text-slate-400 block mt-1 line-clamp-1">{sec.description}</span>
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* Floating 3D Holographic Callouts Connected to Buildings */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        {Object.entries(HOSPITAL_SECTIONS).map(([key, sec]) => {
          const coords = calloutCoords[key];
          if (!coords || !coords.visible) return null;

          const isHovered = hoveredSection === key;
          const isSelected = selectedSection === key;
          const Icon = sec.icon;

          // Target offset for panel placement
          const offsetX = sec.calloutOffset.x;
          const offsetY = sec.calloutOffset.y;
          const panelX = coords.x + offsetX;
          const panelY = coords.y + offsetY;

          return (
            <div key={key} className="absolute inset-0 pointer-events-none">
              {/* Thin glowing holographic connecting line */}
              <svg className="absolute inset-0 w-full h-full pointer-events-none">
                <defs>
                  <linearGradient id={`line-grad-${key}`} x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor={sec.color} stopOpacity="0.9" />
                    <stop offset="100%" stopColor="#00f0ff" stopOpacity="0.4" />
                  </linearGradient>
                </defs>
                <line
                  x1={coords.x}
                  y1={coords.y}
                  x2={panelX}
                  y2={panelY}
                  stroke={`url(#line-grad-${key})`}
                  strokeWidth={isHovered ? '2' : '1.2'}
                  strokeDasharray="4 3"
                  className="transition-all"
                />
                <circle cx={coords.x} cy={coords.y} r={isHovered ? 4 : 2.5} fill={sec.color} />
              </svg>

              {/* Holographic Floating Information Panel */}
              <div
                style={{
                  left: `${panelX}px`,
                  top: `${panelY}px`,
                  transform: 'translate(-50%, -50%)',
                }}
                className={`absolute pointer-events-auto cursor-pointer transition-all duration-300 ${
                  isHovered || isSelected ? 'scale-105 z-30' : 'scale-95 opacity-90 hover:opacity-100 z-20'
                }`}
                onMouseEnter={() => setHoveredSection(key)}
                onMouseLeave={() => setHoveredSection(null)}
                onClick={() => handleCalloutClick(key)}
              >
                <div
                  className={`px-3 py-2 rounded-xl backdrop-blur-xl border flex items-center gap-2.5 shadow-xl transition-all ${
                    isHovered || isSelected
                      ? 'bg-slate-900/95 border-cyan-400 shadow-cyan-500/30'
                      : 'bg-slate-950/80 border-slate-800/90 hover:border-cyan-500/50'
                  }`}
                  style={{
                    boxShadow: isHovered ? `0 0 16px ${sec.color}40` : undefined,
                  }}
                >
                  <div
                    className="w-7 h-7 rounded-lg flex items-center justify-center text-white flex-shrink-0"
                    style={{ backgroundColor: `${sec.color}35`, borderColor: `${sec.color}80`, borderWidth: 1 }}
                  >
                    <Icon className="w-3.5 h-3.5" />
                  </div>
                  <div>
                    <div className="flex items-center gap-1.5">
                      <span className="text-xs font-black text-white whitespace-nowrap tracking-tight">
                        {sec.name}
                      </span>
                    </div>
                    <div className="text-[10px] text-slate-300 font-mono whitespace-nowrap">
                      <span className="text-cyan-300 font-semibold">{sec.statPrimary}</span>
                      {sec.statSecondary && (
                        <span className="text-slate-400 ml-1.5 border-l border-slate-700 pl-1.5">
                          {sec.statSecondary}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Top Left Live Digital Twin Telemetry HUD */}
      <div className="absolute top-4 left-4 z-20 flex flex-col gap-2 pointer-events-none">
        <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-900/90 border border-cyan-500/40 backdrop-blur-xl shadow-lg">
          <div className="w-2.5 h-2.5 rounded-full bg-cyan-400 animate-ping" />
          <span className="text-xs font-bold text-cyan-300 tracking-wider uppercase">
            MediSphere 3D &bull; Digital Twin
          </span>
          <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700">
            PBR WebGL &bull; 60 FPS
          </span>
        </div>
        <span className="text-[11px] text-slate-400 max-w-xs drop-shadow hidden sm:block">
          Interactive hospital complex. Click or hover any wing to enter operational module.
        </span>
      </div>

      {/* Top Right Quick Camera Presets */}
      <div className="absolute top-4 right-4 z-20 flex items-center gap-1 p-1 rounded-xl bg-slate-900/90 border border-cyan-500/30 backdrop-blur-xl shadow-lg">
        <button
          onClick={() => setCameraPreset('overview')}
          className={`px-3 py-1 text-xs rounded-lg transition font-semibold ${
            cameraView === 'overview'
              ? 'bg-cyan-500/25 text-cyan-300 border border-cyan-500/50'
              : 'text-slate-400 hover:text-white'
          }`}
          title="Campus Cinematic Overview"
        >
          Overview
        </button>
        <button
          onClick={() => setCameraPreset('emergency')}
          className={`px-3 py-1 text-xs rounded-lg transition font-semibold ${
            cameraView === 'emergency'
              ? 'bg-red-500/25 text-red-300 border border-red-500/50'
              : 'text-slate-400 hover:text-white'
          }`}
          title="Trauma Bay & Ambulances"
        >
          Emergency
        </button>
        <button
          onClick={() => setCameraPreset('icu')}
          className={`px-3 py-1 text-xs rounded-lg transition font-semibold ${
            cameraView === 'icu'
              ? 'bg-cyan-500/25 text-cyan-300 border border-cyan-500/50'
              : 'text-slate-400 hover:text-white'
          }`}
          title="ICU Tower & Helipad"
        >
          ICU Tower
        </button>
        <button
          onClick={() => setCameraPreset('lab')}
          className={`px-3 py-1 text-xs rounded-lg transition font-semibold ${
            cameraView === 'lab'
              ? 'bg-purple-500/25 text-purple-300 border border-purple-500/50'
              : 'text-slate-400 hover:text-white'
          }`}
          title="Pathology Lab"
        >
          Diagnostics
        </button>
      </div>

      {/* Bottom Floating Telemetry & Inspection Card */}
      <div className="absolute bottom-4 left-4 right-4 sm:right-auto sm:max-w-md z-20 pointer-events-auto">
        <div className="p-4 rounded-2xl bg-slate-950/90 border border-cyan-500/40 backdrop-blur-2xl shadow-2xl transition-all">
          <div className="flex items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div
                className="w-10 h-10 rounded-xl flex items-center justify-center border shadow-inner"
                style={{
                  backgroundColor: `${activeSectionData.color}25`,
                  borderColor: `${activeSectionData.color}60`,
                  color: activeSectionData.color,
                }}
              >
                <ActiveIcon className="w-5 h-5" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h4 className="text-sm font-black text-white tracking-wide">
                    {activeSectionData.name}
                  </h4>
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-800 text-cyan-300 border border-cyan-500/30">
                    {activeSectionData.badge}
                  </span>
                </div>
                <p className="text-xs text-slate-300 mt-0.5 leading-snug">{activeSectionData.description}</p>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2 mt-3 pt-3 border-t border-slate-800">
            <div className="px-3 py-1.5 rounded-lg bg-slate-900/90 border border-slate-800">
              <span className="text-[9px] uppercase text-slate-400 font-bold block">
                Telemetry 1
              </span>
              <span className="text-xs font-bold text-white mt-0.5 block">
                {activeSectionData.statPrimary}
              </span>
            </div>
            <div className="px-3 py-1.5 rounded-lg bg-slate-900/90 border border-slate-800">
              <span className="text-[9px] uppercase text-slate-400 font-bold block">
                Telemetry 2
              </span>
              <span className="text-xs font-bold text-cyan-400 mt-0.5 block">
                {activeSectionData.statSecondary}
              </span>
            </div>
          </div>

          <div className="flex items-center justify-between mt-3 pt-2">
            <span className="text-[11px] text-slate-400 flex items-center gap-1">
              <Info className="w-3.5 h-3.5 text-cyan-400" />
              Hover/click wing to launch module
            </span>
            <button
              onClick={() => handleCalloutClick(activeSectionData.key)}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs font-bold bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white transition shadow-lg shadow-cyan-500/25"
            >
              Open Wing
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
