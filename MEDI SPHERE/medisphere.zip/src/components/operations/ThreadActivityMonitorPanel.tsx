import React, { useState, useEffect, useMemo, useRef } from 'react';
import { useHospital } from '../../context/HospitalContext';
import { SystemThreadInfo, JavaThreadState } from '../../types';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  PieChart,
  Pie,
  Cell,
  Legend,
  ReferenceLine,
} from 'recharts';
import {
  Cpu,
  Activity,
  Play,
  Pause,
  RotateCw,
  Lock,
  Unlock,
  ShieldCheck,
  Zap,
  Terminal,
  Flame,
  Plus,
  CheckCircle2,
  AlertTriangle,
  Server,
  Gauge,
  Layers,
  Sparkles,
  ArrowUpRight,
  TrendingUp,
  ShieldAlert,
  BellRing,
  Sliders,
  AlertOctagon,
} from 'lucide-react';

interface ThreadActivityMonitorPanelProps {
  compactMode?: boolean;
}

export const ThreadActivityMonitorPanel: React.FC<ThreadActivityMonitorPanelProps> = ({
  compactMode = false,
}) => {
  const {
    threads = [],
    pauseThread,
    resumeThread,
    toggleThreadState,
    spawnWorkerThread,
    triggerGarbageCollection,
    triggerConcurrencyStressTest,
    simulateThreadLatencySpike,
    mitigateThreadLatency,
    updateThreadLatencyThreshold,
    systemLogs = [],
    addToast,
  } = useHospital();

  const [isLiveStreaming, setIsLiveStreaming] = useState<boolean>(true);
  const [selectedThreadFilter, setSelectedThreadFilter] = useState<'ALL' | 'ACTIVE' | 'WAITING'>('ALL');
  const [isDetectingDeadlock, setIsDetectingDeadlock] = useState<boolean>(false);
  const [deadlockReport, setDeadlockReport] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'charts' | 'threads' | 'locks' | 'logs'>('charts');

  // Automated Latency Alert State & Watchdog
  const [isAutoAlertEnabled, setIsAutoAlertEnabled] = useState<boolean>(true);
  const [globalSafetyThresholdMs, setGlobalSafetyThresholdMs] = useState<number>(140);
  const [selectedSpikeThreadId, setSelectedSpikeThreadId] = useState<string>('');
  const lastAlertTimesRef = useRef<Record<string, number>>({});

  // Real-time timeline history data for process charts
  const [timelineData, setTimelineData] = useState<
    Array<{
      time: string;
      throughput: number;
      cpuLoad: number;
      activeThreads: number;
      memoryUsed: number;
    }>
  >(() => {
    const initial = [];
    const now = new Date();
    for (let i = 9; i >= 0; i--) {
      const past = new Date(now.getTime() - i * 3000);
      const timeStr = past.toTimeString().split(' ')[0].substring(3, 8);
      initial.push({
        time: timeStr,
        throughput: Math.floor(450 + Math.random() * 220),
        cpuLoad: Number((11 + Math.random() * 8).toFixed(1)),
        activeThreads: 5 + (i % 3 === 0 ? 1 : 0),
        memoryUsed: Math.floor(160 + Math.random() * 25),
      });
    }
    return initial;
  });

  // Simulated continuous real-time telemetry streaming
  useEffect(() => {
    if (!isLiveStreaming) return;

    const interval = setInterval(() => {
      const timeStr = new Date().toTimeString().split(' ')[0].substring(3, 8);
      const activeCount = threads.filter(
        (t) => t.state === 'RUNNING' || t.state === 'RUNNABLE'
      ).length;

      const totalCpu = threads.reduce(
        (sum, t) => sum + (t.cpuUsagePercent ?? t.cpuUsage ?? 0),
        0
      );
      const avgCpu = threads.length > 0 ? totalCpu / threads.length : 12.5;
      const jitteredCpu = Number(Math.max(4, avgCpu + (Math.random() * 4 - 2)).toFixed(1));
      const jitteredThroughput = Math.floor(activeCount * 95 + Math.random() * 120 + 200);
      const jitteredMem = Math.floor(164 + Math.random() * 15);

      setTimelineData((prev) => {
        const next = [
          ...prev.slice(1),
          {
            time: timeStr,
            throughput: jitteredThroughput,
            cpuLoad: jitteredCpu,
            activeThreads: activeCount,
            memoryUsed: jitteredMem,
          },
        ];
        return next;
      });
    }, 2800);

    return () => clearInterval(interval);
  }, [isLiveStreaming, threads]);

  // Automated Alert System Watchdog: Evaluates thread latencies against safety thresholds
  useEffect(() => {
    if (!isAutoAlertEnabled) return;

    threads.forEach((t) => {
      const threshold = t.latencyThresholdMs ?? globalSafetyThresholdMs;
      const currentLat = t.latencyMs ?? 42;

      if (currentLat > threshold) {
        const lastAlert = lastAlertTimesRef.current[t.id] || 0;
        const now = Date.now();

        // 12-second debounce per thread
        if (now - lastAlert > 12000) {
          lastAlertTimesRef.current[t.id] = now;
          const isCritical = currentLat >= threshold * 1.5;

          addToast(
            `🚨 Thread Latency SLA Alert: ${t.threadName}`,
            `Thread latency spiked to ${currentLat}ms (Safety SLA Threshold: ${threshold}ms). Resource lock: ${t.synchronizationLock || 'ConcurrentExecutorQueue'}.`,
            isCritical ? 'error' : 'warning',
            `org.medisphere.exceptions.ThreadExecutionTimeoutException: Thread [${t.threadName}] execution latency ${currentLat}ms exceeded safety threshold ${threshold}ms`
          );
        }
      }
    });
  }, [threads, isAutoAlertEnabled, globalSafetyThresholdMs, addToast]);

  // Operational Mutex Locks
  const lockMatrix = [
    {
      name: 'LabAnalyzerSync.class',
      type: 'LinkedBlockingQueue<Specimen>',
      status: 'SYNCHRONIZED',
      owner: 'LabDiagnosticThreadPool-Worker-2',
      waiters: 1,
      module: 'Laboratory Operations',
      criticalSection: 'Automated Specimen Batch Pipeline',
    },
    {
      name: 'PharmacyInventoryLock',
      type: 'AtomicInteger + CompareAndSwap',
      status: 'ACQUIRED',
      owner: 'PharmacyDispenseWorker',
      waiters: 0,
      module: 'Pharmacy Formulary',
      criticalSection: 'SKU Inventory Mutex Decrement',
    },
    {
      name: 'BedAllocationRegistry.mutex',
      type: 'java.util.concurrent.locks.ReentrantLock',
      status: 'ACQUIRED',
      owner: 'BedAllocationLockMonitor',
      waiters: 2,
      module: 'Bed Management',
      criticalSection: 'ICU & Critical Ward Bitset Grid',
    },
    {
      name: 'ReentrantLock(invoiceLedger)',
      type: 'ReadWriteLock.writeLock()',
      status: 'RELEASED',
      owner: 'BillingTransactionLedger-1',
      waiters: 0,
      module: 'Billing & Invoices',
      criticalSection: 'ACID Serializable GST Journal Buffer',
    },
    {
      name: 'EmergencyQueueMonitor.lock',
      type: 'Fair ReentrantLock',
      status: 'ACQUIRED',
      owner: 'EmergencyPriorityQueueTriage-Worker',
      waiters: 0,
      module: 'Emergency Trauma Bay',
      criticalSection: 'PriorityQueue Binary Min-Heap Rebalancing',
    },
  ];

  // Aggregated Computations
  const activeThreadsCount = threads.filter(
    (t) => t.state === 'RUNNING' || t.state === 'RUNNABLE'
  ).length;
  const waitingThreadsCount = threads.filter(
    (t) => t.state === 'WAITING' || t.state === 'TIMED_WAITING'
  ).length;
  const blockedThreadsCount = threads.filter((t) => t.state === 'BLOCKED').length;

  const totalOpsProcessed = threads.reduce(
    (acc, t) => acc + (t.processedCount || 0),
    0
  );

  // State distribution for Donut Chart
  const stateDistribution = useMemo(() => {
    const running = threads.filter((t) => t.state === 'RUNNING').length;
    const runnable = threads.filter((t) => t.state === 'RUNNABLE').length;
    const waiting = threads.filter(
      (t) => t.state === 'WAITING' || t.state === 'TIMED_WAITING'
    ).length;
    const blocked = threads.filter((t) => t.state === 'BLOCKED').length;

    return [
      { name: 'Running', value: running, color: '#10b981' },
      { name: 'Runnable', value: runnable, color: '#06b6d4' },
      { name: 'Waiting / Idle', value: waiting, color: '#6366f1' },
      { name: 'Blocked', value: blocked, color: '#f43f5e' },
    ].filter((item) => item.value > 0);
  }, [threads]);

  // Per-Thread CPU & Operations Bar Chart data
  const threadBarData = useMemo(() => {
    return threads.map((t) => {
      // Short label for chart readability
      const shortName = t.threadName
        .replace('PatientRegistrationWorker-1', 'PatientReg-1')
        .replace('AppointmentSchedulerEngine-1', 'ApptSched-1')
        .replace('EmergencyPriorityQueueTriage-Worker', 'EmergTriage')
        .replace('LabDiagnosticThreadPool-Worker-2', 'LabWorker-2')
        .replace('BillingTransactionLedger-1', 'BillingLedger')
        .replace('BedAllocationLockMonitor', 'BedSync')
        .replace('JavaGarbageCollectorTelemetry-Daemon', 'JVM-GC')
        .replace('AsyncHospitalWorker-', 'Worker-');

      return {
        id: t.id,
        name: shortName,
        fullName: t.threadName,
        cpu: Number((t.cpuUsagePercent ?? t.cpuUsage ?? 0).toFixed(1)),
        ops: t.processedCount || 0,
        state: t.state,
      };
    });
  }, [threads]);

  // Latency & Safety SLA Computations
  const breachedThreads = useMemo(() => {
    return threads.filter(
      (t) => (t.latencyMs ?? 42) > (t.latencyThresholdMs ?? globalSafetyThresholdMs)
    );
  }, [threads, globalSafetyThresholdMs]);

  const avgLatency = useMemo(() => {
    if (threads.length === 0) return 42;
    const sum = threads.reduce((acc, t) => acc + (t.latencyMs ?? 42), 0);
    return Math.round(sum / threads.length);
  }, [threads]);

  const maxLatency = useMemo(() => {
    if (threads.length === 0) return 42;
    return Math.max(...threads.map((t) => t.latencyMs ?? 42));
  }, [threads]);

  const slaCompliancePercent = useMemo(() => {
    if (threads.length === 0) return 100;
    const compliant = threads.filter(
      (t) => (t.latencyMs ?? 42) <= (t.latencyThresholdMs ?? globalSafetyThresholdMs)
    ).length;
    return Math.round((compliant / threads.length) * 100);
  }, [threads, globalSafetyThresholdMs]);

  // Per-Thread Latency Bar Chart data
  const threadLatencyData = useMemo(() => {
    return threads.map((t) => {
      const shortName = t.threadName
        .replace('PatientRegistrationWorker-1', 'PatientReg')
        .replace('AppointmentSchedulerEngine-1', 'ApptSched')
        .replace('EmergencyPriorityQueueTriage-Worker', 'EmergTriage')
        .replace('LabDiagnosticThreadPool-Worker-2', 'LabWorker')
        .replace('BillingTransactionLedger-1', 'BillingLedger')
        .replace('BedAllocationLockMonitor', 'BedSync')
        .replace('JavaGarbageCollectorTelemetry-Daemon', 'JVM-GC')
        .replace('AsyncHospitalWorker-', 'Worker-');

      const lat = t.latencyMs ?? 42;
      const thresh = t.latencyThresholdMs ?? globalSafetyThresholdMs;
      const isBreached = lat > thresh;

      return {
        id: t.id,
        name: shortName,
        fullName: t.threadName,
        latency: lat,
        threshold: thresh,
        isBreached,
        excessMs: Math.max(0, lat - thresh),
        state: t.state,
        lock: t.synchronizationLock || 'Lock-Free',
      };
    });
  }, [threads, globalSafetyThresholdMs]);

  const handleDeadlockDetection = () => {
    setIsDetectingDeadlock(true);
    setDeadlockReport('Analyzing Wait-For-Graph (WFG) & lock acquisition ordering...');
    setTimeout(() => {
      setIsDetectingDeadlock(false);
      setDeadlockReport(
        'STATUS 200 OK: Zero cyclic dependencies found across 5 ReentrantLocks and all active threads.'
      );
    }, 1200);
  };

  const handleSpawnWorker = () => {
    const operationalTasks = [
      'Processing Automated Hematology Analyzer Specimen Batch #842',
      'Validating Pharmacy Barcode Batch Dispensary Lock',
      'Synchronizing Ward Bed Telemetry Vitals with Central Nurse Station',
      'Compiling GST Invoicing Statement for Discharged Patient PAT-1012',
      'Executing Binary Min-Heap Priority Re-index for Emergency Trauma Bay',
    ];
    const task = operationalTasks[Math.floor(Math.random() * operationalTasks.length)];
    spawnWorkerThread(task);
    if (addToast) {
      addToast(
        'Java Worker Spawned',
        `Spawned new worker thread in HospitalWorkerGroup: "${task}"`,
        'success'
      );
    }
  };

  const filteredThreads = threads.filter((t) => {
    if (selectedThreadFilter === 'ACTIVE') {
      return t.state === 'RUNNING' || t.state === 'RUNNABLE';
    }
    if (selectedThreadFilter === 'WAITING') {
      return t.state === 'WAITING' || t.state === 'TIMED_WAITING';
    }
    return true;
  });

  const getBadgeClass = (state: JavaThreadState) => {
    switch (state) {
      case 'RUNNING':
        return 'bg-emerald-500/20 text-emerald-400 border-emerald-500/40';
      case 'RUNNABLE':
        return 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40';
      case 'TIMED_WAITING':
      case 'WAITING':
        return 'bg-blue-500/20 text-blue-300 border-blue-500/40';
      case 'BLOCKED':
        return 'bg-rose-500/20 text-rose-400 border-rose-500/40 animate-pulse';
      default:
        return 'bg-slate-800 text-slate-300 border-slate-700';
    }
  };

  return (
    <div
      id="hospital-operations-thread-monitor-panel"
      className="rounded-3xl glass-card border border-cyan-500/30 shadow-2xl p-4 sm:p-6 relative overflow-hidden space-y-6"
    >
      {/* Background Ambience Glow */}
      <div className="absolute top-0 right-1/4 w-96 h-36 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-10 w-80 h-32 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Top Header & Operational Status */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-4 border-b border-cyan-500/20">
        <div className="space-y-1">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-[10px] font-mono font-bold tracking-widest px-2.5 py-0.5 rounded-full bg-cyan-500/15 text-cyan-300 border border-cyan-500/30 uppercase flex items-center gap-1.5">
              <Cpu className="w-3.5 h-3.5 text-cyan-400 animate-pulse" />
              Java Multi-Threading Engine &bull; ThreadPoolExecutor
            </span>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 font-semibold flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
              CONCURRENCY ENGINE ACTIVE
            </span>
            <span className="text-[10px] font-mono text-slate-400">
              JVM 21 LTS &bull; G1GC
            </span>
          </div>

          <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight flex items-center gap-2.5">
            Hospital Operations Thread Activity Monitor
          </h2>
          <p className="text-xs text-slate-300 max-w-3xl leading-relaxed">
            Real-time process telemetry of concurrent background workers orchestrating laboratory specimen queues,
            pharmacy inventory CAS locks, ward bed allocation mutexes, and ACID billing ledgers.
          </p>
        </div>

        {/* Global Action Controls */}
        <div className="flex items-center flex-wrap gap-2.5 shrink-0">
          <button
            id="toggle-live-stream-btn"
            onClick={() => setIsLiveStreaming(!isLiveStreaming)}
            className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl border text-xs font-bold transition cursor-pointer ${
              isLiveStreaming
                ? 'bg-cyan-500/20 text-cyan-200 border-cyan-400/40 hover:bg-cyan-500/30 shadow-[0_0_12px_rgba(6,182,212,0.3)]'
                : 'bg-slate-900/80 text-slate-400 border-slate-700 hover:text-white'
            }`}
            title="Toggle live telemetry streaming chart updates"
          >
            {isLiveStreaming ? (
              <>
                <Activity className="w-3.5 h-3.5 text-cyan-400 animate-spin" />
                <span>Live Streaming</span>
              </>
            ) : (
              <>
                <Pause className="w-3.5 h-3.5" />
                <span>Stream Paused</span>
              </>
            )}
          </button>

          <button
            id="simulate-latency-spike-btn"
            onClick={() => simulateThreadLatencySpike(selectedSpikeThreadId || undefined)}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 border border-amber-500/50 text-amber-300 hover:text-white text-xs font-bold transition shadow-sm cursor-pointer"
            title="Simulate a sudden latency spike to trigger automated toast alerts and visual markings"
          >
            <Zap className="w-3.5 h-3.5 text-amber-400 animate-pulse" />
            <span>Spike Latency</span>
          </button>

          {breachedThreads.length > 0 && (
            <button
              id="mitigate-all-latencies-btn"
              onClick={() => mitigateThreadLatency()}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-slate-950 text-xs font-black transition shadow-lg shadow-emerald-600/40 cursor-pointer animate-pulse"
              title="Reset all threads back to safe nominal baseline (<50ms)"
            >
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Mitigate ({breachedThreads.length})</span>
            </button>
          )}

          <button
            id="spawn-worker-thread-btn"
            onClick={handleSpawnWorker}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-slate-950 text-xs font-extrabold shadow-lg shadow-cyan-600/30 hover:shadow-cyan-500/50 transition cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Spawn Worker</span>
          </button>

          <button
            id="trigger-stress-test-btn"
            onClick={() => triggerConcurrencyStressTest()}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-rose-950/60 hover:bg-rose-900/70 border border-rose-500/40 text-rose-300 hover:text-white text-xs font-bold transition shadow-sm cursor-pointer"
            title="Fire 20 concurrent threads against shared locks"
          >
            <Flame className="w-3.5 h-3.5 text-rose-400" />
            <span>Stress Test</span>
          </button>

          <button
            id="trigger-gc-btn"
            onClick={() => triggerGarbageCollection()}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900/80 hover:bg-slate-800 border border-slate-700 text-slate-300 hover:text-white text-xs font-mono transition cursor-pointer"
            title="Trigger java.lang.System.gc()"
          >
            <RotateCw className="w-3.5 h-3.5 text-cyan-400" />
            <span>System.gc()</span>
          </button>
        </div>
      </div>

      {/* KPI Telemetry Tiles (6-Grid with Latency SLA Metric) */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        <div className="p-3.5 rounded-2xl bg-slate-950/60 border border-cyan-500/20 shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-[10px] uppercase font-bold tracking-wider">Active Workers</span>
            <Activity className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="flex items-baseline gap-1.5">
            <span className="text-2xl font-black text-white font-mono">{activeThreadsCount}</span>
            <span className="text-xs font-mono text-slate-400">/ {threads.length}</span>
          </div>
          <span className="text-[10px] text-emerald-400 font-mono mt-1 flex items-center gap-1">
            <CheckCircle2 className="w-3 h-3" />
            {blockedThreadsCount === 0 ? '0 Blocked' : `${blockedThreadsCount} Blocked`}
          </span>
        </div>

        <div className="p-3.5 rounded-2xl bg-slate-950/60 border border-cyan-500/20 shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-[10px] uppercase font-bold tracking-wider">Total Throughput</span>
            <TrendingUp className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="flex items-baseline gap-1.5">
            <span className="text-2xl font-black text-emerald-300 font-mono">
              {totalOpsProcessed.toLocaleString()}
            </span>
          </div>
          <span className="text-[10px] text-slate-400 font-mono mt-1">
            Processed tasks
          </span>
        </div>

        {/* Latency & Safety SLA Health Metric */}
        <div
          className={`p-3.5 rounded-2xl border shadow-sm flex flex-col justify-between transition-all ${
            breachedThreads.length > 0
              ? 'bg-rose-950/40 border-rose-500/60 shadow-[0_0_20px_rgba(244,63,94,0.25)] ring-1 ring-rose-500/40'
              : 'bg-slate-950/60 border-cyan-500/20'
          }`}
        >
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-[10px] uppercase font-bold tracking-wider">Latency SLA</span>
            <ShieldAlert
              className={`w-4 h-4 ${
                breachedThreads.length > 0 ? 'text-rose-400 animate-pulse' : 'text-cyan-400'
              }`}
            />
          </div>
          <div className="flex items-baseline gap-1.5">
            <span
              className={`text-2xl font-black font-mono ${
                breachedThreads.length > 0 ? 'text-rose-300' : 'text-cyan-300'
              }`}
            >
              {avgLatency}
            </span>
            <span className="text-xs font-mono text-slate-400">ms avg</span>
          </div>
          <span
            className={`text-[10px] font-mono mt-1 flex items-center gap-1 font-bold ${
              breachedThreads.length > 0 ? 'text-rose-400 animate-pulse' : 'text-emerald-400'
            }`}
          >
            {breachedThreads.length > 0 ? (
              <>
                <AlertTriangle className="w-3 h-3" />
                {breachedThreads.length} Breach ({maxLatency}ms max)
              </>
            ) : (
              <>
                <CheckCircle2 className="w-3 h-3" />
                {slaCompliancePercent}% SLA Compliant
              </>
            )}
          </span>
        </div>

        <div className="p-3.5 rounded-2xl bg-slate-950/60 border border-cyan-500/20 shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-[10px] uppercase font-bold tracking-wider">G1GC JVM Heap</span>
            <Server className="w-4 h-4 text-indigo-400" />
          </div>
          <div className="flex items-baseline gap-1.5">
            <span className="text-2xl font-black text-indigo-300 font-mono">164</span>
            <span className="text-xs font-mono text-slate-400">/ 512 MB</span>
          </div>
          <span className="text-[10px] text-slate-400 font-mono mt-1">
            348 MB free young gen
          </span>
        </div>

        <div className="p-3.5 rounded-2xl bg-slate-950/60 border border-cyan-500/20 shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-[10px] uppercase font-bold tracking-wider">Concurrency Locks</span>
            <Lock className="w-4 h-4 text-amber-400" />
          </div>
          <div className="flex items-baseline gap-1.5">
            <span className="text-2xl font-black text-amber-300 font-mono">5</span>
            <span className="text-xs font-mono text-slate-400">Monitors</span>
          </div>
          <span className="text-[10px] text-slate-400 font-mono mt-1">
            Reentrant & CAS locks
          </span>
        </div>

        <div className="p-3.5 rounded-2xl bg-slate-950/60 border border-cyan-500/20 shadow-sm flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-[10px] uppercase font-bold tracking-wider">Deadlock Detector</span>
            <ShieldCheck className="w-4 h-4 text-cyan-400" />
          </div>
          <button
            id="run-deadlock-audit-btn"
            onClick={handleDeadlockDetection}
            disabled={isDetectingDeadlock}
            className="w-full py-1.5 px-2 rounded-xl bg-cyan-500/15 hover:bg-cyan-500/25 border border-cyan-500/30 text-[10px] font-bold text-cyan-300 hover:text-white transition flex items-center justify-center gap-1 cursor-pointer disabled:opacity-50"
          >
            <ShieldCheck className={`w-3 h-3 ${isDetectingDeadlock ? 'animate-spin' : ''}`} />
            <span>{isDetectingDeadlock ? 'Checking...' : 'Audit Deadlocks'}</span>
          </button>
          <span className="text-[9px] font-mono text-emerald-400 mt-1 truncate">
            {deadlockReport ? 'Cycle Search: Clean' : 'Tarjan/DFS verified'}
          </span>
        </div>
      </div>

      {/* Prominent Automated Latency Safety Alert Banner */}
      {breachedThreads.length > 0 && (
        <div
          id="automated-latency-breach-banner"
          className="p-4 rounded-2xl bg-gradient-to-r from-rose-950/90 via-slate-950/95 to-rose-950/90 border-2 border-rose-500 shadow-[0_0_30px_rgba(244,63,94,0.4)] flex flex-col md:flex-row md:items-center justify-between gap-4 animate-in fade-in"
        >
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-xl bg-rose-500/20 border border-rose-500/60 flex items-center justify-center text-rose-400 shrink-0 mt-0.5">
              <ShieldAlert className="w-6 h-6 animate-pulse" />
            </div>
            <div className="space-y-1">
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-[11px] font-black uppercase tracking-wider px-2 py-0.5 rounded-md bg-rose-500/30 text-rose-200 border border-rose-500/50 flex items-center gap-1">
                  <BellRing className="w-3.5 h-3.5 text-rose-400 animate-bounce" />
                  AUTOMATED LATENCY ALERT TRIGGERED
                </span>
                <span className="text-xs font-mono font-bold text-white">
                  {breachedThreads.length} Thread{breachedThreads.length > 1 ? 's' : ''} Exceeding Safety Thresholds
                </span>
              </div>
              <p className="text-xs text-rose-200/90 leading-relaxed">
                Thread latency exceeds SLA safety limits ({globalSafetyThresholdMs}ms SLA). Synchronized lock contention or blocked worker queue detected on:{' '}
                {breachedThreads.map((t, idx) => (
                  <span key={t.id} className="font-mono font-bold text-white bg-rose-900/60 px-1.5 py-0.5 rounded border border-rose-700/60 mr-1.5 inline-block my-0.5">
                    {t.threadName} ({t.latencyMs}ms / limit {t.latencyThresholdMs ?? globalSafetyThresholdMs}ms)
                  </span>
                ))}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2.5 shrink-0">
            <button
              id="mitigate-breach-banner-btn"
              onClick={() => mitigateThreadLatency()}
              className="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-black text-xs transition shadow-lg shadow-emerald-600/40 flex items-center gap-1.5 cursor-pointer"
            >
              <Zap className="w-3.5 h-3.5" />
              <span>Mitigate All Threads</span>
            </button>
            <button
              onClick={() => setActiveTab('threads')}
              className="px-3 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-rose-500/50 text-rose-300 hover:text-white text-xs font-bold transition flex items-center gap-1.5 cursor-pointer"
            >
              <span>View Marked Rows</span>
            </button>
          </div>
        </div>
      )}

      {/* Latency Watchdog & Safety SLA Configuration Strip */}
      <div className="p-3 rounded-2xl bg-slate-950/50 border border-cyan-500/20 flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-2.5 flex-wrap">
          <div className="flex items-center gap-1.5 font-semibold text-slate-300">
            <Sliders className="w-4 h-4 text-cyan-400" />
            <span>Automated Alert Guard:</span>
          </div>

          <button
            onClick={() => {
              setIsAutoAlertEnabled(!isAutoAlertEnabled);
              addToast(
                isAutoAlertEnabled ? 'Alert Guard Paused' : 'Alert Guard Active',
                isAutoAlertEnabled
                  ? 'Automated thread latency monitoring paused.'
                  : 'Automated thread latency monitoring active with automatic toasts and markings.',
                'info'
              );
            }}
            className={`px-2.5 py-1 rounded-lg font-mono font-bold transition cursor-pointer flex items-center gap-1.5 ${
              isAutoAlertEnabled
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                : 'bg-slate-900 text-slate-400 border border-slate-700'
            }`}
          >
            <span
              className={`w-1.5 h-1.5 rounded-full ${
                isAutoAlertEnabled ? 'bg-emerald-400 animate-ping' : 'bg-slate-500'
              }`}
            />
            {isAutoAlertEnabled ? 'GUARD ACTIVE' : 'GUARD PAUSED'}
          </button>

          <div className="h-4 w-px bg-slate-800 hidden sm:block" />

          {/* SLA Threshold Presets */}
          <div className="flex items-center gap-1.5">
            <span className="text-slate-400 font-mono">SLA Threshold:</span>
            {[
              { label: 'Strict (90ms)', value: 90 },
              { label: 'Balanced (140ms)', value: 140 },
              { label: 'Tolerant (200ms)', value: 200 },
            ].map((preset) => (
              <button
                key={preset.value}
                onClick={() => {
                  setGlobalSafetyThresholdMs(preset.value);
                  threads.forEach((t) => updateThreadLatencyThreshold(t.id, preset.value));
                }}
                className={`px-2 py-0.5 rounded-md font-mono text-[11px] font-bold transition cursor-pointer ${
                  globalSafetyThresholdMs === preset.value
                    ? 'bg-cyan-500/25 text-cyan-300 border border-cyan-400/50'
                    : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
                }`}
              >
                {preset.label}
              </button>
            ))}
          </div>
        </div>

        {/* Quick Spike Test Selector */}
        <div className="flex items-center gap-2">
          <span className="text-slate-400 font-mono">Test Spike on:</span>
          <select
            value={selectedSpikeThreadId}
            onChange={(e) => setSelectedSpikeThreadId(e.target.value)}
            className="bg-slate-900 border border-slate-700 rounded-lg px-2 py-1 text-slate-200 text-xs font-mono cursor-pointer focus:outline-none focus:border-cyan-400"
          >
            <option value="">Random Worker Thread</option>
            {threads.map((t) => (
              <option key={t.id} value={t.id}>
                {t.threadName} ({t.latencyMs ?? 42}ms)
              </option>
            ))}
          </select>
          <button
            onClick={() => simulateThreadLatencySpike(selectedSpikeThreadId || undefined)}
            className="px-2.5 py-1 rounded-lg bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 hover:text-white border border-rose-500/40 font-bold transition flex items-center gap-1 cursor-pointer"
            title="Fire a high latency spike and verify toast alert and visual markings"
          >
            <Zap className="w-3.5 h-3.5 text-rose-400" />
            <span>Test Alert</span>
          </button>
        </div>
      </div>

      {deadlockReport && (
        <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs font-mono flex items-center justify-between gap-3 animate-in fade-in">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>{deadlockReport}</span>
          </div>
          <button
            onClick={() => setDeadlockReport(null)}
            className="text-[10px] text-slate-400 hover:text-white underline cursor-pointer"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* Navigation Sub-Tabs inside Thread Activity Monitor */}
      <div className="flex items-center gap-2 border-b border-cyan-500/20 pb-2.5 overflow-x-auto">
        {[
          { id: 'charts', label: 'Real-Time Process Charts', icon: TrendingUp },
          {
            id: 'threads',
            label: `Worker Thread Pool (${threads.length})`,
            icon: Cpu,
            alertCount: breachedThreads.length,
          },
          { id: 'locks', label: `Synchronization & Mutex Locks (${lockMatrix.length})`, icon: Lock },
          { id: 'logs', label: 'Live System Console Logs', icon: Terminal },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          const hasAlert = (tab as any).alertCount > 0;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition whitespace-nowrap cursor-pointer ${
                isActive
                  ? 'bg-cyan-500/25 text-cyan-200 border border-cyan-400/50 shadow-[0_0_12px_rgba(6,182,212,0.3)]'
                  : 'text-slate-300 hover:text-white bg-slate-900/50 border border-slate-800 hover:border-slate-700'
              }`}
            >
              <Icon className="w-3.5 h-3.5 text-cyan-400" />
              <span>{tab.label}</span>
              {hasAlert && (
                <span className="px-1.5 py-0.5 rounded-full bg-rose-500 text-slate-950 font-black text-[10px] animate-pulse">
                  {(tab as any).alertCount} Alert
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* TAB 1: REAL-TIME PROCESS CHARTS */}
      {activeTab === 'charts' && (
        <div className="space-y-6">
          {/* Row 1: Real-time Throughput Stream & Per-Thread Workload */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Chart 1: Real-time Throughput & CPU Load Over Time */}
            <div className="lg:col-span-2 p-4 sm:p-5 rounded-3xl bg-slate-950/75 border border-cyan-500/25 shadow-xl">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-4">
                <div>
                  <h3 className="text-sm font-extrabold text-white flex items-center gap-2">
                    <TrendingUp className="w-4 h-4 text-cyan-400" />
                    Real-Time Task Throughput & Process Flow
                  </h3>
                  <span className="text-xs text-slate-400">
                    Live tasks executed per second vs. aggregate CPU load across active Java workers
                  </span>
                </div>
                <div className="flex items-center gap-3 text-xs font-mono font-bold">
                  <span className="flex items-center gap-1.5 text-cyan-300">
                    <span className="w-2.5 h-2.5 rounded-full bg-cyan-400 shadow-[0_0_8px_#22d3ee]" />
                    Ops / Sec
                  </span>
                  <span className="flex items-center gap-1.5 text-indigo-300">
                    <span className="w-2.5 h-2.5 rounded-full bg-indigo-400 shadow-[0_0_8px_#818cf8]" />
                    CPU % Load
                  </span>
                </div>
              </div>

              <div className="h-64 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={timelineData} margin={{ top: 10, right: 10, left: -15, bottom: 0 }}>
                    <defs>
                      <linearGradient id="colorThroughput" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#06b6d4" stopOpacity={0.4} />
                        <stop offset="95%" stopColor="#06b6d4" stopOpacity={0} />
                      </linearGradient>
                      <linearGradient id="colorCpu" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#6366f1" stopOpacity={0.35} />
                        <stop offset="95%" stopColor="#6366f1" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
                    <XAxis dataKey="time" stroke="#94a3b8" fontSize={11} tickLine={false} />
                    <YAxis yAxisId="left" stroke="#06b6d4" fontSize={11} tickLine={false} />
                    <YAxis yAxisId="right" orientation="right" stroke="#6366f1" fontSize={11} tickLine={false} />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: '#050f25',
                        borderColor: 'rgba(6,182,212,0.4)',
                        borderRadius: '14px',
                        fontSize: '12px',
                        color: '#fff',
                        boxShadow: '0 8px 32px rgba(0,0,0,0.6)',
                      }}
                    />
                    <Area
                      yAxisId="left"
                      type="monotone"
                      dataKey="throughput"
                      name="Ops Processed / sec"
                      stroke="#06b6d4"
                      strokeWidth={2.5}
                      fillOpacity={1}
                      fill="url(#colorThroughput)"
                    />
                    <Area
                      yAxisId="right"
                      type="monotone"
                      dataKey="cpuLoad"
                      name="CPU Load %"
                      stroke="#6366f1"
                      strokeWidth={2}
                      fillOpacity={1}
                      fill="url(#colorCpu)"
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Chart 2: Thread State Distribution Donut */}
            <div className="p-4 sm:p-5 rounded-3xl bg-slate-950/75 border border-cyan-500/25 shadow-xl flex flex-col justify-between">
              <div>
                <h3 className="text-sm font-extrabold text-white flex items-center gap-2 mb-1">
                  <Activity className="w-4 h-4 text-emerald-400" />
                  Thread State Allocation
                </h3>
                <span className="text-xs text-slate-400 block mb-2">
                  Distribution of Java ThreadPool execution states
                </span>

                <div className="h-44 w-full relative flex items-center justify-center">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={stateDistribution}
                        cx="50%"
                        cy="50%"
                        innerRadius={50}
                        outerRadius={75}
                        paddingAngle={4}
                        dataKey="value"
                      >
                        {stateDistribution.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip
                        contentStyle={{
                          backgroundColor: '#050f25',
                          borderColor: 'rgba(6,182,212,0.4)',
                          borderRadius: '12px',
                          fontSize: '11px',
                          color: '#fff',
                        }}
                      />
                    </PieChart>
                  </ResponsiveContainer>

                  {/* Centered KPI */}
                  <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
                    <span className="text-xl font-black text-white font-mono">
                      {activeThreadsCount}
                    </span>
                    <span className="text-[9px] uppercase font-bold text-slate-400 tracking-wider">
                      Active
                    </span>
                  </div>
                </div>
              </div>

              {/* State Legend Pills */}
              <div className="grid grid-cols-2 gap-2 pt-3 border-t border-slate-800">
                {stateDistribution.map((item) => (
                  <div key={item.name} className="flex items-center justify-between text-xs p-1.5 rounded-lg bg-slate-900/60 border border-slate-800">
                    <div className="flex items-center gap-1.5">
                      <span className="w-2 h-2 rounded-full" style={{ backgroundColor: item.color }} />
                      <span className="text-slate-300 text-[11px]">{item.name}</span>
                    </div>
                    <span className="font-mono font-bold text-white text-[11px]">{item.value}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Row 2: Per-Thread Workload & CPU Utilization Bar Chart */}
          <div className="p-4 sm:p-5 rounded-3xl bg-slate-950/75 border border-cyan-500/25 shadow-xl">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-4">
              <div>
                <h3 className="text-sm font-extrabold text-white flex items-center gap-2">
                  <Gauge className="w-4 h-4 text-cyan-400" />
                  Per-Worker Workload & CPU Utilization Bar Chart
                </h3>
                <span className="text-xs text-slate-400">
                  Individual Java worker thread CPU consumption percentage across hospital operational domains
                </span>
              </div>
              <div className="flex items-center gap-3 text-xs font-mono">
                <span className="text-cyan-400 font-semibold">&bull; Core Pool: 8 Workers</span>
                <span className="text-slate-400">&bull; Fair Scheduling</span>
              </div>
            </div>

            <div className="h-64 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={threadBarData} margin={{ top: 10, right: 10, left: -15, bottom: 25 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
                  <XAxis
                    dataKey="name"
                    stroke="#94a3b8"
                    fontSize={11}
                    tickLine={false}
                    interval={0}
                    angle={-20}
                    textAnchor="end"
                  />
                  <YAxis stroke="#94a3b8" fontSize={11} tickLine={false} />
                  <Tooltip
                    content={({ active, payload }) => {
                      if (active && payload && payload.length) {
                        const data = payload[0].payload;
                        return (
                          <div className="p-3 rounded-xl bg-slate-950 border border-cyan-500/40 text-xs shadow-2xl space-y-1">
                            <p className="font-bold text-white">{data.fullName}</p>
                            <p className="text-cyan-300 font-mono">State: {data.state}</p>
                            <p className="text-indigo-300 font-mono">CPU Usage: {data.cpu}%</p>
                            <p className="text-emerald-300 font-mono">Tasks Processed: {data.ops.toLocaleString()}</p>
                          </div>
                        );
                      }
                      return null;
                    }}
                  />
                  <Bar dataKey="cpu" name="CPU Usage %" fill="#06b6d4" radius={[6, 6, 0, 0]}>
                    {threadBarData.map((entry, index) => (
                      <Cell
                        key={`bar-${index}`}
                        fill={
                          entry.state === 'RUNNING'
                            ? '#10b981'
                            : entry.state === 'RUNNABLE'
                            ? '#06b6d4'
                            : '#6366f1'
                        }
                      />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Row 3: Thread Execution Latency vs. Safety SLA Threshold Chart */}
          <div className="p-4 sm:p-5 rounded-3xl bg-slate-950/75 border border-cyan-500/25 shadow-xl space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h3 className="text-sm font-extrabold text-white flex items-center gap-2">
                  <ShieldAlert className="w-4 h-4 text-rose-400" />
                  Thread Execution Latency vs. Safety SLA Threshold (ms)
                </h3>
                <span className="text-xs text-slate-400">
                  Real-time worker response times. Crimson bars highlight threads violating the {globalSafetyThresholdMs}ms safety SLA threshold.
                </span>
              </div>
              <div className="flex items-center gap-3 text-xs font-mono">
                <span className="flex items-center gap-1.5 text-cyan-300">
                  <span className="w-2.5 h-2.5 rounded-full bg-cyan-400" />
                  Nominal Latency (&le;{globalSafetyThresholdMs}ms)
                </span>
                <span className="flex items-center gap-1.5 text-rose-400 font-bold">
                  <span className="w-2.5 h-2.5 rounded-full bg-rose-500 shadow-[0_0_8px_#f43f5e] animate-ping" />
                  SLA Safety Breach (&gt;{globalSafetyThresholdMs}ms)
                </span>
              </div>
            </div>

            <div className="h-64 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={threadLatencyData} margin={{ top: 15, right: 15, left: -15, bottom: 25 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
                  <XAxis
                    dataKey="name"
                    stroke="#94a3b8"
                    fontSize={11}
                    tickLine={false}
                    interval={0}
                    angle={-20}
                    textAnchor="end"
                  />
                  <YAxis
                    stroke="#94a3b8"
                    fontSize={11}
                    tickLine={false}
                    unit="ms"
                  />
                  <ReferenceLine
                    y={globalSafetyThresholdMs}
                    stroke="#f43f5e"
                    strokeDasharray="4 4"
                    strokeWidth={2}
                    label={{
                      value: `Safety Limit: ${globalSafetyThresholdMs}ms`,
                      fill: '#fb7185',
                      fontSize: 11,
                      position: 'top',
                    }}
                  />
                  <Tooltip
                    content={({ active, payload }) => {
                      if (active && payload && payload.length) {
                        const data = payload[0].payload;
                        return (
                          <div className="p-3 rounded-xl bg-slate-950 border border-cyan-500/40 text-xs shadow-2xl space-y-1.5">
                            <p className="font-bold text-white flex items-center justify-between gap-2">
                              <span>{data.fullName}</span>
                              <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                                data.isBreached ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40' : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                              }`}>
                                {data.isBreached ? 'CRITICAL SLA BREACH' : 'SLA COMPLIANT'}
                              </span>
                            </p>
                            <p className={`font-mono font-bold ${data.isBreached ? 'text-rose-400' : 'text-cyan-300'}`}>
                              Execution Latency: {data.latency}ms
                            </p>
                            <p className="text-slate-400 font-mono">
                              Safety SLA Limit: {data.threshold}ms {data.isBreached && <span className="text-rose-400 font-bold">(+{data.excessMs}ms over safety SLA)</span>}
                            </p>
                            <p className="text-amber-300 font-mono text-[11px]">
                              Sync Lock: {data.lock}
                            </p>
                          </div>
                        );
                      }
                      return null;
                    }}
                  />
                  <Bar dataKey="latency" name="Latency (ms)" radius={[6, 6, 0, 0]}>
                    {threadLatencyData.map((entry, index) => (
                      <Cell
                        key={`lat-bar-${index}`}
                        fill={entry.isBreached ? '#f43f5e' : entry.latency > entry.threshold * 0.8 ? '#f59e0b' : '#06b6d4'}
                      />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: DETAILED THREAD POOL WORKERS TABLE */}
      {activeTab === 'threads' && (
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <span className="text-xs font-semibold text-slate-300">Filter Threads:</span>
              <div className="flex items-center gap-1.5">
                {(['ALL', 'ACTIVE', 'WAITING'] as const).map((filter) => (
                  <button
                    key={filter}
                    onClick={() => setSelectedThreadFilter(filter)}
                    className={`px-2.5 py-1 rounded-lg text-xs font-mono font-bold transition cursor-pointer ${
                      selectedThreadFilter === filter
                        ? 'bg-cyan-500/25 text-cyan-200 border border-cyan-400/50'
                        : 'bg-slate-900 text-slate-400 border border-slate-800 hover:text-white'
                    }`}
                  >
                    {filter}
                  </button>
                ))}
              </div>
            </div>

            <div className="flex items-center gap-3">
              {breachedThreads.length > 0 && (
                <span className="text-xs font-mono text-rose-400 font-bold flex items-center gap-1.5 bg-rose-950/60 px-2.5 py-1 rounded-lg border border-rose-500/40 animate-pulse">
                  <AlertTriangle className="w-3.5 h-3.5" />
                  {breachedThreads.length} Thread{breachedThreads.length > 1 ? 's' : ''} Exceeding Safety Threshold
                </span>
              )}
              <span className="text-xs font-mono text-slate-400">
                Showing {filteredThreads.length} of {threads.length} worker threads
              </span>
            </div>
          </div>

          <div className="overflow-x-auto rounded-2xl border border-cyan-500/20 shadow-xl bg-slate-950/70">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-900/90 text-slate-300 uppercase font-mono text-[10px] tracking-wider border-b border-cyan-500/20">
                <tr>
                  <th className="py-3 px-3.5">Thread ID & Name</th>
                  <th className="py-3 px-3.5">State</th>
                  <th className="py-3 px-3.5">Priority</th>
                  <th className="py-3 px-3.5">CPU Load</th>
                  <th className="py-3 px-3.5">Latency & Safety SLA</th>
                  <th className="py-3 px-3.5">Current Execution Task</th>
                  <th className="py-3 px-3.5">Sync Lock Monitor</th>
                  <th className="py-3 px-3.5 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/80 font-sans">
                {filteredThreads.map((thread) => {
                  const isRunning = thread.state === 'RUNNING' || thread.state === 'RUNNABLE';
                  const lat = thread.latencyMs ?? 42;
                  const thresh = thread.latencyThresholdMs ?? globalSafetyThresholdMs;
                  const isBreached = lat > thresh;
                  const isCritical = lat >= thresh * 1.5;

                  return (
                    <tr
                      key={thread.id}
                      className={`transition ${
                        isBreached
                          ? 'bg-rose-950/30 border-l-4 border-rose-500 shadow-[inset_0_0_20px_rgba(244,63,94,0.18)] hover:bg-rose-950/45'
                          : 'hover:bg-cyan-500/5'
                      }`}
                    >
                      <td className="py-3 px-3.5 font-mono">
                        <div className="font-bold text-white flex items-center gap-1.5">
                          <span
                            className={`text-[10px] px-1.5 py-0.5 rounded border ${
                              isBreached
                                ? 'bg-rose-950 text-rose-300 border-rose-600'
                                : 'text-cyan-400 bg-cyan-950/60 border-cyan-800'
                            }`}
                          >
                            {thread.id}
                          </span>
                          <span className="truncate max-w-[170px]">{thread.threadName}</span>
                          {isBreached && (
                            <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping" title="SLA Threshold Breached" />
                          )}
                        </div>
                        <span className="text-[10px] text-slate-400 truncate block max-w-[210px]">
                          {thread.javaClass}
                        </span>
                      </td>

                      <td className="py-3 px-3.5">
                        <span
                          className={`inline-flex items-center gap-1 text-[10px] font-mono px-2 py-0.5 rounded-full border font-bold ${getBadgeClass(
                            thread.state
                          )}`}
                        >
                          {isRunning && <span className="w-1.5 h-1.5 rounded-full bg-current animate-ping" />}
                          {thread.state}
                        </span>
                      </td>

                      <td className="py-3 px-3.5 font-mono text-slate-300 font-bold">
                        NORM_PRIORITY {thread.priority}/10
                      </td>

                      <td className="py-3 px-3.5">
                        <div className="w-24">
                          <div className="flex justify-between text-[10px] font-mono mb-1">
                            <span className="text-white font-bold">{thread.cpuUsagePercent ?? thread.cpuUsage ?? 0}%</span>
                            <span className="text-slate-400">{thread.processedCount || 0} ops</span>
                          </div>
                          <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                            <div
                              className="h-full bg-gradient-to-r from-cyan-400 to-indigo-500"
                              style={{ width: `${Math.min(100, (thread.cpuUsagePercent ?? 0) * 3.5)}%` }}
                            />
                          </div>
                        </div>
                      </td>

                      {/* Latency & Safety SLA Column with Visual Markings */}
                      <td className="py-3 px-3.5 font-mono">
                        <div className="flex items-center gap-1.5">
                          <span
                            className={`inline-flex items-center gap-1 text-[10px] px-2 py-0.5 rounded-full border font-bold ${
                              isBreached
                                ? 'bg-rose-500/25 text-rose-300 border-rose-500/60 shadow-[0_0_10px_rgba(244,63,94,0.4)] animate-pulse'
                                : 'bg-cyan-500/15 text-cyan-300 border-cyan-500/30'
                            }`}
                          >
                            {isBreached ? (
                              <>
                                <AlertTriangle className="w-3 h-3 text-rose-400" />
                                {lat}ms CRITICAL
                              </>
                            ) : (
                              <>
                                <Zap className="w-3 h-3 text-cyan-400" />
                                {lat}ms OK
                              </>
                            )}
                          </span>
                        </div>
                        <div className="w-28 mt-1.5">
                          <div className="flex justify-between text-[9px] text-slate-400 mb-0.5">
                            <span>Limit: {thresh}ms</span>
                            {isBreached && <span className="text-rose-400 font-bold">+{lat - thresh}ms</span>}
                          </div>
                          <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                            <div
                              className={`h-full transition-all duration-500 ${
                                isBreached
                                  ? 'bg-rose-500 shadow-[0_0_8px_#f43f5e]'
                                  : 'bg-gradient-to-r from-cyan-400 to-emerald-400'
                              }`}
                              style={{ width: `${Math.min(100, (lat / (thresh * 1.5)) * 100)}%` }}
                            />
                          </div>
                        </div>
                      </td>

                      <td className="py-3 px-3.5 text-slate-200 text-xs max-w-xs font-mono">
                        <span className="line-clamp-2" title={thread.currentTask || thread.taskName}>
                          {thread.currentTask || thread.taskName || 'Executing background cycle'}
                        </span>
                      </td>

                      <td className="py-3 px-3.5 font-mono text-[11px] text-amber-300">
                        {thread.synchronizationLock ? (
                          <span className="flex items-center gap-1">
                            <Lock className="w-3 h-3 text-amber-400 shrink-0" />
                            <span className="truncate max-w-[140px]">{thread.synchronizationLock}</span>
                          </span>
                        ) : (
                          <span className="text-slate-500">None (Lock-free)</span>
                        )}
                      </td>

                      <td className="py-3 px-3.5 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          {isBreached && (
                            <button
                              onClick={() => mitigateThreadLatency(thread.id)}
                              className="p-1.5 rounded-lg bg-emerald-600/30 hover:bg-emerald-600/50 border border-emerald-500 text-emerald-300 transition cursor-pointer"
                              title="Mitigate high latency and restore to safe nominal level"
                            >
                              <Zap className="w-3.5 h-3.5 text-emerald-400" />
                            </button>
                          )}
                          <button
                            onClick={() => simulateThreadLatencySpike(thread.id)}
                            className="p-1.5 rounded-lg bg-rose-500/15 hover:bg-rose-500/30 border border-rose-500/30 text-rose-400 transition cursor-pointer"
                            title="Spike latency on this specific thread to test alerts"
                          >
                            <AlertOctagon className="w-3.5 h-3.5" />
                          </button>
                          {isRunning ? (
                            <button
                              onClick={() => pauseThread(thread.id)}
                              className="p-1.5 rounded-lg bg-amber-500/15 hover:bg-amber-500/30 border border-amber-500/30 text-amber-300 transition cursor-pointer"
                              title="Call wait() on thread monitor"
                            >
                              <Pause className="w-3.5 h-3.5" />
                            </button>
                          ) : (
                            <button
                              onClick={() => resumeThread(thread.id)}
                              className="p-1.5 rounded-lg bg-emerald-500/15 hover:bg-emerald-500/30 border border-emerald-500/30 text-emerald-300 transition cursor-pointer"
                              title="Call notify() on thread monitor"
                            >
                              <Play className="w-3.5 h-3.5" />
                            </button>
                          )}
                          <button
                            onClick={() => toggleThreadState(thread.id)}
                            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-300 transition cursor-pointer"
                            title="Cycle State (RUNNING -> WAITING -> RUNNABLE)"
                          >
                            <RotateCw className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 3: SYNCHRONIZATION & MUTEX LOCKS */}
      {activeTab === 'locks' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-extrabold text-white flex items-center gap-2">
              <Lock className="w-4 h-4 text-amber-400" />
              Java ReentrantLock & Mutex Concurrency Registry
            </h3>
            <span className="text-xs text-slate-400 font-mono">
              Preventing Race Conditions Across Operations
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5">
            {lockMatrix.map((lock, idx) => (
              <div
                key={idx}
                className="p-4 rounded-2xl bg-slate-950/80 border border-cyan-500/20 hover:border-cyan-500/40 shadow-lg transition space-y-2.5"
              >
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-cyan-950/80 text-cyan-300 border border-cyan-800">
                    {lock.module}
                  </span>
                  <span
                    className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded-full border ${
                      lock.status === 'ACQUIRED'
                        ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                        : lock.status === 'SYNCHRONIZED'
                        ? 'bg-indigo-500/20 text-indigo-300 border-indigo-500/40'
                        : 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                    }`}
                  >
                    {lock.status}
                  </span>
                </div>

                <h4 className="text-xs font-bold text-white font-mono break-all">
                  {lock.name}
                </h4>

                <div className="text-[11px] space-y-1 text-slate-300">
                  <div className="flex justify-between">
                    <span className="text-slate-400">Lock Type:</span>
                    <span className="font-mono text-cyan-200 text-[10px]">{lock.type}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Current Owner:</span>
                    <span className="font-mono text-emerald-300 text-[10px]">{lock.owner}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Waiting Threads:</span>
                    <span className="font-mono text-amber-300 font-bold">{lock.waiters}</span>
                  </div>
                </div>

                <div className="pt-2 border-t border-slate-800/80 text-[10px] font-mono text-slate-400">
                  <span className="text-slate-500 block">Critical Section:</span>
                  <span className="text-slate-300">{lock.criticalSection}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 4: LIVE SYSTEM CONSOLE LOGS */}
      {activeTab === 'logs' && (
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-extrabold text-white flex items-center gap-2">
              <Terminal className="w-4 h-4 text-cyan-400" />
              Java Virtual Machine Thread & JDBC Event Stream
            </h3>
            <span className="text-[11px] font-mono text-slate-400">
              System.out / HikariCP logger
            </span>
          </div>

          <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 font-mono text-xs space-y-2 h-64 overflow-y-auto shadow-inner">
            {systemLogs.map((log) => (
              <div key={log.id} className="flex items-start gap-2 leading-relaxed">
                <span className="text-slate-500 text-[10px] shrink-0">[{log.timestamp}]</span>
                <span
                  className={`text-[10px] px-1.5 py-0.2 rounded font-bold shrink-0 ${
                    log.type === 'WARN'
                      ? 'bg-amber-950 text-amber-300 border border-amber-800'
                      : log.type === 'ERROR'
                      ? 'bg-rose-950 text-rose-300 border border-rose-800'
                      : 'bg-cyan-950 text-cyan-300 border border-cyan-800'
                  }`}
                >
                  {log.type}
                </span>
                <span className="text-slate-200 break-all">{log.message}</span>
              </div>
            ))}
            <div className="flex items-center gap-2 text-cyan-400 text-[11px] pt-1 animate-pulse">
              <span className="w-1.5 h-1.5 rounded-full bg-cyan-400" />
              <span>JVM multithreaded scheduler waiting for next event loop slice...</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
