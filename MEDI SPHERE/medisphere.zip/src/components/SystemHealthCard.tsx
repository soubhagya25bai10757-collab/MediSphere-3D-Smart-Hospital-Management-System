import React, { useState } from 'react';
import { useHospital } from '../context/HospitalContext';
import {
  Cpu,
  Activity,
  CheckCircle2,
  Zap,
  ShieldCheck,
  Lock,
  RotateCw,
  ArrowUpRight,
  Server,
  Gauge,
  Sparkles,
} from 'lucide-react';

interface SystemHealthCardProps {
  className?: string;
}

export const SystemHealthCard: React.FC<SystemHealthCardProps> = ({ className = '' }) => {
  const { threads = [], setActiveNavigation, triggerGarbageCollection } = useHospital();
  const [isCleaning, setIsCleaning] = useState(false);

  // Computations for Java multithreaded operations
  const activeThreads = threads.filter(
    (t) => t.state === 'RUNNING' || t.state === 'RUNNABLE'
  ).length;
  const waitingThreads = threads.filter(
    (t) => t.state === 'WAITING' || t.state === 'TIMED_WAITING'
  ).length;
  const blockedThreads = threads.filter((t) => t.state === 'BLOCKED').length;
  const totalThreads = threads.length > 0 ? threads.length : 7;

  // Average thread CPU load calculation
  const totalCpu = threads.reduce(
    (sum, t) => sum + (t.cpuUsagePercent ?? t.cpuUsage ?? 0),
    0
  );
  const avgCpu = threads.length > 0 ? totalCpu / threads.length : 9.6;

  // Total operations executed by background workers
  const totalOps = threads.reduce((sum, t) => sum + (t.processedCount || 0), 0);

  // Active top worker thread
  const activeWorker =
    threads.find((t) => t.state === 'RUNNING') ||
    threads[0] ||
    null;
  const activeTaskName =
    activeWorker?.currentTask ||
    activeWorker?.taskName ||
    'Validating JDBC connection pool & persisting records';
  const activeWorkerName = activeWorker?.threadName || 'HospitalWorkerEngine';

  const handleTriggerGC = () => {
    setIsCleaning(true);
    triggerGarbageCollection();
    setTimeout(() => {
      setIsCleaning(false);
    }, 900);
  };

  const handleOpenMonitor = () => {
    setActiveNavigation('analytics', 'threads');
  };

  return (
    <div
      id="system-health-dashboard-card"
      className={`w-full rounded-2xl bg-slate-950/85 border border-cyan-500/25 backdrop-blur-xl shadow-xl shadow-cyan-950/50 p-4 sm:p-5 transition-all duration-300 hover:border-cyan-500/40 relative overflow-hidden ${className}`}
    >
      {/* Decorative subtle ambient sweep */}
      <div className="absolute top-0 right-0 -mt-8 -mr-8 w-36 h-36 bg-cyan-500/10 rounded-full blur-2xl pointer-events-none" />

      {/* Header: Status & Quick Action */}
      <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-800/80 gap-2">
        <div className="flex items-center gap-2.5 min-w-0">
          <div className="w-7 h-7 rounded-lg bg-cyan-500/15 border border-cyan-500/30 flex items-center justify-center shrink-0">
            <Cpu className="w-4 h-4 text-cyan-400 animate-pulse" />
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-xs font-bold text-white tracking-tight truncate">
                Java Runtime & System Health
              </span>
              <span className="inline-flex items-center gap-1 text-[9px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-300 border border-emerald-500/30 font-semibold shrink-0">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                OPTIMAL
              </span>
            </div>
            <span className="text-[10px] text-slate-400 block font-mono truncate">
              Multithreaded Operations Monitor
            </span>
          </div>
        </div>

        <button
          id="open-thread-monitor-btn"
          onClick={handleOpenMonitor}
          className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-cyan-500/15 hover:bg-cyan-500/25 border border-cyan-500/30 hover:border-cyan-400/50 text-[11px] font-bold text-cyan-300 hover:text-white transition group shrink-0"
          title="Open Java Multithreaded Operations Monitor"
        >
          <span>Monitor</span>
          <ArrowUpRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
        </button>
      </div>

      {/* Metrics Grid: 4 Core Vital Indicators */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-3.5">
        {/* 1. Worker Threads */}
        <div className="p-2.5 rounded-xl bg-slate-900/60 border border-slate-800/80 flex flex-col justify-between">
          <div className="flex items-center justify-between mb-1">
            <span className="text-[10px] uppercase tracking-wider font-semibold text-slate-400">
              Threads
            </span>
            <Activity className="w-3.5 h-3.5 text-cyan-400" />
          </div>
          <div className="flex items-baseline gap-1">
            <span className="text-xl font-black text-white font-mono">
              {activeThreads}
            </span>
            <span className="text-[10px] font-mono text-slate-400">
              /{totalThreads} Active
            </span>
          </div>
          <span className="text-[9px] text-emerald-400 font-mono mt-0.5">
            {blockedThreads === 0 ? '0 Deadlocks' : `${blockedThreads} Blocked`}
          </span>
        </div>

        {/* 2. CPU Thread Load */}
        <div className="p-2.5 rounded-xl bg-slate-900/60 border border-slate-800/80 flex flex-col justify-between">
          <div className="flex items-center justify-between mb-1">
            <span className="text-[10px] uppercase tracking-wider font-semibold text-slate-400">
              CPU Load
            </span>
            <Gauge className="w-3.5 h-3.5 text-blue-400" />
          </div>
          <div className="flex items-baseline gap-1">
            <span className="text-xl font-black text-white font-mono">
              {avgCpu.toFixed(1)}%
            </span>
          </div>
          {/* Progress bar */}
          <div className="w-full bg-slate-800 h-1 rounded-full overflow-hidden mt-1">
            <div
              className="h-full bg-gradient-to-r from-cyan-400 to-blue-500 transition-all duration-500"
              style={{ width: `${Math.min(100, Math.max(8, avgCpu * 3))}%` }}
            />
          </div>
        </div>

        {/* 3. JVM Heap Memory */}
        <div className="p-2.5 rounded-xl bg-slate-900/60 border border-slate-800/80 flex flex-col justify-between">
          <div className="flex items-center justify-between mb-1">
            <span className="text-[10px] uppercase tracking-wider font-semibold text-slate-400">
              JVM Heap
            </span>
            <Server className="w-3.5 h-3.5 text-indigo-400" />
          </div>
          <div className="flex items-baseline gap-1">
            <span className="text-xl font-black text-white font-mono">
              348
            </span>
            <span className="text-[10px] font-mono text-slate-400">
              MB Free
            </span>
          </div>
          <span className="text-[9px] text-slate-400 font-mono mt-0.5">
            164/512 MB G1GC
          </span>
        </div>

        {/* 4. Concurrency & Locks */}
        <div className="p-2.5 rounded-xl bg-slate-900/60 border border-slate-800/80 flex flex-col justify-between">
          <div className="flex items-center justify-between mb-1">
            <span className="text-[10px] uppercase tracking-wider font-semibold text-slate-400">
              Locks & Mutex
            </span>
            <Lock className="w-3.5 h-3.5 text-emerald-400" />
          </div>
          <div className="flex items-baseline gap-1">
            <span className="text-sm font-black text-emerald-400 font-mono tracking-tight">
              SYNC OK
            </span>
          </div>
          <span className="text-[9px] text-slate-400 font-mono mt-0.5">
            4 ReentrantLocks
          </span>
        </div>
      </div>

      {/* Live Thread Task Ticker & Interactive Quick Action */}
      <div className="pt-2.5 border-t border-slate-800/60 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-[11px]">
        <div className="flex items-center gap-2 min-w-0">
          <div className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse shrink-0" />
          <span className="font-mono text-[10px] text-slate-400 shrink-0">
            Active Task:
          </span>
          <span className="font-mono text-[10px] text-cyan-200 truncate" title={activeTaskName}>
            {activeWorkerName.split('-')[0]}: {activeTaskName}
          </span>
        </div>

        <div className="flex items-center gap-2 shrink-0 self-end sm:self-auto">
          <button
            id="trigger-jvm-gc-btn"
            onClick={handleTriggerGC}
            disabled={isCleaning}
            className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-700/80 hover:border-cyan-500/40 text-[10px] font-mono text-slate-300 hover:text-white transition disabled:opacity-50"
            title="Invoke java.lang.System.gc() to reclaim memory"
          >
            <RotateCw className={`w-3 h-3 text-cyan-400 ${isCleaning ? 'animate-spin' : ''}`} />
            <span>{isCleaning ? 'Running GC...' : 'System.gc()'}</span>
          </button>

          <span className="text-[9px] font-mono text-slate-500 hidden sm:inline">
            {totalOps.toLocaleString()} ops
          </span>
        </div>
      </div>
    </div>
  );
};
