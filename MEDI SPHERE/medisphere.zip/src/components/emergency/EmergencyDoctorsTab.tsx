import React, { useState, useMemo } from 'react';
import {
  Stethoscope,
  Search,
  Filter,
  CheckCircle2,
  Clock,
  Phone,
  Radio,
  MapPin,
  Award,
  Flame,
  UserCheck,
  AlertCircle,
  Activity,
  PlusCircle,
} from 'lucide-react';
import { EmergencyDoctor, EMERGENCY_SPECIALISTS } from '../../data/emergencyData';

interface DoctorsTabProps {
  doctors: EmergencyDoctor[];
  onOpenAssignDoctorToCase: (doctor: EmergencyDoctor) => void;
  onPageDoctor: (doctorName: string) => void;
}

export const EmergencyDoctorsTab: React.FC<DoctorsTabProps> = ({
  doctors,
  onOpenAssignDoctorToCase,
  onPageDoctor,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [specialistFilter, setSpecialistFilter] = useState<string>('All');
  const [statusFilter, setStatusFilter] = useState<string>('All');

  // Filtered doctors
  const filteredDoctors = useMemo(() => {
    return doctors.filter((doc) => {
      const matchesSearch =
        doc.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        doc.department.toLowerCase().includes(searchQuery.toLowerCase()) ||
        doc.roomNumber.toLowerCase().includes(searchQuery.toLowerCase());

      const matchesSpecialist = specialistFilter === 'All' || doc.specialist === specialistFilter;
      const matchesStatus = statusFilter === 'All' || doc.currentStatus === statusFilter;

      return matchesSearch && matchesSpecialist && matchesStatus;
    });
  }, [doctors, searchQuery, specialistFilter, statusFilter]);

  const availableCount = doctors.filter((d) => d.currentStatus === 'AVAILABLE').length;
  const onCaseCount = doctors.filter((d) => d.currentStatus === 'ON CASE').length;
  const onCallCount = doctors.filter((d) => d.currentStatus === 'ON CALL').length;

  return (
    <div className="space-y-5 animate-in fade-in duration-200">
      {/* Top Banner */}
      <div className="p-4 rounded-2xl glass-card border-cyan-500/30 flex flex-col sm:flex-row items-center justify-between gap-3 shadow-xl">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-cyan-500/20 border border-cyan-500/40 flex items-center justify-center text-cyan-300">
            <Stethoscope className="w-5 h-5 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base font-black text-white">Emergency Physicians Roster</h2>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/25 text-emerald-200 border border-emerald-500/40 font-black">
                {availableCount} IMMEDIATE AVAILABLE
              </span>
            </div>
            <p className="text-xs text-slate-300 font-medium">
              Trauma resuscitation leads, interventional cardiologists & acute surgeons on duty.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 text-xs">
          <span className="px-3 py-1.5 rounded-xl bg-slate-900/80 border border-slate-700 text-slate-300 font-medium">
            Shift: Morning Trauma Rotation (08:00 - 16:00)
          </span>
        </div>
      </div>

      {/* Roster Readiness Status Chips */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="p-3 rounded-xl bg-emerald-950/30 border border-emerald-500/40 flex items-center justify-between">
          <span className="text-xs font-bold text-emerald-200">Available Immediate</span>
          <span className="text-lg font-black text-emerald-300 font-mono">{availableCount}</span>
        </div>
        <div className="p-3 rounded-xl bg-cyan-950/30 border border-cyan-500/40 flex items-center justify-between">
          <span className="text-xs font-bold text-cyan-200">Active On Case</span>
          <span className="text-lg font-black text-cyan-300 font-mono">{onCaseCount}</span>
        </div>
        <div className="p-3 rounded-xl bg-amber-950/30 border border-amber-500/40 flex items-center justify-between">
          <span className="text-xs font-bold text-amber-200">On-Call Standby</span>
          <span className="text-lg font-black text-amber-300 font-mono">{onCallCount}</span>
        </div>
        <div className="p-3 rounded-xl bg-slate-900/50 border border-slate-700/50 flex items-center justify-between">
          <span className="text-xs font-bold text-slate-300">Total Registered</span>
          <span className="text-lg font-black text-white font-mono">{doctors.length}</span>
        </div>
      </div>

      {/* Filters Bar */}
      <div className="p-3.5 rounded-2xl glass-card border-cyan-500/25 flex flex-wrap items-center gap-3 shadow-lg">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Search physician name, department, or bay..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-3.5 py-2 rounded-xl glass-input text-xs text-white"
          />
        </div>

        {/* Specialist Filter */}
        <div className="flex items-center gap-1.5 text-xs">
          <span className="text-slate-400 font-bold text-[11px] whitespace-nowrap">Specialty:</span>
          <select
            value={specialistFilter}
            onChange={(e) => setSpecialistFilter(e.target.value)}
            className="px-2.5 py-2 rounded-xl glass-input text-xs text-cyan-200 cursor-pointer"
          >
            <option value="All" className="bg-slate-950 text-white">All Specialties</option>
            {EMERGENCY_SPECIALISTS.map((s) => (
              <option key={s} value={s} className="bg-slate-950 text-white">
                {s}
              </option>
            ))}
          </select>
        </div>

        {/* Status Filter */}
        <div className="flex items-center gap-1.5 text-xs">
          <span className="text-slate-400 font-bold text-[11px] whitespace-nowrap">Status:</span>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-2.5 py-2 rounded-xl glass-input text-xs text-cyan-200 cursor-pointer"
          >
            <option value="All" className="bg-slate-950 text-white">All Statuses</option>
            <option value="AVAILABLE" className="bg-slate-950 text-emerald-300 font-bold">AVAILABLE</option>
            <option value="ON CASE" className="bg-slate-950 text-cyan-300 font-bold">ON CASE</option>
            <option value="ON CALL" className="bg-slate-950 text-amber-300 font-bold">ON CALL</option>
            <option value="OFF DUTY" className="bg-slate-950 text-slate-400">OFF DUTY</option>
          </select>
        </div>
      </div>

      {/* Doctor Cards Grid */}
      {filteredDoctors.length === 0 ? (
        <div className="p-12 text-center glass-card rounded-2xl border-cyan-500/25 space-y-2">
          <CheckCircle2 className="w-9 h-9 text-emerald-400 mx-auto" />
          <h3 className="text-base font-black text-white">No Matching Emergency Doctors</h3>
          <p className="text-xs text-slate-300">
            No physicians on the roster match your specialty or availability criteria.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-4">
          {filteredDoctors.map((doc) => {
            const isAvail = doc.currentStatus === 'AVAILABLE';
            const isOnCase = doc.currentStatus === 'ON CASE';
            const isOnCall = doc.currentStatus === 'ON CALL';

            return (
              <div
                key={doc.id}
                className={`p-5 rounded-3xl glass-card transition-all duration-200 shadow-xl flex flex-col justify-between relative overflow-hidden ${
                  isAvail
                    ? 'border-emerald-500/40 hover:border-emerald-400 shadow-[0_0_20px_rgba(16,185,129,0.15)]'
                    : isOnCase
                    ? 'border-cyan-500/40'
                    : isOnCall
                    ? 'border-amber-500/40'
                    : 'border-slate-800'
                }`}
              >
                <div>
                  {/* Doctor Header */}
                  <div className="flex items-start justify-between gap-3 mb-3">
                    <div className="flex items-start gap-3">
                      <div
                        className={`w-11 h-11 rounded-2xl flex items-center justify-center font-bold text-sm shrink-0 ${
                          isAvail
                            ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                            : isOnCase
                            ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                            : 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                        }`}
                      >
                        <Stethoscope className="w-6 h-6" />
                      </div>
                      <div>
                        <h3 className="text-base font-black text-white leading-tight">
                          {doc.name}
                        </h3>
                        <span className="text-xs text-cyan-300 font-bold block mt-0.5">
                          {doc.specialist} &bull; <span className="text-slate-300 font-medium">{doc.experience}</span>
                        </span>
                        <span className="text-[11px] text-slate-400 font-medium block mt-0.5">
                          {doc.qualification}
                        </span>
                      </div>
                    </div>

                    <div className="flex flex-col items-end gap-1.5 shrink-0">
                      <span
                        className={`text-[10px] font-black px-2.5 py-0.5 rounded-full uppercase tracking-wider ${
                          isAvail
                            ? 'bg-emerald-500/25 text-emerald-200 border border-emerald-500/50 shadow-[0_0_10px_rgba(16,185,129,0.3)] animate-pulse'
                            : isOnCase
                            ? 'bg-cyan-500/25 text-cyan-200 border border-cyan-500/50'
                            : isOnCall
                            ? 'bg-amber-500/25 text-amber-200 border border-amber-500/50'
                            : 'bg-slate-700/40 text-slate-300 border border-slate-600'
                        }`}
                      >
                        {doc.currentStatus}
                      </span>
                      <span className="text-[10px] font-mono text-cyan-300 font-bold">
                        {doc.emergencyCasesAssigned} Active {doc.emergencyCasesAssigned === 1 ? 'Case' : 'Cases'}
                      </span>
                    </div>
                  </div>

                  {/* Department & Station Info */}
                  <div className="p-3.5 rounded-2xl bg-[rgba(6,18,45,0.65)] border border-cyan-500/20 space-y-2 mb-3 text-xs">
                    <div className="flex items-center justify-between">
                      <span className="text-slate-400 font-medium">Department:</span>
                      <span className="font-bold text-white text-right">{doc.department}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-slate-400 font-medium">Command Desk / Room:</span>
                      <span className="font-mono font-bold text-cyan-300 text-right">{doc.roomNumber}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-slate-400 font-medium">Current Availability:</span>
                      <span className="font-semibold text-emerald-300 text-right">{doc.currentAvailability}</span>
                    </div>
                  </div>

                  {/* Consultation / Dispatch Protocol status */}
                  <div className="mb-4 flex items-center justify-between text-xs px-1">
                    <span className="text-slate-400 text-[11px]">Protocol:</span>
                    <span className="text-[11px] font-semibold text-cyan-200">
                      {doc.consultationStatus}
                    </span>
                  </div>
                </div>

                {/* Bottom Actions */}
                <div className="pt-3 border-t border-cyan-500/20 flex items-center justify-between gap-3">
                  <button
                    onClick={() => onPageDoctor(doc.name)}
                    className="px-3 py-1.5 rounded-xl text-xs font-semibold glass-btn-secondary text-slate-200 hover:text-white flex items-center gap-1.5 transition"
                  >
                    <Phone className="w-3 h-3 text-emerald-400" />
                    <span>Emergency Pager</span>
                  </button>

                  <button
                    onClick={() => onOpenAssignDoctorToCase(doc)}
                    className="px-4 py-2 rounded-xl text-xs font-black bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white shadow-lg shadow-cyan-500/25 transition flex items-center gap-1.5 active:scale-95"
                  >
                    <PlusCircle className="w-3.5 h-3.5" />
                    <span>Assign to Emergency</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
