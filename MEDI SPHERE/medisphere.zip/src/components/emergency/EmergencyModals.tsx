import React, { useState } from 'react';
import {
  X,
  Flame,
  AlertTriangle,
  User,
  Heart,
  Activity,
  CheckCircle2,
  Stethoscope,
  Clock,
  BedDouble,
  ShieldAlert,
  Send,
  FileText,
  Phone,
  ArrowRight,
} from 'lucide-react';
import { EmergencyCase, EmergencyPriority, EmergencyHistoryRecord, Patient } from '../../types';
import { EmergencyDoctor, EMERGENCY_TYPES } from '../../data/emergencyData';

// 1. INGEST CASE MODAL
interface IngestModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (data: any) => void;
}

export const IngestEmergencyCaseModal: React.FC<IngestModalProps> = ({
  isOpen,
  onClose,
  onSubmit,
}) => {
  const [patientName, setPatientName] = useState('');
  const [age, setAge] = useState(42);
  const [gender, setGender] = useState<'Male' | 'Female' | 'Other'>('Male');
  const [emergencyType, setEmergencyType] = useState<string>(EMERGENCY_TYPES[0]);
  const [priority, setPriority] = useState<EmergencyPriority>('Critical');
  const [chiefComplaint, setChiefComplaint] = useState('');
  const [assignedDepartment, setAssignedDepartment] = useState('Trauma & Emergency Resuscitation');
  const [heartRate, setHeartRate] = useState(115);
  const [bloodPressure, setBloodPressure] = useState('155/95');
  const [oxygenSaturation, setOxygenSaturation] = useState(91);
  const [temperature, setTemperature] = useState(98.6);
  const [respiratoryRate, setRespiratoryRate] = useState(24);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit({
      patientName,
      age,
      gender,
      emergencyType,
      priority,
      chiefComplaint,
      assignedDepartment,
      vitals: {
        heartRate,
        bloodPressure,
        oxygenSaturation,
        temperature,
        respiratoryRate,
      },
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-2xl animate-in fade-in">
      <div className="relative w-full max-w-xl rounded-3xl glass-modal border-red-500/50 p-6 overflow-y-auto max-h-[92vh] shadow-[0_20px_50px_rgba(0,0,0,0.9),0_0_30px_rgba(239,68,68,0.25)]">
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-xl text-slate-300 hover:text-white hover:bg-[rgba(6,18,45,0.7)] border border-cyan-500/20 transition"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-2.5 mb-1">
          <Flame className="w-5 h-5 text-red-400 animate-pulse" />
          <h2 className="text-xl font-black text-white">Ingest Trauma / Emergency Case</h2>
        </div>
        <p className="text-xs text-slate-300 mb-6 font-medium">
          Inserts case directly into physiological priority queue stream.
        </p>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="text-xs font-bold text-slate-200 block mb-1">Patient Full Name</label>
            <input
              type="text"
              required
              placeholder="e.g. Anand Mahindra"
              value={patientName}
              onChange={(e) => setPatientName(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl glass-input text-xs text-white"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="text-xs font-bold text-slate-200 block mb-1">Age</label>
              <input
                type="number"
                required
                value={age}
                onChange={(e) => setAge(Number(e.target.value))}
                className="w-full px-3.5 py-2.5 rounded-xl glass-input text-xs text-white"
              />
            </div>
            <div>
              <label className="text-xs font-bold text-slate-200 block mb-1">Gender</label>
              <select
                value={gender}
                onChange={(e) => setGender(e.target.value as any)}
                className="w-full px-3.5 py-2.5 rounded-xl glass-input text-xs text-white cursor-pointer"
              >
                <option value="Male" className="bg-slate-950 text-white">Male</option>
                <option value="Female" className="bg-slate-950 text-white">Female</option>
                <option value="Other" className="bg-slate-950 text-white">Other</option>
              </select>
            </div>
            <div>
              <label className="text-xs font-bold text-slate-200 block mb-1">Triage Priority</label>
              <select
                value={priority}
                onChange={(e) => setPriority(e.target.value as any)}
                className="w-full px-3.5 py-2.5 rounded-xl glass-input text-xs text-red-300 font-extrabold cursor-pointer border-red-500/40"
              >
                <option value="Critical" className="bg-slate-950 text-red-400">CRITICAL (Immediate)</option>
                <option value="High" className="bg-slate-950 text-amber-400">HIGH (&lt;15 min)</option>
                <option value="Medium" className="bg-slate-950 text-cyan-400">MEDIUM (&lt;60 min)</option>
                <option value="Low" className="bg-slate-950 text-slate-300">LOW (&lt;120 min)</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-bold text-slate-200 block mb-1">Emergency Type</label>
              <select
                value={emergencyType}
                onChange={(e) => setEmergencyType(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl glass-input text-xs text-cyan-200 cursor-pointer"
              >
                {EMERGENCY_TYPES.map((t) => (
                  <option key={t} value={t} className="bg-slate-950 text-white">
                    {t}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="text-xs font-bold text-slate-200 block mb-1">Target Department</label>
              <input
                type="text"
                value={assignedDepartment}
                onChange={(e) => setAssignedDepartment(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl glass-input text-xs text-white"
              />
            </div>
          </div>

          <div>
            <label className="text-xs font-bold text-slate-200 block mb-1">
              Chief Complaint / Mechanism of Injury
            </label>
            <textarea
              rows={2}
              required
              placeholder="e.g. Acute substernal crushing pain with radiation to jaw, diaphoresis"
              value={chiefComplaint}
              onChange={(e) => setChiefComplaint(e.target.value)}
              className="w-full p-3.5 rounded-xl glass-input text-xs text-white outline-none resize-none"
            />
          </div>

          {/* Vitals */}
          <div>
            <span className="text-[10px] uppercase font-bold text-cyan-300 block mb-2">
              Initial Triage Telemetry Vitals:
            </span>
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-2.5">
              <div>
                <label className="text-[10px] text-slate-300 font-bold block mb-1">HR (BPM)</label>
                <input
                  type="number"
                  value={heartRate}
                  onChange={(e) => setHeartRate(Number(e.target.value))}
                  className="w-full px-2.5 py-2 rounded-xl glass-input text-xs text-red-300 font-mono font-bold"
                />
              </div>
              <div>
                <label className="text-[10px] text-slate-300 font-bold block mb-1">BP (mmHg)</label>
                <input
                  type="text"
                  value={bloodPressure}
                  onChange={(e) => setBloodPressure(e.target.value)}
                  className="w-full px-2.5 py-2 rounded-xl glass-input text-xs text-amber-300 font-mono font-bold"
                />
              </div>
              <div>
                <label className="text-[10px] text-slate-300 font-bold block mb-1">SpO2 (%)</label>
                <input
                  type="number"
                  value={oxygenSaturation}
                  onChange={(e) => setOxygenSaturation(Number(e.target.value))}
                  className="w-full px-2.5 py-2 rounded-xl glass-input text-xs text-cyan-200 font-mono font-bold"
                />
              </div>
              <div>
                <label className="text-[10px] text-slate-300 font-bold block mb-1">Temp (°F)</label>
                <input
                  type="number"
                  step="0.1"
                  value={temperature}
                  onChange={(e) => setTemperature(Number(e.target.value))}
                  className="w-full px-2.5 py-2 rounded-xl glass-input text-xs text-emerald-200 font-mono font-bold"
                />
              </div>
              <div>
                <label className="text-[10px] text-slate-300 font-bold block mb-1">RR (/min)</label>
                <input
                  type="number"
                  value={respiratoryRate}
                  onChange={(e) => setRespiratoryRate(Number(e.target.value))}
                  className="w-full px-2.5 py-2 rounded-xl glass-input text-xs text-purple-300 font-mono font-bold"
                />
              </div>
            </div>
          </div>

          <div className="pt-4 flex items-center justify-end gap-3 border-t border-cyan-500/20">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl glass-btn-secondary text-xs font-bold text-slate-200"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-red-600 to-amber-600 hover:from-red-500 hover:to-amber-500 text-white text-xs font-black shadow-[0_0_20px_rgba(239,68,68,0.4)] transition flex items-center gap-2"
            >
              <Flame className="w-3.5 h-3.5" />
              <span>Enqueue Emergency Case</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

// 2. CASE DETAILS MODAL
interface CaseDetailsModalProps {
  eCase: EmergencyCase | null;
  onClose: () => void;
  onAssignDoctor?: (eCase: EmergencyCase) => void;
  onUpdateStatus?: (eCase: EmergencyCase) => void;
}

export const CaseDetailsModal: React.FC<CaseDetailsModalProps> = ({
  eCase,
  onClose,
  onAssignDoctor,
  onUpdateStatus,
}) => {
  if (!eCase) return null;

  const isCritical = eCase.priority === 'Critical';
  const isHigh = eCase.priority === 'High';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-2xl animate-in fade-in">
      <div className="relative w-full max-w-2xl rounded-3xl glass-modal border-cyan-500/30 p-6 overflow-y-auto max-h-[90vh] shadow-2xl">
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-xl text-slate-300 hover:text-white hover:bg-[rgba(6,18,45,0.7)] border border-cyan-500/20 transition"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 mb-4">
          <div
            className={`w-10 h-10 rounded-2xl flex items-center justify-center font-bold text-sm ${
              isCritical
                ? 'bg-red-500/20 text-red-300 border border-red-500/40'
                : isHigh
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                : 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
            }`}
          >
            <Activity className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xl font-black text-white">{eCase.patientName}</h2>
              <span
                className={`text-[10px] font-black px-2.5 py-0.5 rounded-full uppercase ${
                  isCritical
                    ? 'bg-red-500/25 text-red-200 border border-red-500/50 animate-pulse'
                    : isHigh
                    ? 'bg-amber-500/25 text-amber-200 border border-amber-500/50'
                    : 'bg-cyan-500/25 text-cyan-200 border border-cyan-500/50'
                }`}
              >
                {eCase.priority} Priority
              </span>
            </div>
            <p className="text-xs text-slate-300 font-medium mt-0.5">
              Case ID: <span className="font-mono text-cyan-300 font-bold">{eCase.id}</span> &bull; Patient ID: {eCase.patientId || 'PAT-ER'} &bull; {eCase.age}y &bull; {eCase.gender}
            </p>
          </div>
        </div>

        {/* Presentation & Emergency Type */}
        <div className="p-4 rounded-2xl bg-[rgba(6,18,45,0.65)] border border-cyan-500/25 space-y-2 mb-4">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-mono uppercase text-cyan-300 font-bold">
              Emergency Classification
            </span>
            <span className="text-xs font-bold text-white px-2.5 py-0.5 rounded-lg bg-cyan-500/15 border border-cyan-500/30">
              {eCase.emergencyType || 'Acute Trauma'}
            </span>
          </div>
          <div>
            <span className="text-[10px] uppercase font-bold text-slate-300 block mb-0.5">
              Chief Complaint & Symptoms:
            </span>
            <p className="text-xs text-white leading-relaxed font-medium">{eCase.chiefComplaint}</p>
          </div>
        </div>

        {/* Telemetry Vitals Grid */}
        <div className="mb-4">
          <span className="text-[10px] uppercase font-bold text-cyan-300 block mb-2 font-mono">
            Live Telemetry Vitals
          </span>
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-2.5 text-center">
            <div className="p-3 rounded-xl bg-[rgba(6,18,45,0.6)] border border-red-500/30">
              <span className="text-[10px] text-slate-300 uppercase block font-bold">HR</span>
              <span className="text-base font-mono font-black text-red-300">
                {eCase.vitals?.heartRate || '--'} <span className="text-[9px] font-normal text-slate-400">BPM</span>
              </span>
            </div>
            <div className="p-3 rounded-xl bg-[rgba(6,18,45,0.6)] border border-amber-500/30">
              <span className="text-[10px] text-slate-300 uppercase block font-bold">BP</span>
              <span className="text-base font-mono font-black text-amber-300">
                {eCase.vitals?.bloodPressure || '--'} <span className="text-[9px] font-normal text-slate-400">mmHg</span>
              </span>
            </div>
            <div className="p-3 rounded-xl bg-[rgba(6,18,45,0.6)] border border-cyan-500/30">
              <span className="text-[10px] text-slate-300 uppercase block font-bold">SpO2</span>
              <span className="text-base font-mono font-black text-cyan-200">
                {eCase.vitals?.oxygenSaturation ? `${eCase.vitals.oxygenSaturation}%` : '--'}
              </span>
            </div>
            <div className="p-3 rounded-xl bg-[rgba(6,18,45,0.6)] border border-emerald-500/30">
              <span className="text-[10px] text-slate-300 uppercase block font-bold">Temp</span>
              <span className="text-base font-mono font-black text-emerald-200">
                {eCase.vitals?.temperature ? `${eCase.vitals.temperature}°F` : '--'}
              </span>
            </div>
            <div className="p-3 rounded-xl bg-[rgba(6,18,45,0.6)] border border-purple-500/30">
              <span className="text-[10px] text-slate-300 uppercase block font-bold">RR</span>
              <span className="text-base font-mono font-black text-purple-300">
                {eCase.vitals?.respiratoryRate || '--'} <span className="text-[9px] font-normal text-slate-400">/min</span>
              </span>
            </div>
          </div>
        </div>

        {/* Department, Physician, Bed Info */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-6 text-xs">
          <div className="p-3 rounded-xl bg-[rgba(6,18,45,0.6)] border border-cyan-500/20">
            <span className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Department</span>
            <span className="font-bold text-white block">{eCase.assignedDepartment}</span>
          </div>
          <div className="p-3 rounded-xl bg-[rgba(6,18,45,0.6)] border border-cyan-500/20">
            <span className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Attending Physician</span>
            <span className="font-bold text-white block">
              {eCase.assignedDoctorName || 'Pending Assignment'}
            </span>
          </div>
          <div className="p-3 rounded-xl bg-[rgba(6,18,45,0.6)] border border-cyan-500/20">
            <span className="text-[10px] uppercase font-bold text-slate-400 block mb-1">Bed / Bay</span>
            <span className="font-mono font-bold text-cyan-300 block">
              {eCase.assignedBedNumber || 'Triage Buffer Bay'}
            </span>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center justify-between gap-3 pt-4 border-t border-cyan-500/20">
          <div className="text-xs text-slate-300 font-medium">
            Arrival: <span className="font-bold text-white">{eCase.arrivalTime}</span> &bull; Waiting: <span className="text-amber-300 font-bold">{eCase.waitingMinutes}m</span>
          </div>
          <div className="flex items-center gap-2">
            {onAssignDoctor && !eCase.assignedDoctorName && (
              <button
                onClick={() => {
                  onClose();
                  onAssignDoctor(eCase);
                }}
                className="px-4 py-2 rounded-xl text-xs font-bold bg-cyan-500/20 text-cyan-200 border border-cyan-500/40 hover:bg-cyan-500/30 transition flex items-center gap-1.5"
              >
                <Stethoscope className="w-3.5 h-3.5" />
                <span>Assign Doctor</span>
              </button>
            )}
            {onUpdateStatus && (
              <button
                onClick={() => {
                  onClose();
                  onUpdateStatus(eCase);
                }}
                className="px-4 py-2 rounded-xl text-xs font-bold bg-gradient-to-r from-red-600 to-amber-600 hover:from-red-500 text-white transition flex items-center gap-1.5 shadow-lg shadow-red-500/20"
              >
                <Activity className="w-3.5 h-3.5" />
                <span>Update Status</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

// 3. ASSIGN DOCTOR QUICK MODAL
interface AssignDoctorModalProps {
  eCase: EmergencyCase | null;
  doctors: EmergencyDoctor[];
  onClose: () => void;
  onAssign: (caseId: string, doctorId: string, doctorName: string) => void;
}

export const AssignDoctorModal: React.FC<AssignDoctorModalProps> = ({
  eCase,
  doctors,
  onClose,
  onAssign,
}) => {
  if (!eCase) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-2xl animate-in fade-in">
      <div className="relative w-full max-w-lg rounded-3xl glass-modal border-cyan-500/40 p-6 shadow-2xl">
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-xl text-slate-300 hover:text-white hover:bg-[rgba(6,18,45,0.7)] border border-cyan-500/20 transition"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-2 mb-1">
          <Stethoscope className="w-5 h-5 text-cyan-400" />
          <h3 className="text-lg font-black text-white">Assign Emergency Doctor</h3>
        </div>
        <p className="text-xs text-slate-300 mb-4 font-medium">
          Dispatching physician for patient <strong className="text-white">{eCase.patientName}</strong> ({eCase.emergencyType || eCase.priority} Priority). Case will advance to Active status.
        </p>

        <div className="space-y-2.5 max-h-80 overflow-y-auto pr-1">
          {doctors.map((doc) => {
            const isAvail = doc.currentStatus === 'AVAILABLE';
            return (
              <div
                key={doc.id}
                className="p-3.5 rounded-2xl glass-card-subtle flex items-center justify-between hover:border-cyan-400/50 transition gap-3"
              >
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-extrabold text-white text-xs">{doc.name}</span>
                    <span
                      className={`text-[9px] font-black px-2 py-0.5 rounded-full uppercase ${
                        isAvail
                          ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                          : doc.currentStatus === 'ON CASE'
                          ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                          : 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                      }`}
                    >
                      {doc.currentStatus}
                    </span>
                  </div>
                  <span className="text-[11px] text-cyan-300 font-bold block mt-0.5">
                    {doc.specialist} &bull; {doc.experience}
                  </span>
                  <span className="text-[10px] text-slate-400 font-medium">
                    {doc.currentAvailability}
                  </span>
                </div>

                <button
                  onClick={() => {
                    onAssign(eCase.id, doc.id, doc.name);
                    onClose();
                  }}
                  className="px-3.5 py-1.5 rounded-xl text-xs font-bold bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-200 border border-cyan-500/40 transition whitespace-nowrap active:scale-95"
                >
                  Assign
                </button>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

// 4. UPDATE CASE STATUS MODAL
interface UpdateStatusModalProps {
  eCase: EmergencyCase | null;
  onClose: () => void;
  onUpdate: (
    caseId: string,
    newStatus: string,
    disposition?: string,
    archiveToHistory?: boolean
  ) => void;
}

export const UpdateCaseStatusModal: React.FC<UpdateStatusModalProps> = ({
  eCase,
  onClose,
  onUpdate,
}) => {
  const [treatmentStatus, setTreatmentStatus] = useState<string>(
    eCase?.treatmentStatus || 'Under Treatment'
  );
  const [disposition, setDisposition] = useState<string>('Admitted to ICU Bed 02');

  if (!eCase) return null;

  const isTerminal = ['Stabilized', 'Discharged', 'Admitted', 'Transferred', 'Referred'].includes(
    treatmentStatus
  );

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdate(eCase.id, treatmentStatus, isTerminal ? disposition : undefined, isTerminal);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-2xl animate-in fade-in">
      <div className="relative w-full max-w-md rounded-3xl glass-modal border-cyan-500/40 p-6 shadow-2xl">
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-xl text-slate-300 hover:text-white hover:bg-[rgba(6,18,45,0.7)] border border-cyan-500/20 transition"
        >
          <X className="w-5 h-5" />
        </button>

        <h3 className="text-lg font-black text-white mb-1">Update Clinical Status</h3>
        <p className="text-xs text-slate-300 mb-4 font-medium">
          Patient: <strong className="text-white">{eCase.patientName}</strong> &bull; Case {eCase.id}
        </p>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="text-xs font-bold text-slate-200 block mb-1">Treatment Status</label>
            <select
              value={treatmentStatus}
              onChange={(e) => setTreatmentStatus(e.target.value)}
              className="w-full p-3 rounded-xl glass-input text-xs text-cyan-200 font-bold cursor-pointer"
            >
              <option value="Awaiting Assessment" className="bg-slate-950 text-white">
                Awaiting Assessment
              </option>
              <option value="Under Treatment" className="bg-slate-950 text-white">
                Under Treatment
              </option>
              <option value="Observation" className="bg-slate-950 text-white">
                Observation (Step-Down)
              </option>
              <option value="Ready for Transfer" className="bg-slate-950 text-white">
                Ready for Transfer
              </option>
              <option value="Stabilized" className="bg-slate-950 text-emerald-400 font-bold">
                Stabilized (Move to History)
              </option>
              <option value="Discharged" className="bg-slate-950 text-emerald-400 font-bold">
                Discharged Home (Move to History)
              </option>
              <option value="Admitted" className="bg-slate-950 text-cyan-400 font-bold">
                Admitted to Inpatient Ward (Move to History)
              </option>
              <option value="Transferred" className="bg-slate-950 text-blue-400 font-bold">
                Transferred to OT/Cath Lab (Move to History)
              </option>
              <option value="Referred" className="bg-slate-950 text-purple-400 font-bold">
                Referred to Tertiary Care (Move to History)
              </option>
            </select>
          </div>

          {isTerminal && (
            <div className="p-3.5 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 animate-in fade-in">
              <label className="text-xs font-bold text-emerald-300 block mb-1">
                Final Disposition & Transfer Notes
              </label>
              <input
                type="text"
                required
                value={disposition}
                onChange={(e) => setDisposition(e.target.value)}
                placeholder="e.g. Admitted to ICU Bed 04 / Discharged Home with Meds"
                className="w-full px-3 py-2 rounded-xl glass-input text-xs text-white"
              />
              <span className="text-[10px] text-emerald-400 block mt-1.5 font-medium">
                Note: This will archive the case into Emergency History.
              </span>
            </div>
          )}

          <div className="pt-3 flex items-center justify-end gap-3 border-t border-cyan-500/20">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl glass-btn-secondary text-xs font-bold text-slate-200"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white text-xs font-black shadow-lg shadow-cyan-500/25 transition"
            >
              Save Status
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

// 5. VIEW PATIENT MODAL
interface ViewPatientModalProps {
  patientName: string;
  age?: number;
  gender?: string;
  onClose: () => void;
}

export const ViewPatientModal: React.FC<ViewPatientModalProps> = ({
  patientName,
  age = 45,
  gender = 'Male',
  onClose,
}) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-2xl animate-in fade-in">
      <div className="relative w-full max-w-md rounded-3xl glass-modal border-cyan-500/30 p-6 shadow-2xl">
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-xl text-slate-300 hover:text-white hover:bg-[rgba(6,18,45,0.7)] border border-cyan-500/20 transition"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 mb-4">
          <div className="w-12 h-12 rounded-2xl bg-cyan-500/20 border border-cyan-500/40 flex items-center justify-center text-cyan-300">
            <User className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-lg font-black text-white">{patientName}</h3>
            <span className="text-xs text-slate-300">
              {age} yrs &bull; {gender} &bull; UHID: <span className="font-mono text-cyan-300 font-bold">UHID-2026-{Math.floor(1000 + Math.random() * 9000)}</span>
            </span>
          </div>
        </div>

        <div className="space-y-2.5 text-xs">
          <div className="p-3 rounded-xl bg-[rgba(6,18,45,0.6)] border border-cyan-500/20 flex items-center justify-between">
            <span className="text-slate-400">Blood Group:</span>
            <span className="font-bold text-red-300">O+ (Universal Emergency)</span>
          </div>
          <div className="p-3 rounded-xl bg-[rgba(6,18,45,0.6)] border border-cyan-500/20 flex items-center justify-between">
            <span className="text-slate-400">Known Allergies:</span>
            <span className="font-bold text-amber-300">Penicillin, NSAIDs (Aspirin cautious)</span>
          </div>
          <div className="p-3 rounded-xl bg-[rgba(6,18,45,0.6)] border border-cyan-500/20 flex items-center justify-between">
            <span className="text-slate-400">Emergency Contact:</span>
            <span className="font-bold text-white">+91 98201 44920 (Spouse)</span>
          </div>
          <div className="p-3 rounded-xl bg-[rgba(6,18,45,0.6)] border border-cyan-500/20 flex items-center justify-between">
            <span className="text-slate-400">Insurance Pre-Auth:</span>
            <span className="font-bold text-emerald-300">Star Health Gold &bull; Active Coverage</span>
          </div>
        </div>

        <div className="mt-5 pt-3 border-t border-cyan-500/20 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl glass-btn-secondary text-xs font-bold text-white"
          >
            Close Preview
          </button>
        </div>
      </div>
    </div>
  );
};

// 6. DOCTOR ASSIGN TO EMERGENCY CASE MODAL (from doctor card)
interface DoctorAssignToCaseModalProps {
  doctor: EmergencyDoctor | null;
  cases: EmergencyCase[];
  onClose: () => void;
  onAssignDoctor: (caseId: string, doctorId: string, doctorName: string) => void;
}

export const DoctorAssignToCaseModal: React.FC<DoctorAssignToCaseModalProps> = ({
  doctor,
  cases,
  onClose,
  onAssignDoctor,
}) => {
  if (!doctor) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-2xl animate-in fade-in">
      <div className="relative w-full max-w-lg rounded-3xl glass-modal border-cyan-500/40 p-6 shadow-2xl">
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-xl text-slate-300 hover:text-white hover:bg-[rgba(6,18,45,0.7)] border border-cyan-500/20 transition"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-2 mb-1">
          <Stethoscope className="w-5 h-5 text-cyan-400" />
          <h3 className="text-lg font-black text-white">Assign {doctor.name} to Case</h3>
        </div>
        <p className="text-xs text-slate-300 mb-4 font-medium">
          Specialty: <strong className="text-cyan-300">{doctor.specialist}</strong> &bull; Select a patient needing emergency physician dispatch:
        </p>

        {cases.length === 0 ? (
          <div className="p-6 text-center text-xs text-slate-400 glass-card-subtle rounded-2xl">
            No pending unassigned cases in queue right now.
          </div>
        ) : (
          <div className="space-y-2.5 max-h-80 overflow-y-auto pr-1">
            {cases.map((c) => {
              const isCrit = c.priority === 'Critical';
              return (
                <div
                  key={c.id}
                  className="p-3.5 rounded-2xl glass-card-subtle flex items-center justify-between hover:border-cyan-400/50 transition gap-3"
                >
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-extrabold text-white text-xs">{c.patientName}</span>
                      <span
                        className={`text-[9px] font-black px-2 py-0.5 rounded-full uppercase ${
                          isCrit
                            ? 'bg-red-500/25 text-red-200 border border-red-500/50'
                            : 'bg-amber-500/25 text-amber-200 border border-amber-500/50'
                        }`}
                      >
                        {c.priority}
                      </span>
                    </div>
                    <span className="text-[11px] text-cyan-300 font-bold block mt-0.5">
                      {c.emergencyType || 'Acute Emergency'} &bull; {c.chiefComplaint.slice(0, 45)}...
                    </span>
                    <span className="text-[10px] text-slate-400 font-medium">
                      Wait: {c.waitingMinutes}m &bull; Arr: {c.arrivalTime}
                    </span>
                  </div>

                  <button
                    onClick={() => {
                      onAssignDoctor(c.id, doctor.id, doctor.name);
                      onClose();
                    }}
                    className="px-3.5 py-1.5 rounded-xl text-xs font-bold bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-200 border border-cyan-500/40 transition whitespace-nowrap active:scale-95"
                  >
                    Assign to Case
                  </button>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};

// 7. HISTORICAL CASE FULL VIEW MODAL
interface HistoricalCaseModalProps {
  record: EmergencyHistoryRecord | null;
  onClose: () => void;
}

export const HistoricalCaseModal: React.FC<HistoricalCaseModalProps> = ({ record, onClose }) => {
  if (!record) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-2xl animate-in fade-in">
      <div className="relative w-full max-w-2xl rounded-3xl glass-modal border-cyan-500/40 p-6 overflow-y-auto max-h-[90vh] shadow-2xl">
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-xl text-slate-300 hover:text-white hover:bg-[rgba(6,18,45,0.7)] border border-cyan-500/20 transition"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 rounded-2xl bg-cyan-500/20 border border-cyan-500/40 flex items-center justify-center text-cyan-300">
            <FileText className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xl font-black text-white">{record.patientName}</h2>
              <span className="text-[10px] font-black px-2.5 py-0.5 rounded-full uppercase bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                {record.finalStatus}
              </span>
            </div>
            <p className="text-xs text-slate-300 font-medium mt-0.5">
              Case ID: <span className="font-mono text-cyan-300 font-bold">{record.id}</span> &bull; Patient ID: {record.patientId} &bull; Date: {record.date}
            </p>
          </div>
        </div>

        {/* Disposition & Summary */}
        <div className="p-4 rounded-2xl bg-[rgba(6,18,45,0.65)] border border-cyan-500/25 space-y-2 mb-4">
          <div className="flex items-center justify-between text-xs">
            <span className="text-[10px] font-mono uppercase text-cyan-300 font-bold">
              Final Disposition
            </span>
            <span className="font-bold text-emerald-300">{record.disposition}</span>
          </div>
          <p className="text-xs text-slate-100 font-medium leading-relaxed">{record.summary}</p>
        </div>

        {/* Timeline Strip */}
        <div className="grid grid-cols-3 gap-3 mb-4 text-center text-xs">
          <div className="p-2.5 rounded-xl bg-[rgba(6,18,45,0.6)] border border-cyan-500/20">
            <span className="text-[10px] text-slate-400 block font-bold">Arrival</span>
            <span className="font-mono font-bold text-white">{record.arrivalTime}</span>
          </div>
          <div className="p-2.5 rounded-xl bg-[rgba(6,18,45,0.6)] border border-cyan-500/20">
            <span className="text-[10px] text-slate-400 block font-bold">Treatment Began</span>
            <span className="font-mono font-bold text-amber-300">{record.treatmentStart}</span>
          </div>
          <div className="p-2.5 rounded-xl bg-[rgba(6,18,45,0.6)] border border-cyan-500/20">
            <span className="text-[10px] text-slate-400 block font-bold">Concluded / Disposition</span>
            <span className="font-mono font-bold text-emerald-300">{record.treatmentEnd}</span>
          </div>
        </div>

        {/* Discharge Vitals */}
        {record.dischargeVitals && (
          <div className="mb-4">
            <span className="text-[10px] uppercase font-bold text-cyan-300 block mb-2 font-mono">
              Vitals at Conclusion / Discharge:
            </span>
            <div className="grid grid-cols-4 gap-2.5 text-center">
              <div className="p-2.5 rounded-xl bg-[rgba(6,18,45,0.6)] border border-red-500/30">
                <span className="text-[9px] text-slate-300 uppercase block font-bold">HR (BPM)</span>
                <span className="text-sm font-mono font-black text-red-300">
                  {record.dischargeVitals.heartRate}
                </span>
              </div>
              <div className="p-2.5 rounded-xl bg-[rgba(6,18,45,0.6)] border border-amber-500/30">
                <span className="text-[9px] text-slate-300 uppercase block font-bold">BP (mmHg)</span>
                <span className="text-sm font-mono font-black text-amber-300">
                  {record.dischargeVitals.bloodPressure}
                </span>
              </div>
              <div className="p-2.5 rounded-xl bg-[rgba(6,18,45,0.6)] border border-cyan-500/30">
                <span className="text-[9px] text-slate-300 uppercase block font-bold">SpO2 (%)</span>
                <span className="text-sm font-mono font-black text-cyan-200">
                  {record.dischargeVitals.oxygenSaturation}%
                </span>
              </div>
              <div className="p-2.5 rounded-xl bg-[rgba(6,18,45,0.6)] border border-emerald-500/30">
                <span className="text-[9px] text-slate-300 uppercase block font-bold">Temp (°F)</span>
                <span className="text-sm font-mono font-black text-emerald-200">
                  {record.dischargeVitals.temperature}°F
                </span>
              </div>
            </div>
          </div>
        )}

        {/* Interventions Performed */}
        <div className="mb-4">
          <span className="text-[10px] uppercase font-bold text-cyan-300 block mb-2 font-mono">
            Interventions Performed:
          </span>
          <div className="flex flex-wrap gap-1.5">
            {record.interventions.map((item, idx) => (
              <span
                key={idx}
                className="px-2.5 py-1 rounded-lg text-xs font-semibold bg-cyan-500/15 border border-cyan-500/30 text-cyan-200 flex items-center gap-1.5"
              >
                <CheckCircle2 className="w-3 h-3 text-cyan-400" />
                {item}
              </span>
            ))}
          </div>
        </div>

        {/* Attending Physician */}
        <div className="p-3 rounded-xl bg-[rgba(6,18,45,0.6)] border border-cyan-500/20 flex items-center justify-between text-xs">
          <span className="text-slate-400 font-medium">Attending Emergency Specialist:</span>
          <span className="font-bold text-white">{record.assignedDoctor}</span>
        </div>

        <div className="mt-5 pt-3 border-t border-cyan-500/20 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl glass-btn-secondary text-xs font-bold text-white"
          >
            Close Record
          </button>
        </div>
      </div>
    </div>
  );
};

// 8. ASSIGN BED MODAL
interface AssignBedModalProps {
  isOpen: boolean;
  eCase: EmergencyCase | null;
  onClose: () => void;
  onAssign: (caseId: string, bedId: string, bedNumber: string) => void;
}

export const AssignBedModal: React.FC<AssignBedModalProps> = ({
  isOpen,
  eCase,
  onClose,
  onAssign,
}) => {
  if (!isOpen || !eCase) return null;

  const emergencyBeds = [
    { id: 'ER-BAY-01', name: 'Trauma Resus Bay 1', department: 'Trauma Wing', type: 'Critical Resus', occupied: false, equipment: 'Crash Cart + Defibrillator + Ventilator' },
    { id: 'ER-BAY-02', name: 'Trauma Resus Bay 2', department: 'Trauma Wing', type: 'Critical Resus', occupied: false, equipment: 'Crash Cart + Multi-lead Telemetry' },
    { id: 'ER-BAY-03', name: 'Trauma Resus Bay 3', department: 'Trauma Wing', type: 'Critical Resus', occupied: true, equipment: 'In use by ER-891' },
    { id: 'ICU-EM-01', name: 'Emergency ICU Bed 01', department: 'ICU', type: 'High Acuity ICU', occupied: false, equipment: 'Hamilton C6 Ventilator + Arterial Line' },
    { id: 'ICU-EM-02', name: 'Emergency ICU Bed 02', department: 'ICU', type: 'High Acuity ICU', occupied: false, equipment: 'Telemetry + Continuous Hemodialysis' },
    { id: 'ICU-EM-03', name: 'Emergency ICU Bed 03', department: 'ICU', type: 'High Acuity ICU', occupied: true, equipment: 'Occupied' },
    { id: 'OBS-BAY-A', name: 'Step-Down Obs Bay A', department: 'Observation', type: 'Step-Down Monitoring', occupied: false, equipment: 'Standard Bedside Telemetry' },
    { id: 'OBS-BAY-B', name: 'Step-Down Obs Bay B', department: 'Observation', type: 'Step-Down Monitoring', occupied: false, equipment: 'Standard Bedside Telemetry' },
    { id: 'TRI-ISO-01', name: 'Negative Pressure Isolation 1', department: 'Infectious / ER', type: 'Isolation Unit', occupied: false, equipment: 'HEPA Negative Pressure + Telemetry' },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-2xl animate-in fade-in">
      <div className="relative w-full max-w-lg rounded-3xl glass-modal border-cyan-500/40 p-6 shadow-2xl overflow-y-auto max-h-[90vh]">
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-xl text-slate-300 hover:text-white border border-cyan-500/20 transition"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 mb-2">
          <div className="w-10 h-10 rounded-xl bg-cyan-500/20 border border-cyan-500/40 flex items-center justify-center text-cyan-300">
            <BedDouble className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-lg font-black text-white">Assign ER / ICU Bed</h3>
            <span className="text-xs font-mono text-cyan-300">
              {eCase.patientName} &bull; Case {eCase.id} ({eCase.priority} Priority)
            </span>
          </div>
        </div>

        <p className="text-xs text-slate-300 mb-4">
          Select an available trauma resuscitation bay or critical care bed to transfer the patient immediately:
        </p>

        <div className="space-y-2.5">
          {emergencyBeds.map((bed) => (
            <div
              key={bed.id}
              className={`p-3.5 rounded-2xl border transition flex items-center justify-between gap-3 ${
                bed.occupied
                  ? 'bg-slate-900/40 border-slate-800 opacity-50 cursor-not-allowed'
                  : 'glass-card border-cyan-500/30 hover:border-cyan-400/70 hover:shadow-[0_0_15px_rgba(6,182,212,0.2)]'
              }`}
            >
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-black text-white">{bed.name}</span>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-cyan-500/15 text-cyan-200 border border-cyan-500/30">
                    {bed.department}
                  </span>
                  {bed.occupied ? (
                    <span className="text-[9px] font-bold px-2 py-0.2 rounded-full bg-red-500/20 text-red-300 border border-red-500/40">
                      Occupied
                    </span>
                  ) : (
                    <span className="text-[9px] font-bold px-2 py-0.2 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                      Available
                    </span>
                  )}
                </div>
                <span className="text-[11px] text-slate-400 block mt-1">
                  {bed.equipment}
                </span>
              </div>

              {!bed.occupied && (
                <button
                  onClick={() => {
                    onAssign(eCase.id, bed.id, bed.name);
                    onClose();
                  }}
                  className="px-3.5 py-1.5 rounded-xl text-xs font-bold bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-200 border border-cyan-500/40 transition shrink-0 active:scale-95"
                >
                  Assign Bed
                </button>
              )}
            </div>
          ))}
        </div>

        <div className="mt-5 pt-3 border-t border-cyan-500/20 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl glass-btn-secondary text-xs font-bold text-slate-300 hover:text-white"
          >
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
};
