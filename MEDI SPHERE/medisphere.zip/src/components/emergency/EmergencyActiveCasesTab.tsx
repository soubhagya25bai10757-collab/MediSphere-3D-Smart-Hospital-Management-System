import React, { useState, useMemo } from 'react';
import {
  Activity,
  Heart,
  Clock,
  Stethoscope,
  BedDouble,
  User,
  Radio,
  Search,
  Filter,
  Eye,
  CheckCircle2,
  Phone,
  Flame,
  AlertCircle,
  TrendingUp,
} from 'lucide-react';
import { EmergencyCase, EmergencyPriority } from '../../types';

interface ActiveCasesTabProps {
  activeCases: EmergencyCase[];
  onViewCase: (eCase: EmergencyCase) => void;
  onUpdateStatus: (eCase: EmergencyCase) => void;
  onViewPatient: (patientName: string, age?: number, gender?: string) => void;
  onContactDoctor: (doctorName: string, caseId: string) => void;
  onAssignBed?: (eCase: EmergencyCase) => void;
}

export const EmergencyActiveCasesTab: React.FC<ActiveCasesTabProps> = ({
  activeCases,
  onViewCase,
  onUpdateStatus,
  onViewPatient,
  onContactDoctor,
  onAssignBed,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [treatmentStatusFilter, setTreatmentStatusFilter] = useState<string>('All');
  const [priorityFilter, setPriorityFilter] = useState<string>('All');
  const [deptFilter, setDeptFilter] = useState<string>('All');

  // Filtered active cases
  const filteredCases = useMemo(() => {
    return activeCases.filter((c) => {
      const matchesSearch =
        c.patientName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        c.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (c.assignedDoctorName && c.assignedDoctorName.toLowerCase().includes(searchQuery.toLowerCase()));

      const matchesTreatmentStatus =
        treatmentStatusFilter === 'All' ||
        (c.treatmentStatus || 'Under Treatment') === treatmentStatusFilter;

      const matchesPriority = priorityFilter === 'All' || c.priority === priorityFilter;

      const matchesDept =
        deptFilter === 'All' ||
        (c.assignedDepartment && c.assignedDepartment.toLowerCase().includes(deptFilter.toLowerCase()));

      return matchesSearch && matchesTreatmentStatus && matchesPriority && matchesDept;
    });
  }, [activeCases, searchQuery, treatmentStatusFilter, priorityFilter, deptFilter]);

  // Departments list from active cases
  const departments = useMemo(() => {
    const set = new Set<string>();
    activeCases.forEach((c) => {
      if (c.assignedDepartment) set.add(c.assignedDepartment);
    });
    return Array.from(set);
  }, [activeCases]);

  return (
    <div className="space-y-5 animate-in fade-in duration-200">
      {/* Top Banner */}
      <div className="p-4 rounded-2xl glass-card border-cyan-500/30 flex flex-col sm:flex-row items-center justify-between gap-3 shadow-xl">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-cyan-500/20 border border-cyan-500/40 flex items-center justify-center text-cyan-300">
            <Activity className="w-5 h-5 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base font-black text-white">Active Emergency Cases</h2>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-cyan-500/25 text-cyan-200 border border-cyan-500/40 font-black">
                {activeCases.length} IN CARE
              </span>
            </div>
            <p className="text-xs text-slate-300 font-medium">
              Real-time telemetry, acute stabilization & physician intervention monitor.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 text-xs text-slate-300 font-medium">
          <span className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-700">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
            Telemetry Stream Live
          </span>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="p-3.5 rounded-2xl glass-card border-cyan-500/25 flex flex-wrap items-center gap-3 shadow-lg">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Search active patient, doctor, or case ID..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-3.5 py-2 rounded-xl glass-input text-xs text-white"
          />
        </div>

        {/* Treatment Status Filter */}
        <div className="flex items-center gap-1.5 text-xs">
          <span className="text-slate-400 font-bold text-[11px] whitespace-nowrap">Status:</span>
          <select
            value={treatmentStatusFilter}
            onChange={(e) => setTreatmentStatusFilter(e.target.value)}
            className="px-2.5 py-2 rounded-xl glass-input text-xs text-cyan-200 cursor-pointer"
          >
            <option value="All" className="bg-slate-950 text-white">All Treatment Statuses</option>
            <option value="Awaiting Assessment" className="bg-slate-950 text-white">Awaiting Assessment</option>
            <option value="Under Treatment" className="bg-slate-950 text-white">Under Treatment</option>
            <option value="Observation" className="bg-slate-950 text-white">Observation</option>
            <option value="Ready for Transfer" className="bg-slate-950 text-white">Ready for Transfer</option>
          </select>
        </div>

        {/* Priority Filter */}
        <div className="flex items-center gap-1.5 text-xs">
          <span className="text-slate-400 font-bold text-[11px] whitespace-nowrap">Priority:</span>
          <select
            value={priorityFilter}
            onChange={(e) => setPriorityFilter(e.target.value)}
            className="px-2.5 py-2 rounded-xl glass-input text-xs text-cyan-200 cursor-pointer"
          >
            <option value="All" className="bg-slate-950 text-white">All Acuities</option>
            <option value="Critical" className="bg-slate-950 text-red-300 font-bold">Critical</option>
            <option value="High" className="bg-slate-950 text-amber-300 font-bold">High</option>
            <option value="Medium" className="bg-slate-950 text-cyan-300">Medium</option>
            <option value="Low" className="bg-slate-950 text-slate-300">Low</option>
          </select>
        </div>

        {/* Department Filter */}
        {departments.length > 0 && (
          <div className="flex items-center gap-1.5 text-xs">
            <span className="text-slate-400 font-bold text-[11px] whitespace-nowrap">Dept:</span>
            <select
              value={deptFilter}
              onChange={(e) => setDeptFilter(e.target.value)}
              className="px-2.5 py-2 rounded-xl glass-input text-xs text-cyan-200 cursor-pointer"
            >
              <option value="All" className="bg-slate-950 text-white">All Departments</option>
              {departments.map((d) => (
                <option key={d} value={d} className="bg-slate-950 text-white">
                  {d}
                </option>
              ))}
            </select>
          </div>
        )}
      </div>

      {/* Active Case Cards Grid */}
      {filteredCases.length === 0 ? (
        <div className="p-12 text-center glass-card rounded-2xl border-cyan-500/25 space-y-2">
          <CheckCircle2 className="w-9 h-9 text-emerald-400 mx-auto" />
          <h3 className="text-base font-black text-white">No Matching Active Cases</h3>
          <p className="text-xs text-slate-300">
            No active trauma patients match your current search or filter criteria.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {filteredCases.map((c) => {
            const isCrit = c.priority === 'Critical';
            const isHigh = c.priority === 'High';
            const duration = c.durationMinutes || Math.max(c.waitingMinutes + 15, 20);

            return (
              <div
                key={c.id}
                className={`p-5 rounded-3xl glass-card transition-all duration-200 shadow-xl relative overflow-hidden flex flex-col justify-between ${
                  isCrit
                    ? 'border-red-500/50 shadow-[0_0_25px_rgba(239,68,68,0.2)] bg-gradient-to-b from-red-950/15 to-transparent'
                    : isHigh
                    ? 'border-amber-500/40'
                    : 'border-cyan-500/30'
                }`}
              >
                <div>
                  {/* Top Bar: Patient, Case ID, Priority, Emergency Type */}
                  <div className="flex items-start justify-between gap-3 mb-3">
                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="text-base font-black text-white hover:text-cyan-200 transition cursor-pointer" onClick={() => onViewCase(c)}>
                          {c.patientName}
                        </h3>
                        <span className="font-mono text-[10px] text-cyan-300 font-bold px-2 py-0.5 rounded bg-cyan-500/15 border border-cyan-500/30">
                          {c.id}
                        </span>
                      </div>
                      <span className="text-xs text-slate-300 font-medium block mt-0.5">
                        {c.age}y &bull; {c.gender} &bull; <strong className="text-cyan-300">{c.emergencyType || 'Acute Trauma'}</strong>
                      </span>
                    </div>

                    <div className="flex flex-col items-end gap-1.5">
                      <span
                        className={`text-[10px] font-black px-2.5 py-0.5 rounded-full uppercase tracking-wider ${
                          isCrit
                            ? 'bg-red-500/25 text-red-200 border border-red-500/50 animate-pulse shadow-[0_0_10px_rgba(239,68,68,0.4)]'
                            : isHigh
                            ? 'bg-amber-500/25 text-amber-200 border border-amber-500/50'
                            : 'bg-cyan-500/25 text-cyan-200 border border-cyan-500/50'
                        }`}
                      >
                        {c.priority} Priority
                      </span>
                      <span className="text-[10px] text-slate-400 font-mono font-medium flex items-center gap-1">
                        <Clock className="w-3 h-3 text-cyan-400" />
                        Arr: {c.arrivalTime} ({duration}m in ER)
                      </span>
                    </div>
                  </div>

                  {/* Doctor & Bed Assignment Bar */}
                  <div className="p-3 rounded-2xl bg-[rgba(6,18,45,0.65)] border border-cyan-500/25 flex flex-wrap items-center justify-between gap-2 mb-3 text-xs">
                    <div className="flex items-center gap-2">
                      <div className="w-7 h-7 rounded-lg bg-cyan-500/20 border border-cyan-500/40 flex items-center justify-center text-cyan-300">
                        <Stethoscope className="w-3.5 h-3.5" />
                      </div>
                      <div>
                        <span className="text-[10px] uppercase font-bold text-slate-400 block">
                          Attending Doctor
                        </span>
                        <span className="font-extrabold text-white">
                          {c.assignedDoctorName || 'Rapid Response Physician'}
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center gap-3">
                      <div>
                        <span className="text-[10px] uppercase font-bold text-slate-400 block">
                          Bed / Bay
                        </span>
                        <span className="font-mono font-bold text-cyan-300">
                          {c.assignedBedNumber || 'Resus Bay 1'}
                        </span>
                      </div>
                      <div>
                        <span className="text-[10px] uppercase font-bold text-slate-400 block">
                          Status
                        </span>
                        <span className="font-bold text-emerald-300">
                          {c.treatmentStatus || 'Under Treatment'}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Chief Complaint */}
                  <div className="mb-3">
                    <span className="text-[10px] uppercase font-bold text-slate-400 block mb-0.5">
                      Chief Complaint / Presentation:
                    </span>
                    <p className="text-xs text-white leading-relaxed font-medium">
                      {c.chiefComplaint}
                    </p>
                  </div>

                  {/* Telemetry Vitals Readout Strip */}
                  <div className="mb-4">
                    <span className="text-[10px] uppercase font-bold text-cyan-300 block mb-1.5 font-mono">
                      Telemetry Vitals Monitor
                    </span>
                    <div className="grid grid-cols-5 gap-2 text-center text-xs">
                      <div className="p-2 rounded-xl bg-[rgba(6,18,45,0.6)] border border-red-500/30">
                        <span className="text-[9px] text-slate-300 uppercase block font-bold">HR</span>
                        <span className="text-xs font-mono font-black text-red-300">
                          {c.vitals?.heartRate || '--'} <span className="text-[8px] font-normal text-slate-400">bpm</span>
                        </span>
                      </div>
                      <div className="p-2 rounded-xl bg-[rgba(6,18,45,0.6)] border border-amber-500/30">
                        <span className="text-[9px] text-slate-300 uppercase block font-bold">BP</span>
                        <span className="text-xs font-mono font-black text-amber-300">
                          {c.vitals?.bloodPressure || '--'}
                        </span>
                      </div>
                      <div className="p-2 rounded-xl bg-[rgba(6,18,45,0.6)] border border-cyan-500/30">
                        <span className="text-[9px] text-slate-300 uppercase block font-bold">SpO2</span>
                        <span className="text-xs font-mono font-black text-cyan-200">
                          {c.vitals?.oxygenSaturation ? `${c.vitals.oxygenSaturation}%` : '--'}
                        </span>
                      </div>
                      <div className="p-2 rounded-xl bg-[rgba(6,18,45,0.6)] border border-emerald-500/30">
                        <span className="text-[9px] text-slate-300 uppercase block font-bold">Temp</span>
                        <span className="text-xs font-mono font-black text-emerald-200">
                          {c.vitals?.temperature ? `${c.vitals.temperature}°` : '--'}
                        </span>
                      </div>
                      <div className="p-2 rounded-xl bg-[rgba(6,18,45,0.6)] border border-purple-500/30">
                        <span className="text-[9px] text-slate-300 uppercase block font-bold">RR</span>
                        <span className="text-xs font-mono font-black text-purple-300">
                          {c.vitals?.respiratoryRate || 18} <span className="text-[8px] font-normal text-slate-400">/m</span>
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Card Actions Bar */}
                <div className="pt-3 border-t border-cyan-500/20 flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => onViewPatient(c.patientName, c.age, c.gender)}
                      className="px-3 py-1.5 rounded-xl text-xs font-semibold glass-btn-secondary text-slate-200 hover:text-white flex items-center gap-1"
                    >
                      <User className="w-3 h-3 text-cyan-400" />
                      <span>Patient Profile</span>
                    </button>

                    {c.assignedDoctorName && (
                      <button
                        onClick={() => onContactDoctor(c.assignedDoctorName!, c.id)}
                        className="px-3 py-1.5 rounded-xl text-xs font-semibold glass-btn-secondary text-slate-200 hover:text-white flex items-center gap-1"
                      >
                        <Phone className="w-3 h-3 text-emerald-400" />
                        <span>Page Doctor</span>
                      </button>
                    )}

                    {onAssignBed && (
                      <button
                        onClick={() => onAssignBed(c)}
                        className="px-3 py-1.5 rounded-xl text-xs font-semibold glass-btn-secondary text-cyan-200 hover:text-white flex items-center gap-1"
                        title="Transfer to ER bay or ICU bed"
                      >
                        <BedDouble className="w-3 h-3 text-cyan-400" />
                        <span>{c.assignedBedNumber ? 'Change Bed' : 'Assign Bed'}</span>
                      </button>
                    )}
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => onViewCase(c)}
                      className="px-3 py-1.5 rounded-xl text-xs font-bold bg-cyan-500/20 text-cyan-200 border border-cyan-500/40 hover:bg-cyan-500/30 transition flex items-center gap-1"
                    >
                      <Eye className="w-3 h-3" />
                      <span>View Case</span>
                    </button>

                    <button
                      onClick={() => onUpdateStatus(c)}
                      className="px-3.5 py-1.5 rounded-xl text-xs font-black bg-gradient-to-r from-red-600 to-amber-600 hover:from-red-500 text-white shadow-md shadow-red-500/25 transition flex items-center gap-1"
                    >
                      <Activity className="w-3 h-3" />
                      <span>Update Status</span>
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
