import React, { useState, useMemo } from 'react';
import {
  FileText,
  Search,
  Filter,
  Eye,
  Calendar,
  CheckCircle2,
  Clock,
  Stethoscope,
  ArrowRight,
  TrendingUp,
} from 'lucide-react';
import { EmergencyHistoryRecord, EmergencyPriority } from '../../types';
import { EMERGENCY_TYPES } from '../../data/emergencyData';

interface HistoryTabProps {
  historyRecords: EmergencyHistoryRecord[];
  onViewRecord: (record: EmergencyHistoryRecord) => void;
}

export const EmergencyHistoryTab: React.FC<HistoryTabProps> = ({
  historyRecords,
  onViewRecord,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [dateFilter, setDateFilter] = useState<string>('All');
  const [typeFilter, setTypeFilter] = useState<string>('All');
  const [statusFilter, setStatusFilter] = useState<string>('All');
  const [doctorFilter, setDoctorFilter] = useState<string>('All');
  const [priorityFilter, setPriorityFilter] = useState<string>('All');

  // Unique doctors from history
  const doctorsList = useMemo(() => {
    const set = new Set<string>();
    historyRecords.forEach((r) => {
      if (r.assignedDoctor) set.add(r.assignedDoctor);
    });
    return Array.from(set);
  }, [historyRecords]);

  // Filtered records
  const filteredRecords = useMemo(() => {
    return historyRecords.filter((r) => {
      const matchesSearch =
        r.patientName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        r.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (r.patientId && r.patientId.toLowerCase().includes(searchQuery.toLowerCase())) ||
        (r.disposition && r.disposition.toLowerCase().includes(searchQuery.toLowerCase()));

      const matchesDate = dateFilter === 'All' || r.date === dateFilter;
      const matchesType = typeFilter === 'All' || r.emergencyType === typeFilter;
      const matchesStatus = statusFilter === 'All' || r.finalStatus === statusFilter;
      const matchesDoctor = doctorFilter === 'All' || r.assignedDoctor === doctorFilter;
      const matchesPriority = priorityFilter === 'All' || r.priority === priorityFilter;

      return matchesSearch && matchesDate && matchesType && matchesStatus && matchesDoctor && matchesPriority;
    });
  }, [historyRecords, searchQuery, dateFilter, typeFilter, statusFilter, doctorFilter, priorityFilter]);

  // Summary counts
  const stabilizedCount = historyRecords.filter((r) => r.finalStatus === 'Stabilized').length;
  const admittedCount = historyRecords.filter((r) => r.finalStatus === 'Admitted').length;
  const dischargedCount = historyRecords.filter((r) => r.finalStatus === 'Discharged').length;
  const transferredCount = historyRecords.filter(
    (r) => r.finalStatus === 'Transferred' || r.finalStatus === 'Referred'
  ).length;

  return (
    <div className="space-y-5 animate-in fade-in duration-200">
      {/* Top Banner */}
      <div className="p-4 rounded-2xl glass-card border-cyan-500/30 flex flex-col sm:flex-row items-center justify-between gap-3 shadow-xl">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-cyan-500/20 border border-cyan-500/40 flex items-center justify-center text-cyan-300">
            <FileText className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base font-black text-white">Emergency Clinical History & Archive</h2>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-cyan-500/25 text-cyan-200 border border-cyan-500/40 font-black">
                {historyRecords.length} ARCHIVED
              </span>
            </div>
            <p className="text-xs text-slate-300 font-medium">
              Permanent clinical audit log of treated, stabilized, admitted & transferred trauma cases.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 text-xs">
          <span className="px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-700 text-slate-300 font-medium">
            Clinical Outcome Audit: 100% Retained
          </span>
        </div>
      </div>

      {/* Outcome Metric Chips */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="p-3 rounded-xl bg-emerald-950/30 border border-emerald-500/40 flex items-center justify-between">
          <span className="text-xs font-bold text-emerald-200">Stabilized</span>
          <span className="text-lg font-black text-emerald-300 font-mono">{stabilizedCount}</span>
        </div>
        <div className="p-3 rounded-xl bg-cyan-950/30 border border-cyan-500/40 flex items-center justify-between">
          <span className="text-xs font-bold text-cyan-200">Inpatient Admitted</span>
          <span className="text-lg font-black text-cyan-300 font-mono">{admittedCount}</span>
        </div>
        <div className="p-3 rounded-xl bg-blue-950/30 border border-blue-500/40 flex items-center justify-between">
          <span className="text-xs font-bold text-blue-200">Discharged Home</span>
          <span className="text-lg font-black text-blue-300 font-mono">{dischargedCount}</span>
        </div>
        <div className="p-3 rounded-xl bg-purple-950/30 border border-purple-500/40 flex items-center justify-between">
          <span className="text-xs font-bold text-purple-200">Transferred / Ref</span>
          <span className="text-lg font-black text-purple-300 font-mono">{transferredCount}</span>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="p-3.5 rounded-2xl glass-card border-cyan-500/25 flex flex-wrap items-center gap-2.5 shadow-lg text-xs">
        <div className="relative flex-1 min-w-[180px]">
          <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Search archive by patient, case ID, disposition..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-3.5 py-2 rounded-xl glass-input text-xs text-white"
          />
        </div>

        {/* Date Filter */}
        <div className="flex items-center gap-1">
          <span className="text-slate-400 font-bold text-[10px]">Date:</span>
          <select
            value={dateFilter}
            onChange={(e) => setDateFilter(e.target.value)}
            className="px-2.5 py-1.5 rounded-xl glass-input text-xs text-cyan-200 cursor-pointer"
          >
            <option value="All" className="bg-slate-950 text-white">All Dates</option>
            <option value="Today" className="bg-slate-950 text-white">Today</option>
            <option value="Yesterday" className="bg-slate-950 text-white">Yesterday</option>
            <option value="Previous 7 Days" className="bg-slate-950 text-white">Previous 7 Days</option>
          </select>
        </div>

        {/* Type Filter */}
        <div className="flex items-center gap-1">
          <span className="text-slate-400 font-bold text-[10px]">Type:</span>
          <select
            value={typeFilter}
            onChange={(e) => setTypeFilter(e.target.value)}
            className="px-2.5 py-1.5 rounded-xl glass-input text-xs text-cyan-200 cursor-pointer"
          >
            <option value="All" className="bg-slate-950 text-white">All Types</option>
            {EMERGENCY_TYPES.map((t) => (
              <option key={t} value={t} className="bg-slate-950 text-white">
                {t}
              </option>
            ))}
          </select>
        </div>

        {/* Final Status Filter */}
        <div className="flex items-center gap-1">
          <span className="text-slate-400 font-bold text-[10px]">Outcome:</span>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-2.5 py-1.5 rounded-xl glass-input text-xs text-cyan-200 cursor-pointer"
          >
            <option value="All" className="bg-slate-950 text-white">All Outcomes</option>
            <option value="Stabilized" className="bg-slate-950 text-emerald-300">Stabilized</option>
            <option value="Admitted" className="bg-slate-950 text-cyan-300">Admitted</option>
            <option value="Discharged" className="bg-slate-950 text-blue-300">Discharged</option>
            <option value="Transferred" className="bg-slate-950 text-purple-300">Transferred</option>
            <option value="Referred" className="bg-slate-950 text-amber-300">Referred</option>
          </select>
        </div>

        {/* Doctor Filter */}
        {doctorsList.length > 0 && (
          <div className="flex items-center gap-1">
            <span className="text-slate-400 font-bold text-[10px]">Doctor:</span>
            <select
              value={doctorFilter}
              onChange={(e) => setDoctorFilter(e.target.value)}
              className="px-2.5 py-1.5 rounded-xl glass-input text-xs text-cyan-200 cursor-pointer"
            >
              <option value="All" className="bg-slate-950 text-white">All Doctors</option>
              {doctorsList.map((d) => (
                <option key={d} value={d} className="bg-slate-950 text-white">
                  {d}
                </option>
              ))}
            </select>
          </div>
        )}
      </div>

      {/* History Table */}
      <div className="rounded-2xl glass-card border-cyan-500/25 overflow-hidden shadow-xl">
        {filteredRecords.length === 0 ? (
          <div className="p-12 text-center space-y-2">
            <CheckCircle2 className="w-9 h-9 text-emerald-400 mx-auto" />
            <h3 className="text-base font-black text-white">No Historical Cases Found</h3>
            <p className="text-xs text-slate-300">
              No archived records match your selected date, type, or outcome criteria.
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-cyan-500/20 bg-[rgba(6,18,45,0.7)] text-[11px] font-mono text-cyan-300 uppercase tracking-wider">
                  <th className="py-3 px-4 font-bold">Case ID</th>
                  <th className="py-3 px-4 font-bold">Patient</th>
                  <th className="py-3 px-4 font-bold">Emergency Type</th>
                  <th className="py-3 px-4 font-bold">Priority</th>
                  <th className="py-3 px-4 font-bold">Timeline (Arr &rarr; End)</th>
                  <th className="py-3 px-4 font-bold">Attending Specialist</th>
                  <th className="py-3 px-4 font-bold">Final Status</th>
                  <th className="py-3 px-4 font-bold">Disposition</th>
                  <th className="py-3 px-4 font-bold text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-cyan-500/15">
                {filteredRecords.map((r) => {
                  const isCrit = r.priority === 'Critical';
                  const isHigh = r.priority === 'High';

                  return (
                    <tr key={r.id} className="hover:bg-cyan-500/[0.06] transition group">
                      {/* Case ID */}
                      <td className="py-3 px-4 font-mono font-bold text-cyan-300 whitespace-nowrap">
                        {r.id}
                        <span className="block text-[9px] text-slate-400 font-medium">{r.date}</span>
                      </td>

                      {/* Patient */}
                      <td className="py-3 px-4">
                        <span className="font-extrabold text-white text-xs block group-hover:text-cyan-200 transition">
                          {r.patientName}
                        </span>
                        <span className="text-[10px] text-slate-400 font-mono block">
                          {r.patientId}
                        </span>
                      </td>

                      {/* Emergency Type */}
                      <td className="py-3 px-4">
                        <span className="px-2.5 py-0.5 rounded-lg text-[10px] font-bold bg-cyan-500/15 text-cyan-200 border border-cyan-500/30 whitespace-nowrap">
                          {r.emergencyType}
                        </span>
                      </td>

                      {/* Priority */}
                      <td className="py-3 px-4">
                        <span
                          className={`px-2 py-0.5 rounded-full text-[9px] font-black uppercase ${
                            isCrit
                              ? 'bg-red-500/25 text-red-200 border border-red-500/40'
                              : isHigh
                              ? 'bg-amber-500/25 text-amber-200 border border-amber-500/40'
                              : 'bg-cyan-500/25 text-cyan-200 border border-cyan-500/40'
                          }`}
                        >
                          {r.priority}
                        </span>
                      </td>

                      {/* Timeline */}
                      <td className="py-3 px-4 font-mono text-[11px] text-slate-300 whitespace-nowrap">
                        <span>{r.arrivalTime}</span>
                        <span className="text-slate-500 mx-1">&rarr;</span>
                        <span className="text-emerald-300 font-bold">{r.treatmentEnd}</span>
                      </td>

                      {/* Attending Doctor */}
                      <td className="py-3 px-4">
                        <span className="text-white font-bold text-xs flex items-center gap-1 whitespace-nowrap">
                          <Stethoscope className="w-3 h-3 text-cyan-400" />
                          {r.assignedDoctor}
                        </span>
                      </td>

                      {/* Final Status */}
                      <td className="py-3 px-4">
                        <span
                          className={`px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase whitespace-nowrap ${
                            r.finalStatus === 'Stabilized'
                              ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                              : r.finalStatus === 'Admitted'
                              ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                              : r.finalStatus === 'Discharged'
                              ? 'bg-blue-500/20 text-blue-300 border border-blue-500/40'
                              : 'bg-purple-500/20 text-purple-300 border border-purple-500/40'
                          }`}
                        >
                          {r.finalStatus}
                        </span>
                      </td>

                      {/* Disposition */}
                      <td className="py-3 px-4 text-slate-300 text-xs max-w-[200px] truncate" title={r.disposition}>
                        {r.disposition}
                      </td>

                      {/* Actions */}
                      <td className="py-3 px-4 text-right whitespace-nowrap">
                        <button
                          onClick={() => onViewRecord(r)}
                          className="px-3 py-1.5 rounded-lg text-xs font-bold bg-cyan-500/20 text-cyan-200 border border-cyan-500/40 hover:bg-cyan-500/30 transition flex items-center gap-1.5 ml-auto active:scale-95"
                        >
                          <Eye className="w-3.5 h-3.5" />
                          <span>View Full Case</span>
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
