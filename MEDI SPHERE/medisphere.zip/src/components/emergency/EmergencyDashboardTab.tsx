import React from 'react';
import {
  Flame,
  Activity,
  Heart,
  BedDouble,
  Clock,
  AlertTriangle,
  Radio,
  Truck,
  UserCheck,
  ShieldCheck,
  ArrowRight,
  TrendingUp,
  Zap,
  Gauge,
  CheckCircle2,
} from 'lucide-react';
import { EmergencyCase, EmergencyHistoryRecord } from '../../types';
import { EmergencyDoctor, AmbulanceUnit, EmergencyActivityEvent } from '../../data/emergencyData';

interface EmergencyDashboardTabProps {
  queueCases: EmergencyCase[];
  activeCases: EmergencyCase[];
  historyRecords: EmergencyHistoryRecord[];
  doctors: EmergencyDoctor[];
  ambulances: AmbulanceUnit[];
  activities: EmergencyActivityEvent[];
  onSelectTab: (tabId: string) => void;
  onViewCase: (eCase: EmergencyCase) => void;
}

export const EmergencyDashboardTab: React.FC<EmergencyDashboardTabProps> = ({
  queueCases,
  activeCases,
  historyRecords,
  doctors,
  ambulances,
  activities,
  onSelectTab,
  onViewCase,
}) => {
  // Aggregate statistics
  const totalToday = activeCases.length + queueCases.length + historyRecords.filter(r => r.date === 'Today').length;
  const criticalCasesCount = [...activeCases, ...queueCases].filter(c => c.priority === 'Critical').length;
  const highPriorityCasesCount = [...activeCases, ...queueCases].filter(c => c.priority === 'High').length;
  const stableCases = activeCases.filter(c => c.treatmentStatus === 'Stabilized' || c.treatmentStatus === 'Observation');
  const availableBeds = 5; // e.g. 5 out of 12 ER trauma beds available
  const icuAvailableBeds = 3; // e.g. 3 out of 8 ICU emergency beds
  const availableAmbulances = ambulances.filter(a => a.status === 'Available').length;
  const doctorsOnDuty = doctors.filter(d => d.currentStatus !== 'OFF DUTY').length;
  const avgResponseTime = '3.4m';

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* HUD Telemetry Stream Banner */}
      <div className="p-4 rounded-2xl glass-card border-red-500/30 flex flex-col sm:flex-row items-center justify-between gap-3 shadow-xl overflow-hidden">
        <div className="flex items-center gap-3 w-full sm:w-auto">
          <div className="w-9 h-9 rounded-xl bg-red-500/20 border border-red-500/40 flex items-center justify-center text-red-400">
            <Activity className="w-5 h-5 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-mono uppercase font-black text-white">
                Live Trauma Lead-II Telemetry
              </span>
              <span className="flex items-center gap-1 text-[10px] font-mono px-2 py-0.5 rounded-full bg-red-500/25 text-red-200 border border-red-500/40 animate-pulse font-extrabold">
                <Radio className="w-2.5 h-2.5 text-red-300" />
                ONLINE
              </span>
            </div>
            <span className="text-[11px] text-slate-300 font-medium">
              Acuity Index: Severity Level 1-4 Active &bull; Real-Time Vitals Feed
            </span>
          </div>
        </div>

        {/* Animated ECG SVG line */}
        <div className="hidden lg:block flex-1 max-w-md mx-6 h-6 overflow-hidden relative">
          <svg
            className="w-full h-full stroke-red-400 fill-none stroke-2 drop-shadow-[0_0_8px_rgba(239,68,68,0.6)]"
            viewBox="0 0 400 30"
          >
            <path d="M0 15 L80 15 L90 5 L100 25 L110 5 L120 18 L130 15 L250 15 L260 2 L270 28 L280 8 L290 18 L300 15 L400 15" />
          </svg>
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
          <button
            onClick={() => onSelectTab('queue')}
            className="px-3 py-1.5 rounded-xl text-xs font-bold bg-red-500/20 text-red-200 border border-red-500/40 hover:bg-red-500/30 transition flex items-center gap-1.5"
          >
            <span>Priority Queue ({queueCases.length})</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* 8-Stat Key Metrics Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3">
        {/* Stat 1 */}
        <div className="p-3.5 rounded-2xl glass-card border-cyan-500/25 flex flex-col justify-between hover:border-cyan-400 transition shadow-lg">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-[10px] font-bold uppercase tracking-wider">Cases Today</span>
            <Flame className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="text-xl font-black text-white font-mono">{totalToday}</div>
          <span className="text-[10px] text-cyan-300 font-semibold mt-0.5">+4 vs last shift</span>
        </div>

        {/* Stat 2 */}
        <div className="p-3.5 rounded-2xl glass-card border-red-500/40 flex flex-col justify-between hover:border-red-400 transition shadow-lg shadow-red-500/10">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-[10px] font-bold uppercase tracking-wider text-red-300">Active Cases</span>
            <Activity className="w-4 h-4 text-red-400 animate-pulse" />
          </div>
          <div className="text-xl font-black text-red-300 font-mono">{activeCases.length}</div>
          <span className="text-[10px] text-red-400/90 font-semibold mt-0.5">In trauma bays</span>
        </div>

        {/* Stat 3 */}
        <div className="p-3.5 rounded-2xl glass-card border-red-500/50 flex flex-col justify-between hover:border-red-400 transition shadow-[0_0_15px_rgba(239,68,68,0.2)] bg-red-950/20">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-[10px] font-bold uppercase tracking-wider text-red-200">Critical</span>
            <ShieldCheck className="w-4 h-4 text-red-400 animate-pulse" />
          </div>
          <div className="text-xl font-black text-red-200 font-mono">{criticalCasesCount}</div>
          <span className="text-[10px] text-red-300 font-semibold mt-0.5">Immediate triage</span>
        </div>

        {/* Stat 4 */}
        <div className="p-3.5 rounded-2xl glass-card border-cyan-500/25 flex flex-col justify-between hover:border-cyan-400 transition shadow-lg">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-[10px] font-bold uppercase tracking-wider">ER Beds</span>
            <BedDouble className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="text-xl font-black text-white font-mono">{availableBeds} <span className="text-xs text-slate-400 font-normal">/ 12</span></div>
          <span className="text-[10px] text-emerald-400 font-semibold mt-0.5">Ready for intake</span>
        </div>

        {/* Stat 5 */}
        <div className="p-3.5 rounded-2xl glass-card border-purple-500/30 flex flex-col justify-between hover:border-purple-400 transition shadow-lg">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-[10px] font-bold uppercase tracking-wider">ICU Beds</span>
            <Heart className="w-4 h-4 text-purple-400" />
          </div>
          <div className="text-xl font-black text-white font-mono">{icuAvailableBeds} <span className="text-xs text-slate-400 font-normal">/ 8</span></div>
          <span className="text-[10px] text-purple-300 font-semibold mt-0.5">Critical ready</span>
        </div>

        {/* Stat 6 */}
        <div className="p-3.5 rounded-2xl glass-card border-emerald-500/30 flex flex-col justify-between hover:border-emerald-400 transition shadow-lg">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-[10px] font-bold uppercase tracking-wider">Ambulances</span>
            <Truck className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-xl font-black text-white font-mono">{availableAmbulances} <span className="text-xs text-slate-400 font-normal">/ {ambulances.length}</span></div>
          <span className="text-[10px] text-emerald-300 font-semibold mt-0.5">On base dock</span>
        </div>

        {/* Stat 7 */}
        <div className="p-3.5 rounded-2xl glass-card border-cyan-500/25 flex flex-col justify-between hover:border-cyan-400 transition shadow-lg">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-[10px] font-bold uppercase tracking-wider">ER Doctors</span>
            <UserCheck className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="text-xl font-black text-white font-mono">{doctorsOnDuty} <span className="text-xs text-slate-400 font-normal">/ {doctors.length}</span></div>
          <span className="text-[10px] text-cyan-300 font-semibold mt-0.5">On active roster</span>
        </div>

        {/* Stat 8 */}
        <div className="p-3.5 rounded-2xl glass-card border-amber-500/30 flex flex-col justify-between hover:border-amber-400 transition shadow-lg">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-[10px] font-bold uppercase tracking-wider">Resp. Time</span>
            <Clock className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-xl font-black text-amber-300 font-mono">{avgResponseTime}</div>
          <span className="text-[10px] text-emerald-400 font-semibold mt-0.5">Fast-track avg</span>
        </div>
      </div>

      {/* LIVE EMERGENCY OVERVIEW SECTION */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Zap className="w-4 h-4 text-cyan-400" />
            <h2 className="text-base font-black text-white tracking-tight">
              Live Emergency Overview
            </h2>
          </div>
          <span className="text-xs text-slate-400 font-medium">
            Active monitoring across bays, triage queues & transit fleet
          </span>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          {/* Column 1: Critical & High Priority Cases */}
          <div className="p-5 rounded-2xl glass-card border-red-500/40 shadow-xl flex flex-col justify-between space-y-4">
            <div>
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-red-400 animate-ping" />
                  <h3 className="text-xs font-black uppercase text-red-200 tracking-wider">
                    Critical Cases ({criticalCasesCount})
                  </h3>
                </div>
                <button
                  onClick={() => onSelectTab('active')}
                  className="text-[11px] text-cyan-300 hover:text-white font-bold flex items-center gap-1"
                >
                  <span>View All</span>
                  <ArrowRight className="w-3 h-3" />
                </button>
              </div>

              <div className="space-y-2.5">
                {[...activeCases, ...queueCases]
                  .filter((c) => c.priority === 'Critical')
                  .slice(0, 3)
                  .map((c) => (
                    <div
                      key={c.id}
                      onClick={() => onViewCase(c)}
                      className="p-3 rounded-xl bg-[rgba(6,18,45,0.7)] border border-red-500/40 hover:border-red-400 cursor-pointer transition flex items-center justify-between group"
                    >
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-extrabold text-white group-hover:text-cyan-200 transition">
                            {c.patientName}
                          </span>
                          <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-red-500/30 text-red-200 border border-red-500/40">
                            {c.id}
                          </span>
                        </div>
                        <span className="text-[11px] text-slate-300 font-medium block mt-0.5">
                          {c.emergencyType || 'Acute Emergency'} &bull; Bed: <span className="text-cyan-300 font-mono font-bold">{c.assignedBedNumber || 'Triage'}</span>
                        </span>
                        <div className="flex items-center gap-2 mt-1 text-[10px] font-mono text-slate-400">
                          <span>HR: <strong className="text-red-300">{c.vitals?.heartRate}</strong></span>
                          <span>BP: <strong className="text-amber-300">{c.vitals?.bloodPressure}</strong></span>
                          <span>SpO2: <strong className="text-cyan-200">{c.vitals?.oxygenSaturation}%</strong></span>
                        </div>
                      </div>
                      <div className="text-right">
                        <span className="text-[10px] font-bold text-amber-300 block">
                          {c.waitingMinutes}m wait
                        </span>
                        <span className="text-[9px] px-2 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700 block mt-1">
                          {c.status}
                        </span>
                      </div>
                    </div>
                  ))}

                {criticalCasesCount === 0 && (
                  <div className="p-4 rounded-xl glass-card-subtle text-center text-xs text-slate-400">
                    No critical resuscitation cases active at this moment.
                  </div>
                )}
              </div>
            </div>

            {/* High Priority sub-box */}
            <div className="pt-3 border-t border-red-500/20">
              <div className="flex items-center justify-between text-xs mb-2">
                <span className="text-[11px] font-extrabold text-amber-300 uppercase tracking-wider">
                  High Priority Active: {highPriorityCasesCount}
                </span>
                <span className="text-[10px] text-slate-400">Under Fast-Track Review</span>
              </div>
              <p className="text-[11px] text-slate-300 leading-relaxed font-medium">
                Acute stroke, severe chemical burn & cardiac monitoring patients undergoing continuous physician oversight.
              </p>
            </div>
          </div>

          {/* Column 2: Ambulance Fleet Status Tracker */}
          <div className="p-5 rounded-2xl glass-card border-cyan-500/30 shadow-xl flex flex-col justify-between space-y-4">
            <div>
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <Truck className="w-4 h-4 text-emerald-400" />
                  <h3 className="text-xs font-black uppercase text-white tracking-wider">
                    Ambulance Fleet Status ({availableAmbulances} Available)
                  </h3>
                </div>
                <span className="text-[10px] font-mono text-emerald-300 font-bold px-2 py-0.5 rounded bg-emerald-500/20 border border-emerald-500/40">
                  GPS ACTIVE
                </span>
              </div>

              <div className="space-y-2.5 max-h-72 overflow-y-auto pr-1">
                {ambulances.map((amb) => {
                  const isEnRoute = amb.status === 'En Route';
                  const isAvailable = amb.status === 'Available';
                  const isOnScene = amb.status === 'On Scene';

                  return (
                    <div
                      key={amb.id}
                      className="p-3 rounded-xl bg-[rgba(6,18,45,0.6)] border border-cyan-500/20 flex items-center justify-between gap-2 text-xs"
                    >
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-extrabold text-white">{amb.callSign}</span>
                          <span
                            className={`text-[9px] font-bold px-2 py-0.5 rounded-full uppercase ${
                              isAvailable
                                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                                : isEnRoute
                                ? 'bg-red-500/25 text-red-200 border border-red-500/40 animate-pulse'
                                : isOnScene
                                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                                : 'bg-cyan-500/20 text-cyan-200 border border-cyan-500/40'
                            }`}
                          >
                            {amb.status}
                          </span>
                        </div>
                        <span className="text-[10px] text-slate-300 font-medium block mt-0.5">
                          {amb.location}
                        </span>
                        <span className="text-[10px] text-slate-400 font-medium">
                          Paramedic: {amb.paramedicInCharge}
                        </span>
                      </div>

                      <div className="text-right whitespace-nowrap">
                        <span className="text-[11px] font-mono font-extrabold text-cyan-300 block">
                          ETA: {amb.eta}
                        </span>
                        <span className="text-[9px] text-slate-400 block mt-0.5">
                          {amb.type.split(' ')[0]}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="pt-3 border-t border-cyan-500/20 flex items-center justify-between text-xs">
              <span className="text-[11px] text-slate-300 font-medium">Trauma Bay Transit Channel:</span>
              <span className="text-[11px] font-mono text-cyan-300 font-bold">VHF 155.340 MHz</span>
            </div>
          </div>

          {/* Column 3: Emergency Room Capacity & Stable Cases */}
          <div className="p-5 rounded-2xl glass-card border-cyan-500/30 shadow-xl flex flex-col justify-between space-y-4">
            <div>
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <Gauge className="w-4 h-4 text-cyan-400" />
                  <h3 className="text-xs font-black uppercase text-white tracking-wider">
                    Emergency Room Capacity
                  </h3>
                </div>
                <span className="text-[10px] font-mono text-cyan-300 font-bold">
                  BAYS 1-4
                </span>
              </div>

              {/* Bay Capacities */}
              <div className="space-y-3">
                <div>
                  <div className="flex justify-between text-xs mb-1">
                    <span className="font-bold text-red-300 flex items-center gap-1.5">
                      <span className="w-2 h-2 rounded-full bg-red-500" />
                      Red Bay (Resuscitation / Trauma)
                    </span>
                    <span className="font-mono font-bold text-white">4 / 5 Beds (80%)</span>
                  </div>
                  <div className="w-full h-2 rounded-full bg-slate-950 border border-red-500/30 overflow-hidden">
                    <div className="h-full bg-gradient-to-r from-red-600 to-red-400 w-[80%] rounded-full shadow-[0_0_10px_rgba(239,68,68,0.5)]" />
                  </div>
                </div>

                <div>
                  <div className="flex justify-between text-xs mb-1">
                    <span className="font-bold text-amber-300 flex items-center gap-1.5">
                      <span className="w-2 h-2 rounded-full bg-amber-500" />
                      Yellow Bay (Acute Emergency)
                    </span>
                    <span className="font-mono font-bold text-white">6 / 9 Beds (66%)</span>
                  </div>
                  <div className="w-full h-2 rounded-full bg-slate-950 border border-amber-500/30 overflow-hidden">
                    <div className="h-full bg-gradient-to-r from-amber-600 to-amber-400 w-[66%] rounded-full" />
                  </div>
                </div>

                <div>
                  <div className="flex justify-between text-xs mb-1">
                    <span className="font-bold text-emerald-300 flex items-center gap-1.5">
                      <span className="w-2 h-2 rounded-full bg-emerald-500" />
                      Green Bay (Subacute / Fast-Track)
                    </span>
                    <span className="font-mono font-bold text-white">3 / 8 Beds (37%)</span>
                  </div>
                  <div className="w-full h-2 rounded-full bg-slate-950 border border-emerald-500/30 overflow-hidden">
                    <div className="h-full bg-gradient-to-r from-emerald-600 to-emerald-400 w-[37%] rounded-full" />
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-[rgba(6,18,45,0.6)] border border-cyan-500/20 flex items-center justify-between text-xs">
                  <div>
                    <span className="font-bold text-white block">Emergency OT 1</span>
                    <span className="text-[10px] text-red-300 font-medium">In Use: Acute Laparotomy</span>
                  </div>
                  <div>
                    <span className="font-bold text-white block">Emergency OT 2</span>
                    <span className="text-[10px] text-emerald-300 font-medium">Standby & Sanitized</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Stable Cases Monitor */}
            <div className="pt-3 border-t border-cyan-500/20">
              <div className="flex items-center justify-between text-xs mb-1.5">
                <span className="text-[11px] font-bold text-emerald-300 flex items-center gap-1.5 uppercase">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                  Stabilized / Observation Cases ({stableCases.length})
                </span>
                <button
                  onClick={() => onSelectTab('history')}
                  className="text-[10px] text-cyan-300 hover:text-white font-bold"
                >
                  History Archive
                </button>
              </div>
              <p className="text-[11px] text-slate-300 leading-relaxed font-medium">
                Patients with normalized hemodynamics awaiting step-down ward bed allocation or discharge clearance.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* RECENT EMERGENCY ACTIVITY FEED */}
      <div className="p-5 rounded-2xl glass-card border-cyan-500/30 shadow-xl">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-cyan-400" />
            <h2 className="text-base font-black text-white tracking-tight">
              Recent Emergency Activity Stream
            </h2>
          </div>
          <span className="text-xs text-slate-400 font-mono">Real-Time Event Chrono</span>
        </div>

        <div className="divide-y divide-cyan-500/15">
          {activities.slice(0, 5).map((act) => {
            const isCodeRed = act.type === 'CODE_RED';
            const isStabilized = act.type === 'STABILIZED';

            return (
              <div key={act.id} className="py-3 flex items-start justify-between gap-4 text-xs">
                <div className="flex items-start gap-3">
                  <div
                    className={`mt-0.5 w-7 h-7 rounded-lg flex items-center justify-center font-bold text-xs ${
                      isCodeRed
                        ? 'bg-red-500/25 text-red-300 border border-red-500/40 animate-pulse'
                        : isStabilized
                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                        : 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                    }`}
                  >
                    {isCodeRed ? <Flame className="w-4 h-4" /> : <Activity className="w-4 h-4" />}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-extrabold text-white">{act.title}</span>
                      <span className="text-[10px] text-cyan-300 font-mono font-medium">
                        by {act.actor}
                      </span>
                    </div>
                    <p className="text-slate-300 text-[11px] mt-0.5 leading-relaxed font-medium">
                      {act.description}
                    </p>
                  </div>
                </div>

                <div className="text-right whitespace-nowrap">
                  <span className="font-mono text-cyan-300 font-bold text-[11px] block">{act.time}</span>
                  {act.priority && (
                    <span
                      className={`text-[9px] font-black px-2 py-0.5 rounded uppercase mt-1 inline-block ${
                        act.priority === 'Critical'
                          ? 'bg-red-500/30 text-red-200 border border-red-500/40'
                          : 'bg-amber-500/30 text-amber-200 border border-amber-500/40'
                      }`}
                    >
                      {act.priority}
                    </span>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
