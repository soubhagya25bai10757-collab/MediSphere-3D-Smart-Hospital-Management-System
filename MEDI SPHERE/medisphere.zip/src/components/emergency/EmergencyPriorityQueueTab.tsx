import React, { useState, useMemo } from 'react';
import {
  Flame,
  Search,
  Filter,
  Stethoscope,
  Eye,
  Clock,
  AlertTriangle,
  Zap,
  UserPlus,
  ArrowUpDown,
  CheckCircle2,
  ShieldAlert,
} from 'lucide-react';
import { EmergencyCase, EmergencyPriority } from '../../types';
import { EmergencyDoctor, EMERGENCY_TYPES } from '../../data/emergencyData';

interface PriorityQueueTabProps {
  queueCases: EmergencyCase[];
  doctors: EmergencyDoctor[];
  onViewCase: (eCase: EmergencyCase) => void;
  onOpenAssignDoctor: (eCase: EmergencyCase) => void;
  onUpdatePriority: (caseId: string, newPriority: EmergencyPriority) => void;
  onOpenIngestModal: () => void;
}

export const EmergencyPriorityQueueTab: React.FC<PriorityQueueTabProps> = ({
  queueCases,
  doctors,
  onViewCase,
  onOpenAssignDoctor,
  onUpdatePriority,
  onOpenIngestModal,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [priorityFilter, setPriorityFilter] = useState<string>('All');
  const [typeFilter, setTypeFilter] = useState<string>('All');
  const [waitTimeFilter, setWaitTimeFilter] = useState<string>('All');

  // Filtered and priority-sorted queue
  const filteredCases = useMemo(() => {
    return queueCases
      .filter((c) => {
        const matchesSearch =
          c.patientName.toLowerCase().includes(searchQuery.toLowerCase()) ||
          c.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
          (c.patientId && c.patientId.toLowerCase().includes(searchQuery.toLowerCase()));

        const matchesPriority = priorityFilter === 'All' || c.priority === priorityFilter;
        const matchesType = typeFilter === 'All' || c.emergencyType === typeFilter;

        let matchesWaitTime = true;
        if (waitTimeFilter === '<15') matchesWaitTime = c.waitingMinutes < 15;
        else if (waitTimeFilter === '15-30') matchesWaitTime = c.waitingMinutes >= 15 && c.waitingMinutes <= 30;
        else if (waitTimeFilter === '>30') matchesWaitTime = c.waitingMinutes > 30;

        return matchesSearch && matchesPriority && matchesType && matchesWaitTime;
      })
      .sort((a, b) => {
        // Priority weight: Critical (4) > High (3) > Medium (2) > Low (1)
        const weight: Record<EmergencyPriority, number> = {
          Critical: 4,
          High: 3,
          Medium: 2,
          Low: 1,
        };
        const diff = weight[b.priority] - weight[a.priority];
        if (diff !== 0) return diff;
        // Secondary sort: longest waiting time first
        return b.waitingMinutes - a.waitingMinutes;
      });
  }, [queueCases, searchQuery, priorityFilter, typeFilter, waitTimeFilter]);

  const criticalWaiting = queueCases.filter((c) => c.priority === 'Critical').length;
  const highWaiting = queueCases.filter((c) => c.priority === 'High').length;

  return (
    <div className="space-y-5 animate-in fade-in duration-200">
      {/* Top Banner & Strategy notice */}
      <div className="p-4 rounded-2xl glass-card border-red-500/30 flex flex-col sm:flex-row items-center justify-between gap-3 shadow-xl">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-red-500/20 border border-red-500/40 flex items-center justify-center text-red-400">
            <Flame className="w-5 h-5 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base font-black text-white">Emergency Priority Queue</h2>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-red-500/25 text-red-200 border border-red-500/40 font-black">
                {queueCases.length} WAITING
              </span>
            </div>
            <p className="text-xs text-slate-300 font-medium">
              Ranked dynamically by physiologic acuity: <strong className="text-red-300">CRITICAL</strong> &gt; <strong className="text-amber-300">HIGH</strong> &gt; <strong className="text-cyan-300">MEDIUM</strong> &gt; LOW
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2.5 w-full sm:w-auto justify-end">
          <button
            onClick={onOpenIngestModal}
            className="px-4 py-2 rounded-xl text-xs font-black bg-gradient-to-r from-red-600 to-amber-600 hover:from-red-500 hover:to-amber-500 text-white shadow-lg shadow-red-500/25 transition flex items-center gap-1.5"
          >
            <UserPlus className="w-3.5 h-3.5" />
            <span>+ Ingest Triage Case</span>
          </button>
        </div>
      </div>

      {/* Acuity Status Chips */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="p-3 rounded-xl bg-red-950/30 border border-red-500/40 flex items-center justify-between">
          <span className="text-xs font-bold text-red-200">Critical Awaiting</span>
          <span className="text-lg font-black text-red-300 font-mono">{criticalWaiting}</span>
        </div>
        <div className="p-3 rounded-xl bg-amber-950/30 border border-amber-500/40 flex items-center justify-between">
          <span className="text-xs font-bold text-amber-200">High Awaiting</span>
          <span className="text-lg font-black text-amber-300 font-mono">{highWaiting}</span>
        </div>
        <div className="p-3 rounded-xl bg-cyan-950/30 border border-cyan-500/40 flex items-center justify-between">
          <span className="text-xs font-bold text-cyan-200">Available Doctors</span>
          <span className="text-lg font-black text-cyan-300 font-mono">
            {doctors.filter((d) => d.currentStatus === 'AVAILABLE').length}
          </span>
        </div>
        <div className="p-3 rounded-xl bg-slate-900/50 border border-slate-700/50 flex items-center justify-between">
          <span className="text-xs font-bold text-slate-300">Avg Wait Time</span>
          <span className="text-lg font-black text-emerald-300 font-mono">
            {queueCases.length ? Math.round(queueCases.reduce((a, b) => a + b.waitingMinutes, 0) / queueCases.length) : 0}m
          </span>
        </div>
      </div>

      {/* Interactive Filters Bar */}
      <div className="p-3.5 rounded-2xl glass-card border-cyan-500/25 flex flex-wrap items-center gap-3 shadow-lg">
        {/* Search */}
        <div className="relative flex-1 min-w-[200px]">
          <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Search patient name, case ID, UHID..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-3.5 py-2 rounded-xl glass-input text-xs text-white"
          />
        </div>

        {/* Priority Filter */}
        <div className="flex items-center gap-1.5 text-xs">
          <span className="text-slate-400 font-bold text-[11px] whitespace-nowrap">Priority:</span>
          <select
            value={priorityFilter}
            onChange={(e) => setPriorityFilter(e.target.value)}
            className="px-2.5 py-2 rounded-xl glass-input text-xs text-cyan-200 cursor-pointer"
          >
            <option value="All" className="bg-slate-950 text-white">All Acuities</option>
            <option value="Critical" className="bg-slate-950 text-red-300 font-bold">Critical</option>
            <option value="High" className="bg-slate-950 text-amber-300 font-bold">High</option>
            <option value="Medium" className="bg-slate-950 text-cyan-300">Medium</option>
            <option value="Low" className="bg-slate-950 text-slate-300">Low</option>
          </select>
        </div>

        {/* Emergency Type Filter */}
        <div className="flex items-center gap-1.5 text-xs">
          <span className="text-slate-400 font-bold text-[11px] whitespace-nowrap">Type:</span>
          <select
            value={typeFilter}
            onChange={(e) => setTypeFilter(e.target.value)}
            className="px-2.5 py-2 rounded-xl glass-input text-xs text-cyan-200 cursor-pointer"
          >
            <option value="All" className="bg-slate-950 text-white">All Emergency Types</option>
            {EMERGENCY_TYPES.map((t) => (
              <option key={t} value={t} className="bg-slate-950 text-white">
                {t}
              </option>
            ))}
          </select>
        </div>

        {/* Waiting Time Filter */}
        <div className="flex items-center gap-1.5 text-xs">
          <span className="text-slate-400 font-bold text-[11px] whitespace-nowrap">Wait Time:</span>
          <select
            value={waitTimeFilter}
            onChange={(e) => setWaitTimeFilter(e.target.value)}
            className="px-2.5 py-2 rounded-xl glass-input text-xs text-cyan-200 cursor-pointer"
          >
            <option value="All" className="bg-slate-950 text-white">All Waiting Times</option>
            <option value="<15" className="bg-slate-950 text-white">&lt; 15 mins</option>
            <option value="15-30" className="bg-slate-950 text-white">15 - 30 mins</option>
            <option value=">30" className="bg-slate-950 text-white">&gt; 30 mins</option>
          </select>
        </div>
      </div>

      {/* Priority Queue Table */}
      <div className="rounded-2xl glass-card border-cyan-500/25 overflow-hidden shadow-xl">
        {filteredCases.length === 0 ? (
          <div className="p-12 text-center space-y-3">
            <CheckCircle2 className="w-10 h-10 text-emerald-400 mx-auto" />
            <h3 className="text-base font-black text-white">Priority Queue Cleared</h3>
            <p className="text-xs text-slate-300 max-w-md mx-auto">
              All triage queue patients have been assigned to active emergency care or no cases match the active filter criteria.
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-cyan-500/20 bg-[rgba(6,18,45,0.7)] text-[11px] font-mono text-cyan-300 uppercase tracking-wider">
                  <th className="py-3 px-4 font-bold">Queue #</th>
                  <th className="py-3 px-4 font-bold">Patient & Demographic</th>
                  <th className="py-3 px-4 font-bold">Emergency Type</th>
                  <th className="py-3 px-4 font-bold">Priority Level</th>
                  <th className="py-3 px-4 font-bold">Arrival Time</th>
                  <th className="py-3 px-4 font-bold">Waiting Time</th>
                  <th className="py-3 px-4 font-bold">Physician Status</th>
                  <th className="py-3 px-4 font-bold text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-cyan-500/15">
                {filteredCases.map((c, idx) => {
                  const isCrit = c.priority === 'Critical';
                  const isHigh = c.priority === 'High';
                  const isMed = c.priority === 'Medium';

                  return (
                    <tr
                      key={c.id}
                      className="hover:bg-cyan-500/[0.06] transition group"
                    >
                      {/* Queue # */}
                      <td className="py-3.5 px-4 font-mono font-bold text-slate-400">
                        <span className="px-2 py-0.5 rounded bg-slate-900 border border-slate-700 text-slate-200">
                          #{idx + 1 < 10 ? `0${idx + 1}` : idx + 1}
                        </span>
                      </td>

                      {/* Patient & Demographics */}
                      <td className="py-3.5 px-4">
                        <div className="flex items-center gap-2">
                          <span className="font-extrabold text-white text-xs group-hover:text-cyan-200 transition">
                            {c.patientName}
                          </span>
                          <span className="text-[10px] font-mono text-cyan-300 font-bold">
                            {c.id}
                          </span>
                        </div>
                        <span className="text-[10px] text-slate-300 block font-medium mt-0.5">
                          {c.age} yrs &bull; {c.gender} &bull; {c.chiefComplaint.slice(0, 40)}...
                        </span>
                      </td>

                      {/* Emergency Type */}
                      <td className="py-3.5 px-4">
                        <span className="px-2.5 py-1 rounded-lg text-[11px] font-bold bg-cyan-500/15 text-cyan-200 border border-cyan-500/30 whitespace-nowrap">
                          {c.emergencyType || 'Acute Emergency'}
                        </span>
                      </td>

                      {/* Priority Level */}
                      <td className="py-3.5 px-4">
                        <div className="flex items-center gap-1.5">
                          <span
                            className={`px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider ${
                              isCrit
                                ? 'bg-red-500/25 text-red-200 border border-red-500/50 animate-pulse shadow-[0_0_10px_rgba(239,68,68,0.3)]'
                                : isHigh
                                ? 'bg-amber-500/25 text-amber-200 border border-amber-500/50'
                                : isMed
                                ? 'bg-cyan-500/25 text-cyan-200 border border-cyan-500/50'
                                : 'bg-slate-700/40 text-slate-300 border border-slate-600'
                            }`}
                          >
                            {c.priority}
                          </span>

                          {/* Quick Reprioritize Dropdown */}
                          <select
                            value={c.priority}
                            onChange={(e) => onUpdatePriority(c.id, e.target.value as EmergencyPriority)}
                            className="text-[9px] bg-slate-900/80 border border-slate-700 text-slate-300 rounded px-1 py-0.5 cursor-pointer opacity-70 hover:opacity-100 transition"
                            title="Quick Change Priority"
                          >
                            <option value="Critical">Crit</option>
                            <option value="High">High</option>
                            <option value="Medium">Med</option>
                            <option value="Low">Low</option>
                          </select>
                        </div>
                      </td>

                      {/* Arrival Time */}
                      <td className="py-3.5 px-4 font-mono text-slate-300 font-bold">
                        {c.arrivalTime}
                      </td>

                      {/* Waiting Time */}
                      <td className="py-3.5 px-4">
                        <span
                          className={`font-mono font-black text-xs ${
                            c.waitingMinutes > 25
                              ? 'text-red-300'
                              : c.waitingMinutes > 15
                              ? 'text-amber-300'
                              : 'text-emerald-300'
                          }`}
                        >
                          {c.waitingMinutes} min
                        </span>
                      </td>

                      {/* Physician Status */}
                      <td className="py-3.5 px-4">
                        {c.assignedDoctorName ? (
                          <span className="text-cyan-200 font-bold flex items-center gap-1">
                            <Stethoscope className="w-3 h-3 text-cyan-400" />
                            {c.assignedDoctorName}
                          </span>
                        ) : (
                          <span className="text-amber-300 font-medium text-[11px] flex items-center gap-1">
                            <AlertTriangle className="w-3 h-3 text-amber-400" />
                            Awaiting Doctor
                          </span>
                        )}
                      </td>

                      {/* Actions */}
                      <td className="py-3.5 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            onClick={() => onViewCase(c)}
                            title="View Case Details"
                            className="p-1.5 rounded-lg text-slate-300 hover:text-white hover:bg-cyan-500/20 border border-cyan-500/20 transition"
                          >
                            <Eye className="w-3.5 h-3.5" />
                          </button>

                          <button
                            onClick={() => onOpenAssignDoctor(c)}
                            className="px-3 py-1.5 rounded-lg text-xs font-bold bg-cyan-500/20 text-cyan-200 border border-cyan-500/40 hover:bg-cyan-500/30 transition flex items-center gap-1 active:scale-95 shadow-sm"
                          >
                            <Stethoscope className="w-3 h-3" />
                            <span>Assign</span>
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
