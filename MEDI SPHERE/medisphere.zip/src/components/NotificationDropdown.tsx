import React, { useState } from 'react';
import { useHospital } from '../context/HospitalContext';
import {
  Bell,
  Calendar,
  Flame,
  UserCheck,
  AlertTriangle,
  CheckCircle2,
  X,
  Clock,
  ChevronRight,
} from 'lucide-react';

interface NotificationItem {
  id: string;
  category: 'appointment' | 'emergency' | 'doctor' | 'capacity' | 'confirmation';
  title: string;
  description: string;
  timestamp: string;
  read: boolean;
  targetTab?: 'dashboard' | 'patients' | 'doctors' | 'appointments' | 'emergency' | 'operations' | 'analytics';
  targetSubTab?: string;
}

const INITIAL_NOTIFICATIONS: NotificationItem[] = [
  {
    id: 'NOTIF-01',
    category: 'emergency',
    title: 'Emergency Case Update',
    description: 'Critical trauma patient Aarav Patel triaged in ER Bay 1. Assigned to Dr. Vivek Malhotra.',
    timestamp: '2 mins ago',
    read: false,
    targetTab: 'emergency',
    targetSubTab: 'queue',
  },
  {
    id: 'NOTIF-02',
    category: 'capacity',
    title: 'Hospital Capacity Warning',
    description: 'ICU occupancy at 85% (9 of 12 beds occupied). 3 critical beds remaining.',
    timestamp: '14 mins ago',
    read: false,
    targetTab: 'operations',
    targetSubTab: 'beds',
  },
  {
    id: 'NOTIF-03',
    category: 'appointment',
    title: 'Upcoming Appointment',
    description: 'Consultation with Dr. Arvind Swaminathan for Vikramjit Singh at 09:30 AM.',
    timestamp: '25 mins ago',
    read: false,
    targetTab: 'appointments',
    targetSubTab: 'today',
  },
  {
    id: 'NOTIF-04',
    category: 'doctor',
    title: 'Doctor Availability',
    description: 'Dr. Rajesh Sharma (Cardiology) is now Available for OPD consultations in Room OPD-201.',
    timestamp: '42 mins ago',
    read: true,
    targetTab: 'doctors',
    targetSubTab: 'directory',
  },
  {
    id: 'NOTIF-05',
    category: 'confirmation',
    title: 'Appointment Confirmed',
    description: 'Booking APT-902 confirmed for Meera Iyer with Dr. Anita Desai (Gynecology).',
    timestamp: '1 hour ago',
    read: true,
    targetTab: 'appointments',
    targetSubTab: 'today',
  },
];

interface NotificationDropdownProps {
  isOpen: boolean;
  onClose: () => void;
}

export const NotificationDropdown: React.FC<NotificationDropdownProps> = ({
  isOpen,
  onClose,
}) => {
  const { setActiveNavigation } = useHospital();
  const [notifications, setNotifications] = useState<NotificationItem[]>(INITIAL_NOTIFICATIONS);

  if (!isOpen) return null;

  const unreadCount = notifications.filter((n) => !n.read).length;

  const markAllRead = () => {
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
  };

  const markItemRead = (id: string) => {
    setNotifications((prev) =>
      prev.map((n) => (n.id === id ? { ...n, read: true } : n))
    );
  };

  const getIcon = (category: NotificationItem['category']) => {
    switch (category) {
      case 'emergency':
        return <Flame className="w-4 h-4 text-red-400" />;
      case 'capacity':
        return <AlertTriangle className="w-4 h-4 text-amber-400" />;
      case 'appointment':
        return <Calendar className="w-4 h-4 text-cyan-400" />;
      case 'doctor':
        return <UserCheck className="w-4 h-4 text-blue-400" />;
      case 'confirmation':
        return <CheckCircle2 className="w-4 h-4 text-emerald-400" />;
      default:
        return <Bell className="w-4 h-4 text-cyan-400" />;
    }
  };

  return (
    <div
      className="absolute right-0 top-full mt-2 w-80 sm:w-96 bg-[rgba(3,10,26,0.96)] backdrop-blur-2xl border border-cyan-500/40 rounded-2xl shadow-[0_20px_50px_rgba(0,0,0,0.8),0_0_30px_rgba(6,182,212,0.25)] overflow-hidden z-50 animate-in fade-in slide-in-from-top-2 duration-150"
      onClick={(e) => e.stopPropagation()}
    >
      {/* Header */}
      <div className="px-4 py-3 border-b border-cyan-500/20 flex items-center justify-between bg-[rgba(6,18,45,0.7)]">
        <div className="flex items-center gap-2">
          <Bell className="w-4 h-4 text-cyan-400" />
          <span className="text-xs font-black text-white tracking-wide">
            Notifications
          </span>
          {unreadCount > 0 && (
            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
              {unreadCount} unread
            </span>
          )}
        </div>

        <div className="flex items-center gap-2">
          {unreadCount > 0 && (
            <button
              onClick={markAllRead}
              className="text-[10px] text-cyan-300 hover:text-white font-semibold transition"
            >
              Mark all read
            </button>
          )}
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Notifications List */}
      <div className="max-h-[380px] overflow-y-auto divide-y divide-cyan-500/15">
        {notifications.map((notif) => (
          <div
            key={notif.id}
            onClick={() => {
              markItemRead(notif.id);
              if (notif.targetTab) {
                setActiveNavigation(notif.targetTab, notif.targetSubTab);
              }
              onClose();
            }}
            className={`p-3.5 hover:bg-[rgba(6,18,45,0.8)] cursor-pointer transition flex items-start gap-3 ${
              notif.read ? 'bg-transparent opacity-85' : 'bg-[rgba(6,25,60,0.4)]'
            }`}
          >
            <div className="p-2 rounded-xl bg-[rgba(6,18,45,0.8)] border border-cyan-500/25 shrink-0 mt-0.5">
              {getIcon(notif.category)}
            </div>

            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between gap-1">
                <span className="text-xs font-extrabold text-white truncate">
                  {notif.title}
                </span>
                <span className="text-[10px] font-mono text-slate-400 shrink-0">
                  {notif.timestamp}
                </span>
              </div>
              <p className="text-[11px] text-slate-300 mt-1 leading-snug">
                {notif.description}
              </p>
            </div>

            {!notif.read && (
              <span className="w-2 h-2 rounded-full bg-cyan-400 shadow-[0_0_8px_#00f0ff] shrink-0 mt-1.5" />
            )}
          </div>
        ))}
      </div>

      {/* Footer */}
      <div className="px-4 py-2.5 border-t border-cyan-500/20 bg-[rgba(6,18,45,0.9)] flex items-center justify-between text-[11px] text-slate-400">
        <span className="flex items-center gap-1">
          <Clock className="w-3 h-3 text-cyan-400" />
          Live hospital dispatch alerts
        </span>
        <span className="text-cyan-300 font-bold font-mono">5 Active</span>
      </div>
    </div>
  );
};
