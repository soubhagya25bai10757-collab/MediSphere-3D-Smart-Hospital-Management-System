import React, { useMemo } from 'react';
import { useHospital } from '../context/HospitalContext';
import {
  Search,
  User,
  Stethoscope,
  Calendar,
  Flame,
  Building2,
  ChevronRight,
  X,
  ExternalLink,
} from 'lucide-react';
import { ALL_SPECIALIZATIONS } from '../data/initialData';

interface GlobalSearchDropdownProps {
  query: string;
  onClose: () => void;
  onSelectPatient?: (patientId: string) => void;
}

export const GlobalSearchDropdown: React.FC<GlobalSearchDropdownProps> = ({
  query,
  onClose,
  onSelectPatient,
}) => {
  const {
    patients = [],
    doctors = [],
    appointments = [],
    emergencyCases = [],
    setActiveNavigation,
    initiateBookingForDoctor,
  } = useHospital();

  const trimmed = query.trim().toLowerCase();

  // Search Patients
  const patientMatches = useMemo(() => {
    if (!trimmed) return [];
    return patients.filter((p) => {
      const name = (p.name || '').toLowerCase();
      const id = (p.id || '').toLowerCase();
      const phone = (p.contact || '').toLowerCase();
      const uhid = (p.uhid || '').toLowerCase();
      const doc = (p.assignedDoctorName || '').toLowerCase();
      const dept = (p.department || '').toLowerCase();
      return (
        name.includes(trimmed) ||
        id.includes(trimmed) ||
        phone.includes(trimmed) ||
        uhid.includes(trimmed) ||
        doc.includes(trimmed) ||
        dept.includes(trimmed)
      );
    }).slice(0, 5);
  }, [patients, trimmed]);

  // Search Doctors
  const doctorMatches = useMemo(() => {
    if (!trimmed) return [];
    return doctors.filter((d) => {
      const name = (d.name || '').toLowerCase();
      const spec = (d.specialization || '').toLowerCase();
      const qual = (d.qualification || '').toLowerCase();
      const room = (d.roomNumber || '').toLowerCase();
      return (
        name.includes(trimmed) ||
        spec.includes(trimmed) ||
        qual.includes(trimmed) ||
        room.includes(trimmed)
      );
    }).slice(0, 5);
  }, [doctors, trimmed]);

  // Search Appointments
  const appointmentMatches = useMemo(() => {
    if (!trimmed) return [];
    return appointments.filter((a) => {
      const id = (a.id || '').toLowerCase();
      const pName = (a.patientName || '').toLowerCase();
      const dName = (a.doctorName || '').toLowerCase();
      const spec = (a.specialization || '').toLowerCase();
      const date = (a.date || '').toLowerCase();
      return (
        id.includes(trimmed) ||
        pName.includes(trimmed) ||
        dName.includes(trimmed) ||
        spec.includes(trimmed) ||
        date.includes(trimmed)
      );
    }).slice(0, 4);
  }, [appointments, trimmed]);

  // Search Emergency Cases
  const emergencyMatches = useMemo(() => {
    if (!trimmed) return [];
    return emergencyCases.filter((e) => {
      const id = (e.id || '').toLowerCase();
      const pName = (e.patientName || '').toLowerCase();
      const priority = (e.priority || '').toLowerCase();
      const complaint = (e.chiefComplaint || '').toLowerCase();
      return (
        id.includes(trimmed) ||
        pName.includes(trimmed) ||
        priority.includes(trimmed) ||
        complaint.includes(trimmed)
      );
    }).slice(0, 4);
  }, [emergencyCases, trimmed]);

  // Search Departments
  const departmentMatches = useMemo(() => {
    if (!trimmed) return [];
    return ALL_SPECIALIZATIONS.filter((spec) => {
      return spec.toLowerCase().includes(trimmed);
    }).slice(0, 4);
  }, [trimmed]);

  const totalMatches =
    patientMatches.length +
    doctorMatches.length +
    appointmentMatches.length +
    emergencyMatches.length +
    departmentMatches.length;

  if (!trimmed) return null;

  return (
    <div
      className="absolute left-0 right-0 top-full mt-2 bg-[rgba(3,10,26,0.95)] backdrop-blur-2xl border border-cyan-500/40 rounded-2xl shadow-[0_20px_50px_rgba(0,0,0,0.8),0_0_30px_rgba(6,182,212,0.2)] overflow-hidden z-50 max-h-[80vh] flex flex-col animate-in fade-in slide-in-from-top-2 duration-150"
      onClick={(e) => e.stopPropagation()}
    >
      {/* Header */}
      <div className="px-4 py-3 border-b border-cyan-500/20 flex items-center justify-between bg-[rgba(6,18,45,0.7)]">
        <div className="flex items-center gap-2">
          <Search className="w-4 h-4 text-cyan-400" />
          <span className="text-xs font-bold text-white">
            Global Hospital Search
          </span>
          <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
            {totalMatches} results for "{query}"
          </span>
        </div>
        <button
          onClick={onClose}
          className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition"
          title="Close search"
        >
          <X className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Content Stream */}
      <div className="overflow-y-auto p-3 space-y-4 divide-y divide-cyan-500/15">
        {totalMatches === 0 && (
          <div className="py-8 text-center text-slate-400">
            <Search className="w-8 h-8 mx-auto text-cyan-500/40 mb-2" />
            <p className="text-xs font-semibold text-white">No hospital records found</p>
            <p className="text-[11px] text-slate-400 mt-1">
              Try searching by patient name, UHID, doctor specialty, or emergency case ID.
            </p>
          </div>
        )}

        {/* 1. PATIENTS */}
        {patientMatches.length > 0 && (
          <div className="pt-2">
            <div className="flex items-center gap-2 mb-2 px-1">
              <User className="w-3.5 h-3.5 text-cyan-400" />
              <span className="text-[11px] font-extrabold uppercase tracking-wider text-cyan-300">
                Patients ({patientMatches.length})
              </span>
            </div>
            <div className="space-y-1.5">
              {patientMatches.map((p) => (
                <div
                  key={p.id}
                  onClick={() => {
                    setActiveNavigation('patients', 'list');
                    if (onSelectPatient) onSelectPatient(p.id);
                    onClose();
                  }}
                  className="p-2.5 rounded-xl bg-[rgba(6,18,45,0.6)] hover:bg-[rgba(10,30,70,0.8)] border border-cyan-500/20 hover:border-cyan-400/50 cursor-pointer transition flex items-center justify-between group"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg bg-cyan-600/30 border border-cyan-500/40 flex items-center justify-center text-white font-extrabold text-xs">
                      {p.name.charAt(0)}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-white group-hover:text-cyan-200 transition">
                          {p.name}
                        </span>
                        <span className="text-[9px] font-mono px-1.5 py-0.2 rounded bg-slate-800 text-slate-300 border border-slate-700">
                          {p.id}
                        </span>
                        <span className="text-[9px] font-bold px-1.5 py-0.2 rounded bg-cyan-500/20 text-cyan-300">
                          {p.bloodGroup}
                        </span>
                      </div>
                      <div className="text-[11px] text-slate-300 mt-0.5 flex items-center gap-2">
                        <span>{p.age} yrs &bull; {p.gender}</span>
                        <span>&bull;</span>
                        <span className="text-cyan-300/90">{p.department || 'General Medicine'}</span>
                        {p.assignedDoctorName && (
                          <span className="hidden sm:inline">&bull; {p.assignedDoctorName}</span>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <span
                      className={`text-[9px] font-bold px-2 py-0.5 rounded-full ${
                        p.currentStatus === 'Admitted'
                          ? 'bg-purple-500/20 text-purple-300 border border-purple-500/40'
                          : p.currentStatus === 'Emergency'
                          ? 'bg-red-500/20 text-red-300 border border-red-500/40 animate-pulse'
                          : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                      }`}
                    >
                      {p.currentStatus}
                    </span>
                    <button
                      className="px-2 py-1 rounded-lg text-[10px] font-bold bg-cyan-500/20 text-cyan-200 hover:bg-cyan-500/40 border border-cyan-500/40 flex items-center gap-1"
                    >
                      <span>Profile</span>
                      <ChevronRight className="w-3 h-3" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* 2. DOCTORS */}
        {doctorMatches.length > 0 && (
          <div className="pt-3">
            <div className="flex items-center gap-2 mb-2 px-1">
              <Stethoscope className="w-3.5 h-3.5 text-blue-400" />
              <span className="text-[11px] font-extrabold uppercase tracking-wider text-blue-300">
                Doctors & Specialists ({doctorMatches.length})
              </span>
            </div>
            <div className="space-y-1.5">
              {doctorMatches.map((d) => (
                <div
                  key={d.id}
                  className="p-2.5 rounded-xl bg-[rgba(6,18,45,0.6)] hover:bg-[rgba(10,30,70,0.8)] border border-cyan-500/20 hover:border-cyan-400/50 transition flex items-center justify-between group"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg bg-blue-600/30 border border-blue-500/40 flex items-center justify-center text-white font-extrabold text-xs">
                      {d.name.replace('Dr. ', '').charAt(0)}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-white group-hover:text-cyan-200 transition">
                          {d.name}
                        </span>
                        <span className="text-[10px] text-cyan-300 font-bold">
                          {d.specialization}
                        </span>
                      </div>
                      <div className="text-[11px] text-slate-300 mt-0.5 flex items-center gap-2 font-mono">
                        <span>Room: {d.roomNumber || 'OPD'}</span>
                        <span>&bull;</span>
                        <span>Fee: ₹{d.consultationFee || 800}</span>
                        <span>&bull;</span>
                        <span>{d.experienceYears} yrs exp</span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <span
                      className={`text-[9px] font-bold px-2 py-0.5 rounded-full ${
                        d.status === 'Available'
                          ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                          : d.status === 'In Consultation'
                          ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 animate-pulse'
                          : 'bg-slate-800 text-slate-300 border border-slate-700'
                      }`}
                    >
                      {d.status}
                    </span>
                    <button
                      onClick={() => {
                        initiateBookingForDoctor(d);
                        onClose();
                      }}
                      className="px-2.5 py-1 rounded-lg text-[10px] font-extrabold glass-btn text-white transition flex items-center gap-1"
                    >
                      <span>Book</span>
                      <Calendar className="w-3 h-3" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* 3. APPOINTMENTS */}
        {appointmentMatches.length > 0 && (
          <div className="pt-3">
            <div className="flex items-center gap-2 mb-2 px-1">
              <Calendar className="w-3.5 h-3.5 text-indigo-400" />
              <span className="text-[11px] font-extrabold uppercase tracking-wider text-indigo-300">
                Appointments ({appointmentMatches.length})
              </span>
            </div>
            <div className="space-y-1.5">
              {appointmentMatches.map((a) => (
                <div
                  key={a.id}
                  onClick={() => {
                    setActiveNavigation('appointments', 'today');
                    onClose();
                  }}
                  className="p-2.5 rounded-xl bg-[rgba(6,18,45,0.6)] hover:bg-[rgba(10,30,70,0.8)] border border-cyan-500/20 hover:border-cyan-400/50 cursor-pointer transition flex items-center justify-between group"
                >
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-white group-hover:text-cyan-200">
                        {a.patientName} &rarr; {a.doctorName}
                      </span>
                      <span className="text-[9px] font-mono px-1.5 py-0.2 rounded bg-slate-800 text-slate-300 border border-slate-700">
                        {a.id}
                      </span>
                    </div>
                    <div className="text-[11px] text-slate-300 mt-0.5 flex items-center gap-2 font-mono">
                      <span>{a.date}</span>
                      <span>&bull;</span>
                      <span className="text-cyan-300 font-bold">{a.timeSlot}</span>
                      <span>&bull;</span>
                      <span>{a.appointmentType}</span>
                    </div>
                  </div>

                  <span
                    className={`text-[9px] font-bold px-2 py-0.5 rounded-full ${
                      a.status === 'Confirmed'
                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                        : a.status === 'Waiting'
                        ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                        : a.status === 'Completed'
                        ? 'bg-slate-800 text-slate-300 border border-slate-700'
                        : 'bg-red-500/20 text-red-300 border border-red-500/40'
                    }`}
                  >
                    {a.status}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* 4. EMERGENCY CASES */}
        {emergencyMatches.length > 0 && (
          <div className="pt-3">
            <div className="flex items-center gap-2 mb-2 px-1">
              <Flame className="w-3.5 h-3.5 text-red-400" />
              <span className="text-[11px] font-extrabold uppercase tracking-wider text-red-300">
                Emergency Priority Cases ({emergencyMatches.length})
              </span>
            </div>
            <div className="space-y-1.5">
              {emergencyMatches.map((e) => (
                <div
                  key={e.id}
                  onClick={() => {
                    setActiveNavigation('emergency', 'queue');
                    onClose();
                  }}
                  className="p-2.5 rounded-xl bg-[rgba(20,5,10,0.6)] hover:bg-[rgba(40,10,20,0.8)] border border-red-500/30 hover:border-red-400/60 cursor-pointer transition flex items-center justify-between group"
                >
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-white group-hover:text-red-200">
                        {e.patientName}
                      </span>
                      <span className="text-[9px] font-mono px-1.5 py-0.2 rounded bg-slate-800 text-slate-300 border border-slate-700">
                        {e.id}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-300 mt-0.5 line-clamp-1">
                      {e.chiefComplaint || 'Acute clinical presentation'}
                    </p>
                  </div>

                  <span
                    className={`text-[9px] font-extrabold px-2.5 py-0.5 rounded-full uppercase tracking-wider ${
                      e.priority === 'Critical'
                        ? 'bg-red-500/25 text-red-300 border border-red-500/50 animate-pulse'
                        : e.priority === 'High'
                        ? 'bg-amber-500/25 text-amber-300 border border-amber-500/50'
                        : 'bg-cyan-500/25 text-cyan-300 border border-cyan-500/50'
                    }`}
                  >
                    {e.priority}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* 5. DEPARTMENTS */}
        {departmentMatches.length > 0 && (
          <div className="pt-3">
            <div className="flex items-center gap-2 mb-2 px-1">
              <Building2 className="w-3.5 h-3.5 text-purple-400" />
              <span className="text-[11px] font-extrabold uppercase tracking-wider text-purple-300">
                Departments & Centers ({departmentMatches.length})
              </span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {departmentMatches.map((dept) => {
                const count = doctors.filter((d) => d.specialization === dept).length;
                return (
                  <div
                    key={dept}
                    onClick={() => {
                      setActiveNavigation('doctors', 'directory');
                      onClose();
                    }}
                    className="p-2 rounded-xl bg-[rgba(6,18,45,0.6)] hover:bg-[rgba(10,30,70,0.8)] border border-cyan-500/20 hover:border-cyan-400/50 cursor-pointer transition flex items-center justify-between group"
                  >
                    <span className="text-xs font-bold text-white group-hover:text-cyan-200">
                      {dept}
                    </span>
                    <span className="text-[10px] font-mono text-cyan-300">
                      {count} specialists
                    </span>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>

      {/* Footer */}
      <div className="px-4 py-2 border-t border-cyan-500/20 bg-[rgba(6,18,45,0.9)] flex items-center justify-between text-[11px] text-slate-400">
        <span>Press <strong className="text-cyan-300">ESC</strong> to exit search</span>
        <span>Click any record to navigate immediately</span>
      </div>
    </div>
  );
};
