import React from 'react';
import { Activity } from 'lucide-react';

interface LoadingStateProps {
  message?: string;
  subtext?: string;
}

export const LoadingState: React.FC<LoadingStateProps> = ({
  message = 'Synchronizing Clinical Telemetry...',
  subtext = 'Connecting to real-time hospital management nodes',
}) => {
  return (
    <div className="w-full min-h-[400px] flex flex-col items-center justify-center p-8 rounded-3xl bg-slate-900/60 border border-cyan-500/20 backdrop-blur-xl animate-in fade-in duration-300">
      <div className="relative mb-6">
        {/* Outer glowing pulse ring */}
        <div className="w-16 h-16 rounded-2xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400 shadow-xl shadow-cyan-500/10 animate-pulse">
          <Activity className="w-8 h-8 text-cyan-400" />
        </div>
        <div className="absolute -top-1 -right-1 w-3 h-3 rounded-full bg-cyan-400 animate-ping" />
      </div>

      <h3 className="text-base font-bold text-white tracking-tight">{message}</h3>
      <p className="text-xs text-slate-400 mt-1 max-w-sm text-center">{subtext}</p>

      {/* Dark Futuristic Skeleton Cards Preview */}
      <div className="w-full max-w-lg mt-8 space-y-3">
        <div className="h-4 w-3/4 rounded-lg bg-slate-800/60 animate-pulse" />
        <div className="h-10 w-full rounded-xl bg-slate-800/40 animate-pulse" />
        <div className="grid grid-cols-3 gap-3 pt-2">
          <div className="h-16 rounded-xl bg-slate-800/30 animate-pulse" />
          <div className="h-16 rounded-xl bg-slate-800/30 animate-pulse" />
          <div className="h-16 rounded-xl bg-slate-800/30 animate-pulse" />
        </div>
      </div>
    </div>
  );
};
