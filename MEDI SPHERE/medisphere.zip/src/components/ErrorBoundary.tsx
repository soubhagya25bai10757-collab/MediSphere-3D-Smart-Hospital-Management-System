import React, { Component, ErrorInfo, ReactNode } from 'react';
import { AlertTriangle, RefreshCw, Home, Activity } from 'lucide-react';

interface ErrorBoundaryProps {
  children: ReactNode;
  fallbackTitle?: string;
  onReset?: () => void;
  showHomeButton?: boolean;
}

interface ErrorBoundaryState {
  hasError: boolean;
  error: Error | null;
}

export class ErrorBoundary extends Component<ErrorBoundaryProps, ErrorBoundaryState> {
  constructor(props: ErrorBoundaryProps) {
    super(props);
    this.state = {
      hasError: false,
      error: null,
    };
  }

  static getDerivedStateFromError(error: Error): ErrorBoundaryState {
    return {
      hasError: true,
      error,
    };
  }

  componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('MediSphere 3D UI Error caught by boundary:', error, errorInfo);
  }

  handleRetry = () => {
    if (this.props.onReset) {
      this.props.onReset();
    }
    this.setState({
      hasError: false,
      error: null,
    });
  };

  handleGoHome = () => {
    window.location.href = '/';
  };

  render() {
    if (this.state.hasError) {
      const sectionTitle = this.props.fallbackTitle || 'this module';
      const isLanding = sectionTitle.toLowerCase().includes('landing');

      if (isLanding) {
        return (
          <div className="min-h-screen w-full bg-slate-950 text-slate-100 flex items-center justify-center p-4 selection:bg-cyan-500/30 selection:text-cyan-200">
            <div className="w-full max-w-md p-8 sm:p-10 rounded-3xl bg-slate-900/90 border border-cyan-500/30 backdrop-blur-2xl text-slate-100 shadow-2xl flex flex-col items-center justify-center text-center animate-in fade-in">
              <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-cyan-500 via-blue-600 to-indigo-600 p-[1.5px] shadow-lg shadow-cyan-500/25 mb-4">
                <div className="w-full h-full bg-slate-950 rounded-[14px] flex items-center justify-center">
                  <Activity className="w-8 h-8 text-cyan-400 animate-pulse" />
                </div>
              </div>

              <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
                MediSphere 3D
              </h2>

              <p className="text-sm font-medium text-slate-300 mt-2 mb-6">
                Unable to load the landing page.
              </p>

              <button
                onClick={this.handleRetry}
                className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white text-xs sm:text-sm font-bold transition flex items-center gap-2 shadow-lg shadow-cyan-500/20 active:scale-95"
              >
                <RefreshCw className="w-4 h-4" />
                <span>Retry</span>
              </button>
            </div>
          </div>
        );
      }

      return (
        <div className="w-full p-6 sm:p-8 rounded-3xl bg-slate-900/85 border border-red-500/30 backdrop-blur-2xl text-slate-100 shadow-2xl flex flex-col items-center justify-center text-center my-6 min-h-[300px] animate-in fade-in">
          <div className="w-14 h-14 rounded-2xl bg-red-500/10 border border-red-500/30 flex items-center justify-center text-red-400 mb-4 shadow-lg shadow-red-500/10">
            <AlertTriangle className="w-7 h-7 animate-pulse" />
          </div>

          <h3 className="text-xl font-black text-white tracking-tight">
            Unable to load {sectionTitle}
          </h3>

          <p className="text-xs sm:text-sm text-slate-400 mt-2 max-w-md leading-relaxed">
            A temporary rendering condition occurred. Your application navigation and telemetry remain fully operational.
          </p>

          {this.state.error?.message && (
            <div className="mt-4 px-4 py-2 rounded-xl bg-slate-950/80 border border-slate-800 text-[11px] font-mono text-slate-400 max-w-lg truncate">
              {this.state.error.message}
            </div>
          )}

          <div className="mt-6 flex flex-wrap items-center justify-center gap-3">
            <button
              onClick={this.handleRetry}
              className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white text-xs font-bold transition flex items-center gap-2 shadow-lg shadow-cyan-500/20 active:scale-95"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Retry Component</span>
            </button>

            {this.props.showHomeButton && (
              <button
                onClick={this.handleGoHome}
                className="px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold transition flex items-center gap-2 active:scale-95"
              >
                <Home className="w-3.5 h-3.5" />
                <span>Return to Home</span>
              </button>
            )}
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
