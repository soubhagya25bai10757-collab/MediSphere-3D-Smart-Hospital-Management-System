import React from 'react';
import { useHospital } from '../context/HospitalContext';
import {
  CheckCircle2,
  AlertCircle,
  Info,
  AlertTriangle,
  X,
  Code2,
} from 'lucide-react';

export const ToastContainer: React.FC = () => {
  const { toasts, removeToast } = useHospital();

  if (toasts.length === 0) return null;

  return (
    <div className="fixed bottom-5 right-5 z-50 flex flex-col gap-2.5 max-w-sm w-full pointer-events-none">
      {toasts.map((toast) => {
        const isError = toast.type === 'error';
        const isSuccess = toast.type === 'success';
        const isWarning = toast.type === 'warning';

        return (
          <div
            key={toast.id}
            className={`pointer-events-auto p-4 rounded-2xl border backdrop-blur-xl shadow-2xl transition-all animate-in slide-in-from-bottom-3 duration-300 ${
              isError
                ? 'bg-slate-900/95 border-red-500/40 shadow-red-500/10'
                : isSuccess
                ? 'bg-slate-900/95 border-emerald-500/40 shadow-emerald-500/10'
                : isWarning
                ? 'bg-slate-900/95 border-amber-500/40 shadow-amber-500/10'
                : 'bg-slate-900/95 border-cyan-500/40 shadow-cyan-500/10'
            }`}
          >
            <div className="flex items-start justify-between gap-2.5">
              <div className="flex items-start gap-3">
                <div className="mt-0.5">
                  {isError && <AlertCircle className="w-5 h-5 text-red-400" />}
                  {isSuccess && <CheckCircle2 className="w-5 h-5 text-emerald-400" />}
                  {isWarning && <AlertTriangle className="w-5 h-5 text-amber-400" />}
                  {!isError && !isSuccess && !isWarning && <Info className="w-5 h-5 text-cyan-400" />}
                </div>
                <div>
                  <h4 className="text-xs font-bold text-white tracking-wide">{toast.title}</h4>
                  <p className="text-xs text-slate-300 mt-0.5 leading-relaxed">{toast.message}</p>

                  {toast.javaExceptionClass && (
                    <div className="mt-2 inline-flex items-center gap-1.5 px-2 py-0.5 rounded bg-red-950/70 border border-red-500/30 text-[10px] font-mono text-red-300">
                      <Code2 className="w-3 h-3 text-red-400" />
                      <span>{toast.javaExceptionClass}</span>
                    </div>
                  )}
                </div>
              </div>

              <button
                onClick={() => removeToast(toast.id)}
                className="text-slate-400 hover:text-white p-1 rounded-lg transition"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>
        );
      })}
    </div>
  );
};
