import React, { useState } from 'react';
import {
  X,
  Play,
  Pause,
  RotateCcw,
  CheckCircle2,
  Activity,
  Flame,
  ShieldCheck,
  Building2,
  Layers,
  Sparkles,
  ArrowRight,
} from 'lucide-react';
import { useHospital } from '../context/HospitalContext';

interface WatchDemoModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const WatchDemoModal: React.FC<WatchDemoModalProps> = ({ isOpen, onClose }) => {
  const { setShowLandingPage, navigateToSection } = useHospital();
  const [activeStep, setActiveStep] = useState(0);
  const [isPlaying, setIsPlaying] = useState(true);

  if (!isOpen) return null;

  const demoSteps = [
    {
      title: '3D Campus Digital Twin',
      subtitle: 'Real-Time WebGL Architectural Telemetry',
      badge: 'Level 1: 3D Visualization',
      description:
        'Explore the unified hospital complex in interactive 3D space with high-precision PBR materials, rotating helipads, active trauma ambulance docks, and floating holographic status tags connected to each medical wing.',
      metrics: [
        { label: 'Campus Wings', val: '8 Active Zones' },
        { label: 'Frame Rate', val: '60 FPS WebGL' },
        { label: 'PBR Shaders', val: 'Transmission & Glow' },
      ],
      actionLabel: 'Explore 3D Complex',
      onAction: () => {
        onClose();
        setShowLandingPage(false);
        navigateToSection('dashboard');
      },
    },
    {
      title: 'Emergency Algorithmic Triage',
      subtitle: 'Resuscitation Response with Zero Delay',
      badge: 'Level 2: Critical Care',
      description:
        'Witness emergency patient sorting powered by an automated algorithmic model. Vital urgency scores automatically elevate critical cardiac and trauma cases above routine screening.',
      metrics: [
        { label: 'Active Triages', val: '7 Patients' },
        { label: 'Critical Readiness', val: '100% On-Call' },
        { label: 'Mean Response', val: '< 90 Seconds' },
      ],
      actionLabel: 'Open Emergency Bay',
      onAction: () => {
        onClose();
        setShowLandingPage(false);
        navigateToSection('emergency');
      },
    },
    {
      title: 'System Performance & Resource Monitor',
      subtitle: 'Multithreaded Enterprise Reliability',
      badge: 'Level 3: Operations',
      description:
        'Inspect background telemetry, monitor real-time worker execution, trace subsystem synchronization, and verify seamless coordination across all hospital operating wards.',
      metrics: [
        { label: 'Active Workers', val: '7 Background Workers' },
        { label: 'Concurrency Engine', val: 'Async Task Pool' },
        { label: 'State Sync', val: 'Real-time Synchronized' },
      ],
      actionLabel: 'Inspect Monitor',
      onAction: () => {
        onClose();
        setShowLandingPage(false);
        navigateToSection('threads');
      },
    },
    {
      title: 'Smart Pharmacy & Diagnostic Lab',
      subtitle: 'Automated Formulary & Specimen Queues',
      badge: 'Level 4: Diagnostics',
      description:
        'Track multi-sample bio-assay processing through robotic pipetting pipelines while maintaining atomic formulary inventory with automated low-stock reorder thresholds.',
      metrics: [
        { label: 'Pending Lab Tests', val: '14 Assays' },
        { label: 'Formulary Items', val: '450+ SKU Units' },
        { label: 'Barcoded Dispensing', val: '100% Traceability' },
      ],
      actionLabel: 'View Pharmacy & Lab',
      onAction: () => {
        onClose();
        setShowLandingPage(false);
        navigateToSection('pharmacy');
      },
    },
  ];

  const currentStep = demoSteps[activeStep];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-slate-950/85 backdrop-blur-2xl animate-in fade-in duration-200">
      <div className="relative w-full max-w-4xl rounded-3xl bg-gradient-to-b from-slate-900 via-slate-950 to-slate-900 border border-cyan-500/40 shadow-2xl shadow-cyan-500/20 overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-cyan-500/20 bg-slate-950/60">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-xl bg-cyan-500/20 border border-cyan-500/40 flex items-center justify-center text-cyan-400">
              <Play className="w-4 h-4 fill-cyan-400" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-sm font-bold text-white tracking-wide">
                  MediSphere 3D &bull; System Walkthrough
                </span>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                  Interactive Showcase
                </span>
              </div>
              <span className="text-[10px] text-slate-400">
                Architectural Demonstration of the Smart Hospital Platform
              </span>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Video Simulator / Interactive Stage */}
        <div className="p-6 overflow-y-auto flex-1 flex flex-col gap-6">
          <div className="relative rounded-2xl bg-gradient-to-tr from-slate-950 via-slate-900 to-slate-950 border border-cyan-500/30 p-6 shadow-inner overflow-hidden">
            {/* Ambient scanner effect */}
            <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-cyan-500/10 via-transparent to-transparent pointer-events-none" />

            <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 mb-6">
              <div>
                <span className="text-[10px] uppercase font-bold tracking-widest text-cyan-400 block mb-1">
                  {currentStep.badge}
                </span>
                <h3 className="text-2xl font-black text-white tracking-tight">
                  {currentStep.title}
                </h3>
                <p className="text-xs text-slate-400 mt-1">{currentStep.subtitle}</p>
              </div>

              {/* Progress Stepper pills */}
              <div className="flex items-center gap-1.5 p-1 rounded-xl bg-slate-950 border border-slate-800">
                {demoSteps.map((s, idx) => (
                  <button
                    key={idx}
                    onClick={() => setActiveStep(idx)}
                    className={`px-3 py-1 rounded-lg text-xs font-semibold transition ${
                      activeStep === idx
                        ? 'bg-cyan-500/25 text-cyan-300 border border-cyan-500/50 shadow-md'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    0{idx + 1}
                  </button>
                ))}
              </div>
            </div>

            <p className="text-sm text-slate-300 leading-relaxed max-w-2xl">
              {currentStep.description}
            </p>

            {/* Metrics HUD Row */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mt-6">
              {currentStep.metrics.map((m, idx) => (
                <div
                  key={idx}
                  className="p-3.5 rounded-xl bg-slate-950/80 border border-cyan-500/20 backdrop-blur-md"
                >
                  <span className="text-[10px] uppercase text-slate-400 font-semibold block">
                    {m.label}
                  </span>
                  <span className="text-sm font-black text-cyan-300 mt-1 block">
                    {m.val}
                  </span>
                </div>
              ))}
            </div>

            {/* Action Bar */}
            <div className="flex flex-wrap items-center justify-between gap-3 mt-6 pt-4 border-t border-slate-800">
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setActiveStep((prev) => (prev > 0 ? prev - 1 : demoSteps.length - 1))}
                  className="px-3 py-1.5 rounded-lg bg-slate-950 border border-slate-800 text-xs text-slate-300 hover:text-white transition"
                >
                  &larr; Previous Tour
                </button>
                <button
                  onClick={() => setActiveStep((prev) => (prev < demoSteps.length - 1 ? prev + 1 : 0))}
                  className="px-3 py-1.5 rounded-lg bg-slate-950 border border-slate-800 text-xs text-slate-300 hover:text-white transition"
                >
                  Next Tour &rarr;
                </button>
              </div>

              <button
                onClick={currentStep.onAction}
                className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white text-xs font-bold transition shadow-lg shadow-cyan-500/25 flex items-center gap-2"
              >
                {currentStep.actionLabel}
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
