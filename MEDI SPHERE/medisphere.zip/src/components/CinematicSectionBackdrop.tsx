import React from 'react';
import { useHospital } from '../context/HospitalContext';
import { HOSPITAL_BACKGROUNDS, SectionBackgroundMeta } from '../assets/backgrounds';

export const CinematicSectionBackdrop: React.FC = () => {
  const { activeMainTab } = useHospital();

  // Normalize mapping to background meta
  const bgKey =
    activeMainTab === 'analytics'
      ? 'analytics'
      : activeMainTab === 'operations'
      ? 'operations'
      : activeMainTab in HOSPITAL_BACKGROUNDS
      ? activeMainTab
      : 'dashboard';

  const currentBg: SectionBackgroundMeta =
    HOSPITAL_BACKGROUNDS[bgKey] || HOSPITAL_BACKGROUNDS.dashboard;

  // Module-specific ambient accent glow
  const getAmbientTone = () => {
    switch (activeMainTab) {
      case 'emergency':
        return {
          glowColor: 'rgba(239, 68, 68, 0.14)',
          glowPosition: '75% 20%',
          pulseClass: 'text-red-500/20',
          accentBorder: 'rgba(239, 68, 68, 0.2)',
        };
      case 'patients':
        return {
          glowColor: 'rgba(6, 182, 212, 0.12)',
          glowPosition: '60% 30%',
          pulseClass: 'text-cyan-400/20',
          accentBorder: 'rgba(6, 182, 212, 0.2)',
        };
      case 'doctors':
        return {
          glowColor: 'rgba(59, 130, 246, 0.12)',
          glowPosition: '70% 35%',
          pulseClass: 'text-blue-400/20',
          accentBorder: 'rgba(59, 130, 246, 0.2)',
        };
      case 'appointments':
        return {
          glowColor: 'rgba(14, 165, 233, 0.12)',
          glowPosition: '50% 25%',
          pulseClass: 'text-sky-400/20',
          accentBorder: 'rgba(14, 165, 233, 0.2)',
        };
      case 'operations':
        return {
          glowColor: 'rgba(168, 85, 247, 0.11)',
          glowPosition: '65% 40%',
          pulseClass: 'text-purple-400/20',
          accentBorder: 'rgba(168, 85, 247, 0.2)',
        };
      case 'analytics':
        return {
          glowColor: 'rgba(16, 185, 129, 0.11)',
          glowPosition: '80% 30%',
          pulseClass: 'text-emerald-400/20',
          accentBorder: 'rgba(16, 185, 129, 0.2)',
        };
      default:
        return {
          glowColor: 'rgba(6, 182, 212, 0.14)',
          glowPosition: '70% 30%',
          pulseClass: 'text-cyan-400/20',
          accentBorder: 'rgba(6, 182, 212, 0.2)',
        };
    }
  };

  const ambient = getAmbientTone();

  return (
    <div
      id="cinematic-hospital-backdrop"
      className="fixed inset-0 z-0 overflow-hidden pointer-events-none select-none"
      aria-hidden="true"
    >
      {/* 1. Full-Viewport High-Definition Medical Environment Image */}
      <img
        key={currentBg.id}
        src={currentBg.src}
        alt={currentBg.name}
        referrerPolicy="no-referrer"
        className="w-full h-full object-cover object-center transition-opacity duration-1000 ease-in-out opacity-75 transform scale-100"
      />

      {/* 2. Uniform Balanced Deep Midnight Navy Tint: 40-50% visibility across edge-to-edge */}
      <div className="absolute inset-0 bg-gradient-to-b from-[#020617]/72 via-[#03091e]/58 to-[#020617]/78 transition-all duration-700" />

      {/* 3. Subtle Module-Specific Ambient Light Source (Pulsing Glow) */}
      <div
        className="absolute inset-0 animate-ambient-pulse"
        style={{
          background: `radial-gradient(circle at ${ambient.glowPosition}, ${ambient.glowColor} 0%, transparent 65%)`,
        }}
      />

      {/* 4. Delicate Holographic Telemetry Grid Lines (Ultra-lightweight SVG) */}
      <svg
        className="absolute inset-0 w-full h-full opacity-[0.07] pointer-events-none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <defs>
          <pattern
            id="medical-grid-pattern"
            width="60"
            height="60"
            patternUnits="userSpaceOnUse"
          >
            <path
              d="M 60 0 L 0 0 0 60"
              fill="none"
              stroke="#00e5ff"
              strokeWidth="0.75"
            />
            <circle cx="60" cy="0" r="1.5" fill="#00e5ff" />
          </pattern>
        </defs>
        <rect width="100%" height="100%" fill="url(#medical-grid-pattern)" />
      </svg>

      {/* 5. Subtle Distant Hospital Telemetry Particle Nodes (Gentle Drift) */}
      <div className="absolute inset-0 animate-slow-drift opacity-60">
        <div className="absolute top-[18%] left-[22%] w-1.5 h-1.5 rounded-full bg-cyan-400/40 blur-[0.5px]" />
        <div className="absolute top-[35%] right-[15%] w-2 h-2 rounded-full bg-cyan-300/35 blur-[1px]" />
        <div className="absolute top-[62%] left-[12%] w-1.5 h-1.5 rounded-full bg-blue-400/30 blur-[0.5px]" />
        <div className="absolute top-[78%] right-[28%] w-2 h-2 rounded-full bg-indigo-400/35 blur-[1px]" />
        {activeMainTab === 'emergency' && (
          <div className="absolute top-[25%] right-[22%] w-2.5 h-2.5 rounded-full bg-red-500/45 blur-[1px] animate-pulse" />
        )}
      </div>

      {/* 6. Subtle Perimeter Vignette for Frame Polish (Preserving Edge-to-Edge Visibility) */}
      <div className="absolute inset-0 bg-gradient-to-t from-[#020617]/50 via-transparent to-[#020617]/35 pointer-events-none" />
    </div>
  );
};

