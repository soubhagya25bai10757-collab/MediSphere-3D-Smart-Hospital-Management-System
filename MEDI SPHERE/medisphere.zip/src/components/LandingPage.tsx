import React, { useState, useEffect } from 'react';
import { useHospital } from '../context/HospitalContext';
import { HolographicHuman } from './HolographicHuman';
import { SystemHealthCard } from './SystemHealthCard';
import medisphereHeroBg from '../assets/images/medisphere_hero_bg_1789138701890.jpg';
import {
  Activity,
  Flame,
  Calendar,
  Microscope,
  BarChart3,
  ShieldCheck,
  Sparkles,
  ArrowRight,
  User,
  Stethoscope,
  Clock,
  Zap,
} from 'lucide-react';

export const LandingPage: React.FC = () => {
  const { setShowLandingPage } = useHospital();
  const [isEnlarged, setIsEnlarged] = useState(false);

  // Close enlarged mode on ESC key press
  useEffect(() => {
    if (!isEnlarged) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setIsEnlarged(false);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [isEnlarged]);

  // Lock background scroll when enlarged
  useEffect(() => {
    if (isEnlarged) {
      const originalOverflow = document.body.style.overflow;
      document.body.style.overflow = 'hidden';
      return () => {
        document.body.style.overflow = originalOverflow;
      };
    }
  }, [isEnlarged]);

  const handleExplore = () => {
    setShowLandingPage(false);
  };

  const features = [
    {
      icon: Activity,
      title: 'Smart Hospital Operations',
      description:
        'Integrated digital platform orchestrating admissions, bed allocations, and clinical workflows across all wings.',
      color: 'from-cyan-500/20 to-blue-500/10',
      border: 'border-cyan-500/30',
      badge: 'Hospital Core',
    },
    {
      icon: Flame,
      title: 'Emergency Management',
      description:
        'Algorithmic real-time triage prioritizing Critical, High, Medium, and Low cases with automated physician dispatch.',
      color: 'from-red-500/20 to-orange-500/10',
      border: 'border-red-500/30',
      badge: 'Real-Time Triage',
    },
    {
      icon: Calendar,
      title: 'Appointment Intelligence',
      description:
        'Zero-conflict multi-specialty scheduling across 25 medical domains with automated conflict detection and timeline visualization.',
      color: 'from-blue-500/20 to-indigo-500/10',
      border: 'border-blue-500/30',
      badge: 'Smart Scheduling',
    },
    {
      icon: Microscope,
      title: 'Laboratory & Pharmacy',
      description:
        'Automated specimen processing pipelines paired with robotic formulary inventory tracking and low-stock alerts.',
      color: 'from-purple-500/20 to-pink-500/10',
      border: 'border-purple-500/30',
      badge: 'High Throughput',
    },
    {
      icon: BarChart3,
      title: 'Real-Time Analytics',
      description:
        'Operational clinical telemetry, bed occupancy rates, doctor workloads, and financial metrics in Indian Rupees.',
      color: 'from-emerald-500/20 to-teal-500/10',
      border: 'border-emerald-500/30',
      badge: 'Clinical Telemetry',
    },
    {
      icon: ShieldCheck,
      title: 'Secure Role-Based Access',
      description:
        'Strict security boundaries tailored for Administrators, Doctors, Receptionists, Lab Technicians, and Pharmacists.',
      color: 'from-amber-500/20 to-yellow-500/10',
      border: 'border-amber-500/30',
      badge: 'RBAC Security',
    },
  ];

  return (
    <div className="min-h-screen bg-[#030814] text-slate-100 selection:bg-cyan-500 selection:text-black font-sans relative overflow-x-hidden">
      {/* Ultra-Premium Cinematic Ambient Background */}
      <div className="fixed inset-0 z-0 pointer-events-none overflow-hidden select-none">
        <img
          src={medisphereHeroBg}
          alt="MediSphere 3D Cinematic Futuristic Medical Atmosphere"
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover object-center opacity-85 scale-100"
        />
        {/* Soft volumetric gradients & deep midnight vignette maintaining clean UI readability */}
        <div className="absolute inset-0 bg-gradient-to-b from-[#030814]/75 via-[#030814]/40 to-[#030814]/90" />
        <div className="absolute inset-0 bg-gradient-to-r from-[#030814]/90 via-[#030814]/65 to-transparent" />
        {/* Extra shadow protection for the center-left text reading zone */}
        <div className="absolute top-0 left-0 w-full sm:w-2/3 h-full bg-gradient-to-r from-[#030814]/90 via-[#030814]/60 to-transparent" />
      </div>

      {/* Background Subtle Electric Ambience */}
      <div className="absolute top-0 left-1/4 w-[600px] h-[500px] bg-gradient-to-b from-cyan-500/10 via-blue-600/5 to-transparent rounded-full blur-[120px] pointer-events-none z-[1]" />
      <div className="absolute top-1/3 right-10 w-[500px] h-[500px] bg-gradient-to-b from-blue-600/10 via-indigo-600/5 to-transparent rounded-full blur-[140px] pointer-events-none z-[1]" />

      {/* TOP NAVIGATION: Transparent Glass Navigation Bar */}
      <header className="fixed top-0 left-0 right-0 z-50 h-20 border-b border-cyan-500/20 bg-slate-950/85 backdrop-blur-2xl px-4 sm:px-6 lg:px-8 flex items-center">
        <div className="max-w-7xl w-full mx-auto flex items-center justify-between">
          {/* LEFT: Medical cross logo + MediSphere 3D */}
          <div
            onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
            className="flex items-center gap-3 cursor-pointer group"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-cyan-500 via-sky-400 to-blue-600 p-[1.5px] shadow-lg shadow-cyan-500/25 transition-transform group-hover:scale-105">
              <div className="w-full h-full bg-slate-950 rounded-[10px] flex items-center justify-center">
                <Activity className="w-5 h-5 text-cyan-400 animate-pulse" />
              </div>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xl font-black tracking-tight text-white">MediSphere</span>
                <span className="text-xs font-black px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/40">
                  3D
                </span>
              </div>
              <span className="text-[10px] text-slate-400 block tracking-widest uppercase font-semibold">
                Smart Hospital Management System
              </span>
            </div>
          </div>

          {/* RIGHT: Primary Action - Explore System */}
          <div className="flex items-center">
            <button
              onClick={handleExplore}
              className="px-5 py-2.5 sm:px-6 sm:py-2.5 rounded-xl text-xs sm:text-sm font-bold text-white bg-gradient-to-r from-cyan-500 via-sky-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 transition shadow-lg shadow-cyan-500/30 flex items-center gap-2 hover:shadow-cyan-400/40 hover:scale-[1.02] active:scale-[0.98] border border-cyan-400/20 whitespace-nowrap"
            >
              <span>Explore System</span>
              <ArrowRight className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
            </button>
          </div>
        </div>
      </header>

      {/* FULL-SCREEN CINEMATIC HERO SECTION */}
      <section className="relative pt-24 pb-14 sm:pt-28 sm:pb-16 lg:pt-28 lg:pb-18 flex flex-col justify-center overflow-hidden border-b border-cyan-500/10">
        {/* Subtle Ambient Electric Glows */}
        <div className="absolute top-1/4 left-10 w-96 h-96 bg-cyan-500/10 rounded-full blur-[120px] pointer-events-none" />
        <div className="absolute top-1/3 right-10 w-96 h-96 bg-blue-600/10 rounded-full blur-[140px] pointer-events-none" />

        <div className="relative z-10 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-8 xl:gap-12 items-center">
            {/* LEFT COLUMN: ~40% on Desktop (lg:col-span-5) */}
            <div className="lg:col-span-5 w-full flex flex-col items-start text-left">
              {/* Small glowing badge */}
              <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-slate-900/90 border border-cyan-500/40 backdrop-blur-md mb-5 shadow-lg shadow-cyan-500/10">
                <Sparkles className="w-3.5 h-3.5 text-cyan-400 animate-pulse" />
                <span className="text-[10px] sm:text-[11px] font-black text-cyan-300 tracking-wider uppercase">
                  NEXT GENERATION HOSPITAL MANAGEMENT
                </span>
              </div>

              {/* Large headline */}
              <h1 className="text-4xl sm:text-5xl xl:text-6xl font-black text-white tracking-tight leading-[1.08]">
                MediSphere{' '}
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-sky-300 to-blue-500">
                  3D
                </span>
              </h1>

              {/* Tagline */}
              <p className="text-lg sm:text-xl font-bold text-slate-200 mt-3 tracking-tight">
                Intelligent Hospital Management, Reimagined.
              </p>

              {/* Description */}
              <p className="text-xs sm:text-sm text-slate-300 mt-3 font-normal leading-relaxed max-w-lg">
                A unified platform for patients, doctors, appointments, emergency care, diagnostics,
                pharmacy, beds and hospital operations.
              </p>

              {/* Primary Action Button: Explore System */}
              <div className="flex items-center mt-6">
                <button
                  onClick={handleExplore}
                  className="px-6 py-3.5 rounded-xl text-xs sm:text-sm font-bold text-white bg-gradient-to-r from-cyan-500 via-sky-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 transition shadow-lg shadow-cyan-500/25 flex items-center gap-2.5 group active:scale-95 whitespace-nowrap border border-cyan-400/20 hover:shadow-cyan-400/40"
                >
                  <span>Explore System</span>
                  <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </button>
              </div>

              {/* LIVE HOSPITAL STATS: Live Campus Telemetry Card */}
              <div className="w-full mt-6 p-4 sm:p-5 rounded-2xl bg-slate-950/85 border border-cyan-500/25 backdrop-blur-xl shadow-xl shadow-cyan-950/50">
                <div className="flex items-center justify-between pb-2.5 mb-3 border-b border-slate-800/80">
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                    <span className="text-[10px] font-mono text-cyan-300 uppercase tracking-widest font-bold">
                      Live Campus Telemetry
                    </span>
                  </div>
                  <span className="text-[9px] font-mono text-slate-400">
                    REAL-TIME SYNCHRONIZED
                  </span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  {/* Patients */}
                  <div className="flex flex-col">
                    <div className="flex items-center gap-1.5 text-cyan-400 mb-0.5">
                      <User className="w-3.5 h-3.5" />
                      <span className="text-[10px] uppercase tracking-wider text-slate-400 font-semibold">
                        Patients
                      </span>
                    </div>
                    <span className="text-xl sm:text-2xl font-black text-white tracking-tight">
                      1,284
                    </span>
                    <span className="text-[9px] text-slate-400">Total Registered</span>
                  </div>

                  {/* Doctors */}
                  <div className="flex flex-col sm:border-l sm:border-slate-800/80 sm:pl-3">
                    <div className="flex items-center gap-1.5 text-blue-400 mb-0.5">
                      <Stethoscope className="w-3.5 h-3.5" />
                      <span className="text-[10px] uppercase tracking-wider text-slate-400 font-semibold">
                        Doctors
                      </span>
                    </div>
                    <span className="text-xl sm:text-2xl font-black text-white tracking-tight">
                      48
                    </span>
                    <span className="text-[9px] text-slate-400">On Duty Roster</span>
                  </div>

                  {/* Appointments */}
                  <div className="flex flex-col sm:border-l sm:border-slate-800/80 sm:pl-3">
                    <div className="flex items-center gap-1.5 text-indigo-400 mb-0.5">
                      <Clock className="w-3.5 h-3.5" />
                      <span className="text-[10px] uppercase tracking-wider text-slate-400 font-semibold">
                        Appointments
                      </span>
                    </div>
                    <span className="text-xl sm:text-2xl font-black text-white tracking-tight">
                      76
                    </span>
                    <span className="text-[9px] text-slate-400">Today Scheduled</span>
                  </div>

                  {/* Emergency */}
                  <div className="flex flex-col border-l border-slate-800/80 pl-3">
                    <div className="flex items-center gap-1.5 text-red-400 mb-0.5">
                      <Flame className="w-3.5 h-3.5 animate-pulse" />
                      <span className="text-[10px] uppercase tracking-wider text-slate-400 font-semibold">
                        Emergency
                      </span>
                    </div>
                    <span className="text-xl sm:text-2xl font-black text-red-400 tracking-tight">
                      07
                    </span>
                    <span className="text-[9px] text-red-300">2 Critical Triage</span>
                  </div>
                </div>
              </div>

              {/* SYSTEM HEALTH DASHBOARD: Java Multithreaded Operations & Performance */}
              <SystemHealthCard className="mt-4" />
            </div>

            {/* RIGHT COLUMN: ~60% on Desktop (lg:col-span-7) - 3D Futuristic Hospital Visualization */}
            <div className="lg:col-span-7 w-full flex items-center justify-center">
              <div className="relative w-full rounded-3xl overflow-hidden border border-cyan-500/30 bg-slate-950/70 backdrop-blur-xl shadow-2xl shadow-cyan-500/10 aspect-[4/3] sm:aspect-[16/10] lg:aspect-[16/11] max-h-[540px] group [perspective:1200px]">
                {/* 3D Futuristic Hospital Visualization with subtle slow spatial rotation */}
                <div className="w-full h-full animate-hospital-slow-rotate flex items-center justify-center [transform-style:preserve-3d]">
                  <img
                    src={medisphereHeroBg}
                    alt="MediSphere 3D Futuristic Smart Hospital Campus"
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-700 ease-out select-none"
                  />
                </div>

                {/* Subtle Futuristic Holographic Scan/Sweep Beam */}
                <div className="absolute inset-0 pointer-events-none overflow-hidden">
                  <div className="w-1/2 h-[200%] -top-1/2 bg-gradient-to-r from-transparent via-cyan-400/10 to-transparent animate-holographic-sweep blur-sm" />
                </div>

                {/* Ambient Vignette Overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-slate-950/20 pointer-events-none" />

                {/* 1. ENLARGE BUTTON: Small elegant "⛶ Enlarge" control */}
                <div className="absolute top-4 right-4 z-10">
                  <button
                    id="enlarge-3d-hospital-btn"
                    onClick={() => setIsEnlarged(true)}
                    className="px-3 py-1.5 rounded-xl bg-slate-950/80 hover:bg-slate-900 border border-cyan-500/30 hover:border-cyan-400 text-xs text-white backdrop-blur-md transition-all duration-200 flex items-center gap-1.5 shadow-[0_0_15px_-3px_rgba(6,182,212,0.3)] hover:shadow-[0_0_20px_0px_rgba(6,182,212,0.5)] active:scale-95 group"
                    title="Enlarge 3D Hospital Visualization"
                    aria-label="Enlarge 3D Hospital Visualization"
                  >
                    <span className="text-cyan-400 text-sm leading-none group-hover:scale-110 transition-transform">
                      ⛶
                    </span>
                    <span className="font-semibold text-white tracking-wide">
                      Enlarge
                    </span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FEATURE STRIP SECTION */}
      <section
        id="features-section"
        className="py-20 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto border-t border-slate-900/90 relative"
      >
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-950/60 border border-cyan-500/30 text-cyan-300 text-xs font-mono font-bold mb-3">
            <Zap className="w-3.5 h-3.5 text-cyan-400" />
            ENTERPRISE CLINICAL CAPABILITIES
          </div>
          <h2 className="text-3xl sm:text-5xl font-black text-white tracking-tight leading-tight">
            Powerful Features for a Smarter Healthcare
          </h2>
          <p className="text-sm sm:text-base text-slate-400 mt-4 leading-relaxed">
            Engineered for high-reliability medical campuses. Every subsystem seamlessly
            interconnects patient telemetry, specialist coordination, and real-time operations.
          </p>
        </div>

        {/* Two-Column Grid: 6 Feature Cards on Left + Holographic Human on Far Right */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          {/* 6 Feature Cards (Span 7 cols) */}
          <div className="lg:col-span-7 grid grid-cols-1 md:grid-cols-2 gap-5">
            {features.map((feature, idx) => {
              const Icon = feature.icon;
              return (
                <div
                  key={idx}
                  className={`p-6 rounded-3xl bg-gradient-to-b ${feature.color} bg-slate-900/70 border ${feature.border} backdrop-blur-2xl transition duration-300 hover:-translate-y-1 hover:shadow-2xl hover:border-cyan-400/60 group`}
                >
                  <div className="flex items-center justify-between mb-4">
                    <div className="w-12 h-12 rounded-2xl bg-slate-950/90 border border-slate-800 flex items-center justify-center text-cyan-400 group-hover:scale-110 transition shadow-inner">
                      <Icon className="w-6 h-6" />
                    </div>
                    <span className="text-[10px] font-mono px-2.5 py-1 rounded-full bg-slate-950/90 text-cyan-300 border border-slate-800">
                      {feature.badge}
                    </span>
                  </div>
                  <h3 className="text-lg font-bold text-white mb-2 tracking-tight group-hover:text-cyan-300 transition">
                    {feature.title}
                  </h3>
                  <p className="text-xs text-slate-300 leading-relaxed">{feature.description}</p>
                </div>
              );
            })}
          </div>

          {/* Far Right: Futuristic Holographic Human Medical Visualization */}
          <div className="lg:col-span-5 w-full flex items-center justify-center">
            <HolographicHuman />
          </div>
        </div>
      </section>

      {/* 2 & 3. FULLSCREEN ENLARGED VIEW */}
      {isEnlarged && (
        <div
          id="enlarged-3d-hospital-overlay"
          className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-950/90 backdrop-blur-2xl p-3 sm:p-6 lg:p-8 animate-in fade-in duration-200"
          onClick={() => setIsEnlarged(false)}
          role="dialog"
          aria-modal="true"
          aria-label="Enlarged 3D Hospital Visualization"
        >
          <div
            className="relative w-full h-full max-w-7xl max-h-[92vh] flex items-center justify-center rounded-2xl sm:rounded-3xl overflow-hidden border border-cyan-500/35 bg-slate-950/80 backdrop-blur-xl shadow-[0_0_60px_-10px_rgba(6,182,212,0.35)]"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Ambient Radial Glow Behind Visualization */}
            <div className="absolute inset-0 bg-gradient-to-b from-cyan-500/5 via-transparent to-blue-600/5 pointer-events-none" />
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-3/4 h-3/4 bg-cyan-500/10 blur-[120px] rounded-full pointer-events-none" />

            {/* Preserved, uncropped, unstretched 3D hospital visualization with subtle slow spatial rotation */}
            <div className="w-full h-full flex items-center justify-center overflow-hidden [perspective:1400px]">
              <div className="w-full h-full animate-hospital-slow-rotate flex items-center justify-center [transform-style:preserve-3d]">
                <img
                  src={medisphereHeroBg}
                  alt="MediSphere 3D Futuristic Smart Hospital Campus"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-contain object-center select-none"
                />
              </div>
            </div>

            {/* Subtle Futuristic Holographic Scan/Sweep Beam in enlarged mode */}
            <div className="absolute inset-0 pointer-events-none overflow-hidden">
              <div className="w-1/2 h-[200%] -top-1/2 bg-gradient-to-r from-transparent via-cyan-400/10 to-transparent animate-holographic-sweep blur-md" />
            </div>

            {/* Ambient Vignette Overlay */}
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950/40 via-transparent to-slate-950/20 pointer-events-none" />

            {/* Top-Right: Small Close control */}
            <div className="absolute top-4 right-4 sm:top-5 sm:right-5 z-20">
              <button
                id="close-enlarge-3d-btn"
                onClick={() => setIsEnlarged(false)}
                className="px-3 py-1.5 rounded-xl bg-slate-950/85 hover:bg-slate-900 border border-cyan-500/30 hover:border-cyan-400 text-xs font-semibold text-white backdrop-blur-md transition-all duration-200 flex items-center gap-1.5 shadow-[0_0_15px_-2px_rgba(6,182,212,0.25)] hover:shadow-[0_0_20px_0px_rgba(6,182,212,0.4)] active:scale-95 group"
                title="Close (Esc)"
                aria-label="Close enlarged view"
              >
                <span className="text-slate-400 group-hover:text-cyan-300 transition-colors font-bold text-sm leading-none">
                  ✕
                </span>
                <span className="font-semibold text-white tracking-wide">
                  Close
                </span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
