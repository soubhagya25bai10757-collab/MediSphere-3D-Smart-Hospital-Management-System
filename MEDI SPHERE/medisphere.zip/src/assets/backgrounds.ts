import dashboardBg from './images/dashboard_command_bg_1788969932876.jpg';
import patientRoomBg from './images/patient_room_bg_1788969951936.jpg';
import doctorWorkspaceBg from './images/doctor_workspace_bg_1788969970311.jpg';
import appointmentsHubBg from './images/appointments_hub_bg_1788969990128.jpg';
import emergencyCommandBg from './images/emergency_command_bg_1788970008710.jpg';
import operationsFloorBg from './images/operations_floor_bg_1788970031157.jpg';
import techCommandBg from './images/tech_command_bg_1788970050394.jpg';
import campusExteriorBg from './images/hospital_hero_background_1788969414765.jpg';
import ambientHeroBg from './images/medisphere_ambient_bg_1789135706422.jpg';
import medisphereHeroBg from './images/medisphere_hero_bg_1789138701890.jpg';

export interface SectionBackgroundMeta {
  id: string;
  name: string;
  category: string;
  description: string;
  src: string;
  lightingTone: string;
  vignetteStyle: string;
}

export const HOSPITAL_BACKGROUNDS: Record<string, SectionBackgroundMeta> = {
  dashboard: {
    id: 'dashboard',
    name: 'Hospital Operations Command Hub',
    category: 'Executive Operations',
    description:
      'Massive futuristic hospital command center with curved workstations overlooking the complete smart campus at dusk through panoramic glass.',
    src: dashboardBg,
    lightingTone: 'from-[#030712] via-[#030712]/92 to-[#030712]/50',
    vignetteStyle: 'bg-gradient-to-r from-[#030712] via-[#030712]/95 lg:via-[#030712]/80 lg:to-transparent lg:to-80%',
  },
  patients: {
    id: 'patients',
    name: 'Smart Patient Care Suite',
    category: 'Inpatient Medicine',
    description:
      'Premium patient room with adjustable high-tech bed, bedside digital monitors, and panoramic evening campus view.',
    src: patientRoomBg,
    lightingTone: 'from-[#030712] via-[#030712]/92 to-[#030712]/50',
    vignetteStyle: 'bg-gradient-to-r from-[#030712] via-[#030712]/95 lg:via-[#030712]/82 lg:to-transparent lg:to-85%',
  },
  doctors: {
    id: 'doctors',
    name: 'Specialist Consultation & Clinical Workspace',
    category: 'Medical Staff',
    description:
      'Executive doctor suite featuring ergonomic workstation, diagnostic display with waveforms, and clinical consultation zone.',
    src: doctorWorkspaceBg,
    lightingTone: 'from-[#030712] via-[#030712]/92 to-[#030712]/50',
    vignetteStyle: 'bg-gradient-to-r from-[#030712] via-[#030712]/95 lg:via-[#030712]/82 lg:to-transparent lg:to-85%',
  },
  appointments: {
    id: 'appointments',
    name: 'High-Tech Reception & OPD Hub',
    category: 'Patient Flow',
    description:
      'Spacious appointment registration lounge with check-in kiosks, modern lounge seating, and indoor architectural gardens.',
    src: appointmentsHubBg,
    lightingTone: 'from-[#030712] via-[#030712]/92 to-[#030712]/50',
    vignetteStyle: 'bg-gradient-to-r from-[#030712] via-[#030712]/95 lg:via-[#030712]/80 lg:to-transparent lg:to-80%',
  },
  emergency: {
    id: 'emergency',
    name: 'Emergency Trauma Pavilion & Helipad',
    category: 'Critical Care',
    description:
      'Massive night-time Emergency Department exterior with illuminated red canopy, parked futuristic ambulances, and rooftop medevac helipad.',
    src: emergencyCommandBg,
    lightingTone: 'from-[#030712] via-[#030712]/94 to-[#030712]/60',
    vignetteStyle: 'bg-gradient-to-r from-[#030712] via-[#030712]/95 lg:via-[#030712]/82 lg:to-transparent lg:to-85%',
  },
  'hospital-operations': {
    id: 'hospital-operations',
    name: 'Integrated Operations Floor',
    category: 'Facility Operations',
    description:
      'Four interconnected operations wings: Robotic Lab, Automated Pharmacy, Bed Management Ward, and Billing Administration.',
    src: operationsFloorBg,
    lightingTone: 'from-[#030712] via-[#030712]/92 to-[#030712]/50',
    vignetteStyle: 'bg-gradient-to-r from-[#030712] via-[#030712]/95 lg:via-[#030712]/82 lg:to-transparent lg:to-85%',
  },
  operations: {
    id: 'operations',
    name: 'Integrated Operations Floor',
    category: 'Facility Operations',
    description:
      'Four interconnected operations wings: Robotic Lab, Automated Pharmacy, Bed Management Ward, and Billing Administration.',
    src: operationsFloorBg,
    lightingTone: 'from-[#030712] via-[#030712]/92 to-[#030712]/50',
    vignetteStyle: 'bg-gradient-to-r from-[#030712] via-[#030712]/95 lg:via-[#030712]/82 lg:to-transparent lg:to-85%',
  },
  'system-monitor': {
    id: 'system-monitor',
    name: 'IT & Analytics Command Center',
    category: 'Infrastructure',
    description:
      'Advanced server infrastructure, network command terminals, abstract data analytics displays overlooking the evening campus.',
    src: techCommandBg,
    lightingTone: 'from-[#030712] via-[#030712]/92 to-[#030712]/50',
    vignetteStyle: 'bg-gradient-to-r from-[#030712] via-[#030712]/95 lg:via-[#030712]/82 lg:to-transparent lg:to-85%',
  },
  analytics: {
    id: 'analytics',
    name: 'IT & Analytics Command Center',
    category: 'Infrastructure',
    description:
      'Advanced server infrastructure, network command terminals, abstract data analytics displays overlooking the evening campus.',
    src: techCommandBg,
    lightingTone: 'from-[#030712] via-[#030712]/92 to-[#030712]/50',
    vignetteStyle: 'bg-gradient-to-r from-[#030712] via-[#030712]/95 lg:via-[#030712]/82 lg:to-transparent lg:to-85%',
  },
  campus: {
    id: 'campus',
    name: 'MediSphere 3D Campus Masterplan',
    category: 'Campus Exterior',
    description:
      'Ultra-HD 16:9 aerial visualization of the entire interconnected futuristic smart hospital complex during twilight blue hour.',
    src: campusExteriorBg,
    lightingTone: 'from-[#030712] via-[#030712]/90 to-[#030712]/40',
    vignetteStyle: 'bg-gradient-to-r from-[#030712] via-[#030712]/95 lg:via-[#030712]/80 lg:to-transparent lg:to-75%',
  },
  landing: {
    id: 'landing',
    name: 'MediSphere 3D Cinematic Hospital Architecture',
    category: 'Healthcare AI Core',
    description:
      'Massive futuristic smart hospital at night with curved glass structures, illuminated medical corridors, subtle holographic interfaces, and deep midnight navy atmosphere.',
    src: medisphereHeroBg,
    lightingTone: 'from-[#030814] via-[#030814]/85 to-[#030814]/40',
    vignetteStyle: 'bg-gradient-to-r from-[#030814] via-[#030814]/90 lg:via-[#030814]/70 lg:to-transparent',
  },
  hero: {
    id: 'hero',
    name: 'MediSphere 3D Cinematic Hospital Hero',
    category: 'Hospital Architecture',
    description:
      'Ultra-realistic 3D visualization of the massive smart hospital campus at night with curved glass, emergency wing, and subtle volumetric cyan and violet lighting.',
    src: medisphereHeroBg,
    lightingTone: 'from-[#030814] via-[#030814]/85 to-[#030814]/40',
    vignetteStyle: 'bg-gradient-to-r from-[#030814] via-[#030814]/90 lg:via-[#030814]/70 lg:to-transparent',
  },
};

export { medisphereHeroBg };
export default HOSPITAL_BACKGROUNDS;
