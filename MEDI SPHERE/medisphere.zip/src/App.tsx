/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { Suspense } from 'react';
import { HospitalProvider, useHospital } from './context/HospitalContext';
import { Navigation } from './components/Navigation';
import { LandingPage } from './components/LandingPage';
import { LoginModal } from './components/LoginModal';
import { JavaArchitectureModal } from './components/JavaArchitectureModal';
import { ToastContainer } from './components/ToastContainer';
import { CinematicSectionBackdrop } from './components/CinematicSectionBackdrop';
import { ErrorBoundary } from './components/ErrorBoundary';
import { LoadingState } from './components/LoadingState';

// Hospital System Views
import { DashboardView } from './views/DashboardView';
import { PatientManagementView } from './views/PatientManagementView';
import { DoctorManagementView } from './views/DoctorManagementView';
import { AppointmentManagementView } from './views/AppointmentManagementView';
import { EmergencyView } from './views/EmergencyView';
import { HospitalOperationsView } from './views/HospitalOperationsView';
import { AnalyticsSystemView } from './views/AnalyticsSystemView';

const HospitalAppContent: React.FC = () => {
  const { activeTab, activeMainTab, showLandingPage, isSidebarExpanded } = useHospital();

  if (showLandingPage) {
    return (
      <div className="min-h-screen bg-slate-950 text-slate-100">
        <ErrorBoundary fallbackTitle="Landing Page" showHomeButton={false}>
          <LandingPage />
        </ErrorBoundary>
        <LoginModal />
        <JavaArchitectureModal />
        <ToastContainer />
      </div>
    );
  }

  const renderActiveView = () => {
    switch (activeMainTab) {
      case 'dashboard':
        return (
          <ErrorBoundary fallbackTitle="Dashboard Analytics">
            <DashboardView />
          </ErrorBoundary>
        );
      case 'patients':
        return (
          <ErrorBoundary fallbackTitle="Patient Management">
            <PatientManagementView />
          </ErrorBoundary>
        );
      case 'doctors':
        return (
          <ErrorBoundary fallbackTitle="Doctor Management">
            <DoctorManagementView />
          </ErrorBoundary>
        );
      case 'appointments':
        return (
          <ErrorBoundary fallbackTitle="Appointment Management">
            <AppointmentManagementView />
          </ErrorBoundary>
        );
      case 'emergency':
        return (
          <ErrorBoundary fallbackTitle="Emergency Trauma Bay">
            <EmergencyView />
          </ErrorBoundary>
        );
      case 'operations':
        return (
          <ErrorBoundary fallbackTitle="Hospital Operations">
            <HospitalOperationsView />
          </ErrorBoundary>
        );
      case 'analytics':
        return (
          <ErrorBoundary fallbackTitle="System Intelligence">
            <AnalyticsSystemView />
          </ErrorBoundary>
        );
      default:
        // Backward compatibility
        if (['laboratory', 'pharmacy', 'beds', 'billing'].includes(activeTab)) {
          return (
            <ErrorBoundary fallbackTitle="Hospital Operations">
              <HospitalOperationsView />
            </ErrorBoundary>
          );
        }
        if (['reports', 'threads', 'settings'].includes(activeTab)) {
          return (
            <ErrorBoundary fallbackTitle="Analytics">
              <AnalyticsSystemView />
            </ErrorBoundary>
          );
        }
        return (
          <ErrorBoundary fallbackTitle="Dashboard">
            <DashboardView />
          </ErrorBoundary>
        );
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-cyan-500/30 selection:text-cyan-200 relative overflow-x-hidden">
      {/* 3D Cinematic Section Backdrop */}
      <ErrorBoundary fallbackTitle="Visual Atmosphere">
        <CinematicSectionBackdrop />
      </ErrorBoundary>

      <Navigation />

      {/* Main Content Area */}
      <main className={`${isSidebarExpanded ? 'lg:pl-72' : 'lg:pl-[72px]'} flex-1 min-h-screen p-4 sm:p-6 lg:p-8 relative z-10 transition-all duration-300 ease-in-out`}>
        <div className="max-w-7xl mx-auto pb-16">
          <Suspense fallback={<LoadingState message="Loading Clinical View..." />}>
            {renderActiveView()}
          </Suspense>
        </div>
      </main>

      {/* Global Floating Modals & Toasts */}
      <LoginModal />
      <JavaArchitectureModal />
      <ToastContainer />
    </div>
  );
};

export default function App() {
  return (
    <ErrorBoundary fallbackTitle="MediSphere 3D Core" showHomeButton>
      <HospitalProvider>
        <HospitalAppContent />
      </HospitalProvider>
    </ErrorBoundary>
  );
}

