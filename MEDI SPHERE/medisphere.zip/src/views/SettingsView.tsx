import React, { useState } from 'react';
import { useHospital } from '../context/HospitalContext';
import {
  Settings,
  Database,
  Building,
  Users,
  Sliders,
  Save,
  RotateCcw,
  Download,
  Upload,
  CheckCircle2,
  AlertTriangle,
  Server,
  Key,
} from 'lucide-react';

export const SettingsView: React.FC = () => {
  const {
    exportDataAsJSON,
    importDataFromJSON,
    resetToDemoData,
    currentUser,
    switchUserRole,
  } = useHospital();

  const [hospitalName, setHospitalName] = useState<string>('MediSphere 3D Super-Specialty Medical Center');
  const [helpline, setHelpline] = useState<string>('1800-419-3300 (Toll-Free 24x7)');
  const [address, setAddress] = useState<string>('Plot 42, Silicon Healthcare Hub, Bengaluru, Karnataka, 560100');
  const [currencySymbol, setCurrencySymbol] = useState<string>('₹ (INR)');
  const [autoSaveInterval, setAutoSaveInterval] = useState<string>('5 minutes');
  const [savedSuccess, setSavedSuccess] = useState<boolean>(false);

  const handleSaveHospitalConfig = (e: React.FormEvent) => {
    e.preventDefault();
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 3000);
  };

  const handleImportFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      if (content) {
        importDataFromJSON(content);
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-black text-white tracking-tight">System Settings & Topology</h1>
            <span className="text-xs font-mono px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
              v3.4 Production Ready
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Hospital metadata, simulated JDBC connection pooling, RBAC security, and Java serialization backups.
          </p>
        </div>

        {savedSuccess && (
          <div className="px-3.5 py-1.5 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs font-bold flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            Hospital Config Persisted
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Hospital Profile Config */}
        <div className="lg:col-span-2 space-y-6">
          <div className="p-6 rounded-3xl glass-card border-cyan-500/30 shadow-xl">
            <div className="flex items-center gap-2.5 mb-4 border-b border-cyan-500/20 pb-3">
              <Building className="w-5 h-5 text-cyan-300" />
              <h3 className="text-base font-extrabold text-white">Hospital Center Profile</h3>
            </div>

            <form onSubmit={handleSaveHospitalConfig} className="space-y-4 text-xs">
              <div>
                <label className="text-slate-200 block mb-1 font-bold">Hospital Name</label>
                <input
                  type="text"
                  value={hospitalName}
                  onChange={(e) => setHospitalName(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl glass-input text-white outline-none font-semibold"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-slate-200 block mb-1 font-bold">24x7 Emergency Helpline</label>
                  <input
                    type="text"
                    value={helpline}
                    onChange={(e) => setHelpline(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl glass-input text-white outline-none font-semibold"
                  />
                </div>
                <div>
                  <label className="text-slate-200 block mb-1 font-bold">Currency Designation</label>
                  <input
                    type="text"
                    value={currencySymbol}
                    onChange={(e) => setCurrencySymbol(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl glass-input text-white outline-none font-semibold"
                  />
                </div>
              </div>

              <div>
                <label className="text-slate-200 block mb-1 font-bold">Campus Postal Address</label>
                <textarea
                  rows={2}
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  className="w-full p-3.5 rounded-xl glass-input text-white outline-none font-semibold"
                />
              </div>

              <div className="flex justify-end pt-2">
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-black transition shadow-[0_0_15px_rgba(6,182,212,0.3)] flex items-center gap-2"
                >
                  <Save className="w-4 h-4" />
                  <span>Save Parameters</span>
                </button>
              </div>
            </form>
          </div>

          {/* Role Switching & Active Session */}
          <div className="p-6 rounded-3xl glass-card border-cyan-500/30 shadow-xl">
            <div className="flex items-center gap-2.5 mb-4 border-b border-cyan-500/20 pb-3">
              <Users className="w-5 h-5 text-indigo-400" />
              <h3 className="text-base font-extrabold text-white">Active Session & RBAC Role Simulation</h3>
            </div>

            <p className="text-xs text-slate-300 mb-4 font-medium">
              Current authenticated entity: <span className="text-white font-bold">{currentUser?.name}</span> ({currentUser?.role})
            </p>

            <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
              {[
                { role: 'ADMIN', label: 'Admin (Full)' },
                { role: 'DOCTOR', label: 'Doctor' },
                { role: 'RECEPTIONIST', label: 'Reception' },
                { role: 'PHARMACIST', label: 'Pharmacy' },
                { role: 'LAB_TECHNICIAN', label: 'Lab Tech' },
              ].map((item) => (
                <button
                  key={item.role}
                  onClick={() => switchUserRole(item.role as any)}
                  className={`p-2.5 rounded-xl border text-xs font-bold transition text-center ${
                    currentUser?.role === item.role
                      ? 'bg-indigo-500/30 text-indigo-200 border-indigo-400 shadow-[0_0_12px_rgba(99,102,241,0.3)] font-black'
                      : 'glass-card-subtle border-cyan-500/20 text-slate-300 hover:text-white hover:border-cyan-500/40'
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Right Column: Database & Java I/O Persistence */}
        <div className="space-y-6">
          {/* JDBC Connection Pool Status */}
          <div className="p-6 rounded-3xl glass-card border-emerald-500/30 shadow-xl">
            <div className="flex items-center gap-2 mb-3">
              <Database className="w-5 h-5 text-emerald-400" />
              <h3 className="text-base font-extrabold text-white">JDBC HikariCP Pool</h3>
            </div>

            <div className="space-y-2 text-xs">
              <div className="flex items-center justify-between p-2.5 rounded-xl glass-card-subtle border border-emerald-500/20">
                <span className="text-slate-300 font-medium">Connection Engine:</span>
                <span className="text-emerald-300 font-mono font-bold flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse shadow-[0_0_6px_#34d399]" />
                  MySQL 8.0 Connected
                </span>
              </div>
              <div className="flex items-center justify-between p-2.5 rounded-xl glass-card-subtle border border-cyan-500/20">
                <span className="text-slate-300 font-medium">Driver:</span>
                <span className="text-slate-100 font-mono font-semibold">com.mysql.cj.jdbc.Driver</span>
              </div>
              <div className="flex items-center justify-between p-2.5 rounded-xl glass-card-subtle border border-cyan-500/20">
                <span className="text-slate-300 font-medium">Round-Trip Latency:</span>
                <span className="text-cyan-300 font-mono font-bold">3.8 ms</span>
              </div>
              <div className="flex items-center justify-between p-2.5 rounded-xl glass-card-subtle border border-cyan-500/20">
                <span className="text-slate-300 font-medium">Active Pool Conns:</span>
                <span className="text-white font-mono font-extrabold">10 / 20</span>
              </div>
            </div>
          </div>

          {/* Backup & Restore Panel */}
          <div className="p-6 rounded-3xl glass-card border-cyan-500/30 shadow-xl space-y-4">
            <div className="flex items-center gap-2 border-b border-cyan-500/20 pb-3">
              <Server className="w-5 h-5 text-cyan-300" />
              <h3 className="text-base font-extrabold text-white">Database Snapshot</h3>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed font-medium">
              Export serialized system records or restore previous state from JSON backups.
            </p>

            <button
              onClick={exportDataAsJSON}
              className="w-full py-2.5 rounded-xl bg-cyan-500/25 text-cyan-200 border border-cyan-500/50 hover:bg-cyan-500/35 text-xs font-black transition flex items-center justify-center gap-2 shadow-[0_0_12px_rgba(6,182,212,0.25)]"
            >
              <Download className="w-4 h-4" />
              <span>Export System Snapshot (JSON)</span>
            </button>

            <label className="w-full py-2.5 rounded-xl glass-card-subtle hover:border-cyan-500/50 text-slate-200 text-xs font-bold transition flex items-center justify-center gap-2 cursor-pointer border border-cyan-500/20">
              <Upload className="w-4 h-4 text-cyan-300" />
              <span>Restore Snapshot from File</span>
              <input
                type="file"
                accept=".json"
                onChange={handleImportFile}
                className="hidden"
              />
            </label>

            <div className="pt-2 border-t border-cyan-500/20">
              <button
                onClick={resetToDemoData}
                className="w-full py-2.5 rounded-xl bg-red-950/40 text-red-300 border border-red-500/40 hover:bg-red-900/50 text-xs font-bold transition flex items-center justify-center gap-2"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Factory Reset Demo Database</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
