import React from 'react';
import { useHospital } from '../context/HospitalContext';
import {
  BarChart3,
  FileSpreadsheet,
  Cpu,
  Activity,
  Layers,
  Sparkles,
  Sliders,
} from 'lucide-react';
import { ReportsAnalyticsView } from './ReportsAnalyticsView';
import { JavaThreadMonitorView } from './JavaThreadMonitorView';
import { SettingsView } from './SettingsView';
import { ErrorBoundary } from '../components/ErrorBoundary';
import { JavaImplementationPanel } from '../components/JavaImplementationPanel';

export const AnalyticsSystemView: React.FC = () => {
  const { activeSubTab, setActiveNavigation, threads = [] } = useHospital();

  // Normalize sub-tab
  const currentTab = ['analytics', 'reports', 'threads', 'activity'].includes(activeSubTab)
    ? activeSubTab
    : 'analytics';

  const runningThreadsCount = (threads || []).filter((t) => t && t.state === 'RUNNING').length;

  const tabs = [
    {
      id: 'analytics',
      name: 'Hospital Analytics',
      badge: 'Live Telemetry',
      icon: BarChart3,
      desc: 'Occupancy Rates, Clinical KPI Charts & Revenue Flow',
      iconColor: 'text-cyan-400',
      activeBorder: 'border-cyan-500',
    },
    {
      id: 'reports',
      name: 'Reports',
      badge: 'Export Hub',
      icon: FileSpreadsheet,
      desc: 'Automated CSV, Census Rosters & Discharge Summaries',
      iconColor: 'text-indigo-400',
      activeBorder: 'border-indigo-500',
    },
    {
      id: 'threads',
      name: 'System Monitor',
      badge: `${runningThreadsCount} Running`,
      icon: Cpu,
      desc: 'System Performance, Background Tasks & Concurrency',
      iconColor: 'text-emerald-400',
      activeBorder: 'border-emerald-500',
    },
    {
      id: 'activity',
      name: 'System Activity',
      badge: 'Audit Logs & DB',
      icon: Activity,
      desc: 'Connection Pool, Diagnostics & System Config',
      iconColor: 'text-amber-400',
      activeBorder: 'border-amber-500',
    },
  ];

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Section Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-cyan-500/20">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-[10px] uppercase font-bold tracking-widest text-cyan-400 px-2 py-0.5 rounded-full bg-cyan-500/10 border border-cyan-500/30">
              VTOP Hospital OS &bull; Module 7
            </span>
            <span className="text-[10px] font-mono text-slate-400">
              Intelligence & JVM Runtime
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight mt-1 flex items-center gap-3">
            <BarChart3 className="w-7 h-7 text-cyan-400" />
            Analytics & System Intelligence
          </h1>
          <p className="text-xs text-slate-400 mt-1 max-w-2xl">
            Real-time hospital KPI dashboards, structured clinical reporting, and live Java
            concurrency monitoring with active worker threadpools and database synchronization.
          </p>
        </div>
      </div>

      {/* 4 Clean Internal Module Cards / Switchers */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = currentTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveNavigation('analytics', tab.id)}
              className={`p-4 rounded-2xl text-left transition-all relative overflow-hidden glass-card border shadow-xl ${
                isActive
                  ? `${tab.activeBorder} shadow-[0_0_20px_rgba(6,182,212,0.25)] scale-[1.01] bg-[rgba(10,25,60,0.85)]`
                  : 'border-cyan-500/20 hover:border-cyan-500/50 hover:bg-[rgba(6,18,45,0.7)]'
              }`}
            >
              {isActive && (
                <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-cyan-400 to-indigo-500 shadow-[0_0_10px_rgba(6,182,212,0.8)]" />
              )}

              <div className="flex items-center justify-between mb-3">
                <div
                  className={`w-9 h-9 rounded-xl flex items-center justify-center border shadow-inner ${
                    isActive
                      ? 'bg-[rgba(6,18,45,0.9)] border-cyan-400/50 text-cyan-300 shadow-[0_0_10px_rgba(6,182,212,0.3)]'
                      : 'bg-[rgba(6,18,45,0.6)] border-cyan-500/20 ' + tab.iconColor
                  }`}
                >
                  <Icon className="w-4 h-4" />
                </div>
                <span
                  className={`text-[10px] font-mono px-2 py-0.5 rounded-full border font-bold ${
                    isActive
                      ? 'bg-cyan-500/25 text-cyan-200 border-cyan-500/50 shadow-[0_0_10px_rgba(6,182,212,0.25)]'
                      : 'bg-[rgba(6,18,45,0.6)] text-slate-300 border-cyan-500/20'
                  }`}
                >
                  {tab.badge}
                </span>
              </div>

              <h3 className={`text-sm font-extrabold tracking-tight ${isActive ? 'text-white' : 'text-slate-200'}`}>
                {tab.name}
              </h3>
              <p className="text-[11px] text-slate-300 mt-1 line-clamp-1 leading-snug font-medium">
                {tab.desc}
              </p>
            </button>
          );
        })}
      </div>

      {/* Java Implementation Panel (6 Core Java OOP Concepts & Architecture) */}
      <ErrorBoundary fallbackTitle="Java Implementation Panel">
        <JavaImplementationPanel />
      </ErrorBoundary>

      {/* Embedded View Body */}
      <div className="pt-2">
        {currentTab === 'analytics' && (
          <ErrorBoundary fallbackTitle="Hospital KPI Analytics">
            <ReportsAnalyticsView />
          </ErrorBoundary>
        )}
        {currentTab === 'reports' && (
          <ErrorBoundary fallbackTitle="Clinical Reports Generator">
            <ReportsAnalyticsView />
          </ErrorBoundary>
        )}
        {currentTab === 'threads' && (
          <ErrorBoundary fallbackTitle="System Performance & Threads">
            <JavaThreadMonitorView />
          </ErrorBoundary>
        )}
        {currentTab === 'activity' && (
          <ErrorBoundary fallbackTitle="System Audit & Activity">
            <SettingsView />
          </ErrorBoundary>
        )}
      </div>
    </div>
  );
};
