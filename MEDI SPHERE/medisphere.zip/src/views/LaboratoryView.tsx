import React, { useState, useMemo } from 'react';
import { useHospital } from '../context/HospitalContext';
import { DiagnosticLabTest, LabTestStatus } from '../types';
import {
  Microscope,
  Search,
  Filter,
  Plus,
  Play,
  CheckCircle2,
  Clock,
  FileText,
  Printer,
  X,
  Sparkles,
  Cpu,
  RotateCw,
  AlertTriangle,
} from 'lucide-react';

export const LaboratoryView: React.FC = () => {
  const {
    labTests,
    patients,
    doctors,
    addLabTest,
    completeLabTest,
    updateLabTestStatus,
    simulateLabAnalysisThread,
    searchQuery,
  } = useHospital();

  const [localSearch, setLocalSearch] = useState<string>('');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [showAddModal, setShowAddModal] = useState<boolean>(false);
  const [selectedTest, setSelectedTest] = useState<DiagnosticLabTest | null>(null);

  // Form
  const [patientId, setPatientId] = useState<string>(patients[0]?.id || '');
  const [doctorId, setDoctorId] = useState<string>(doctors[0]?.id || '');
  const [testType, setTestType] = useState<string>('Complete Blood Count (CBC)');
  const [sampleType, setSampleType] = useState<string>('Whole Blood (EDTA)');
  const [technicianNotes, setTechnicianNotes] = useState<string>('');
  const [fee, setFee] = useState<number>(450);

  // Enter results state
  const [resultParam, setResultParam] = useState<string>('Hemoglobin');
  const [resultVal, setResultVal] = useState<string>('14.2 g/dL');
  const [resultRange, setResultRange] = useState<string>('13.0 - 17.0 g/dL');
  const [isAbnormal, setIsAbnormal] = useState<boolean>(false);

  const testCatalog = [
    { name: 'Complete Blood Count (CBC)', fee: 450, sample: 'Whole Blood (EDTA)' },
    { name: 'Fasting Blood Sugar (FBS)', fee: 180, sample: 'Plasma Fluoride' },
    { name: 'HbA1c Glycated Hemoglobin', fee: 650, sample: 'Whole Blood' },
    { name: 'Lipid Profile Comprehensive', fee: 850, sample: 'Serum' },
    { name: 'Liver Function Test (LFT)', fee: 750, sample: 'Serum' },
    { name: 'Kidney Function Test (KFT)', fee: 700, sample: 'Serum' },
    { name: 'Thyroid Stimulating Hormone (TSH)', fee: 400, sample: 'Serum' },
    { name: 'Routine Urine Analysis', fee: 200, sample: 'Midstream Urine' },
    { name: 'Digital Chest X-Ray PA View', fee: 600, sample: 'Radiology Imaging' },
    { name: '12-Lead Electrocardiogram (ECG)', fee: 350, sample: 'Cardio Electrodes' },
    { name: 'Contrast Enhanced CT Scan Brain', fee: 4500, sample: 'CT Scanner Suite' },
    { name: 'High-Field MRI Lumbar Spine', fee: 7500, sample: 'MRI Suite 3T' },
    { name: 'Whole Abdomen Ultrasound (USG)', fee: 1400, sample: 'Ultrasound Probe' },
    { name: '2D Echocardiography & Color Doppler', fee: 2200, sample: 'Cardio Echo Probe' },
  ];

  const filteredTests = useMemo(() => {
    const q = (localSearch || searchQuery || '').toLowerCase().trim();
    return (labTests || []).filter((t) => {
      if (!t) return false;
      const patientName = (t.patientName || '').toLowerCase();
      const testType = (t.testType || '').toLowerCase();
      const id = (t.id || '').toLowerCase();
      const doc = (t.requestedByDoctor || '').toLowerCase();

      const matchQ =
        !q ||
        patientName.includes(q) ||
        testType.includes(q) ||
        id.includes(q) ||
        doc.includes(q);

      const matchStatus = statusFilter === 'ALL' || t.status === statusFilter;
      return matchQ && matchStatus;
    });
  }, [labTests, localSearch, searchQuery, statusFilter]);

  const handleCreateTest = (e: React.FormEvent) => {
    e.preventDefault();
    const p = patients.find((pat) => pat.id === patientId);
    const d = doctors.find((doc) => doc.id === doctorId);
    if (!p || !d) return;

    addLabTest({
      patientId: p.id,
      patientName: p.name,
      testType,
      sampleType,
      requestedByDoctor: d.name,
      status: 'Pending',
      results: [],
      fee,
      technicianNotes: technicianNotes || 'Specimen barcoded and routed to clinical pathology analyzer.',
    });
    setShowAddModal(false);
  };

  const handleSaveResult = (testId: string) => {
    completeLabTest(
      testId,
      [
        {
          parameter: resultParam,
          value: resultVal,
          normalRange: resultRange,
          status: isAbnormal ? 'High' : 'Normal',
        },
      ],
      'Automated analysis verified by Pathologist.'
    );
    setSelectedTest(null);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-black text-white tracking-tight">
              Diagnostic Pathology & Imaging
            </h1>
            <span className="text-xs font-mono px-2 py-0.5 rounded-full bg-purple-500/20 text-purple-300 border border-purple-500/30">
              {labTests.length} In Queue
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Multithreaded automated analyzers, radiological modalities, and reference range validation.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={() => {
              const pending = labTests.find((t) => t.status === 'Pending') || labTests[0];
              if (pending) simulateLabAnalysisThread(pending.id);
            }}
            className="inline-flex items-center gap-2 px-3.5 py-2.5 rounded-xl glass-btn-secondary text-purple-200 hover:text-white text-xs font-bold transition shadow-sm"
          >
            <Cpu className="w-4 h-4 text-purple-300" />
            <span>Run Batch Analysis</span>
          </button>
          <button
            onClick={() => setShowAddModal(true)}
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-purple-500 to-indigo-600 hover:from-purple-400 hover:to-indigo-500 text-white text-xs font-black transition shadow-[0_0_20px_rgba(168,85,247,0.35)]"
          >
            <Plus className="w-4 h-4" />
            <span>Order Diagnostic Test</span>
          </button>
        </div>
      </div>

      {/* Filter & Search Bar */}
      <div className="p-4 rounded-2xl glass-card border-purple-500/30 flex flex-col sm:flex-row items-center justify-between gap-3 shadow-xl">
        <div className="relative w-full max-w-md">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-300" />
          <input
            type="text"
            placeholder="Search test name, patient ID, doctor..."
            value={localSearch}
            onChange={(e) => setLocalSearch(e.target.value)}
            className="w-full pl-10 pr-4 py-2 text-xs rounded-xl glass-input text-white placeholder-slate-400"
          />
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
          <Filter className="w-3.5 h-3.5 text-cyan-300" />
          <span className="text-xs text-slate-300 font-bold whitespace-nowrap">Queue State:</span>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-3 py-1.5 rounded-xl glass-input text-xs text-white cursor-pointer"
          >
            <option value="ALL" className="bg-slate-950 text-white">All States</option>
            <option value="Pending" className="bg-slate-950 text-amber-300">Pending Ingestion</option>
            <option value="Processing" className="bg-slate-950 text-purple-300">Processing Analyzer</option>
            <option value="Completed" className="bg-slate-950 text-emerald-300">Verified & Ready</option>
          </select>
        </div>
      </div>

      {/* Diagnostic Tests Queue Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredTests.map((test) => (
          <div
            key={test.id}
            className="p-5 rounded-2xl glass-card border-purple-500/30 hover:border-purple-400/60 transition-all hover:-translate-y-0.5 shadow-xl flex flex-col justify-between"
          >
            <div>
              <div className="flex items-start justify-between gap-2">
                <div>
                  <span className="text-[10px] font-mono px-2.5 py-0.5 rounded-full bg-[rgba(6,18,45,0.8)] text-purple-200 border border-purple-500/40 font-extrabold">
                    {test.id}
                  </span>
                  <h3 className="text-sm font-extrabold text-white mt-2 leading-tight">
                    {test.testType}
                  </h3>
                  <span className="text-xs text-slate-300 block mt-1 font-medium">
                    Patient: <strong className="text-white">{test.patientName}</strong>
                  </span>
                </div>

                <span
                  className={`text-[9px] font-extrabold px-2.5 py-1 rounded-full uppercase tracking-wider ${
                    test.status === 'Processing'
                      ? 'bg-purple-500/25 text-purple-200 border border-purple-500/50 animate-pulse shadow-[0_0_10px_rgba(168,85,247,0.3)]'
                      : test.status === 'Completed'
                      ? 'bg-emerald-500/25 text-emerald-200 border border-emerald-500/50'
                      : 'bg-amber-500/25 text-amber-200 border border-amber-500/50'
                  }`}
                >
                  {test.status}
                </span>
              </div>

              <div className="mt-3 p-3 rounded-xl glass-card-subtle text-xs text-slate-200 space-y-1.5">
                <div className="flex justify-between">
                  <span className="text-slate-300 font-medium">Specimen:</span>
                  <span className="text-white font-bold">{test.sampleType}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-300 font-medium">Requested By:</span>
                  <span className="text-cyan-300 font-bold">{test.requestedByDoctor}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-300 font-medium">Diagnostic Fee:</span>
                  <span className="font-mono font-extrabold text-emerald-300">₹{test.fee}</span>
                </div>
              </div>

              {/* Verified Result Output */}
              {test.results && test.results.length > 0 && (
                <div className="mt-3 space-y-1.5">
                  <span className="text-[10px] uppercase font-bold text-cyan-300 block">
                    Verified Parameters:
                  </span>
                  {test.results.map((res, idx) => (
                    <div
                      key={idx}
                      className="p-2.5 rounded-xl bg-[rgba(6,18,45,0.7)] border border-cyan-500/20 text-xs flex items-center justify-between"
                    >
                      <div>
                        <span className="text-white font-bold block">{res.parameter}</span>
                        <span className="text-[10px] text-slate-300 font-medium">
                          Ref: {res.referenceRange}
                        </span>
                      </div>
                      <span
                        className={`font-mono font-black ${
                          res.isAbnormal ? 'text-red-300' : 'text-emerald-300'
                        }`}
                      >
                        {res.value}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="mt-4 pt-3 border-t border-purple-500/20 flex items-center justify-between">
              {test.status === 'Pending' && (
                <button
                  onClick={() => updateLabTestStatus(test.id, 'Processing')}
                  className="px-3.5 py-1.5 rounded-xl text-xs font-bold bg-purple-600 hover:bg-purple-500 text-white transition flex items-center gap-1.5 shadow-[0_0_12px_rgba(168,85,247,0.3)]"
                >
                  <Play className="w-3.5 h-3.5" />
                  <span>Mount on Analyzer</span>
                </button>
              )}

              {test.status === 'Processing' && (
                <button
                  onClick={() => setSelectedTest(test)}
                  className="px-3.5 py-1.5 rounded-xl text-xs font-bold bg-emerald-600 hover:bg-emerald-500 text-white transition flex items-center gap-1.5 shadow-[0_0_12px_rgba(16,185,129,0.3)]"
                >
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>Enter Test Findings</span>
                </button>
              )}

              {test.status === 'Completed' && (
                <button
                  onClick={() => alert(`Printing verified diagnostic report for ${test.patientName} (${test.testType})`)}
                  className="px-3.5 py-1.5 rounded-xl text-xs font-bold glass-btn-secondary text-slate-200 hover:text-white transition flex items-center gap-1.5"
                >
                  <Printer className="w-3.5 h-3.5 text-cyan-300" />
                  <span>Print Lab Slip</span>
                </button>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Enter Findings Modal */}
      {selectedTest && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-2xl animate-in fade-in">
          <div className="relative w-full max-w-lg rounded-3xl glass-modal border-purple-500/40 p-6 shadow-2xl">
            <button
              onClick={() => setSelectedTest(null)}
              className="absolute top-5 right-5 p-2 rounded-xl text-slate-300 hover:text-white hover:bg-[rgba(6,18,45,0.7)] border border-cyan-500/20 transition"
            >
              <X className="w-5 h-5" />
            </button>

            <h3 className="text-base font-extrabold text-white mb-1">
              Enter Clinical Pathological Findings
            </h3>
            <p className="text-xs text-slate-300 mb-4 font-medium">
              Test: <strong className="text-white">{selectedTest.testType}</strong> &bull; Patient: <strong className="text-white">{selectedTest.patientName}</strong>
            </p>

            <div className="space-y-3 text-xs">
              <div>
                <label className="text-slate-200 font-bold block mb-1">Parameter Analyzed</label>
                <input
                  type="text"
                  value={resultParam}
                  onChange={(e) => setResultParam(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-xl glass-input text-white"
                />
              </div>
              <div>
                <label className="text-slate-200 font-bold block mb-1">Observed Value</label>
                <input
                  type="text"
                  value={resultVal}
                  onChange={(e) => setResultVal(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-xl glass-input text-white font-mono"
                />
              </div>
              <div>
                <label className="text-slate-200 font-bold block mb-1">Normal Reference Range</label>
                <input
                  type="text"
                  value={resultRange}
                  onChange={(e) => setResultRange(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-xl glass-input text-white font-mono"
                />
              </div>
              <label className="flex items-center gap-2 cursor-pointer pt-1 text-slate-200 font-medium">
                <input
                  type="checkbox"
                  checked={isAbnormal}
                  onChange={(e) => setIsAbnormal(e.target.checked)}
                  className="w-4 h-4 rounded bg-slate-950 border-cyan-500/40 text-red-500 cursor-pointer"
                />
                Flag as Clinically Abnormal (Alert Attending Physician)
              </label>

              <div className="pt-4 flex items-center justify-end gap-3 border-t border-purple-500/20">
                <button
                  onClick={() => setSelectedTest(null)}
                  className="px-4 py-2.5 rounded-xl glass-btn-secondary text-slate-200 hover:text-white font-bold"
                >
                  Cancel
                </button>
                <button
                  onClick={() => handleSaveResult(selectedTest.id)}
                  className="px-5 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold shadow-[0_0_15px_rgba(168,85,247,0.35)] transition"
                >
                  Verify & Commit Findings
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Order Diagnostic Test Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-2xl animate-in fade-in">
          <div className="relative w-full max-w-2xl rounded-3xl glass-modal border-purple-500/40 p-6 shadow-2xl overflow-y-auto max-h-[90vh]">
            <button
              onClick={() => setShowAddModal(false)}
              className="absolute top-5 right-5 p-2 rounded-xl text-slate-300 hover:text-white hover:bg-[rgba(6,18,45,0.7)] border border-cyan-500/20 transition"
            >
              <X className="w-5 h-5" />
            </button>

            <h2 className="text-xl font-black text-white mb-1">Order Diagnostic Investigation</h2>
            <p className="text-xs text-slate-300 mb-6 font-medium">
              Routes order to automated laboratory worker pool.
            </p>

            <form onSubmit={handleCreateTest} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-bold text-slate-200 block mb-1">Patient</label>
                  <select
                    value={patientId}
                    onChange={(e) => setPatientId(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl glass-input text-xs text-white cursor-pointer"
                  >
                    {patients.map((p) => (
                      <option key={p.id} value={p.id} className="bg-slate-950 text-white">
                        {p.name} ({p.id})
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="text-xs font-bold text-slate-200 block mb-1">
                    Ordering Physician
                  </label>
                  <select
                    value={doctorId}
                    onChange={(e) => setDoctorId(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl glass-input text-xs text-white cursor-pointer"
                  >
                    {doctors.map((d) => (
                      <option key={d.id} value={d.id} className="bg-slate-950 text-white">
                        {d.name} ({d.specialization})
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-200 block mb-1">
                  Investigation Test Type
                </label>
                <select
                  value={testType}
                  onChange={(e) => {
                    setTestType(e.target.value);
                    const catalogItem = testCatalog.find((c) => c.name === e.target.value);
                    if (catalogItem) {
                      setFee(catalogItem.fee);
                      setSampleType(catalogItem.sample);
                    }
                  }}
                  className="w-full px-3.5 py-2.5 rounded-xl glass-input text-xs text-white cursor-pointer"
                >
                  {testCatalog.map((c) => (
                    <option key={c.name} value={c.name} className="bg-slate-950 text-white">
                      {c.name} (₹{c.fee})
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-bold text-slate-200 block mb-1">
                    Specimen Required
                  </label>
                  <input
                    type="text"
                    required
                    value={sampleType}
                    onChange={(e) => setSampleType(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl glass-input text-xs text-white"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-slate-200 block mb-1">
                    Tariff Fee (₹)
                  </label>
                  <input
                    type="number"
                    required
                    value={fee}
                    onChange={(e) => setFee(Number(e.target.value))}
                    className="w-full px-3.5 py-2.5 rounded-xl glass-input text-xs text-white font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-200 block mb-1">
                  Clinical Indication / Technician Notes
                </label>
                <textarea
                  rows={2}
                  value={technicianNotes}
                  onChange={(e) => setTechnicianNotes(e.target.value)}
                  placeholder="Special instructions, fasting status, or clinical urgency..."
                  className="w-full p-3.5 rounded-xl glass-input text-xs text-white resize-none"
                />
              </div>

              <div className="pt-4 flex items-center justify-end gap-3 border-t border-purple-500/20">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2.5 rounded-xl glass-btn-secondary text-xs font-bold text-slate-200"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-purple-500 to-indigo-600 hover:from-purple-400 hover:to-indigo-500 text-white text-xs font-black shadow-[0_0_20px_rgba(168,85,247,0.35)] transition"
                >
                  Order Investigation
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
