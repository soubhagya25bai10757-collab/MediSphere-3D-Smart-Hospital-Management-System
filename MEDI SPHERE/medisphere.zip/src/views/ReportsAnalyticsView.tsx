import React, { useState } from 'react';
import { useHospital } from '../context/HospitalContext';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  AreaChart,
  Area,
} from 'recharts';
import {
  FileBarChart,
  Download,
  Printer,
  Calendar,
  Filter,
  FileSpreadsheet,
  TrendingUp,
  DollarSign,
  Users,
  BedDouble,
  CheckCircle2,
} from 'lucide-react';

export const ReportsAnalyticsView: React.FC = () => {
  const {
    patients = [],
    doctors = [],
    bills = [],
    beds = [],
    appointments = [],
    exportDataAsJSON,
  } = useHospital();

  const [dateRange, setDateRange] = useState<string>('This Month');
  const [reportType, setReportType] = useState<string>('Daily Hospital Summary');

  // Monthly Admission Trend data
  const admissionTrendData = [
    { month: 'Oct', admissions: 120, discharges: 110 },
    { month: 'Nov', admissions: 145, discharges: 130 },
    { month: 'Dec', admissions: 190, discharges: 165 },
    { month: 'Jan', admissions: 175, discharges: 170 },
    { month: 'Feb', admissions: 210, discharges: 195 },
    { month: 'Mar', admissions: 245, discharges: 220 },
  ];

  // Financial Ledger Data (₹ in Lakhs)
  const financialData = [
    { month: 'Oct', revenue: 42, expense: 28 },
    { month: 'Nov', revenue: 48, expense: 30 },
    { month: 'Dec', revenue: 61, expense: 35 },
    { month: 'Jan', revenue: 58, expense: 34 },
    { month: 'Feb', revenue: 72, expense: 38 },
    { month: 'Mar', revenue: 84, expense: 42 },
  ];

  // Department Clinical Workload
  const deptWorkload = [
    { name: 'Cardiology', value: 35, color: '#06b6d4' },
    { name: 'Neurology', value: 25, color: '#3b82f6' },
    { name: 'Orthopedics', value: 20, color: '#8b5cf6' },
    { name: 'Oncology', value: 12, color: '#ec4899' },
    { name: 'Pediatrics', value: 8, color: '#10b981' },
  ];

  // Top Diagnoses
  const topDiagnoses = [
    { diagnosis: 'Acute Coronary Syndrome', count: 48, trend: '+12%' },
    { diagnosis: 'Type 2 Diabetes Mellitus', count: 42, trend: '+5%' },
    { diagnosis: 'Ischemic Cerebrovascular Stroke', count: 28, trend: '-2%' },
    { diagnosis: 'Chronic Kidney Disease Stage 3', count: 24, trend: '+8%' },
    { diagnosis: 'Severe Bronchial Asthma Exacerbation', count: 19, trend: '-6%' },
  ];

  const handleExportCSV = (filename: string) => {
    // Generate simulated CSV export
    let csvContent = 'data:text/csv;charset=utf-8,';
    csvContent += 'ID,Date,Category,Metric_Value,Status\n';
    csvContent += 'HSP-01,2026-03-29,Admissions,245,Normal\n';
    csvContent += 'HSP-02,2026-03-29,Discharges,220,Normal\n';
    csvContent += 'HSP-03,2026-03-29,OPD_Consultations,412,Surge\n';
    csvContent += 'HSP-04,2026-03-29,Total_Revenue_INR,8400000,Audited\n';

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `${filename.toLowerCase().replace(/\s+/g, '_')}_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-black text-white tracking-tight">
              Reports & Executive Analytics
            </h1>
            <span className="text-xs font-mono px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
              Audit Ready
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Clinical throughput, financial ledger reconciliation, and department resource utilization.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl glass-input text-xs text-slate-200">
            <Calendar className="w-3.5 h-3.5 text-cyan-300" />
            <select
              value={dateRange}
              onChange={(e) => setDateRange(e.target.value)}
              className="bg-transparent outline-none cursor-pointer text-white font-semibold"
            >
              <option value="Today" className="bg-slate-950 text-white">Today</option>
              <option value="This Week" className="bg-slate-950 text-white">This Week</option>
              <option value="This Month" className="bg-slate-950 text-white">This Month</option>
              <option value="Quarter 1 (2026)" className="bg-slate-950 text-white">Quarter 1 (2026)</option>
              <option value="Fiscal Year 2025-26" className="bg-slate-950 text-white">Fiscal Year 2025-26</option>
            </select>
          </div>

          <button
            onClick={() => handleExportCSV('Executive_Hospital_Summary')}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-cyan-500/25 text-cyan-200 border border-cyan-500/50 hover:bg-cyan-500/35 text-xs font-black transition shadow-[0_0_15px_rgba(6,182,212,0.3)]"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export CSV</span>
          </button>
        </div>
      </div>

      {/* KPI Metric Strip */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="p-4 rounded-2xl glass-card border-cyan-500/30 shadow-lg">
          <span className="text-[10px] uppercase font-extrabold tracking-wider text-slate-300 block">Total Patients Enrolled</span>
          <div className="flex items-baseline gap-2 mt-1">
            <span className="text-2xl font-black text-white font-mono">{patients.length}</span>
            <span className="text-xs text-emerald-300 font-bold">+18% MoM</span>
          </div>
        </div>

        <div className="p-4 rounded-2xl glass-card border-blue-500/30 shadow-lg">
          <span className="text-[10px] uppercase font-extrabold tracking-wider text-slate-300 block">Active Specialists</span>
          <div className="flex items-baseline gap-2 mt-1">
            <span className="text-2xl font-black text-blue-300 font-mono">{doctors.length}</span>
            <span className="text-xs text-slate-300 font-medium">Across 8 Depts</span>
          </div>
        </div>

        <div className="p-4 rounded-2xl glass-card border-teal-500/30 shadow-lg">
          <span className="text-[10px] uppercase font-extrabold tracking-wider text-slate-300 block">Gross Revenue (MTD)</span>
          <div className="flex items-baseline gap-2 mt-1">
            <span className="text-2xl font-black text-teal-300 font-mono">₹84.2 L</span>
            <span className="text-xs text-emerald-300 font-bold">+24%</span>
          </div>
        </div>

        <div className="p-4 rounded-2xl glass-card border-purple-500/30 shadow-lg">
          <span className="text-[10px] uppercase font-extrabold tracking-wider text-slate-300 block">Bed Occupancy Rate</span>
          <div className="flex items-baseline gap-2 mt-1">
            <span className="text-2xl font-black text-purple-300 font-mono">82.4%</span>
            <span className="text-xs text-amber-300 font-bold">Optimal</span>
          </div>
        </div>
      </div>

      {/* Charts Row 1: Admissions Trend & Financial Revenue */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Admissions Trend */}
        <div className="p-5 rounded-3xl glass-card border-cyan-500/30 shadow-xl">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-extrabold text-white">Inpatient Admissions vs Discharges</h3>
              <span className="text-xs text-slate-300 font-medium">Monthly patient census turnover</span>
            </div>
            <div className="flex items-center gap-3 text-xs font-bold">
              <span className="flex items-center gap-1 text-cyan-300">
                <span className="w-2 h-2 rounded-full bg-cyan-400 shadow-[0_0_6px_#22d3ee]" /> Admissions
              </span>
              <span className="flex items-center gap-1 text-emerald-300">
                <span className="w-2 h-2 rounded-full bg-emerald-400 shadow-[0_0_6px_#34d399]" /> Discharges
              </span>
            </div>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={admissionTrendData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
                <XAxis dataKey="month" stroke="#94a3b8" fontSize={11} tickLine={false} />
                <YAxis stroke="#94a3b8" fontSize={11} tickLine={false} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#071330', borderColor: 'rgba(6,182,212,0.4)', borderRadius: '14px', fontSize: '12px', color: '#fff' }}
                />
                <Bar dataKey="admissions" fill="#06b6d4" radius={[6, 6, 0, 0]} />
                <Bar dataKey="discharges" fill="#10b981" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Financial Overview */}
        <div className="p-5 rounded-3xl glass-card border-teal-500/30 shadow-xl">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-extrabold text-white">Financial Ledger (₹ in Lakhs)</h3>
              <span className="text-xs text-slate-300 font-medium">Gross Clinical Revenue vs Operating Outflow</span>
            </div>
            <div className="flex items-center gap-3 text-xs font-bold">
              <span className="flex items-center gap-1 text-teal-300">
                <span className="w-2 h-2 rounded-full bg-teal-400 shadow-[0_0_6px_#2dd4bf]" /> Revenue
              </span>
              <span className="flex items-center gap-1 text-rose-300">
                <span className="w-2 h-2 rounded-full bg-rose-400 shadow-[0_0_6px_#fb7185]" /> Operating Cost
              </span>
            </div>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={financialData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorRev" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#14b8a6" stopOpacity={0.4} />
                    <stop offset="95%" stopColor="#14b8a6" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="colorExp" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#f43f5e" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#f43f5e" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
                <XAxis dataKey="month" stroke="#94a3b8" fontSize={11} tickLine={false} />
                <YAxis stroke="#94a3b8" fontSize={11} tickLine={false} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#071330', borderColor: 'rgba(20,184,166,0.4)', borderRadius: '14px', fontSize: '12px', color: '#fff' }}
                />
                <Area type="monotone" dataKey="revenue" stroke="#14b8a6" strokeWidth={2} fillOpacity={1} fill="url(#colorRev)" />
                <Area type="monotone" dataKey="expense" stroke="#f43f5e" strokeWidth={2} fillOpacity={1} fill="url(#colorExp)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Charts Row 2: Department Workload & Top Diagnoses */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Department Workload Donut */}
        <div className="p-5 rounded-3xl glass-card border-indigo-500/30 shadow-xl">
          <h3 className="text-sm font-extrabold text-white mb-1">Clinical Department Load</h3>
          <span className="text-xs text-slate-300 block mb-3 font-medium">Relative inpatient allocation</span>

          <div className="h-48 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={deptWorkload}
                  cx="50%"
                  cy="50%"
                  innerRadius={45}
                  outerRadius={70}
                  paddingAngle={4}
                  dataKey="value"
                >
                  {deptWorkload.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{ backgroundColor: '#071330', borderColor: 'rgba(99,102,241,0.4)', borderRadius: '14px', fontSize: '12px', color: '#fff' }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>

          <div className="grid grid-cols-2 gap-2 text-xs mt-2">
            {deptWorkload.map((item) => (
              <div key={item.name} className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-sm" style={{ backgroundColor: item.color }} />
                <span className="text-slate-200 text-[11px] truncate font-medium">
                  {item.name} ({item.value}%)
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Top Diagnoses Table */}
        <div className="p-5 rounded-3xl glass-card border-cyan-500/25 shadow-xl lg:col-span-2">
          <h3 className="text-sm font-extrabold text-white mb-1">Top Hospital Diagnoses</h3>
          <span className="text-xs text-slate-300 block mb-4 font-medium">Morbidity classification & monthly trends</span>

          <div className="divide-y divide-cyan-500/20 text-xs">
            {topDiagnoses.map((d, idx) => (
              <div key={idx} className="py-2.5 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <span className="font-mono text-cyan-400 font-bold w-5">0{idx + 1}</span>
                  <span className="text-white font-semibold">{d.diagnosis}</span>
                </div>
                <div className="flex items-center gap-4">
                  <span className="font-mono text-cyan-200 font-extrabold">{d.count} Cases</span>
                  <span
                    className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded ${
                      d.trend.startsWith('+')
                        ? 'bg-red-500/25 text-red-300 border border-red-500/40'
                        : 'bg-emerald-500/25 text-emerald-300 border border-emerald-500/40'
                    }`}
                  >
                    {d.trend}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Reports Generation Hub */}
      <div className="p-6 rounded-3xl glass-card border-cyan-500/30 shadow-2xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-cyan-500/20 pb-4 mb-4">
          <div>
            <h3 className="text-base font-extrabold text-white">Generate Structured Audit Reports</h3>
            <p className="text-xs text-slate-300 mt-0.5 font-medium">
              Exports comprehensive hospital records formatted for accreditation, statutory boards, and financial auditors.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
          <div className="p-4 rounded-2xl glass-card-subtle border border-cyan-500/20 flex flex-col justify-between">
            <div>
              <FileBarChart className="w-5 h-5 text-cyan-300 mb-2" />
              <h4 className="text-xs font-extrabold text-white">Daily Hospital Summary</h4>
              <p className="text-[11px] text-slate-300 mt-1 leading-snug font-medium">
                Admissions, surgeries performed, discharges, and ER triage log.
              </p>
            </div>
            <button
              onClick={() => handleExportCSV('Daily_Hospital_Summary')}
              className="mt-4 w-full py-2 rounded-xl text-xs font-bold bg-cyan-500/20 text-cyan-200 border border-cyan-500/40 hover:bg-cyan-500/30 transition flex items-center justify-center gap-1.5 shadow-[0_0_10px_rgba(6,182,212,0.2)]"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export Report</span>
            </button>
          </div>

          <div className="p-4 rounded-2xl glass-card-subtle border border-teal-500/20 flex flex-col justify-between">
            <div>
              <DollarSign className="w-5 h-5 text-teal-300 mb-2" />
              <h4 className="text-xs font-extrabold text-white">Financial Ledger & GST</h4>
              <p className="text-[11px] text-slate-300 mt-1 leading-snug font-medium">
                Itemized invoice transactions, tax brackets, and pending settlements.
              </p>
            </div>
            <button
              onClick={() => handleExportCSV('Financial_Ledger_Report')}
              className="mt-4 w-full py-2 rounded-xl text-xs font-bold bg-teal-500/20 text-teal-200 border border-teal-500/40 hover:bg-teal-500/30 transition flex items-center justify-center gap-1.5 shadow-[0_0_10px_rgba(20,184,166,0.2)]"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export Report</span>
            </button>
          </div>

          <div className="p-4 rounded-2xl glass-card-subtle border border-purple-500/20 flex flex-col justify-between">
            <div>
              <Users className="w-5 h-5 text-purple-300 mb-2" />
              <h4 className="text-xs font-extrabold text-white">Discharge Summaries</h4>
              <p className="text-[11px] text-slate-300 mt-1 leading-snug font-medium">
                Clinical discharge notes, recovery instructions, and follow-ups.
              </p>
            </div>
            <button
              onClick={() => handleExportCSV('Patient_Discharges_Audit')}
              className="mt-4 w-full py-2 rounded-xl text-xs font-bold bg-purple-500/20 text-purple-200 border border-purple-500/40 hover:bg-purple-500/30 transition flex items-center justify-center gap-1.5 shadow-[0_0_10px_rgba(168,85,247,0.2)]"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export Report</span>
            </button>
          </div>

          <div className="p-4 rounded-2xl glass-card-subtle border border-pink-500/20 flex flex-col justify-between">
            <div>
              <FileSpreadsheet className="w-5 h-5 text-pink-300 mb-2" />
              <h4 className="text-xs font-extrabold text-white">Formulary Stock Audit</h4>
              <p className="text-[11px] text-slate-300 mt-1 leading-snug font-medium">
                Batch movement, expiring pharmaceuticals, and reorder triggers.
              </p>
            </div>
            <button
              onClick={() => handleExportCSV('Pharmacy_Stock_Movement')}
              className="mt-4 w-full py-2 rounded-xl text-xs font-bold bg-pink-500/20 text-pink-200 border border-pink-500/40 hover:bg-pink-500/30 transition flex items-center justify-center gap-1.5 shadow-[0_0_10px_rgba(236,72,153,0.2)]"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export Report</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
