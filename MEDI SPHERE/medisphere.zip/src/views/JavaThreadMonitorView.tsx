import React, { useState } from 'react';
import { useHospital } from '../context/HospitalContext';
import { JavaThreadInfo } from '../types';
import {
  Cpu,
  Play,
  Pause,
  RotateCw,
  Lock,
  Unlock,
  ShieldCheck,
  Zap,
  Terminal,
  FileCode,
  CheckCircle2,
  AlertTriangle,
  Flame,
  Activity,
  Download,
  Upload,
} from 'lucide-react';

export const JavaThreadMonitorView: React.FC = () => {
  const {
    threads,
    pauseThread,
    resumeThread,
    triggerConcurrencyStressTest,
    systemLogs,
    exportDataAsJSON,
  } = useHospital();

  const [deadlockStatus, setDeadlockStatus] = useState<string | null>(null);
  const [isDetectingDeadlock, setIsDetectingDeadlock] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<'threads' | 'mutex' | 'io' | 'curriculum'>('threads');

  const locks = [
    {
      name: 'PatientDatabaseLock (ReentrantLock)',
      status: 'UNLOCKED',
      owner: 'None',
      waiters: 0,
      resource: 'MySQL table `patients` record level',
    },
    {
      name: 'BedAllocationMutex (synchronized)',
      status: 'LOCKED',
      owner: 'Thread-4 [BedSyncManager]',
      waiters: 2,
      resource: 'Memory shared ward grid bitset',
    },
    {
      name: 'BillingLedgerLock (ReadWriteLock.writeLock)',
      status: 'UNLOCKED',
      owner: 'None',
      waiters: 0,
      resource: 'Transaction journal buffer',
    },
    {
      name: 'PharmacyInventoryLock (AtomicInteger + CAS)',
      status: 'LOCKED',
      owner: 'Thread-6 [PharmacyDispenser]',
      waiters: 1,
      resource: 'Medicine SKU stock counter',
    },
  ];

  const handleRunDeadlockDetector = () => {
    setIsDetectingDeadlock(true);
    setDeadlockStatus('Tracing Thread Allocation Graph & Cycle Search (Tarjan/DFS)...');
    setTimeout(() => {
      setIsDetectingDeadlock(false);
      setDeadlockStatus('NO DEADLOCK DETECTED: 0 cycles detected across 8 active worker threads and 4 reentrant locks.');
    }, 1200);
  };

  const getThreadStateBadge = (state: JavaThreadInfo['state']) => {
    switch (state) {
      case 'RUNNABLE':
        return 'bg-emerald-500/20 text-emerald-400 border-emerald-500/40';
      case 'TIMED_WAITING':
        return 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40';
      case 'WAITING':
        return 'bg-blue-500/20 text-blue-300 border-blue-500/40';
      case 'BLOCKED':
        return 'bg-red-500/20 text-red-400 border-red-500/40 animate-pulse';
      case 'TERMINATED':
        return 'bg-slate-800 text-slate-400 border-slate-700';
      default:
        return 'bg-amber-500/20 text-amber-300 border-amber-500/40';
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-black text-white tracking-tight">
              System Runtime & Task Monitor
            </h1>
            <span className="text-xs font-mono px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
              System Services / Active Tasks
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Live telemetry of background worker tasks, resource lock synchronization, and data storage streams.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => triggerConcurrencyStressTest()}
            className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-red-950/60 border border-red-500/40 hover:bg-red-900/60 text-red-300 hover:text-white text-xs font-bold transition shadow-sm"
          >
            <Flame className="w-4 h-4 text-red-400" />
            Trigger Concurrency Stress Test
          </button>
        </div>
      </div>

      {/* Subnav Tabs */}
      <div className="flex items-center gap-2 border-b border-cyan-500/20 pb-3">
        {[
          { id: 'threads', label: 'Background Tasks', icon: Cpu },
          { id: 'mutex', label: 'Mutex & Synchronization', icon: Lock },
          { id: 'io', label: 'Data I/O & File Operations', icon: Terminal },
          { id: 'curriculum', label: 'Architecture & System Specs', icon: FileCode },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition ${
                isActive
                  ? 'bg-cyan-500/25 text-cyan-200 border border-cyan-500/50 shadow-[0_0_12px_rgba(6,182,212,0.3)]'
                  : 'text-slate-300 hover:text-white glass-btn-secondary'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* TAB 1: THREAD POOL EXECUTOR */}
      {activeTab === 'threads' && (
        <div className="space-y-6">
          {/* Thread Pool Telemetry Banner */}
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
            <div className="p-4 rounded-2xl glass-card border-cyan-500/25 shadow-lg">
              <span className="text-[10px] uppercase font-extrabold tracking-wider text-slate-300 block">Core Pool Size</span>
              <span className="text-2xl font-black text-white font-mono mt-1 block">8</span>
            </div>
            <div className="p-4 rounded-2xl glass-card border-cyan-500/25 shadow-lg">
              <span className="text-[10px] uppercase font-extrabold tracking-wider text-slate-300 block">Max Pool Limit</span>
              <span className="text-2xl font-black text-cyan-300 font-mono mt-1 block">16</span>
            </div>
            <div className="p-4 rounded-2xl glass-card border-emerald-500/30 shadow-lg">
              <span className="text-[10px] uppercase font-extrabold tracking-wider text-emerald-300 block">Active Threads</span>
              <span className="text-2xl font-black text-emerald-300 font-mono mt-1 block">
                {threads.filter((t) => t.state === 'RUNNABLE').length}
              </span>
            </div>
            <div className="p-4 rounded-2xl glass-card border-purple-500/30 shadow-lg">
              <span className="text-[10px] uppercase font-extrabold tracking-wider text-slate-300 block">LinkedBlockingQueue</span>
              <span className="text-2xl font-black text-purple-300 font-mono mt-1 block">14 / 100</span>
            </div>
            <div className="p-4 rounded-2xl glass-card border-cyan-500/25 shadow-lg">
              <span className="text-[10px] uppercase font-extrabold tracking-wider text-slate-300 block">Thread Factory</span>
              <span className="text-xs font-mono text-cyan-200 font-bold mt-2 block">HospitalWorkerGroup</span>
            </div>
          </div>

          {/* Threads List */}
          <div className="divide-y divide-cyan-500/20 border border-cyan-500/30 rounded-3xl glass-card overflow-hidden shadow-2xl">
            <div className="p-4 bg-[rgba(6,18,45,0.85)] flex items-center justify-between text-xs font-extrabold text-slate-300 border-b border-cyan-500/20">
              <span className="w-1/4">Thread Name & ID</span>
              <span className="w-1/6 text-center">State</span>
              <span className="w-1/4">Active Task</span>
              <span className="w-1/6 text-center">Progress / CPU</span>
              <span className="w-1/6 text-right">Interrupt Control</span>
            </div>

            {threads.map((th) => (
              <div
                key={th.id}
                className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:bg-cyan-500/10 transition text-xs"
              >
                <div className="w-full sm:w-1/4">
                  <div className="flex items-center gap-2">
                    <Cpu className="w-4 h-4 text-cyan-300" />
                    <span className="font-bold text-white">{th.name}</span>
                  </div>
                  <span className="text-[10px] font-mono text-slate-400 block mt-0.5 font-medium">
                    ID: {th.id} &bull; Priority: {th.priority} (NORM_PRIORITY)
                  </span>
                </div>

                <div className="w-full sm:w-1/6 flex sm:justify-center">
                  <span
                    className={`text-[10px] font-mono font-bold px-2.5 py-0.5 rounded-full border ${getThreadStateBadge(
                      th.state
                    )}`}
                  >
                    {th.state}
                  </span>
                </div>

                <div className="w-full sm:w-1/4">
                  <span className="text-slate-100 font-semibold block truncate">{th.taskName}</span>
                </div>

                <div className="w-full sm:w-1/6">
                  <div className="flex items-center justify-between text-[10px] font-mono text-slate-300 mb-1 font-semibold">
                    <span>{th.progress}%</span>
                    <span className="text-cyan-300">{th.cpuUsage}% CPU</span>
                  </div>
                  <div className="w-full h-1.5 rounded-full bg-slate-950 overflow-hidden border border-cyan-500/20">
                    <div
                      className="h-full bg-gradient-to-r from-cyan-400 to-blue-500 rounded-full transition-all duration-300 shadow-[0_0_8px_#22d3ee]"
                      style={{ width: `${th.progress}%` }}
                    />
                  </div>
                </div>

                <div className="w-full sm:w-1/6 flex sm:justify-end gap-2">
                  {th.state === 'RUNNABLE' ? (
                    <button
                      onClick={() => pauseThread(th.id)}
                      className="p-2 rounded-xl glass-btn-secondary text-amber-300 hover:text-white transition"
                      title="Pause (wait())"
                    >
                      <Pause className="w-3.5 h-3.5" />
                    </button>
                  ) : (
                    <button
                      onClick={() => resumeThread(th.id)}
                      className="p-2 rounded-xl glass-btn-secondary text-emerald-300 hover:text-white transition"
                      title="Resume (notify())"
                    >
                      <Play className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 2: MUTEX & SYNCHRONIZATION */}
      {activeTab === 'mutex' && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-5 rounded-2xl glass-card border-cyan-500/30">
            <div>
              <h3 className="text-sm font-extrabold text-white">ReentrantLock & Mutex Allocation</h3>
              <p className="text-xs text-slate-300 font-medium">
                Prevents race conditions on critical hospital sections (bed allocation, slot reservation).
              </p>
            </div>
            <button
              onClick={handleRunDeadlockDetector}
              disabled={isDetectingDeadlock}
              className="px-4 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-black transition flex items-center gap-2 shadow-[0_0_15px_rgba(6,182,212,0.3)]"
            >
              <ShieldCheck className="w-4 h-4" />
              <span>{isDetectingDeadlock ? 'Tracing Cycles...' : 'Run Deadlock Detector'}</span>
            </button>
          </div>

          {deadlockStatus && (
            <div className="p-4 rounded-2xl bg-emerald-950/40 border border-emerald-500/40 text-xs font-mono text-emerald-200 flex items-center gap-2 backdrop-blur-xl shadow-lg">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
              <span>{deadlockStatus}</span>
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {locks.map((lock, idx) => {
              const isLocked = lock.status === 'LOCKED';
              return (
                <div
                  key={idx}
                  className={`p-5 rounded-2xl border backdrop-blur-xl transition shadow-xl ${
                    isLocked
                      ? 'glass-card border-red-500/40'
                      : 'glass-card border-emerald-500/30'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      {isLocked ? (
                        <Lock className="w-4 h-4 text-red-400" />
                      ) : (
                        <Unlock className="w-4 h-4 text-emerald-400" />
                      )}
                      <span className="text-sm font-extrabold text-white">{lock.name}</span>
                    </div>
                    <span
                      className={`text-[10px] font-mono font-bold px-2 py-0.5 rounded ${
                        isLocked
                          ? 'bg-red-500/25 text-red-300 border border-red-500/40'
                          : 'bg-emerald-500/25 text-emerald-300 border border-emerald-500/40'
                      }`}
                    >
                      {lock.status}
                    </span>
                  </div>

                  <div className="mt-3 text-xs text-slate-200 space-y-1.5">
                    <div>
                      <span className="text-slate-400 text-[10px] uppercase font-bold block">
                        Guarded Resource:
                      </span>
                      <span className="font-semibold text-white">{lock.resource}</span>
                    </div>
                    <div className="flex justify-between pt-1 text-[11px]">
                      <span className="text-slate-300 font-medium">Lock Holding Owner:</span>
                      <span className="font-mono text-cyan-300 font-bold">{lock.owner}</span>
                    </div>
                    <div className="flex justify-between text-[11px]">
                      <span className="text-slate-300 font-medium">Blocked Waiting Threads:</span>
                      <span className="font-mono text-amber-300 font-bold">{lock.waiters} threads queued</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* TAB 3: JAVA I/O & AUDIT TRAIL */}
      {activeTab === 'io' && (
        <div className="space-y-6">
          <div className="p-5 rounded-3xl glass-card border-cyan-500/30 shadow-xl">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-cyan-500/20 pb-4 mb-4">
              <div>
                <h3 className="text-sm font-extrabold text-white">Java I/O Serialization & File Streams</h3>
                <p className="text-xs text-slate-300 font-medium">
                  Simulates `java.io.ObjectOutputStream` binary serialization & `BufferedReader`/`BufferedWriter`.
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={exportDataAsJSON}
                  className="px-3.5 py-2 rounded-xl bg-cyan-500/25 text-cyan-200 border border-cyan-500/50 hover:bg-cyan-500/35 text-xs font-black transition flex items-center gap-1.5 shadow-[0_0_12px_rgba(6,182,212,0.25)]"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Serialize State (ObjectOutputStream)</span>
                </button>
              </div>
            </div>

            {/* Simulated Log Output Stream */}
            <div className="p-4 rounded-2xl glass-card-subtle border border-cyan-500/20 font-mono text-xs text-slate-200 space-y-1.5 max-h-72 overflow-y-auto">
              <div className="text-cyan-400/80 pb-2 border-b border-cyan-500/20 font-bold">
                // System.out.println() streaming from hospital_event_bus.log
              </div>
              {systemLogs.map((log) => (
                <div key={log.id} className="flex items-start gap-2">
                  <span className="text-slate-400 text-[10px] font-semibold">{log.timestamp}</span>
                  <span
                    className={`text-[10px] px-1.5 py-0.5 rounded font-bold ${
                      log.type === 'ERROR'
                        ? 'bg-red-500/25 text-red-300 border border-red-500/40'
                        : log.type === 'WARN'
                        ? 'bg-amber-500/25 text-amber-300 border border-amber-500/40'
                        : 'bg-cyan-500/25 text-cyan-200 border border-cyan-500/40'
                    }`}
                  >
                    [{log.type}]
                  </span>
                  <span className="text-slate-200 font-medium">{log.message}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: JAVA CURRICULUM CONCEPT MAPPING */}
      {activeTab === 'curriculum' && (
        <div className="space-y-4">
          <div className="p-5 rounded-3xl glass-card border-cyan-500/30 shadow-xl">
            <h3 className="text-base font-extrabold text-white mb-1">
              Java Course Academic Mapping Reference
            </h3>
            <p className="text-xs text-slate-300 mb-4 font-medium">
              Detailed alignment of every MediSphere 3D module with official core Java syllabus concepts.
            </p>

            <div className="divide-y divide-cyan-500/20 text-xs">
              {[
                {
                  concept: 'Object-Oriented Programming (OOP)',
                  implementation: 'Abstract `Person` base class inherited by `Doctor`, `Patient`, `Staff`. Encapsulation with private attributes and getter/setter validation.',
                  classes: 'Person.java, Patient.java, Doctor.java, MedicalRecord.java',
                },
                {
                  concept: 'Java Collections Framework',
                  implementation: '`PriorityQueue<EmergencyCase>` for trauma triage, `HashMap<String, Doctor>` for O(1) slot lookups, `ArrayList<Appointment>` for daily registers.',
                  classes: 'TriageQueue.java, HospitalRegistry.java, BedManager.java',
                },
                {
                  concept: 'Multithreading & Thread States',
                  implementation: '`ThreadPoolExecutor` background workers for telemetry streams, lab analyzer simulations, and periodic bed occupancy recalculations.',
                  classes: 'TelemetryWorker.java, LabAnalyzerThread.java, ECGMonitorThread.java',
                },
                {
                  concept: 'Thread Synchronization & Mutex',
                  implementation: '`ReentrantLock` and `synchronized` blocks guarding bed allocations and double-booking prevention in appointment scheduling wizards.',
                  classes: 'AppointmentMutexLock.java, BedAllocationMutex.java',
                },
                {
                  concept: 'Custom Exception Handling',
                  implementation: 'Hierarchical checked exceptions: `DoctorUnavailableException`, `BedOccupiedException`, `InsufficientMedicineStockException`.',
                  classes: 'HospitalException.java, DoubleBookingException.java',
                },
                {
                  concept: 'Java I/O & Serialization',
                  implementation: '`ObjectOutputStream` binary serialization for hospital snapshot backups and `PrintWriter` for invoice/EHR report generation.',
                  classes: 'BackupSerializer.java, InvoiceReportWriter.java',
                },
                {
                  concept: 'JDBC & Relational Persistence',
                  implementation: '`PreparedStatement` parameterized queries, connection pooling (`HikariCP`), and ACID transaction commit/rollback logic.',
                  classes: 'DatabaseConnection.java, PatientDAO.java, BillDAO.java',
                },
              ].map((item, idx) => (
                <div key={idx} className="py-3.5 space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="font-extrabold text-cyan-300 text-sm">{item.concept}</span>
                    <span className="font-mono text-[10px] text-slate-200 bg-[rgba(6,18,45,0.75)] px-2.5 py-1 rounded-lg border border-cyan-500/25 font-semibold">
                      {item.classes}
                    </span>
                  </div>
                  <p className="text-slate-200 leading-relaxed font-medium">{item.implementation}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
