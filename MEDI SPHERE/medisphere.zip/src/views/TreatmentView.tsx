import React, { useState, useMemo } from 'react';
import { useHospital } from '../context/HospitalContext';
import { Treatment, TreatmentStatus } from '../types';
import {
  HeartPulse,
  Search,
  Filter,
  Plus,
  Calendar,
  User,
  Stethoscope,
  Pill,
  CheckCircle2,
  Clock,
  X,
  FileText,
} from 'lucide-react';

export const TreatmentView: React.FC = () => {
  const {
    treatments = [],
    patients = [],
    doctors = [],
    addTreatment,
    updateTreatmentStatus,
    searchQuery = '',
  } = useHospital();

  const [localSearch, setLocalSearch] = useState<string>('');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [showAddModal, setShowAddModal] = useState<boolean>(false);
  const [selectedTreatment, setSelectedTreatment] = useState<Treatment | null>(null);

  // Form states
  const [patientId, setPatientId] = useState<string>(patients[0]?.id || '');
  const [doctorId, setDoctorId] = useState<string>(doctors[0]?.id || '');
  const [diagnosis, setDiagnosis] = useState<string>('');
  const [treatmentName, setTreatmentName] = useState<string>('');
  const [startDate, setStartDate] = useState<string>('2026-03-29');
  const [endDate, setEndDate] = useState<string>('2026-04-20');
  const [instructions, setInstructions] = useState<string>('');
  const [medName, setMedName] = useState<string>('');
  const [dosage, setDosage] = useState<string>('1 tablet');
  const [frequency, setFrequency] = useState<string>('Twice daily after meals');
  const [duration, setDuration] = useState<string>('14 days');

  const filteredTreatments = useMemo(() => {
    const q = (localSearch || searchQuery || '').toLowerCase().trim();
    return (treatments || []).filter((t) => {
      if (!t) return false;
      const patientName = (t.patientName || '').toLowerCase();
      const trtName = (t.treatmentName || '').toLowerCase();
      const docName = (t.doctorName || '').toLowerCase();
      const diag = (t.diagnosis || '').toLowerCase();
      const matchQ =
        !q ||
        patientName.includes(q) ||
        trtName.includes(q) ||
        docName.includes(q) ||
        diag.includes(q);
      const matchStatus = statusFilter === 'ALL' || t.status === statusFilter;
      return matchQ && matchStatus;
    });
  }, [treatments, localSearch, searchQuery, statusFilter]);

  const handleAddTreatment = (e: React.FormEvent) => {
    e.preventDefault();
    const p = patients.find((pat) => pat.id === patientId);
    const d = doctors.find((doc) => doc.id === doctorId);
    if (!p || !d) return;

    addTreatment({
      patientId: p.id,
      patientName: p.name,
      doctorId: d.id,
      doctorName: d.name,
      diagnosis,
      treatmentName,
      endDate,
      status: 'Ongoing',
      instructions,
      medicines: [
        {
          id: `RX-${Date.now()}`,
          medicineName: medName || 'Standard therapeutic formulation',
          dosage,
          frequency,
          duration,
          instructions: instructions || 'Take as advised by physician.',
        },
      ],
      prescriptions: [
        {
          id: `RX-${Date.now()}`,
          medicineName: medName || 'Standard therapeutic formulation',
          dosage,
          frequency,
          duration,
          instructions: instructions || 'Take as advised by physician.',
        },
      ],
    });
    setShowAddModal(false);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-black text-white tracking-tight">Active Treatment Plans</h1>
            <span className="text-xs font-mono px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
              {treatments.length} Care Protocols
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Clinical therapeutic regimens, pharmacological dosing intervals, and patient recovery milestones.
          </p>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white text-xs font-bold transition shadow-lg shadow-cyan-500/20"
        >
          <Plus className="w-4 h-4" />
          Initiate Treatment Plan
        </button>
      </div>

      {/* Filter & Search */}
      <div className="p-4 rounded-2xl bg-slate-900/80 border border-cyan-500/20 backdrop-blur-xl flex items-center justify-between gap-3 shadow-lg">
        <div className="relative w-full max-w-md">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            type="text"
            placeholder="Search treatment, patient, diagnosis..."
            value={localSearch}
            onChange={(e) => setLocalSearch(e.target.value)}
            className="w-full pl-9 pr-4 py-2 text-xs rounded-xl bg-slate-950/80 border border-slate-800 focus:border-cyan-500/60 text-white placeholder-slate-500 outline-none"
          />
        </div>

        <div className="flex items-center gap-2">
          <Filter className="w-3.5 h-3.5 text-slate-400" />
          <span className="text-xs text-slate-400">Status:</span>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-2.5 py-1.5 rounded-lg bg-slate-950 border border-slate-800 text-xs text-white outline-none"
          >
            <option value="ALL">All Statuses</option>
            <option value="Ongoing">Ongoing</option>
            <option value="Completed">Completed</option>
            <option value="Paused">Paused</option>
          </select>
        </div>
      </div>

      {/* Treatments Grid */}
      {filteredTreatments.length === 0 ? (
        <div className="p-12 rounded-3xl bg-slate-900/60 border border-slate-800 text-center flex flex-col items-center justify-center">
          <HeartPulse className="w-10 h-10 text-cyan-400 mb-3 opacity-60 animate-pulse" />
          <h3 className="text-base font-bold text-white mb-1">No Active Protocols Found</h3>
          <p className="text-xs text-slate-400 max-w-md">
            No clinical treatment protocols match your active search query or status filter. Try clearing filters or initiate a new treatment plan.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredTreatments.map((trt) => {
            const rxList = (trt.prescriptions && trt.prescriptions.length > 0)
              ? trt.prescriptions
              : (trt.medicines || []);

            return (
              <div
                key={trt.id}
                className="p-5 rounded-2xl bg-slate-900/70 border border-cyan-500/20 backdrop-blur-xl hover:border-cyan-500/40 transition shadow-lg flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-950 text-cyan-300 border border-slate-800">
                        {trt.id}
                      </span>
                      <h3 className="text-base font-bold text-white mt-1.5">{trt.treatmentName}</h3>
                      <span className="text-xs text-slate-300 block mt-0.5">
                        Patient: <span className="text-white font-semibold">{trt.patientName}</span> &bull; Dr: {trt.doctorName}
                      </span>
                    </div>

                    <span
                      className={`text-[9px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wider ${
                        trt.status === 'Ongoing'
                          ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 animate-pulse'
                          : trt.status === 'Completed'
                          ? 'bg-slate-800 text-slate-400'
                          : 'bg-amber-500/20 text-amber-400 border border-amber-500/40'
                      }`}
                    >
                      {trt.status}
                    </span>
                  </div>

                  <div className="mt-3 p-3 rounded-xl bg-slate-950/60 border border-slate-800/80 text-xs text-slate-300 space-y-2">
                    <div>
                      <span className="text-[10px] uppercase font-bold text-slate-500 block">
                        Underlying Diagnosis:
                      </span>
                      <span>{trt.diagnosis}</span>
                    </div>
                    <div>
                      <span className="text-[10px] uppercase font-bold text-slate-500 block">
                        Timeline:
                      </span>
                      <span className="font-mono text-slate-400">
                        {trt.startDate} &rarr; {trt.endDate || 'Ongoing'}
                      </span>
                    </div>
                    {trt.instructions && (
                      <div>
                        <span className="text-[10px] uppercase font-bold text-slate-500 block">
                          Clinical Instructions:
                        </span>
                        <p className="text-slate-400 leading-relaxed">{trt.instructions}</p>
                      </div>
                    )}
                  </div>

                  {/* Prescriptions */}
                  <div className="mt-3 space-y-1.5">
                    <span className="text-[10px] uppercase font-bold text-slate-500 block">
                      Prescription Regimen:
                    </span>
                    {rxList.length > 0 ? (
                      rxList.map((rx, idx) => (
                        <div
                          key={rx.id || idx}
                          className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between text-xs"
                        >
                          <div className="flex items-center gap-2">
                            <Pill className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                            <div>
                              <span className="font-bold text-white block">{rx.medicineName}</span>
                              <span className="text-[10px] text-slate-400">
                                {rx.dosage} &bull; {rx.frequency}
                              </span>
                            </div>
                          </div>
                          <span className="text-[10px] font-mono text-cyan-300 px-2 py-0.5 rounded bg-slate-900 border border-cyan-500/20">
                            {rx.duration}
                          </span>
                        </div>
                      ))
                    ) : (
                      <div className="p-2.5 rounded-xl bg-slate-950/50 border border-slate-800/60 text-slate-500 text-xs italic">
                        No active pharmacological medications recorded
                      </div>
                    )}
                  </div>
                </div>

                <div className="mt-4 pt-3 border-t border-slate-800 flex items-center justify-between">
                  <span className="text-[10px] text-slate-500">Update Protocol State:</span>
                  <div className="flex items-center gap-1.5">
                    {trt.status !== 'Completed' && (
                      <button
                        onClick={() => updateTreatmentStatus(trt.id, 'Completed')}
                        className="px-2.5 py-1 rounded-lg text-[10px] font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 hover:bg-emerald-500/30 transition"
                      >
                        Mark Completed
                      </button>
                    )}
                    {trt.status === 'Ongoing' && (
                      <button
                        onClick={() => updateTreatmentStatus(trt.id, 'Paused')}
                        className="px-2.5 py-1 rounded-lg text-[10px] font-bold bg-amber-500/20 text-amber-400 border border-amber-500/40 hover:bg-amber-500/30 transition"
                      >
                        Pause Protocol
                      </button>
                    )}
                    {trt.status === 'Paused' && (
                      <button
                        onClick={() => updateTreatmentStatus(trt.id, 'Ongoing')}
                        className="px-2.5 py-1 rounded-lg text-[10px] font-bold bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 hover:bg-cyan-500/30 transition"
                      >
                        Resume Protocol
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Initiate Treatment Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-2xl animate-in fade-in">
          <div className="relative w-full max-w-2xl rounded-3xl bg-slate-900 border border-cyan-500/30 p-6 shadow-2xl overflow-y-auto max-h-[90vh]">
            <button
              onClick={() => setShowAddModal(false)}
              className="absolute top-5 right-5 p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800"
            >
              <X className="w-5 h-5" />
            </button>

            <h2 className="text-lg font-bold text-white mb-1">Initiate Clinical Treatment Protocol</h2>
            <p className="text-xs text-slate-400 mb-6">
              Binds diagnosis, therapy protocol, and drug prescriptions into persistent care plan.
            </p>

            <form onSubmit={handleAddTreatment} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1">Patient</label>
                  <select
                    value={patientId}
                    onChange={(e) => setPatientId(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white outline-none focus:border-cyan-500"
                  >
                    {(patients || []).map((p) => (
                      <option key={p.id} value={p.id}>
                        {p.name} ({p.id})
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1">
                    Supervising Physician
                  </label>
                  <select
                    value={doctorId}
                    onChange={(e) => setDoctorId(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white outline-none focus:border-cyan-500"
                  >
                    {(doctors || []).map((d) => (
                      <option key={d.id} value={d.id}>
                        {d.name} ({d.specialization})
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1">
                    Treatment / Protocol Name
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Post-Myocardial Infarction Rehabilitation"
                    value={treatmentName}
                    onChange={(e) => setTreatmentName(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white outline-none focus:border-cyan-500"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1">
                    Diagnosis
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Acute Coronary Syndrome (STEMI)"
                    value={diagnosis}
                    onChange={(e) => setDiagnosis(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white outline-none focus:border-cyan-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1">
                    Protocol Start Date
                  </label>
                  <input
                    type="date"
                    required
                    value={startDate}
                    onChange={(e) => setStartDate(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white outline-none focus:border-cyan-500"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1">
                    Target End Date
                  </label>
                  <input
                    type="date"
                    required
                    value={endDate}
                    onChange={(e) => setEndDate(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white outline-none focus:border-cyan-500"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1">
                  Clinical Directives / Nursing Instructions
                </label>
                <textarea
                  rows={2}
                  required
                  placeholder="Daily vital logs, diet restrictions, telemetry monitoring guidelines..."
                  value={instructions}
                  onChange={(e) => setInstructions(e.target.value)}
                  className="w-full p-3 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white outline-none focus:border-cyan-500"
                />
              </div>

              {/* Primary Drug Formulation */}
              <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-3">
                <span className="text-[10px] uppercase font-bold text-cyan-400 block">
                  Primary Pharmacological Prescription:
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="text-[10px] text-slate-400 block mb-0.5">Medicine Name</label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Clopidogrel 75mg"
                      value={medName}
                      onChange={(e) => setMedName(e.target.value)}
                      className="w-full px-2.5 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-xs text-white"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] text-slate-400 block mb-0.5">Dosage</label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. 1 tablet"
                      value={dosage}
                      onChange={(e) => setDosage(e.target.value)}
                      className="w-full px-2.5 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-xs text-white"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] text-slate-400 block mb-0.5">Frequency</label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. Once daily after lunch"
                      value={frequency}
                      onChange={(e) => setFrequency(e.target.value)}
                      className="w-full px-2.5 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-xs text-white"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] text-slate-400 block mb-0.5">Duration</label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. 30 days"
                      value={duration}
                      onChange={(e) => setDuration(e.target.value)}
                      className="w-full px-2.5 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-xs text-white"
                    />
                  </div>
                </div>
              </div>

              <div className="pt-4 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-xs font-semibold text-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white text-xs font-bold shadow-lg shadow-cyan-500/20"
                >
                  Authorize Care Plan
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
