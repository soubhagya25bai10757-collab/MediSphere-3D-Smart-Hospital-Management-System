import React, { useState, useMemo } from 'react';
import { useHospital } from '../context/HospitalContext';
import { Bed, BedStatus, WardType } from '../types';
import {
  BedDouble,
  Filter,
  Search,
  User,
  CheckCircle2,
  AlertTriangle,
  RotateCw,
  X,
  Layers,
  Activity,
  Plus,
} from 'lucide-react';

export const BedManagementView: React.FC = () => {
  const {
    beds,
    allocateBed,
    vacateBed,
    updateBedStatus,
    patients,
  } = useHospital();

  const [selectedWard, setSelectedWard] = useState<string>('ALL');
  const [selectedStatus, setSelectedStatus] = useState<string>('ALL');

  // Allocate bed modal
  const [selectedBedForAlloc, setSelectedBedForAlloc] = useState<Bed | null>(null);
  const [allocPatientId, setAllocPatientId] = useState<string>(patients[0]?.id || '');

  const wardTypes: WardType[] = ['ICU', 'Emergency', 'General Ward', 'Private', 'Semi-Private'];

  // Ward calculations
  const totalBeds = beds.length;
  const occupiedBeds = beds.filter((b) => b.status === 'Occupied').length;
  const availableBeds = beds.filter((b) => b.status === 'Available').length;
  const maintenanceBeds = beds.filter((b) => b.status === 'Maintenance').length;
  const reservedBeds = beds.filter((b) => b.status === 'Reserved').length;
  const occupancyPercentage = Math.round((occupiedBeds / (totalBeds || 1)) * 100);

  const filteredBeds = useMemo(() => {
    return beds.filter((b) => {
      const matchWard = selectedWard === 'ALL' || b.wardType === selectedWard;
      const matchStatus = selectedStatus === 'ALL' || b.status === selectedStatus;
      return matchWard && matchStatus;
    });
  }, [beds, selectedWard, selectedStatus]);

  const handleAllocate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedBedForAlloc) return;
    const pat = patients.find((p) => p.id === allocPatientId);
    if (!pat) return;

    allocateBed(selectedBedForAlloc.id, pat.id, pat.name);
    setSelectedBedForAlloc(null);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-black text-white tracking-tight">Inpatient Bed Grid</h1>
            <span className="text-xs font-mono px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
              {availableBeds} / {totalBeds} Available
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Ward & floor telemetry, oxygen delivery points, and synchronized patient bed allocations.
          </p>
        </div>
      </div>

      {/* Ward Occupancy Telemetry Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
        <div className="p-4 rounded-2xl glass-card border-cyan-500/30 shadow-lg">
          <span className="text-[10px] text-slate-300 uppercase font-extrabold tracking-wider block">Hospital Occupancy</span>
          <div className="flex items-baseline gap-2 mt-1">
            <span className="text-2xl font-black text-white font-mono">{occupancyPercentage}%</span>
            <span className="text-[10px] text-cyan-300 font-bold">{occupiedBeds} occupied</span>
          </div>
        </div>

        <div className="p-4 rounded-2xl glass-card border-emerald-500/40 shadow-lg">
          <span className="text-[10px] text-emerald-300 uppercase font-extrabold tracking-wider block">Available Ready</span>
          <div className="flex items-baseline gap-2 mt-1">
            <span className="text-2xl font-black text-emerald-300 font-mono">{availableBeds}</span>
            <span className="text-[10px] text-slate-300 font-medium">Sanitized</span>
          </div>
        </div>

        <div className="p-4 rounded-2xl glass-card border-red-500/40 shadow-lg">
          <span className="text-[10px] text-red-300 uppercase font-extrabold tracking-wider block">Active Inpatients</span>
          <div className="flex items-baseline gap-2 mt-1">
            <span className="text-2xl font-black text-red-300 font-mono">{occupiedBeds}</span>
            <span className="text-[10px] text-slate-300 font-medium">Occupied</span>
          </div>
        </div>

        <div className="p-4 rounded-2xl glass-card border-amber-500/40 shadow-lg">
          <span className="text-[10px] text-amber-300 uppercase font-extrabold tracking-wider block">Reserved Beds</span>
          <div className="flex items-baseline gap-2 mt-1">
            <span className="text-2xl font-black text-amber-300 font-mono">{reservedBeds}</span>
            <span className="text-[10px] text-slate-300 font-medium">Admissions</span>
          </div>
        </div>

        <div className="p-4 rounded-2xl glass-card border-slate-700/60 shadow-lg">
          <span className="text-[10px] text-slate-300 uppercase font-extrabold tracking-wider block">Maintenance</span>
          <div className="flex items-baseline gap-2 mt-1">
            <span className="text-2xl font-black text-slate-200 font-mono">{maintenanceBeds}</span>
            <span className="text-[10px] text-slate-400 font-medium">Sanitizing</span>
          </div>
        </div>
      </div>

      {/* Ward Filter Tabs */}
      <div className="p-4 rounded-2xl glass-card border-cyan-500/30 flex flex-wrap items-center justify-between gap-3 shadow-xl">
        <div className="flex flex-wrap items-center gap-1.5">
          <button
            onClick={() => setSelectedWard('ALL')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition ${
              selectedWard === 'ALL'
                ? 'bg-cyan-500/25 text-cyan-200 border border-cyan-500/50 shadow-[0_0_12px_rgba(6,182,212,0.3)]'
                : 'text-slate-300 hover:text-white hover:bg-[rgba(6,18,45,0.6)]'
            }`}
          >
            All Wards
          </button>
          {wardTypes.map((w) => (
            <button
              key={w}
              onClick={() => setSelectedWard(w)}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition ${
                selectedWard === w
                  ? 'bg-cyan-500/25 text-cyan-200 border border-cyan-500/50 shadow-[0_0_12px_rgba(6,182,212,0.3)]'
                  : 'text-slate-300 hover:text-white hover:bg-[rgba(6,18,45,0.6)]'
              }`}
            >
              {w}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-2">
          <Filter className="w-3.5 h-3.5 text-cyan-300" />
          <span className="text-xs text-slate-300 font-bold">Bed State:</span>
          <select
            value={selectedStatus}
            onChange={(e) => setSelectedStatus(e.target.value)}
            className="px-3 py-1.5 rounded-xl glass-input text-xs text-white cursor-pointer"
          >
            <option value="ALL" className="bg-slate-950 text-white">All States</option>
            <option value="Available" className="bg-slate-950 text-emerald-300">Available Only</option>
            <option value="Occupied" className="bg-slate-950 text-red-300">Occupied Only</option>
            <option value="Reserved" className="bg-slate-950 text-amber-300">Reserved</option>
            <option value="Maintenance" className="bg-slate-950 text-slate-300">Maintenance</option>
          </select>
        </div>
      </div>

      {/* Visual Bed Grid (Tiles) */}
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3">
        {filteredBeds.map((bed) => {
          const isAvailable = bed.status === 'Available';
          const isOccupied = bed.status === 'Occupied';
          const isReserved = bed.status === 'Reserved';

          return (
            <div
              key={bed.id}
              className={`p-4 rounded-2xl glass-card transition-all hover:-translate-y-1 shadow-xl flex flex-col justify-between ${
                isAvailable
                  ? 'border-emerald-500/40 hover:border-emerald-400/70 shadow-[0_0_15px_rgba(16,185,129,0.15)]'
                  : isOccupied
                  ? 'border-red-500/40 hover:border-red-400/70 shadow-[0_0_15px_rgba(239,68,68,0.15)]'
                  : isReserved
                  ? 'border-amber-500/40 hover:border-amber-400/70 shadow-[0_0_15px_rgba(245,158,11,0.15)]'
                  : 'border-slate-700/60'
              }`}
            >
              <div>
                <div className="flex items-center justify-between">
                  <span className="text-sm font-black font-mono text-white tracking-wider">
                    {bed.bedNumber}
                  </span>
                  <div
                    className={`w-2.5 h-2.5 rounded-full shadow-[0_0_8px_currentColor] ${
                      isAvailable
                        ? 'bg-emerald-400 text-emerald-400'
                        : isOccupied
                        ? 'bg-red-400 text-red-400 animate-pulse'
                        : isReserved
                        ? 'bg-amber-400 text-amber-400'
                        : 'bg-slate-500 text-slate-500'
                    }`}
                  />
                </div>

                <span className="text-[10px] text-cyan-300 font-extrabold block mt-1">
                  {bed.wardType} &bull; Fl.{bed.floor}
                </span>

                <div className="mt-3 text-xs">
                  {isOccupied ? (
                    <div className="p-2 rounded-xl glass-card-subtle">
                      <span className="text-[9px] uppercase font-bold text-slate-300 block">
                        Patient:
                      </span>
                      <span className="font-extrabold text-white block truncate">
                        {bed.patientName}
                      </span>
                      <span className="text-[10px] font-mono text-slate-300 block mt-0.5">
                        Since: {bed.admissionDate}
                      </span>
                    </div>
                  ) : (
                    <div className="py-2">
                      <span className="text-[11px] text-slate-300 italic font-medium">
                        {bed.status === 'Maintenance' ? 'Under Sanitize' : 'Ready for Patient'}
                      </span>
                    </div>
                  )}
                </div>
              </div>

              {/* Action buttons */}
              <div className="mt-4 pt-2.5 border-t border-cyan-500/20">
                {isAvailable && (
                  <button
                    onClick={() => setSelectedBedForAlloc(bed)}
                    className="w-full py-1.5 rounded-xl text-[10px] font-black bg-emerald-600 hover:bg-emerald-500 text-white transition shadow-[0_0_10px_rgba(16,185,129,0.3)]"
                  >
                    Allocate Bed
                  </button>
                )}

                {isOccupied && (
                  <button
                    onClick={() => vacateBed(bed.id)}
                    className="w-full py-1.5 rounded-xl text-[10px] font-bold glass-btn-secondary text-slate-200 hover:text-white transition"
                  >
                    Vacate / Discharge
                  </button>
                )}

                {(isReserved || bed.status === 'Maintenance') && (
                  <button
                    onClick={() => updateBedStatus(bed.id, 'Available')}
                    className="w-full py-1.5 rounded-xl text-[10px] font-bold glass-btn-secondary text-emerald-300 hover:text-white transition"
                  >
                    Mark Ready
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Allocate Bed Modal */}
      {selectedBedForAlloc && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-2xl animate-in fade-in">
          <div className="relative w-full max-w-md rounded-3xl glass-modal border-cyan-500/40 p-6 shadow-2xl">
            <button
              onClick={() => setSelectedBedForAlloc(null)}
              className="absolute top-5 right-5 p-2 rounded-xl text-slate-300 hover:text-white hover:bg-[rgba(6,18,45,0.7)] border border-cyan-500/20 transition"
            >
              <X className="w-5 h-5" />
            </button>

            <h3 className="text-base font-extrabold text-white mb-1">
              Allocate Bed {selectedBedForAlloc.bedNumber}
            </h3>
            <p className="text-xs text-slate-300 mb-4 font-medium">
              Ward: <strong className="text-white">{selectedBedForAlloc.wardType}</strong> &bull; Floor <strong className="text-white">{selectedBedForAlloc.floor}</strong>
            </p>

            <form onSubmit={handleAllocate} className="space-y-4 text-xs">
              <div>
                <label className="text-slate-200 font-bold block mb-1">Select Patient to Admit</label>
                <select
                  value={allocPatientId}
                  onChange={(e) => setAllocPatientId(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl glass-input text-white cursor-pointer"
                >
                  {patients.map((p) => (
                    <option key={p.id} value={p.id} className="bg-slate-950 text-white">
                      {p.name} ({p.id}) - {p.currentStatus}
                    </option>
                  ))}
                </select>
              </div>

              <div className="pt-3 flex items-center justify-end gap-3 border-t border-cyan-500/20">
                <button
                  type="button"
                  onClick={() => setSelectedBedForAlloc(null)}
                  className="px-4 py-2.5 rounded-xl glass-btn-secondary text-slate-200 hover:text-white font-bold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-black shadow-[0_0_15px_rgba(16,185,129,0.35)] transition"
                >
                  Confirm Allocation
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
