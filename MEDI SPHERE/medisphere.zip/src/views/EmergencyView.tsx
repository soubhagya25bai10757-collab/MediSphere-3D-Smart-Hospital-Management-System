import React, { useState } from 'react';
import { useHospital } from '../context/HospitalContext';
import { EmergencyCase, EmergencyPriority, EmergencyHistoryRecord } from '../types';
import {
  Flame,
  Activity,
  Plus,
  Radio,
  CheckCircle2,
  Bell,
  X,
  Stethoscope,
  Clock,
} from 'lucide-react';
import { ErrorBoundary } from '../components/ErrorBoundary';
import {
  INITIAL_EMERGENCY_DOCTORS,
  INITIAL_AMBULANCES,
  INITIAL_EMERGENCY_ACTIVITIES,
  INITIAL_EMERGENCY_HISTORY,
  EmergencyDoctor,
  AmbulanceUnit,
  EmergencyActivityEvent,
} from '../data/emergencyData';
import { EmergencyDashboardTab } from '../components/emergency/EmergencyDashboardTab';
import { EmergencyPriorityQueueTab } from '../components/emergency/EmergencyPriorityQueueTab';
import { EmergencyActiveCasesTab } from '../components/emergency/EmergencyActiveCasesTab';
import { EmergencyDoctorsTab } from '../components/emergency/EmergencyDoctorsTab';
import { EmergencyHistoryTab } from '../components/emergency/EmergencyHistoryTab';
import {
  IngestEmergencyCaseModal,
  CaseDetailsModal,
  AssignDoctorModal,
  UpdateCaseStatusModal,
  ViewPatientModal,
  DoctorAssignToCaseModal,
  HistoricalCaseModal,
  AssignBedModal,
} from '../components/emergency/EmergencyModals';

export const EmergencyView: React.FC = () => {
  const {
    emergencyCases,
    addEmergencyCase,
    updateEmergencyPriority,
    assignEmergencyDoctor,
    assignEmergencyBed,
    markEmergencyTreated,
    activeSubTab,
    setActiveNavigation,
  } = useHospital();

  const currentTab = ['dashboard', 'queue', 'active', 'doctors', 'history'].includes(activeSubTab)
    ? activeSubTab
    : 'dashboard';

  // Live state for emergency doctors, ambulances, history & activities
  const [doctors, setDoctors] = useState<EmergencyDoctor[]>(INITIAL_EMERGENCY_DOCTORS);
  const [historyRecords, setHistoryRecords] = useState<EmergencyHistoryRecord[]>(INITIAL_EMERGENCY_HISTORY);
  const [ambulances] = useState<AmbulanceUnit[]>(INITIAL_AMBULANCES);
  const [activities, setActivities] = useState<EmergencyActivityEvent[]>(INITIAL_EMERGENCY_ACTIVITIES);

  // Toast notification state
  const [toastMessage, setToastMessage] = useState<{ title: string; desc: string; type?: 'info' | 'success' | 'alert' } | null>(null);

  const showToast = (title: string, desc: string, type: 'info' | 'success' | 'alert' = 'success') => {
    setToastMessage({ title, desc, type });
    setTimeout(() => {
      setToastMessage((prev) => (prev?.title === title ? null : prev));
    }, 4500);
  };

  // Modals state
  const [showIngestModal, setShowIngestModal] = useState<boolean>(false);
  const [selectedCaseForDetails, setSelectedCaseForDetails] = useState<EmergencyCase | null>(null);
  const [selectedCaseForAssignDoctor, setSelectedCaseForAssignDoctor] = useState<EmergencyCase | null>(null);
  const [selectedCaseForUpdateStatus, setSelectedCaseForUpdateStatus] = useState<EmergencyCase | null>(null);
  const [selectedPatientForProfile, setSelectedPatientForProfile] = useState<{
    name: string;
    age?: number;
    gender?: string;
  } | null>(null);
  const [selectedDoctorForAssign, setSelectedDoctorForAssign] = useState<EmergencyDoctor | null>(null);
  const [selectedHistoryRecord, setSelectedHistoryRecord] = useState<EmergencyHistoryRecord | null>(null);
  const [selectedCaseForAssignBed, setSelectedCaseForAssignBed] = useState<EmergencyCase | null>(null);

  // Partition queue vs active cases
  // Queue: no doctor assigned, or in triage status, or awaiting assessment
  const queueCases = emergencyCases.filter(
    (c) =>
      !c.assignedDoctorName ||
      c.status === 'Triage' ||
      c.treatmentStatus === 'Awaiting Assessment'
  );

  // Active: has doctor assigned and is under treatment / observation / ready for transfer
  const activeCases = emergencyCases.filter(
    (c) =>
      c.assignedDoctorName &&
      c.status !== 'Triage' &&
      c.treatmentStatus !== 'Awaiting Assessment'
  );

  // Handlers
  const handleIngestCase = (newCaseData: any) => {
    addEmergencyCase({
      patientName: newCaseData.patientName,
      age: newCaseData.age,
      gender: newCaseData.gender,
      emergencyType: newCaseData.emergencyType,
      priority: newCaseData.priority,
      chiefComplaint: newCaseData.chiefComplaint,
      assignedDepartment: newCaseData.assignedDepartment,
      treatmentStatus: 'Awaiting Assessment',
      durationMinutes: 0,
      vitals: newCaseData.vitals,
    });

    const nowStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    setActivities((prev) => [
      {
        id: `ACT-${Date.now()}`,
        time: nowStr,
        type: newCaseData.priority === 'Critical' ? 'CODE_RED' : 'TRIAGE_INGEST',
        title: `${newCaseData.patientName} Enqueued (${newCaseData.emergencyType})`,
        description: `Ingested to Emergency Priority Queue with ${newCaseData.priority} acuity. Vitals: HR ${newCaseData.vitals.heartRate}, BP ${newCaseData.vitals.bloodPressure}.`,
        actor: 'Triage Officer',
        priority: newCaseData.priority,
      },
      ...prev,
    ]);

    showToast(
      'Case Enqueued in Emergency Triage',
      `${newCaseData.patientName} entered queue as ${newCaseData.priority} priority.`,
      newCaseData.priority === 'Critical' ? 'alert' : 'info'
    );
  };

  const handleAssignDoctor = (caseId: string, doctorId: string, doctorName: string) => {
    // 1. Assign in hospital context
    assignEmergencyDoctor(caseId, doctorId, doctorName);

    // 2. Update doctor roster state (increment case count & set ON CASE)
    setDoctors((prev) =>
      prev.map((d) =>
        d.id === doctorId
          ? {
              ...d,
              currentStatus: 'ON CASE',
              emergencyCasesAssigned: d.emergencyCasesAssigned + 1,
            }
          : d
      )
    );

    // 3. Find the patient name for activities & toast
    const targetCase = emergencyCases.find((c) => c.id === caseId);
    const patientName = targetCase ? targetCase.patientName : 'Patient';

    const nowStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    setActivities((prev) => [
      {
        id: `ACT-${Date.now()}`,
        time: nowStr,
        type: 'BED_ASSIGNED',
        title: `${doctorName} Assigned to ${patientName}`,
        description: `Case moved from Priority Queue to Active Care bay. Treatment protocol activated.`,
        actor: doctorName,
        priority: targetCase?.priority,
      },
      ...prev,
    ]);

    showToast(
      'Emergency Doctor Dispatched',
      `${doctorName} has taken charge of ${patientName}. Case advanced to Active Cases.`,
      'success'
    );
  };

  const handleAssignBed = (caseId: string, bedId: string, bedNumber: string) => {
    assignEmergencyBed(caseId, bedId, bedNumber);
    const targetCase = emergencyCases.find((c) => c.id === caseId);
    const patientName = targetCase ? targetCase.patientName : 'Patient';

    const nowStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    setActivities((prev) => [
      {
        id: `ACT-${Date.now()}`,
        time: nowStr,
        type: 'BED_ASSIGNED',
        title: `Bed ${bedNumber} Allocated`,
        description: `${patientName} transferred to ${bedNumber} (${bedId}). Equipment telemetry connected.`,
        actor: 'Charge Nurse',
        priority: targetCase?.priority,
      },
      ...prev,
    ]);

    showToast(
      'Bed Allocated',
      `${patientName} assigned to ${bedNumber}.`,
      'success'
    );
  };

  const handleUpdateStatus = (
    caseId: string,
    newStatus: string,
    disposition?: string,
    archiveToHistory?: boolean
  ) => {
    const targetCase = emergencyCases.find((c) => c.id === caseId);
    if (!targetCase) return;

    if (archiveToHistory) {
      // 1. Mark treated / remove from active cases
      markEmergencyTreated(caseId);

      // 2. Archive to history
      const nowStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
      const newHistoryRecord: EmergencyHistoryRecord = {
        id: `ER-HIST-${Math.floor(100 + Math.random() * 900)}`,
        patientName: targetCase.patientName,
        patientId: targetCase.patientId || `PAT-${Math.floor(1000 + Math.random() * 9000)}`,
        emergencyType: targetCase.emergencyType || 'Acute Emergency',
        priority: targetCase.priority,
        arrivalTime: targetCase.arrivalTime,
        treatmentStart: targetCase.arrivalTime,
        treatmentEnd: nowStr,
        assignedDoctor: targetCase.assignedDoctorName || 'Emergency Physician',
        doctorId: targetCase.assignedDoctorId,
        finalStatus: (newStatus === 'Under Treatment' || newStatus === 'Observation' || newStatus === 'Ready for Transfer'
          ? 'Stabilized'
          : newStatus) as any,
        disposition: disposition || `Resolved: ${newStatus}`,
        date: 'Today',
        summary: `Emergency care completed. Patient was presented with "${targetCase.chiefComplaint}". Successfully stabilized and disposition resolved.`,
        dischargeVitals: targetCase.vitals
          ? {
              bloodPressure: targetCase.vitals.bloodPressure,
              heartRate: targetCase.vitals.heartRate,
              oxygenSaturation: targetCase.vitals.oxygenSaturation,
              temperature: targetCase.vitals.temperature,
              respiratoryRate: targetCase.vitals.respiratoryRate || 16,
            }
          : undefined,
        interventions: [
          'Immediate Bedside Triage Evaluation',
          'Continuous Telemetry & ECG Monitoring',
          'IV Access & Hemodynamic Stabilization',
          'Physician Clinical Clearance',
        ],
      };

      setHistoryRecords((prev) => [newHistoryRecord, ...prev]);

      // 3. Decrement doctor's active cases count if assigned
      if (targetCase.assignedDoctorId) {
        setDoctors((prev) =>
          prev.map((d) =>
            d.id === targetCase.assignedDoctorId
              ? {
                  ...d,
                  emergencyCasesAssigned: Math.max(0, d.emergencyCasesAssigned - 1),
                  currentStatus: d.emergencyCasesAssigned <= 1 ? 'AVAILABLE' : d.currentStatus,
                }
              : d
          )
        );
      }

      // 4. Add activity log
      setActivities((prev) => [
        {
          id: `ACT-${Date.now()}`,
          time: nowStr,
          type: 'STABILIZED',
          title: `${targetCase.patientName} ${newStatus}`,
          description: disposition || `Case concluded and archived to Emergency History.`,
          actor: targetCase.assignedDoctorName || 'Attending Physician',
          priority: targetCase.priority,
        },
        ...prev,
      ]);

      showToast(
        `Case ${newStatus}`,
        `${targetCase.patientName} has been archived to Emergency History.`,
        'success'
      );
    } else {
      // Just update treatment status in place
      targetCase.treatmentStatus = newStatus as any;
      targetCase.status = 'In Treatment';

      showToast(
        'Treatment Status Updated',
        `${targetCase.patientName}'s clinical status set to ${newStatus}.`,
        'info'
      );
    }
  };

  const handleUpdatePriority = (caseId: string, newPriority: EmergencyPriority) => {
    updateEmergencyPriority(caseId, newPriority);
    const targetCase = emergencyCases.find((c) => c.id === caseId);
    if (targetCase) {
      targetCase.priority = newPriority;
    }

    showToast(
      'Priority Reclassified',
      `Case ${caseId} updated to ${newPriority} priority.`,
      newPriority === 'Critical' ? 'alert' : 'info'
    );
  };

  const handlePageDoctor = (doctorName: string, caseId?: string) => {
    showToast(
      'Emergency Pager Transmitted',
      `High-priority alert dispatched to ${doctorName}${caseId ? ` for Case ${caseId}` : ''}. Response expected < 60s.`,
      'alert'
    );
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Toast Notification Banner */}
      {toastMessage && (
        <div
          className={`p-4 rounded-2xl border backdrop-blur-2xl shadow-2xl flex items-center justify-between gap-3 animate-in fade-in slide-in-from-top duration-200 ${
            toastMessage.type === 'alert'
              ? 'bg-red-950/80 border-red-500 text-red-200 shadow-[0_0_20px_rgba(239,68,68,0.3)]'
              : toastMessage.type === 'info'
              ? 'bg-cyan-950/80 border-cyan-500 text-cyan-200 shadow-[0_0_20px_rgba(6,182,212,0.3)]'
              : 'bg-emerald-950/80 border-emerald-500 text-emerald-200 shadow-[0_0_20px_rgba(16,185,129,0.3)]'
          }`}
        >
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-xl bg-white/10 flex items-center justify-center shrink-0">
              <Bell className="w-4 h-4 animate-bounce" />
            </div>
            <div>
              <h4 className="text-xs font-black uppercase tracking-wider">{toastMessage.title}</h4>
              <p className="text-xs opacity-90 font-medium mt-0.5">{toastMessage.desc}</p>
            </div>
          </div>
          <button
            onClick={() => setToastMessage(null)}
            className="p-1 rounded-lg hover:bg-white/10 transition text-current"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Top HUD Banner */}
      <div className="p-6 rounded-3xl bg-[rgba(30,10,20,0.65)] border border-red-500/50 backdrop-blur-2xl shadow-[0_20px_50px_rgba(0,0,0,0.8),0_0_30px_rgba(239,68,68,0.25)] flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-red-500/25 border border-red-500/50 flex items-center justify-center text-red-300 shadow-[0_0_15px_rgba(239,68,68,0.4)]">
            <Flame className="w-6 h-6 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-2xl font-black text-white tracking-tight">
                Emergency Command HUD
              </h1>
              <span className="flex items-center gap-1.5 px-3 py-0.5 rounded-full bg-red-500/25 text-red-200 border border-red-500/50 text-xs font-black animate-pulse shadow-[0_0_12px_rgba(239,68,68,0.3)]">
                <Radio className="w-3 h-3 text-red-300" />
                LIVE TRIAGE
              </span>
            </div>
            <p className="text-xs text-slate-300 mt-1 font-medium">
              Multi-subsystem trauma response: Dashboard &bull; Queue &bull; Active Care &bull; Roster &bull; History Archive.
            </p>
          </div>
        </div>

        <button
          onClick={() => setShowIngestModal(true)}
          className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-red-600 to-amber-600 hover:from-red-500 hover:to-amber-500 text-white text-xs font-black transition shadow-[0_0_20px_rgba(239,68,68,0.4)]"
        >
          <Plus className="w-4 h-4" />
          <span>Ingest Emergency Case</span>
        </button>
      </div>

      {/* 5 Distinct Sub-Tabs Navigation */}
      <div className="flex flex-wrap items-center gap-2 border-b border-red-500/20 pb-3">
        {[
          { id: 'dashboard', label: '1. Emergency Dashboard', count: undefined },
          { id: 'queue', label: '2. Priority Queue', count: queueCases.length },
          { id: 'active', label: '3. Active Cases', count: activeCases.length },
          { id: 'doctors', label: '4. Available Emergency Doctors', count: doctors.filter(d => d.currentStatus === 'AVAILABLE').length },
          { id: 'history', label: '5. Emergency History', count: historyRecords.length },
        ].map((sub) => {
          const isActive = currentTab === sub.id;

          return (
            <button
              key={sub.id}
              onClick={() => setActiveNavigation('emergency', sub.id)}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 ${
                isActive
                  ? 'bg-red-500/25 text-red-200 border border-red-500/50 shadow-[0_0_14px_rgba(239,68,68,0.25)]'
                  : 'text-slate-300 hover:text-white bg-[rgba(6,18,45,0.4)] hover:bg-[rgba(6,18,45,0.7)] border border-cyan-500/15'
              }`}
            >
              <span>{sub.label}</span>
              {sub.count !== undefined && (
                <span
                  className={`text-[10px] font-mono px-1.5 py-0.2 rounded font-black ${
                    isActive
                      ? 'bg-red-500/30 text-white border border-red-500/40'
                      : 'bg-slate-800 text-slate-300 border border-slate-700'
                  }`}
                >
                  {sub.count}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* RENDER ACTIVE SUB-TAB SAFELY INSIDE ERROR BOUNDARY */}
      <ErrorBoundary fallbackTitle="Emergency Command Information">
        {currentTab === 'dashboard' && (
          <EmergencyDashboardTab
            queueCases={queueCases}
            activeCases={activeCases}
            historyRecords={historyRecords}
            doctors={doctors}
            ambulances={ambulances}
            activities={activities}
            onSelectTab={(tabId) => setActiveNavigation('emergency', tabId)}
            onViewCase={(c) => setSelectedCaseForDetails(c)}
          />
        )}

        {currentTab === 'queue' && (
          <EmergencyPriorityQueueTab
            queueCases={queueCases}
            doctors={doctors}
            onViewCase={(c) => setSelectedCaseForDetails(c)}
            onOpenAssignDoctor={(c) => setSelectedCaseForAssignDoctor(c)}
            onUpdatePriority={handleUpdatePriority}
            onOpenIngestModal={() => setShowIngestModal(true)}
          />
        )}

        {currentTab === 'active' && (
          <EmergencyActiveCasesTab
            activeCases={activeCases}
            onViewCase={(c) => setSelectedCaseForDetails(c)}
            onUpdateStatus={(c) => setSelectedCaseForUpdateStatus(c)}
            onViewPatient={(name, age, gender) =>
              setSelectedPatientForProfile({ name, age, gender })
            }
            onContactDoctor={(name, caseId) => handlePageDoctor(name, caseId)}
            onAssignBed={(c) => setSelectedCaseForAssignBed(c)}
          />
        )}

        {currentTab === 'doctors' && (
          <EmergencyDoctorsTab
            doctors={doctors}
            onOpenAssignDoctorToCase={(doc) => setSelectedDoctorForAssign(doc)}
            onPageDoctor={(name) => handlePageDoctor(name)}
          />
        )}

        {currentTab === 'history' && (
          <EmergencyHistoryTab
            historyRecords={historyRecords}
            onViewRecord={(r) => setSelectedHistoryRecord(r)}
          />
        )}
      </ErrorBoundary>

      {/* ALL MODALS */}
      {/* 1. Ingest Case Modal */}
      <IngestEmergencyCaseModal
        isOpen={showIngestModal}
        onClose={() => setShowIngestModal(false)}
        onSubmit={handleIngestCase}
      />

      {/* 2. Case Details Modal */}
      <CaseDetailsModal
        eCase={selectedCaseForDetails}
        onClose={() => setSelectedCaseForDetails(null)}
        onAssignDoctor={(c) => setSelectedCaseForAssignDoctor(c)}
        onUpdateStatus={(c) => setSelectedCaseForUpdateStatus(c)}
      />

      {/* 3. Assign Doctor Modal (from case) */}
      <AssignDoctorModal
        eCase={selectedCaseForAssignDoctor}
        doctors={doctors}
        onClose={() => setSelectedCaseForAssignDoctor(null)}
        onAssign={handleAssignDoctor}
      />

      {/* 4. Update Status Modal */}
      <UpdateCaseStatusModal
        eCase={selectedCaseForUpdateStatus}
        onClose={() => setSelectedCaseForUpdateStatus(null)}
        onUpdate={handleUpdateStatus}
      />

      {/* 5. View Patient Demographics Modal */}
      {selectedPatientForProfile && (
        <ViewPatientModal
          patientName={selectedPatientForProfile.name}
          age={selectedPatientForProfile.age}
          gender={selectedPatientForProfile.gender}
          onClose={() => setSelectedPatientForProfile(null)}
        />
      )}

      {/* 6. Assign Doctor to Case Modal (from doctor card) */}
      <DoctorAssignToCaseModal
        doctor={selectedDoctorForAssign}
        cases={queueCases}
        onClose={() => setSelectedDoctorForAssign(null)}
        onAssignDoctor={handleAssignDoctor}
      />

      {/* 7. Historical Case Full View Modal */}
      <HistoricalCaseModal
        record={selectedHistoryRecord}
        onClose={() => setSelectedHistoryRecord(null)}
      />

      {/* 8. Assign ER / ICU Bed Modal */}
      <AssignBedModal
        isOpen={!!selectedCaseForAssignBed}
        eCase={selectedCaseForAssignBed}
        onClose={() => setSelectedCaseForAssignBed(null)}
        onAssign={handleAssignBed}
      />
    </div>
  );
};
