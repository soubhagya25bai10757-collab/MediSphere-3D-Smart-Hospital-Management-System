import React, { useState, useMemo } from 'react';
import { useHospital } from '../context/HospitalContext';
import { Bill, PaymentMethod, PaymentStatus } from '../types';
import {
  ReceiptText,
  Search,
  Filter,
  Plus,
  CreditCard,
  DollarSign,
  Printer,
  CheckCircle2,
  Clock,
  AlertCircle,
  X,
  FileSpreadsheet,
  Download,
} from 'lucide-react';
import confetti from 'canvas-confetti';

export const BillingView: React.FC = () => {
  const {
    bills,
    patients,
    generateBill,
    payBill,
    searchQuery,
  } = useHospital();

  const [localSearch, setLocalSearch] = useState<string>('');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');

  // Modals
  const [showGenerateModal, setShowGenerateModal] = useState<boolean>(false);
  const [selectedBillForPay, setSelectedBillForPay] = useState<Bill | null>(null);
  const [selectedBillToView, setSelectedBillToView] = useState<Bill | null>(null);

  // Form
  const [patientId, setPatientId] = useState<string>(patients[0]?.id || '');
  const [consultationFee, setConsultationFee] = useState<number>(1000);
  const [labCharges, setLabCharges] = useState<number>(650);
  const [medicineCharges, setMedicineCharges] = useState<number>(420);
  const [bedCharges, setBedCharges] = useState<number>(2500);
  const [otherCharges, setOtherCharges] = useState<number>(300);
  const [discountPercent, setDiscountPercent] = useState<number>(5);
  const [taxPercent, setTaxPercent] = useState<number>(5); // 5% GST

  // Payment form
  const [payAmount, setPayAmount] = useState<number>(0);
  const [payMethod, setPayMethod] = useState<PaymentMethod>('UPI');

  // Computed subtotal
  const subtotal = consultationFee + labCharges + medicineCharges + bedCharges + otherCharges;
  const discountAmount = Math.round((subtotal * discountPercent) / 100);
  const taxableAmount = subtotal - discountAmount;
  const taxAmount = Math.round((taxableAmount * taxPercent) / 100);
  const totalAmount = taxableAmount + taxAmount;

  const filteredBills = useMemo(() => {
    const q = (localSearch || searchQuery || '').toLowerCase().trim();
    return (bills || []).filter((b) => {
      if (!b) return false;
      const patientName = (b.patientName || '').toLowerCase();
      const id = (b.id || '').toLowerCase();
      const patientId = (b.patientId || '').toLowerCase();
      const matchQ =
        !q ||
        patientName.includes(q) ||
        id.includes(q) ||
        patientId.includes(q);
      const matchStat = statusFilter === 'ALL' || b.paymentStatus === statusFilter;
      return matchQ && matchStat;
    });
  }, [bills, localSearch, searchQuery, statusFilter]);

  const handleGenerate = (e: React.FormEvent) => {
    e.preventDefault();
    const p = patients.find((pat) => pat.id === patientId);
    if (!p) return;

    generateBill({
      patientId: p.id,
      patientName: p.name,
      items: [
        { description: 'Specialist Physician Consultation', amount: consultationFee, category: 'Consultation' },
        { description: 'Clinical Diagnostics & Laboratory Panel', amount: labCharges, category: 'Lab' },
        { description: 'Inpatient Formulary & Pharmacy Dispensation', amount: medicineCharges, category: 'Pharmacy' },
        { description: 'Ward Accommodations & Nursing Care', amount: bedCharges, category: 'Bed' },
        { description: 'Sterilization & Bio-medical Equipment', amount: otherCharges, category: 'Other' },
      ],
      discountPercent,
      taxPercent,
    });
    setShowGenerateModal(false);
  };

  const handlePaySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedBillForPay) return;

    payBill(selectedBillForPay.id, payMethod, payAmount);

    // Trigger celebratory confetti effect
    try {
      confetti({
        particleCount: 80,
        spread: 60,
        origin: { y: 0.7 },
        colors: ['#06b6d4', '#10b981', '#3b82f6', '#8b5cf6'],
      });
    } catch {
      // Confetti fallback
    }

    setSelectedBillForPay(null);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-black text-white tracking-tight">Billing & Invoices</h1>
            <span className="text-xs font-mono px-2 py-0.5 rounded-full bg-teal-500/20 text-teal-300 border border-teal-500/30">
              ₹ GST Compliant
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Itemized charges, insurance co-pays, GST calculations, and electronic receipt generation.
          </p>
        </div>

        <button
          onClick={() => setShowGenerateModal(true)}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-teal-500 to-emerald-600 hover:from-teal-400 hover:to-emerald-500 text-white text-xs font-black transition shadow-[0_0_20px_rgba(20,184,166,0.35)]"
        >
          <Plus className="w-4 h-4" />
          <span>Generate Patient Invoice</span>
        </button>
      </div>

      {/* Filter & Search */}
      <div className="p-4 rounded-2xl glass-card border-teal-500/30 flex flex-col sm:flex-row items-center justify-between gap-3 shadow-xl">
        <div className="relative w-full max-w-md">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-300" />
          <input
            type="text"
            placeholder="Search invoice number, patient..."
            value={localSearch}
            onChange={(e) => setLocalSearch(e.target.value)}
            className="w-full pl-10 pr-4 py-2 text-xs rounded-xl glass-input text-white placeholder-slate-400"
          />
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
          <Filter className="w-3.5 h-3.5 text-teal-300" />
          <span className="text-xs text-slate-300 font-bold whitespace-nowrap">Payment Status:</span>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-3 py-1.5 rounded-xl glass-input text-xs text-white cursor-pointer"
          >
            <option value="ALL" className="bg-slate-950 text-white">All Statuses</option>
            <option value="Paid" className="bg-slate-950 text-emerald-300">Fully Paid</option>
            <option value="Pending" className="bg-slate-950 text-red-300">Pending</option>
            <option value="Partial" className="bg-slate-950 text-amber-300">Partial Settlement</option>
          </select>
        </div>
      </div>

      {/* Invoices List */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredBills.map((bill) => {
          const isPaid = bill.paymentStatus === 'Paid';
          const isPending = bill.paymentStatus === 'Pending';
          const balance = bill.totalAmount - bill.paidAmount;

          return (
            <div
              key={bill.id}
              className="p-5 rounded-2xl glass-card border-teal-500/30 hover:border-teal-400/60 transition-all hover:-translate-y-0.5 shadow-xl flex flex-col justify-between"
            >
              <div>
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <span className="text-[10px] font-mono px-2.5 py-0.5 rounded-full bg-[rgba(6,18,45,0.8)] text-teal-200 border border-teal-500/40 font-extrabold">
                      {bill.id}
                    </span>
                    <h3 className="text-base font-extrabold text-white mt-2 leading-tight">{bill.patientName}</h3>
                    <span className="text-xs text-slate-300 block mt-0.5 font-medium">
                      Date: <strong className="text-white">{bill.invoiceDate}</strong> &bull; ID: <span className="text-cyan-300 font-mono">{bill.patientId}</span>
                    </span>
                  </div>

                  <span
                    className={`text-[9px] font-extrabold px-2.5 py-1 rounded-full uppercase tracking-wider ${
                      isPaid
                        ? 'bg-emerald-500/25 text-emerald-200 border border-emerald-500/50'
                        : isPending
                        ? 'bg-red-500/25 text-red-200 border border-red-500/50 animate-pulse shadow-[0_0_10px_rgba(239,68,68,0.3)]'
                        : 'bg-amber-500/25 text-amber-200 border border-amber-500/50'
                    }`}
                  >
                    {bill.paymentStatus}
                  </span>
                </div>

                <div className="mt-3 p-3.5 rounded-xl glass-card-subtle text-xs text-slate-200 space-y-1.5">
                  <div className="flex justify-between">
                    <span className="text-slate-300 font-medium">Subtotal:</span>
                    <span className="font-mono font-bold text-white">₹{bill.subtotal.toLocaleString('en-IN')}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-300 font-medium">
                      Discount ({bill.discountPercent}%) & GST ({bill.taxPercent}%):
                    </span>
                    <span className="font-mono font-bold text-cyan-300">
                      -₹{bill.discountAmount} / +₹{bill.taxAmount}
                    </span>
                  </div>
                  <div className="flex justify-between pt-1.5 border-t border-teal-500/20 font-black text-white">
                    <span>Total Invoiced:</span>
                    <span className="font-mono text-teal-300 text-sm">
                      ₹{bill.totalAmount.toLocaleString('en-IN')}
                    </span>
                  </div>
                  <div className="flex justify-between text-slate-300">
                    <span className="font-medium">Paid Amount:</span>
                    <span className="font-mono text-emerald-300 font-bold">
                      ₹{bill.paidAmount.toLocaleString('en-IN')} ({bill.paymentMethod})
                    </span>
                  </div>
                  {balance > 0 && (
                    <div className="flex justify-between text-red-300 font-extrabold">
                      <span>Outstanding Balance:</span>
                      <span className="font-mono">₹{balance.toLocaleString('en-IN')}</span>
                    </div>
                  )}
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-teal-500/20 flex items-center justify-between gap-2">
                <button
                  onClick={() => setSelectedBillToView(bill)}
                  className="px-3.5 py-1.5 rounded-xl text-xs font-bold glass-btn-secondary text-slate-200 hover:text-white transition flex items-center gap-1.5"
                >
                  <ReceiptText className="w-3.5 h-3.5 text-teal-300" />
                  <span>View Breakdown</span>
                </button>

                {!isPaid && (
                  <button
                    onClick={() => {
                      setSelectedBillForPay(bill);
                      setPayAmount(balance);
                    }}
                    className="px-4 py-1.5 rounded-xl text-xs font-black bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-white transition flex items-center gap-1.5 shadow-[0_0_15px_rgba(16,185,129,0.35)]"
                  >
                    <CreditCard className="w-3.5 h-3.5" />
                    <span>Process Payment</span>
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Process Payment Modal */}
      {selectedBillForPay && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-2xl animate-in fade-in">
          <div className="relative w-full max-w-md rounded-3xl glass-modal border-emerald-500/40 p-6 shadow-2xl">
            <button
              onClick={() => setSelectedBillForPay(null)}
              className="absolute top-5 right-5 p-2 rounded-xl text-slate-300 hover:text-white hover:bg-[rgba(6,18,45,0.7)] border border-cyan-500/20 transition"
            >
              <X className="w-5 h-5" />
            </button>

            <h3 className="text-base font-extrabold text-white mb-1">Process Inpatient Payment</h3>
            <p className="text-xs text-slate-300 mb-4 font-medium">
              Invoice: <span className="text-teal-300 font-mono font-bold">{selectedBillForPay.id}</span> &bull; Patient: <strong className="text-white">{selectedBillForPay.patientName}</strong>
            </p>

            <form onSubmit={handlePaySubmit} className="space-y-4 text-xs">
              <div>
                <label className="text-slate-200 font-bold block mb-1">Payment Method</label>
                <div className="grid grid-cols-2 gap-2">
                  {(['UPI', 'Credit Card', 'Cash', 'Insurance Claim'] as PaymentMethod[]).map(
                    (method) => (
                      <button
                        key={method}
                        type="button"
                        onClick={() => setPayMethod(method)}
                        className={`p-2.5 rounded-xl border text-left transition ${
                          payMethod === method
                            ? 'bg-emerald-500/25 border-emerald-500/50 text-emerald-200 font-black shadow-[0_0_10px_rgba(16,185,129,0.25)]'
                            : 'bg-[rgba(6,18,45,0.6)] border-teal-500/20 text-slate-300 hover:text-white'
                        }`}
                      >
                        {method}
                      </button>
                    )
                  )}
                </div>
              </div>

              <div>
                <label className="text-slate-200 font-bold block mb-1">Amount to Settle (₹)</label>
                <input
                  type="number"
                  required
                  min={1}
                  max={selectedBillForPay.totalAmount - selectedBillForPay.paidAmount}
                  value={payAmount}
                  onChange={(e) => setPayAmount(Number(e.target.value))}
                  className="w-full px-3.5 py-2.5 rounded-xl glass-input text-white font-mono text-sm font-bold"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-3 border-t border-emerald-500/20">
                <button
                  type="button"
                  onClick={() => setSelectedBillForPay(null)}
                  className="px-4 py-2.5 rounded-xl glass-btn-secondary text-slate-200 hover:text-white font-bold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-white font-black shadow-[0_0_15px_rgba(16,185,129,0.35)] transition"
                >
                  Record Payment & Print Slip
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* View Itemized Breakdown Modal */}
      {selectedBillToView && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-2xl animate-in fade-in">
          <div className="relative w-full max-w-2xl rounded-3xl glass-modal border-teal-500/40 p-6 shadow-2xl overflow-y-auto max-h-[90vh]">
            <button
              onClick={() => setSelectedBillToView(null)}
              className="absolute top-5 right-5 p-2 rounded-xl text-slate-300 hover:text-white hover:bg-[rgba(6,18,45,0.7)] border border-cyan-500/20 transition"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="border-b border-teal-500/20 pb-4 mb-4">
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[rgba(6,18,45,0.8)] text-teal-300 border border-teal-500/40 font-bold">{selectedBillToView.id}</span>
              <h2 className="text-xl font-black text-white mt-2">Official Hospital Invoice</h2>
              <p className="text-xs text-slate-300 font-medium">
                Patient: <strong className="text-white">{selectedBillToView.patientName}</strong> &bull; Date: <strong className="text-white">{selectedBillToView.invoiceDate}</strong>
              </p>
            </div>

            <div className="space-y-4 text-xs">
              <div>
                <span className="text-[10px] uppercase font-bold text-teal-300 block mb-2">
                  Itemized Tariff Breakdown:
                </span>
                <div className="divide-y divide-teal-500/20 border border-teal-500/30 rounded-2xl bg-[rgba(6,18,45,0.6)] overflow-hidden">
                  {selectedBillToView.items.map((item, idx) => (
                    <div key={idx} className="p-3.5 flex items-center justify-between">
                      <div>
                        <span className="text-white font-bold block">{item.description}</span>
                        <span className="text-[10px] text-cyan-300 font-medium">{item.category} Category</span>
                      </div>
                      <span className="font-mono text-emerald-300 font-extrabold text-sm">
                        ₹{item.amount.toLocaleString('en-IN')}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="p-4 rounded-2xl glass-card-subtle space-y-2">
                <div className="flex justify-between">
                  <span className="text-slate-300 font-medium">Gross Subtotal:</span>
                  <span className="font-mono font-bold text-white">₹{selectedBillToView.subtotal.toLocaleString('en-IN')}</span>
                </div>
                <div className="flex justify-between text-cyan-300 font-bold">
                  <span>Concessional Discount ({selectedBillToView.discountPercent}%):</span>
                  <span className="font-mono">-₹{selectedBillToView.discountAmount}</span>
                </div>
                <div className="flex justify-between text-slate-300">
                  <span className="font-medium">Goods & Services Tax (GST {selectedBillToView.taxPercent}%):</span>
                  <span className="font-mono text-teal-300 font-bold">+₹{selectedBillToView.taxAmount}</span>
                </div>
                <div className="flex justify-between pt-2.5 border-t border-teal-500/20 font-black text-white text-base">
                  <span>Net Payable:</span>
                  <span className="font-mono text-teal-300">
                    ₹{selectedBillToView.totalAmount.toLocaleString('en-IN')}
                  </span>
                </div>
              </div>

              <div className="pt-2 flex items-center justify-end gap-3 border-t border-teal-500/20">
                <button
                  onClick={() => alert(`Downloading GST-compliant invoice PDF for ${selectedBillToView.id}`)}
                  className="px-5 py-2.5 rounded-xl bg-teal-600 hover:bg-teal-500 text-white font-black transition flex items-center gap-2 shadow-[0_0_15px_rgba(20,184,166,0.35)]"
                >
                  <Printer className="w-4 h-4" />
                  <span>Print Official Tax Invoice</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Generate Bill Modal */}
      {showGenerateModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-2xl animate-in fade-in">
          <div className="relative w-full max-w-2xl rounded-3xl glass-modal border-teal-500/40 p-6 shadow-2xl overflow-y-auto max-h-[90vh]">
            <button
              onClick={() => setShowGenerateModal(false)}
              className="absolute top-5 right-5 p-2 rounded-xl text-slate-300 hover:text-white hover:bg-[rgba(6,18,45,0.7)] border border-cyan-500/20 transition"
            >
              <X className="w-5 h-5" />
            </button>

            <h2 className="text-xl font-black text-white mb-1">Generate Patient Invoice</h2>
            <p className="text-xs text-slate-300 mb-6 font-medium">
              Compiles clinical, diagnostic, and bed stay fees into itemized invoice.
            </p>

            <form onSubmit={handleGenerate} className="space-y-4">
              <div>
                <label className="text-xs font-bold text-slate-200 block mb-1">Select Patient</label>
                <select
                  value={patientId}
                  onChange={(e) => setPatientId(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl glass-input text-xs text-white cursor-pointer"
                >
                  {patients.map((p) => (
                    <option key={p.id} value={p.id} className="bg-slate-950 text-white">
                      {p.name} ({p.id})
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="text-xs font-bold text-slate-200 block mb-1">
                    Doctor Consultation (₹)
                  </label>
                  <input
                    type="number"
                    value={consultationFee}
                    onChange={(e) => setConsultationFee(Number(e.target.value))}
                    className="w-full px-3.5 py-2 rounded-xl glass-input text-xs text-white font-mono"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-slate-200 block mb-1">
                    Lab Diagnostics (₹)
                  </label>
                  <input
                    type="number"
                    value={labCharges}
                    onChange={(e) => setLabCharges(Number(e.target.value))}
                    className="w-full px-3.5 py-2 rounded-xl glass-input text-xs text-white font-mono"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-slate-200 block mb-1">
                    Pharmacy Drugs (₹)
                  </label>
                  <input
                    type="number"
                    value={medicineCharges}
                    onChange={(e) => setMedicineCharges(Number(e.target.value))}
                    className="w-full px-3.5 py-2 rounded-xl glass-input text-xs text-white font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-slate-200 block mb-1">
                    Bed / Room Stay Charges (₹)
                  </label>
                  <input
                    type="number"
                    value={bedCharges}
                    onChange={(e) => setBedCharges(Number(e.target.value))}
                    className="w-full px-3.5 py-2 rounded-xl glass-input text-xs text-white font-mono"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-slate-200 block mb-1">
                    Nursing & Equipment (₹)
                  </label>
                  <input
                    type="number"
                    value={otherCharges}
                    onChange={(e) => setOtherCharges(Number(e.target.value))}
                    className="w-full px-3.5 py-2 rounded-xl glass-input text-xs text-white font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-slate-200 block mb-1">
                    Discount Concession (%)
                  </label>
                  <input
                    type="number"
                    min={0}
                    max={100}
                    value={discountPercent}
                    onChange={(e) => setDiscountPercent(Number(e.target.value))}
                    className="w-full px-3.5 py-2 rounded-xl glass-input text-xs text-white font-mono"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-slate-200 block mb-1">
                    Applicable GST (%)
                  </label>
                  <select
                    value={taxPercent}
                    onChange={(e) => setTaxPercent(Number(e.target.value))}
                    className="w-full px-3.5 py-2 rounded-xl glass-input text-xs text-white font-mono cursor-pointer"
                  >
                    <option value={0} className="bg-slate-950 text-white">0% Exempt</option>
                    <option value={5} className="bg-slate-950 text-white">5% Healthcare Standard</option>
                    <option value={12} className="bg-slate-950 text-white">12% Medical Devices</option>
                    <option value={18} className="bg-slate-950 text-white">18% Special Services</option>
                  </select>
                </div>
              </div>

              <div className="p-4 rounded-2xl glass-card-subtle text-xs space-y-1.5">
                <div className="flex justify-between text-slate-300 font-medium">
                  <span>Gross Total: ₹{subtotal}</span>
                  <span>Discount: -₹{discountAmount}</span>
                  <span>Tax: +₹{taxAmount}</span>
                </div>
                <div className="flex justify-between font-black text-white text-base pt-2 border-t border-teal-500/20">
                  <span>Calculated Net Payable:</span>
                  <span className="text-teal-300 font-mono">₹{totalAmount.toLocaleString('en-IN')}</span>
                </div>
              </div>

              <div className="pt-4 flex items-center justify-end gap-3 border-t border-teal-500/20">
                <button
                  type="button"
                  onClick={() => setShowGenerateModal(false)}
                  className="px-4 py-2.5 rounded-xl glass-btn-secondary text-xs font-bold text-slate-200"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-teal-500 to-emerald-600 hover:from-teal-400 hover:to-emerald-500 text-white text-xs font-black shadow-[0_0_20px_rgba(20,184,166,0.35)] transition"
                >
                  Commit Invoice to Ledger
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
