import React, { useState, useMemo } from 'react';
import { useHospital } from '../context/HospitalContext';
import { MedicalRecord } from '../types';
import {
  FileText,
  Search,
  Filter,
  Plus,
  Calendar,
  User,
  Stethoscope,
  Clock,
  Printer,
  X,
  ChevronRight,
  CheckCircle2,
  FileSpreadsheet,
} from 'lucide-react';

export const MedicalRecordsView: React.FC = () => {
  const { medicalRecords, patients, doctors, addMedicalRecord, searchQuery } = useHospital();

  const [localSearch, setLocalSearch] = useState<string>('');
  const [selectedRecord, setSelectedRecord] = useState<MedicalRecord | null>(null);
  const [showAddModal, setShowAddModal] = useState<boolean>(false);

  // Form state
  const [patientId, setPatientId] = useState<string>(patients[0]?.id || '');
  const [doctorId, setDoctorId] = useState<string>(doctors[0]?.id || '');
  const [diagnosis, setDiagnosis] = useState<string>('');
  const [symptoms, setSymptoms] = useState<string>('');
  const [clinicalNotes, setClinicalNotes] = useState<string>('');
  const [prescriptions, setPrescriptions] = useState<string>('');
  const [followUpDate, setFollowUpDate] = useState<string>('2026-04-15');

  const filteredRecords = useMemo(() => {
    const q = (localSearch || searchQuery).toLowerCase();
    return medicalRecords.filter((rec) => {
      return (
        rec.patientName.toLowerCase().includes(q) ||
        rec.doctorName.toLowerCase().includes(q) ||
        rec.diagnosis.toLowerCase().includes(q) ||
        rec.id.toLowerCase().includes(q)
      );
    });
  }, [medicalRecords, localSearch, searchQuery]);

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    const p = patients.find((pat) => pat.id === patientId);
    const d = doctors.find((doc) => doc.id === doctorId);
    if (!p || !d) return;

    addMedicalRecord({
      patientId: p.id,
      patientName: p.name,
      doctorId: d.id,
      doctorName: d.name,
      department: d.specialization,
      diagnosis,
      symptoms: symptoms.split(',').map((s) => s.trim()),
      doctorNotes: clinicalNotes,
      clinicalNotes,
      treatmentSummary: `Treatment plan initiated for ${diagnosis}.`,
      prescriptions: prescriptions.split(',').map((s) => s.trim()),
      labTestIds: [],
      followUpDate,
    });
    setShowAddModal(false);
    setDiagnosis('');
    setSymptoms('');
    setClinicalNotes('');
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-black text-white tracking-tight">
              Electronic Health Records (EHR)
            </h1>
            <span className="text-xs font-mono px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
              {medicalRecords.length} Archived
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Chronological diagnostic timeline with clinical symptoms, prescribed pharmacological agents, and follow-ups.
          </p>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white text-xs font-bold transition shadow-lg shadow-cyan-500/20"
        >
          <Plus className="w-4 h-4" />
          Create Diagnostic File
        </button>
      </div>

      {/* Search Bar */}
      <div className="p-4 rounded-2xl bg-slate-900/80 border border-cyan-500/20 backdrop-blur-xl flex items-center justify-between shadow-lg">
        <div className="relative w-full max-w-md">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            type="text"
            placeholder="Search records by patient, doctor, or diagnosis..."
            value={localSearch}
            onChange={(e) => setLocalSearch(e.target.value)}
            className="w-full pl-9 pr-4 py-2 text-xs rounded-xl bg-slate-950/80 border border-slate-800 focus:border-cyan-500/60 text-white placeholder-slate-500 outline-none"
          />
        </div>
      </div>

      {/* Records Timeline / Feed */}
      <div className="space-y-4">
        {filteredRecords.map((rec) => (
          <div
            key={rec.id}
            className="p-5 rounded-2xl bg-slate-900/70 border border-cyan-500/20 backdrop-blur-xl hover:border-cyan-500/40 transition shadow-lg"
          >
            <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-mono font-bold text-cyan-300">{rec.id}</span>
                  <span className="text-xs text-slate-500">&bull;</span>
                  <span className="text-xs text-slate-400">{rec.date}</span>
                </div>
                <h3 className="text-base font-bold text-white mt-1">{rec.diagnosis}</h3>
                <p className="text-xs text-slate-300 mt-0.5">
                  Patient: <span className="text-white font-semibold">{rec.patientName}</span> &bull; Attending: <span className="text-cyan-400">{rec.doctorName}</span>
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => setSelectedRecord(rec)}
                  className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-white transition flex items-center gap-1.5"
                >
                  View EHR Summary
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* Diagnostic journey pipeline preview */}
            <div className="mt-4 pt-3 border-t border-slate-800/80">
              <span className="text-[10px] uppercase font-bold text-slate-500 block mb-2">
                Clinical Workflow Stages:
              </span>
              <div className="flex items-center gap-2 overflow-x-auto text-[11px] pb-1">
                <div className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-emerald-950/60 border border-emerald-500/30 text-emerald-300 whitespace-nowrap">
                  <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                  Consultation
                </div>
                <span className="text-slate-600">&rarr;</span>
                <div className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-emerald-950/60 border border-emerald-500/30 text-emerald-300 whitespace-nowrap">
                  <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                  Diagnosis
                </div>
                <span className="text-slate-600">&rarr;</span>
                <div className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-cyan-950/60 border border-cyan-500/30 text-cyan-300 whitespace-nowrap">
                  <CheckCircle2 className="w-3 h-3 text-cyan-400" />
                  Prescriptions ({(rec.prescriptions || []).length})
                </div>
                <span className="text-slate-600">&rarr;</span>
                <div className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-indigo-950/60 border border-indigo-500/30 text-indigo-300 whitespace-nowrap">
                  <Calendar className="w-3 h-3 text-indigo-400" />
                  Follow-up: {rec.followUpDate}
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* View Detailed Record Modal */}
      {selectedRecord && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-2xl animate-in fade-in">
          <div className="relative w-full max-w-2xl rounded-3xl bg-slate-900 border border-cyan-500/30 p-6 shadow-2xl overflow-y-auto max-h-[90vh]">
            <button
              onClick={() => setSelectedRecord(null)}
              className="absolute top-5 right-5 p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="border-b border-slate-800 pb-4 mb-4">
              <span className="text-[10px] font-mono text-cyan-400">{selectedRecord.id}</span>
              <h2 className="text-xl font-bold text-white mt-1">{selectedRecord.diagnosis}</h2>
              <div className="flex items-center gap-3 text-xs text-slate-400 mt-1">
                <span>Patient: {selectedRecord.patientName}</span>
                <span>&bull;</span>
                <span>Doctor: {selectedRecord.doctorName}</span>
                <span>&bull;</span>
                <span>Date: {selectedRecord.date}</span>
              </div>
            </div>

            <div className="space-y-4 text-xs">
              <div>
                <span className="text-[10px] font-bold uppercase text-slate-500 block mb-1">
                  Documented Symptoms
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {(selectedRecord.symptoms || []).map((s, idx) => (
                    <span
                      key={idx}
                      className="px-2.5 py-1 rounded-lg bg-slate-950 border border-slate-800 text-slate-200"
                    >
                      {s}
                    </span>
                  ))}
                </div>
              </div>

              <div>
                <span className="text-[10px] font-bold uppercase text-slate-500 block mb-1">
                  Attending Clinical Notes
                </span>
                <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-slate-200 leading-relaxed">
                  {selectedRecord.clinicalNotes}
                </div>
              </div>

              <div>
                <span className="text-[10px] font-bold uppercase text-slate-500 block mb-1">
                  Prescription Directives
                </span>
                <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
                  {(selectedRecord.prescriptions || []).map((rx, idx) => {
                    const text = typeof rx === 'string' ? rx : `${rx.medicineName} (${rx.dosage}) - ${rx.frequency}`;
                    return (
                      <div key={idx} className="flex items-center gap-2 text-cyan-300">
                        <span className="w-1.5 h-1.5 rounded-full bg-cyan-400" />
                        <span>{text}</span>
                      </div>
                    );
                  })}
                </div>
              </div>

              <div className="p-3 rounded-xl bg-indigo-950/40 border border-indigo-500/30 flex items-center justify-between">
                <div>
                  <span className="text-[10px] uppercase font-bold text-indigo-300 block">
                    Next Follow-up Consultation
                  </span>
                  <span className="text-white font-mono font-bold mt-0.5 block">
                    {selectedRecord.followUpDate}
                  </span>
                </div>
                <button
                  onClick={() => alert(`Printing official EHR document for ${selectedRecord.patientName}`)}
                  className="px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold transition flex items-center gap-1.5"
                >
                  <Printer className="w-3.5 h-3.5" />
                  Print File
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Add Record Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-2xl animate-in fade-in">
          <div className="relative w-full max-w-2xl rounded-3xl bg-slate-900 border border-cyan-500/30 p-6 shadow-2xl overflow-y-auto max-h-[90vh]">
            <button
              onClick={() => setShowAddModal(false)}
              className="absolute top-5 right-5 p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800"
            >
              <X className="w-5 h-5" />
            </button>

            <h2 className="text-lg font-bold text-white mb-1">Create Diagnostic Health Record</h2>
            <p className="text-xs text-slate-400 mb-6">
              Encapsulates diagnostic assessment into Java MedicalRecord entity.
            </p>

            <form onSubmit={handleAdd} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1">Patient</label>
                  <select
                    value={patientId}
                    onChange={(e) => setPatientId(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white outline-none focus:border-cyan-500"
                  >
                    {patients.map((p) => (
                      <option key={p.id} value={p.id}>
                        {p.name} ({p.id})
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1">
                    Attending Physician
                  </label>
                  <select
                    value={doctorId}
                    onChange={(e) => setDoctorId(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white outline-none focus:border-cyan-500"
                  >
                    {doctors.map((d) => (
                      <option key={d.id} value={d.id}>
                        {d.name} ({d.specialization})
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1">
                  Primary Clinical Diagnosis
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Type 2 Diabetes Mellitus with Peripheral Neuropathy"
                  value={diagnosis}
                  onChange={(e) => setDiagnosis(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white outline-none focus:border-cyan-500"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1">
                  Symptoms (comma-separated)
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Polyuria, Polydipsia, Tingling sensations"
                  value={symptoms}
                  onChange={(e) => setSymptoms(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white outline-none focus:border-cyan-500"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-300 block mb-1">
                  Clinical Examination Notes
                </label>
                <textarea
                  rows={3}
                  required
                  placeholder="Doctor's detailed observations, vitals assessment, lifestyle recommendations..."
                  value={clinicalNotes}
                  onChange={(e) => setClinicalNotes(e.target.value)}
                  className="w-full p-3 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white outline-none focus:border-cyan-500"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1">
                    Prescriptions (comma-separated)
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Metformin 500mg BD, Gabapentin 100mg HS"
                    value={prescriptions}
                    onChange={(e) => setPrescriptions(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white outline-none focus:border-cyan-500"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-300 block mb-1">
                    Follow-up Review Date
                  </label>
                  <input
                    type="date"
                    required
                    value={followUpDate}
                    onChange={(e) => setFollowUpDate(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white outline-none focus:border-cyan-500"
                  />
                </div>
              </div>

              <div className="pt-4 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-xs font-semibold text-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white text-xs font-bold shadow-lg shadow-cyan-500/20"
                >
                  Commit to Medical History
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
