import React, { useState } from 'react';
import { motion, AnimatePresence, type Variants } from 'motion/react';
import { useHospital } from '../context/HospitalContext';
import {
  Microscope,
  Pill,
  BedDouble,
  ReceiptText,
  Building2,
  Layers,
  Activity,
  Sparkles,
  Cpu,
  TrendingUp,
  ChevronDown,
  ChevronUp,
  Flame,
  CheckCircle2,
} from 'lucide-react';
import { LaboratoryView } from './LaboratoryView';
import { PharmacyView } from './PharmacyView';
import { BedManagementView } from './BedManagementView';
import { BillingView } from './BillingView';
import { ThreadActivityMonitorPanel } from '../components/operations/ThreadActivityMonitorPanel';
import { ErrorBoundary } from '../components/ErrorBoundary';

// Entrance animation variants for smooth fade-in and slide-up effect
const containerVariants: Variants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.06,
      delayChildren: 0.02,
    },
  },
};

const cardItemVariants: Variants = {
  hidden: { opacity: 0, y: 16 },
  visible: {
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.38,
      ease: 'easeOut',
    },
  },
};

const tabContentVariants: Variants = {
  hidden: { opacity: 0, y: 14 },
  visible: {
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.35,
      ease: 'easeOut',
    },
  },
  exit: {
    opacity: 0,
    y: -8,
    transition: {
      duration: 0.15,
      ease: 'easeIn',
    },
  },
};

export const HospitalOperationsView: React.FC = () => {
  const {
    activeSubTab,
    setActiveNavigation,
    labTests = [],
    medicines = [],
    beds = [],
    bills = [],
    threads = [],
  } = useHospital();

  const [isInlineMonitorExpanded, setIsInlineMonitorExpanded] = useState<boolean>(false);

  // Selected sub-module tab
  const currentTab = ['laboratory', 'pharmacy', 'beds', 'billing', 'threads'].includes(activeSubTab)
    ? activeSubTab
    : 'laboratory';

  // Live telemetry metrics for each module
  const pendingLabCount = (labTests || []).filter((t) => t && (t.status === 'Requested' || t.status === 'In Progress')).length;
  const lowStockCount = (medicines || []).filter((m) => m && (m.status === 'Low Stock' || m.status === 'Out of Stock')).length;
  const availableBeds = (beds || []).filter((b) => b && b.status === 'Available').length;
  const pendingBillsCount = (bills || []).filter((b) => b && b.paymentStatus !== 'Paid').length;
  const activeThreadsCount = (threads || []).filter(
    (t) => t && (t.state === 'RUNNING' || t.state === 'RUNNABLE')
  ).length;

  const operationTabs = [
    {
      id: 'laboratory',
      name: 'Laboratory',
      badge: `${pendingLabCount} Active Assays`,
      icon: Microscope,
      desc: 'Hematology, Bio-Chemistry & Pathology Queues',
      color: 'from-purple-500/20 to-indigo-500/10',
      activeBorder: 'border-purple-500',
      activeText: 'text-purple-300',
      iconColor: 'text-purple-400',
    },
    {
      id: 'pharmacy',
      name: 'Pharmacy',
      badge: `${lowStockCount} Alerts`,
      icon: Pill,
      desc: 'Formulary Inventory & Barcoded Dispensing',
      color: 'from-emerald-500/20 to-teal-500/10',
      activeBorder: 'border-emerald-500',
      activeText: 'text-emerald-300',
      iconColor: 'text-emerald-400',
    },
    {
      id: 'beds',
      name: 'Bed Management',
      badge: `${availableBeds} Available`,
      icon: BedDouble,
      desc: 'ICU, General Ward & Critical Care Census',
      color: 'from-cyan-500/20 to-blue-500/10',
      activeBorder: 'border-cyan-500',
      activeText: 'text-cyan-300',
      iconColor: 'text-cyan-400',
    },
    {
      id: 'billing',
      name: 'Billing & Invoices',
      badge: `${pendingBillsCount} Pending`,
      icon: ReceiptText,
      desc: 'GST Invoicing, Claims & Ledger Tracking',
      color: 'from-amber-500/20 to-yellow-500/10',
      activeBorder: 'border-amber-500',
      activeText: 'text-amber-300',
      iconColor: 'text-amber-400',
    },
    {
      id: 'threads',
      name: 'Thread Activity Monitor',
      badge: `${activeThreadsCount} Active`,
      icon: Cpu,
      desc: 'Java Multithreaded Operations & Process Charts',
      color: 'from-cyan-500/20 to-teal-500/10',
      activeBorder: 'border-cyan-500',
      activeText: 'text-cyan-300',
      iconColor: 'text-cyan-400',
    },
  ];

  return (
    <motion.div
      className="space-y-6"
      initial="hidden"
      animate="visible"
      variants={containerVariants}
    >
      {/* Section Header */}
      <motion.div
        variants={cardItemVariants}
        className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-cyan-500/20"
      >
        <div>
          <div className="flex items-center gap-2">
            <span className="text-[10px] uppercase font-bold tracking-widest text-cyan-400 px-2 py-0.5 rounded-full bg-cyan-500/10 border border-cyan-500/30">
              VTOP Hospital OS &bull; Module 6
            </span>
            <span className="text-[10px] font-mono text-slate-400">
              Core Operations
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight mt-1 flex items-center gap-3">
            <Building2 className="w-7 h-7 text-cyan-400" />
            Hospital Operations Command
          </h1>
          <p className="text-xs text-slate-400 mt-1 max-w-2xl">
            Unified clinical operations center integrating automated diagnostic pathology,
            pharmacy stock dispensing, live bed occupancy grid, and GST revenue invoicing.
          </p>
        </div>
      </motion.div>

      {/* 5 Clean Internal Module Cards / Switchers */}
      <motion.div
        variants={containerVariants}
        className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-3"
      >
        {operationTabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = currentTab === tab.id;
          return (
            <motion.button
              key={tab.id}
              variants={cardItemVariants}
              whileHover={{ y: -3, transition: { duration: 0.2 } }}
              whileTap={{ scale: 0.98 }}
              onClick={() => setActiveNavigation('operations', tab.id)}
              className={`p-4 rounded-2xl text-left transition-all relative overflow-hidden backdrop-blur-xl border cursor-pointer ${
                isActive
                  ? `glass-card ${tab.activeBorder} shadow-[0_12px_28px_rgba(0,0,0,0.6),0_0_20px_rgba(6,182,212,0.25)] scale-[1.01]`
                  : 'glass-card-subtle hover:border-cyan-500/40 hover:bg-[rgba(6,18,45,0.6)]'
              }`}
            >
              {/* Subtle top indicator bar */}
              {isActive && (
                <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-cyan-400 to-blue-500 shadow-[0_0_8px_rgba(6,182,212,0.8)]" />
              )}

              <div className="flex items-center justify-between mb-3">
                <div
                  className={`w-9 h-9 rounded-xl flex items-center justify-center border shadow-inner ${
                    isActive
                      ? 'bg-[rgba(6,18,45,0.8)] border-cyan-400/50 text-cyan-200 shadow-[0_0_10px_rgba(6,182,212,0.3)]'
                      : 'bg-[rgba(6,18,45,0.6)] border-cyan-500/20 ' + tab.iconColor
                  }`}
                >
                  <Icon className="w-4 h-4" />
                </div>
                <span
                  className={`text-[10px] font-mono px-2.5 py-0.5 rounded-full border font-bold ${
                    isActive
                      ? 'bg-cyan-500/25 text-cyan-200 border-cyan-400/50 shadow-[0_0_10px_rgba(6,182,212,0.2)]'
                      : 'bg-[rgba(6,18,45,0.7)] text-slate-300 border-cyan-500/20'
                  }`}
                >
                  {tab.badge}
                </span>
              </div>

              <h3 className={`text-sm font-extrabold tracking-tight ${isActive ? 'text-white' : 'text-slate-200'}`}>
                {tab.name}
              </h3>
              <p className="text-[11px] text-slate-300 mt-1 line-clamp-1 leading-snug font-medium">
                {tab.desc}
              </p>
            </motion.button>
          );
        })}
      </motion.div>

      {/* Live Operational Concurrency Telemetry Strip */}
      <motion.div
        variants={cardItemVariants}
        className="flex flex-wrap items-center justify-between gap-3 p-3.5 rounded-2xl bg-slate-950/70 border border-cyan-500/25 backdrop-blur-xl shadow-lg"
      >
        <div className="flex items-center gap-3 min-w-0">
          <div className="w-8 h-8 rounded-xl bg-cyan-500/15 border border-cyan-500/30 flex items-center justify-center text-cyan-400 shrink-0">
            <Cpu className="w-4 h-4 animate-pulse" />
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-xs font-bold text-white">
                Java Multithreaded Operations Engine
              </span>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-300 border border-emerald-500/30 font-semibold flex items-center gap-1">
                <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                {activeThreadsCount} / {threads.length} Workers Active
              </span>
              <span className="text-[10px] font-mono text-cyan-300 hidden md:inline">
                &bull; 0 Deadlocks &bull; 5 ReentrantLocks Synchronized
              </span>
            </div>
            <span className="text-[11px] text-slate-400 truncate block">
              Background tasks concurrently servicing diagnostic pathology, pharmacy CAS dispensing, ward mutexes, and billing commits.
            </span>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          {currentTab !== 'threads' ? (
            <>
              <button
                id="toggle-inline-thread-panel-btn"
                onClick={() => setIsInlineMonitorExpanded(!isInlineMonitorExpanded)}
                className="px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-200 hover:text-white text-xs font-bold transition flex items-center gap-1.5 cursor-pointer"
                title="Toggle inline thread monitor panel"
              >
                <Activity className="w-3.5 h-3.5 text-cyan-400" />
                <span>{isInlineMonitorExpanded ? 'Hide Quick Panel' : 'Quick Process Panel'}</span>
                {isInlineMonitorExpanded ? (
                  <ChevronUp className="w-3.5 h-3.5" />
                ) : (
                  <ChevronDown className="w-3.5 h-3.5" />
                )}
              </button>

              <button
                id="view-full-thread-monitor-tab-btn"
                onClick={() => setActiveNavigation('operations', 'threads')}
                className="px-3 py-1.5 rounded-xl bg-cyan-500/20 hover:bg-cyan-500/30 border border-cyan-500/40 text-cyan-200 hover:text-white text-xs font-bold transition flex items-center gap-1.5 cursor-pointer shadow-sm"
              >
                <TrendingUp className="w-3.5 h-3.5 text-cyan-400" />
                <span>Full Process Charts</span>
              </button>
            </>
          ) : (
            <span className="text-xs font-mono text-cyan-300 bg-cyan-950/60 px-3 py-1 rounded-xl border border-cyan-800">
              Active View: Detailed Monitor
            </span>
          )}
        </div>
      </motion.div>

      {/* Inline Thread Activity Monitor Panel (when toggled from another tab) */}
      {isInlineMonitorExpanded && currentTab !== 'threads' && (
        <motion.div
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: 'auto' }}
          exit={{ opacity: 0, height: 0 }}
          transition={{ duration: 0.3 }}
          className="overflow-hidden"
        >
          <div className="relative mb-2">
            <ThreadActivityMonitorPanel />
          </div>
        </motion.div>
      )}

      {/* Embedded View Body with Entrance Animations when switching tabs */}
      <AnimatePresence mode="wait">
        <motion.div
          key={currentTab}
          initial="hidden"
          animate="visible"
          exit="exit"
          variants={tabContentVariants}
          className="pt-2"
        >
          {currentTab === 'laboratory' && (
            <ErrorBoundary fallbackTitle="Laboratory Queue">
              <LaboratoryView />
            </ErrorBoundary>
          )}
          {currentTab === 'pharmacy' && (
            <ErrorBoundary fallbackTitle="Pharmacy Formulary">
              <PharmacyView />
            </ErrorBoundary>
          )}
          {currentTab === 'beds' && (
            <ErrorBoundary fallbackTitle="Bed Census Management">
              <BedManagementView />
            </ErrorBoundary>
          )}
          {currentTab === 'billing' && (
            <ErrorBoundary fallbackTitle="Billing & Invoicing">
              <BillingView />
            </ErrorBoundary>
          )}
          {currentTab === 'threads' && (
            <ErrorBoundary fallbackTitle="Thread Activity Monitor">
              <ThreadActivityMonitorPanel />
            </ErrorBoundary>
          )}
        </motion.div>
      </AnimatePresence>
    </motion.div>
  );
};
