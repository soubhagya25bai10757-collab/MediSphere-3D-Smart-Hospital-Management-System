import React, { useState, useEffect } from 'react';
import { motion, type Variants } from 'motion/react';
import { useHospital } from '../context/HospitalContext';
import hospitalHeroBg from '../assets/images/hospital_hero_background_1788969414765.jpg';
import { medisphereHeroBg } from '../assets/backgrounds';
import { Hospital3DScene } from '../components/Hospital3DScene';
import {
  Users,
  UserCheck,
  Calendar,
  Flame,
  BedDouble,
  ReceiptText,
  Pill,
  TrendingUp,
  Activity,
  ArrowUpRight,
  Clock,
  AlertTriangle,
  ChevronRight,
  PlusCircle,
  Stethoscope,
  CheckCircle2,
  HeartPulse,
  Sparkles,
  Maximize,
  Minimize,
  X,
  Layers,
  Eye,
} from 'lucide-react';

// Entrance animation variants for smooth fade-in and slide-up effect
const containerVariants: Variants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.05,
      delayChildren: 0.02,
    },
  },
};

const cardItemVariants: Variants = {
  hidden: { opacity: 0, y: 16 },
  visible: {
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.38,
      ease: 'easeOut',
    },
  },
};

export const DashboardView: React.FC = () => {
  const [isEnlarged, setIsEnlarged] = useState(false);
  const [enlargeMode, setEnlargeMode] = useState<'interactive' | 'cinematic'>('interactive');

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isEnlarged) {
        setIsEnlarged(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isEnlarged]);

  const {
    kpiStats,
    appointments = [],
    emergencyCases = [],
    doctors = [],
    patients = [],
    setActiveTab,
    currentUser,
  } = useHospital();

  const kpis = [
    {
      title: 'Total Patients',
      value: (kpiStats?.totalPatients || 1240).toLocaleString('en-IN'),
      change: '+8% Patients',
      icon: Users,
      color: 'from-cyan-500/20 to-blue-500/10',
      border: 'border-cyan-500/30',
      textColor: 'text-cyan-400',
      tab: 'patients' as const,
    },
    {
      title: 'Available Doctors',
      value: kpiStats?.availableDoctors || 38,
      change: '+3 on duty',
      icon: UserCheck,
      color: 'from-blue-500/20 to-indigo-500/10',
      border: 'border-blue-500/30',
      textColor: 'text-blue-400',
      tab: 'doctors' as const,
    },
    {
      title: "Today's Appointments",
      value: kpiStats?.todayAppointments || appointments.length || 28,
      change: '+12 Appointments',
      icon: Calendar,
      color: 'from-indigo-500/20 to-purple-500/10',
      border: 'border-indigo-500/30',
      textColor: 'text-indigo-400',
      tab: 'appointments' as const,
    },
    {
      title: 'Active Emergency Cases',
      value: String(emergencyCases.length || 3).padStart(2, '0'),
      change: '3 Emergency Cases',
      icon: Flame,
      color: 'from-red-500/20 to-amber-500/10',
      border: 'border-red-500/30',
      textColor: 'text-red-400',
      tab: 'emergency' as const,
    },
    {
      title: 'Available Beds',
      value: kpiStats?.availableBeds || 18,
      change: '18 / 64 Beds Available',
      icon: BedDouble,
      color: 'from-emerald-500/20 to-teal-500/10',
      border: 'border-emerald-500/30',
      textColor: 'text-emerald-400',
      tab: 'beds' as const,
    },
    {
      title: 'ICU Occupancy',
      value: '85%',
      change: '85% ICU Occupancy',
      icon: HeartPulse,
      color: 'from-purple-500/20 to-pink-500/10',
      border: 'border-purple-500/30',
      textColor: 'text-purple-400',
      tab: 'beds' as const,
    },
    {
      title: 'Operation Theatres',
      value: '4 / 6',
      change: '4 / 6 In Operation',
      icon: Layers,
      color: 'from-teal-500/20 to-cyan-500/10',
      border: 'border-teal-500/30',
      textColor: 'text-teal-400',
      tab: 'operations' as const,
    },
    {
      title: 'Pending Appointments',
      value: '2',
      change: '2 Waiting Confirmation',
      icon: Clock,
      color: 'from-amber-500/20 to-orange-500/10',
      border: 'border-amber-500/30',
      textColor: 'text-amber-400',
      tab: 'appointments' as const,
    },
  ];

  return (
    <motion.div
      className="space-y-6"
      initial="hidden"
      animate="visible"
      variants={containerVariants}
    >
      {/* Welcome Banner */}
      <motion.div
        variants={cardItemVariants}
        className="p-6 rounded-3xl glass-card flex flex-col md:flex-row items-start md:items-center justify-between gap-4 shadow-2xl"
      >
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-cyan-500/20 border border-cyan-400/40 flex items-center justify-center text-cyan-300 shadow-[0_0_15px_rgba(6,182,212,0.3)]">
            <Activity className="w-6 h-6 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl sm:text-2xl font-black text-white tracking-tight drop-shadow-sm">
                Hospital Command Center
              </h1>
              <span className="text-[10px] font-bold px-2.5 py-0.5 rounded-full bg-cyan-500/20 text-cyan-200 border border-cyan-500/40 shadow-[0_0_8px_rgba(6,182,212,0.2)]">
                ACTIVE MONITOR
              </span>
            </div>
            <p className="text-xs text-slate-300 mt-1 font-medium">
              Logged in as <span className="text-white font-extrabold">{currentUser.name}</span> ({currentUser.role}). All clinical subsystems synchronized.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={() => setActiveTab('patients')}
            className="glass-btn-secondary inline-flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold text-white transition cursor-pointer"
          >
            <PlusCircle className="w-4 h-4 text-cyan-400" />
            New Patient
          </button>
          <button
            onClick={() => setActiveTab('emergency')}
            className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-red-600 to-amber-600 hover:from-red-500 hover:to-amber-500 text-xs font-bold text-white shadow-lg shadow-red-500/35 border border-red-400/50 transition active:scale-95 cursor-pointer"
          >
            <Flame className="w-4 h-4" />
            Emergency Triage
          </button>
        </div>
      </motion.div>

      {/* KPI Cards Grid */}
      <motion.div
        variants={containerVariants}
        className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-4 gap-3.5 sm:gap-4"
      >
        {kpis.map((kpi, idx) => {
          const Icon = kpi.icon;
          return (
            <motion.div
              key={idx}
              variants={cardItemVariants}
              whileHover={{ y: -4, transition: { duration: 0.2 } }}
              onClick={() => setActiveTab(kpi.tab)}
              className={`p-4 sm:p-5 rounded-2xl glass-card border ${kpi.border} transition-all hover:shadow-[0_12px_32px_rgba(0,0,0,0.5),0_0_20px_rgba(6,182,212,0.2)] cursor-pointer group`}
            >
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-200">{kpi.title}</span>
                <div className="p-2 rounded-xl bg-[rgba(6,18,45,0.5)] border border-cyan-500/25 text-cyan-300 group-hover:text-white transition">
                  <Icon className="w-4 h-4" />
                </div>
              </div>

              <div className="mt-2 flex items-baseline justify-between">
                <span className="text-2xl sm:text-3xl font-black text-white tracking-tight drop-shadow-sm">
                  {kpi.value}
                </span>
                <ArrowUpRight className="w-4 h-4 text-cyan-400/70 group-hover:text-cyan-300 transition" />
              </div>

              <span className={`text-[11px] font-bold mt-1 block ${kpi.textColor}`}>
                {kpi.change}
              </span>
            </motion.div>
          );
        })}
      </motion.div>

      {/* 3D Campus Centerpiece Widget */}
      <motion.div variants={cardItemVariants} className="space-y-3">
        <div className="flex items-center justify-between px-1">
          <div className="flex items-center gap-2">
            <span className="text-xs uppercase font-extrabold tracking-widest text-cyan-300 flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse shadow-[0_0_8px_#00f0ff]" />
              3D Digital Twin &bull; Campus Telemetry
            </span>
          </div>

          <div className="flex items-center gap-2">
            <div className="px-3.5 py-1.5 rounded-xl bg-[rgba(6,18,45,0.6)] border border-cyan-500/40 text-cyan-200 text-xs font-bold backdrop-blur-md shadow-sm">
              Cinematic 3D
            </div>
            <button
              id="dashboard-enlarge-btn"
              onClick={() => setIsEnlarged(true)}
              title="Enlarge 3D Campus View"
              aria-label="Enlarge 3D Campus View"
              className="p-2 rounded-xl bg-[rgba(6,18,45,0.6)] hover:bg-cyan-500/20 border border-cyan-500/40 hover:border-cyan-400 text-cyan-300 hover:text-white transition-all shadow-sm flex items-center justify-center cursor-pointer group active:scale-95"
            >
              <Maximize className="w-4 h-4 transition-transform group-hover:scale-110" />
            </button>
          </div>
        </div>

        <div className="relative w-full rounded-3xl overflow-hidden glass-card shadow-2xl min-h-[440px]">
          <div className="relative w-full h-[460px] overflow-hidden group">
            <img
              src={medisphereHeroBg || hospitalHeroBg}
              alt="3D Futuristic Smart Hospital Complex"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-700 ease-out"
            />

            {/* Atmospheric Vignette Overlay */}
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-slate-950/40 pointer-events-none" />
            <div className="absolute inset-0 bg-gradient-to-r from-slate-950/60 via-transparent to-transparent pointer-events-none" />

            {/* Top-Right Floating Enlarge Button */}
            <button
              id="dashboard-enlarge-floating-btn"
              onClick={() => setIsEnlarged(true)}
              title="Enlarge 3D Campus View"
              aria-label="Enlarge 3D Campus View"
              className="absolute top-4 right-4 z-20 px-3 py-1.5 rounded-xl bg-slate-950/85 hover:bg-slate-900 border border-cyan-500/40 hover:border-cyan-300 text-cyan-300 hover:text-white transition-all shadow-xl backdrop-blur-md flex items-center gap-1.5 cursor-pointer group active:scale-95"
            >
              <Maximize className="w-4 h-4 transition-transform group-hover:scale-110" />
              <span className="text-xs font-bold text-cyan-200 hidden sm:inline-block">Enlarge</span>
            </button>

            {/* Live Campus Telemetry Badges */}
            <div className="absolute top-4 left-4 z-10 flex flex-wrap items-center gap-2">
              <span className="px-3 py-1 rounded-full bg-slate-950/85 border border-cyan-500/40 text-[11px] font-mono text-cyan-300 backdrop-blur-md flex items-center gap-1.5 shadow-lg">
                <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
                Next-Gen MediSphere Smart Campus
              </span>
              <span className="px-3 py-1 rounded-full bg-slate-950/85 border border-emerald-500/40 text-[11px] font-mono text-emerald-400 backdrop-blur-md flex items-center gap-1.5 shadow-lg">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                All Subsystems Nominal
              </span>
            </div>

            {/* Sector Callout Pills */}
            <div className="absolute bottom-4 left-4 z-10 flex flex-wrap items-center gap-2 max-w-lg">
              {[
                { label: 'Rooftop Helipad', stat: 'Medevac Ready', color: 'text-sky-300 bg-slate-950/85 border-sky-500/40' },
                { label: 'Emergency Trauma Port', stat: '7 Active', color: 'text-red-400 bg-slate-950/85 border-red-500/40' },
                { label: 'Central Tower Spire', stat: 'Admin Core', color: 'text-cyan-300 bg-slate-950/85 border-cyan-500/40' },
                { label: 'ICU Pavilion', stat: '12/16 Beds', color: 'text-indigo-300 bg-slate-950/85 border-indigo-500/40' },
              ].map((s, idx) => (
                <div
                  key={idx}
                  className={`px-3 py-1.5 rounded-xl text-[11px] font-mono border backdrop-blur-md shadow-md flex items-center gap-1.5 ${s.color}`}
                >
                  <span className="font-bold">{s.label}:</span>
                  <span className="opacity-80">{s.stat}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </motion.div>

      {/* SYSTEM STATUS INDICATOR */}
      <motion.div
        variants={cardItemVariants}
        className="p-4 rounded-2xl glass-card border border-cyan-500/25 flex flex-col md:flex-row items-start md:items-center justify-between gap-3 shadow-lg"
      >
        <div className="flex items-center gap-2">
          <span className="text-[11px] font-black uppercase tracking-widest text-white">
            System Status
          </span>
          <span className="text-[10px] text-slate-400 font-mono">Live Telemetry</span>
        </div>

        <div className="flex flex-wrap items-center gap-2 sm:gap-3">
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-[rgba(6,18,45,0.7)] border border-emerald-500/30 text-xs font-semibold text-emerald-300">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse shadow-[0_0_8px_#34d399]" />
            <span>● Hospital Operational</span>
            <span className="text-[10px] text-slate-400 font-mono hidden sm:inline">&bull; 99.8% Uptime</span>
          </div>

          <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-[rgba(6,18,45,0.7)] border border-red-500/30 text-xs font-semibold text-red-300">
            <span className="w-2 h-2 rounded-full bg-red-400 animate-pulse shadow-[0_0_8px_#f87171]" />
            <span>● Emergency Department Active</span>
            <span className="text-[10px] text-slate-400 font-mono hidden sm:inline">&bull; Level 1 Trauma</span>
          </div>

          <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-[rgba(6,18,45,0.7)] border border-cyan-500/30 text-xs font-semibold text-cyan-300">
            <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse shadow-[0_0_8px_#00f0ff]" />
            <span>● Appointment System Online</span>
            <span className="text-[10px] text-slate-400 font-mono hidden sm:inline">&bull; Synchronized</span>
          </div>
        </div>
      </motion.div>

      {/* TODAY'S HOSPITAL ACTIVITY SECTION */}
      <motion.div variants={cardItemVariants} className="space-y-3">
        <div className="flex items-center justify-between px-1">
          <div className="flex items-center gap-2">
            <span className="text-xs uppercase font-extrabold tracking-widest text-cyan-300 flex items-center gap-1.5">
              <Activity className="w-4 h-4 text-cyan-400 animate-pulse" />
              Today's Hospital Activity
            </span>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-cyan-500/15 text-cyan-300 border border-cyan-500/30">
              Live Feed
            </span>
          </div>
        </div>

        <motion.div
          variants={containerVariants}
          className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4"
        >
          {/* Card 1: Upcoming Appointments */}
          <motion.div
            variants={cardItemVariants}
            whileHover={{ y: -3, transition: { duration: 0.2 } }}
            className="p-4 rounded-2xl glass-card border border-cyan-500/25 flex flex-col justify-between shadow-xl"
          >
            <div>
              <div className="flex items-center justify-between pb-2.5 border-b border-cyan-500/15 mb-2.5">
                <div className="flex items-center gap-2">
                  <div className="p-1.5 rounded-lg bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                    <Calendar className="w-3.5 h-3.5" />
                  </div>
                  <h4 className="text-xs font-extrabold text-white">Upcoming Appointments</h4>
                </div>
                <button
                  onClick={() => setActiveTab('appointments')}
                  className="text-[10px] text-cyan-300 hover:text-white font-bold transition"
                >
                  View All
                </button>
              </div>

              <div className="space-y-2">
                {(appointments || []).slice(0, 3).map((apt) => (
                  <div
                    key={apt.id}
                    onClick={() => setActiveTab('appointments')}
                    className="p-2 rounded-xl bg-[rgba(6,18,45,0.6)] hover:bg-[rgba(10,30,70,0.8)] border border-cyan-500/15 transition cursor-pointer"
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-white truncate">{apt.patientName}</span>
                      <span className="text-[9px] font-mono font-bold text-cyan-300 bg-cyan-500/20 px-1.5 py-0.5 rounded">
                        {apt.timeSlot}
                      </span>
                    </div>
                    <div className="text-[10px] text-slate-300 mt-0.5 flex items-center gap-1.5">
                      <span className="truncate">{apt.doctorName}</span>
                      <span>&bull;</span>
                      <span className="text-cyan-400/90 truncate">{apt.specialization}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            <div className="mt-3 pt-2 border-t border-cyan-500/10 flex items-center justify-between text-[10px] text-slate-400 font-mono">
              <span>Next in 15 mins</span>
              <span className="text-emerald-400 font-bold">18 Scheduled</span>
            </div>
          </motion.div>

          {/* Card 2: Recently Registered Patients */}
          <motion.div
            variants={cardItemVariants}
            whileHover={{ y: -3, transition: { duration: 0.2 } }}
            className="p-4 rounded-2xl glass-card border border-cyan-500/25 flex flex-col justify-between shadow-xl"
          >
            <div>
              <div className="flex items-center justify-between pb-2.5 border-b border-cyan-500/15 mb-2.5">
                <div className="flex items-center gap-2">
                  <div className="p-1.5 rounded-lg bg-blue-500/20 text-blue-300 border border-blue-500/30">
                    <Users className="w-3.5 h-3.5" />
                  </div>
                  <h4 className="text-xs font-extrabold text-white">Registered Patients</h4>
                </div>
                <button
                  onClick={() => setActiveTab('patients')}
                  className="text-[10px] text-cyan-300 hover:text-white font-bold transition"
                >
                  Directory
                </button>
              </div>

              <div className="space-y-2">
                {(patients || []).slice(0, 3).map((p) => (
                  <div
                    key={p.id}
                    onClick={() => setActiveTab('patients')}
                    className="p-2 rounded-xl bg-[rgba(6,18,45,0.6)] hover:bg-[rgba(10,30,70,0.8)] border border-cyan-500/15 transition cursor-pointer"
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-white truncate">{p.name}</span>
                      <span className="text-[9px] font-mono px-1.5 py-0.5 rounded bg-slate-800 text-cyan-300 border border-slate-700">
                        {p.bloodGroup}
                      </span>
                    </div>
                    <div className="text-[10px] text-slate-300 mt-0.5 flex items-center gap-1.5">
                      <span>{p.age}y &bull; {p.gender}</span>
                      <span>&bull;</span>
                      <span className="text-cyan-400/90 truncate">{p.department || 'General'}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            <div className="mt-3 pt-2 border-t border-cyan-500/10 flex items-center justify-between text-[10px] text-slate-400 font-mono">
              <span>Registration Desk #1-4</span>
              <span className="text-cyan-300 font-bold">+14 Today</span>
            </div>
          </motion.div>

          {/* Card 3: Current Emergency Cases */}
          <motion.div
            variants={cardItemVariants}
            whileHover={{ y: -3, transition: { duration: 0.2 } }}
            className="p-4 rounded-2xl glass-card border border-red-500/30 flex flex-col justify-between shadow-xl"
          >
            <div>
              <div className="flex items-center justify-between pb-2.5 border-b border-red-500/20 mb-2.5">
                <div className="flex items-center gap-2">
                  <div className="p-1.5 rounded-lg bg-red-500/20 text-red-300 border border-red-500/40">
                    <Flame className="w-3.5 h-3.5 animate-pulse" />
                  </div>
                  <h4 className="text-xs font-extrabold text-white">Current Emergency Cases</h4>
                </div>
                <button
                  onClick={() => setActiveTab('emergency')}
                  className="text-[10px] text-red-400 hover:text-white font-bold transition"
                >
                  Triage
                </button>
              </div>

              <div className="space-y-2">
                {(emergencyCases || []).slice(0, 3).map((e) => (
                  <div
                    key={e.id}
                    onClick={() => setActiveTab('emergency')}
                    className="p-2 rounded-xl bg-[rgba(25,5,10,0.6)] hover:bg-[rgba(45,10,20,0.8)] border border-red-500/20 transition cursor-pointer"
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-white truncate">{e.patientName}</span>
                      <span
                        className={`text-[8px] font-extrabold uppercase px-1.5 py-0.5 rounded-full ${
                          e.priority === 'Critical'
                            ? 'bg-red-500/30 text-red-300 border border-red-500/50 animate-pulse'
                            : 'bg-amber-500/30 text-amber-300 border border-amber-500/50'
                        }`}
                      >
                        {e.priority}
                      </span>
                    </div>
                    <p className="text-[10px] text-slate-300 mt-0.5 truncate">
                      {e.chiefComplaint || 'Acute trauma presentation'}
                    </p>
                  </div>
                ))}
              </div>
            </div>
            <div className="mt-3 pt-2 border-t border-red-500/15 flex items-center justify-between text-[10px] text-slate-400 font-mono">
              <span>Avg response: 3.4m</span>
              <span className="text-red-400 font-bold">Level 1 Ready</span>
            </div>
          </motion.div>

          {/* Card 4: Recently Available Doctors */}
          <motion.div
            variants={cardItemVariants}
            whileHover={{ y: -3, transition: { duration: 0.2 } }}
            className="p-4 rounded-2xl glass-card border border-cyan-500/25 flex flex-col justify-between shadow-xl"
          >
            <div>
              <div className="flex items-center justify-between pb-2.5 border-b border-cyan-500/15 mb-2.5">
                <div className="flex items-center gap-2">
                  <div className="p-1.5 rounded-lg bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                    <UserCheck className="w-3.5 h-3.5" />
                  </div>
                  <h4 className="text-xs font-extrabold text-white">Available Doctors</h4>
                </div>
                <button
                  onClick={() => setActiveTab('doctors')}
                  className="text-[10px] text-cyan-300 hover:text-white font-bold transition"
                >
                  Roster
                </button>
              </div>

              <div className="space-y-2">
                {(doctors || [])
                  .filter((d) => d.status === 'Available')
                  .slice(0, 3)
                  .map((d) => (
                    <div
                      key={d.id}
                      onClick={() => setActiveTab('doctors')}
                      className="p-2 rounded-xl bg-[rgba(6,18,45,0.6)] hover:bg-[rgba(10,30,70,0.8)] border border-cyan-500/15 transition cursor-pointer"
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-white truncate">{d.name}</span>
                        <span className="text-[9px] font-mono text-emerald-400 bg-emerald-500/20 px-1.5 py-0.5 rounded border border-emerald-500/30">
                          {d.status}
                        </span>
                      </div>
                      <div className="text-[10px] text-slate-300 mt-0.5 flex items-center gap-1.5">
                        <span className="text-cyan-400/90 truncate">{d.specialization}</span>
                        <span>&bull;</span>
                        <span className="font-mono text-slate-400">Room {d.roomNumber || 'OPD'}</span>
                      </div>
                    </div>
                  ))}
              </div>
            </div>
            <div className="mt-3 pt-2 border-t border-cyan-500/10 flex items-center justify-between text-[10px] text-slate-400 font-mono">
              <span>On-call: 14 Doctors</span>
              <span className="text-emerald-400 font-bold">38 Active</span>
            </div>
          </motion.div>
        </motion.div>
      </motion.div>

      {/* Bottom Two Columns: Real-Time Emergency Priority Stream & Today's Appointments */}
      <motion.div variants={containerVariants} className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Emergency Priority Queue */}
        <motion.div variants={cardItemVariants} className="p-6 rounded-3xl glass-card border border-red-500/30 shadow-2xl">
          <div className="flex items-center justify-between pb-4 border-b border-red-500/20">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-red-500/20 border border-red-500/40 flex items-center justify-center text-red-400 shadow-[0_0_10px_rgba(239,68,68,0.25)]">
                <Flame className="w-4 h-4 animate-pulse" />
              </div>
              <div>
                <h3 className="text-sm font-extrabold text-white">Emergency Priority Queue</h3>
                <span className="text-[10px] text-slate-300 font-mono font-medium">
                  High-Priority Clinical Triage Stream
                </span>
              </div>
            </div>
            <button
              onClick={() => setActiveTab('emergency')}
              className="text-xs font-bold text-red-400 hover:text-red-300 flex items-center gap-1 cursor-pointer"
            >
              Command HUD
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="divide-y divide-cyan-500/15 mt-2">
            {(emergencyCases || []).slice(0, 4).map((c) => (
              <div key={c.id} className="py-3 flex items-center justify-between">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-white">{c.patientName || 'Emergency Patient'}</span>
                    <span
                      className={`text-[9px] font-bold px-2 py-0.5 rounded-full uppercase ${
                        c.priority === 'Critical'
                          ? 'bg-red-500/25 text-red-300 border border-red-500/50 animate-pulse'
                          : c.priority === 'High'
                          ? 'bg-amber-500/25 text-amber-300 border border-amber-500/50'
                          : 'bg-cyan-500/25 text-cyan-200 border border-cyan-500/50'
                      }`}
                    >
                      {c.priority}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-300 mt-0.5 line-clamp-1 max-w-sm font-medium">
                    {c.chiefComplaint || 'Clinical trauma evaluation'}
                  </p>
                </div>

                <div className="text-right">
                  <span className="text-xs font-mono font-bold text-white block">
                    Wait: {c.waitingMinutes || 0}m
                  </span>
                  <span className="text-[10px] text-cyan-300 font-semibold block mt-0.5">
                    {c.assignedDoctorName ? c.assignedDoctorName.replace('Dr. ', 'Dr. ') : 'Unassigned'}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </motion.div>

        {/* Today's Appointments Timeline */}
        <motion.div variants={cardItemVariants} className="p-6 rounded-3xl glass-card shadow-2xl">
          <div className="flex items-center justify-between pb-4 border-b border-cyan-500/20">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-cyan-500/20 border border-cyan-500/40 flex items-center justify-center text-cyan-300 shadow-[0_0_10px_rgba(6,182,212,0.25)]">
                <Calendar className="w-4 h-4" />
              </div>
              <div>
                <h3 className="text-sm font-extrabold text-white">Active Consultations & Timeline</h3>
                <span className="text-[10px] text-slate-300 font-mono font-medium">
                  Synchronized OPD Clinical Scheduling
                </span>
              </div>
            </div>
            <button
              onClick={() => setActiveTab('appointments')}
              className="text-xs font-bold text-cyan-300 hover:text-cyan-200 flex items-center gap-1 cursor-pointer"
            >
              Schedule Full View
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="divide-y divide-cyan-500/15 mt-2">
            {(appointments || []).slice(0, 4).map((apt) => {
              const parts = (apt.timeSlot || '09:00 AM').split(' ');
              const timeNum = parts[0] || '09:00';
              const timePeriod = parts[1] || 'AM';

              return (
                <div key={apt.id} className="py-3 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-12 text-center p-1.5 rounded-xl bg-[rgba(6,18,45,0.6)] border border-cyan-500/30 text-[10px] font-mono text-cyan-200 font-bold">
                      {timeNum}
                      <span className="block text-[8px] text-slate-300">
                        {timePeriod}
                      </span>
                    </div>
                    <div>
                      <span className="text-xs font-bold text-white block">{apt.patientName || 'Patient'}</span>
                      <span className="text-[11px] text-slate-300 font-medium">
                        {apt.doctorName || 'Doctor'} &bull; {apt.specialization || 'OPD'}
                      </span>
                    </div>
                  </div>

                  <span
                    className={`text-[10px] font-bold px-2.5 py-1 rounded-full ${
                      apt.status === 'In Consultation'
                        ? 'bg-cyan-500/25 text-cyan-200 border border-cyan-500/50 animate-pulse'
                        : apt.status === 'Completed'
                        ? 'bg-slate-800/80 text-slate-300 border border-slate-700'
                        : 'bg-emerald-500/25 text-emerald-200 border border-emerald-500/50'
                    }`}
                  >
                    {apt.status}
                  </span>
                </div>
              );
            })}
          </div>
        </motion.div>
      </motion.div>

      {/* Enlarged 3D Campus Telemetry Modal */}
      {isEnlarged && (
        <div className="fixed inset-0 z-50 bg-slate-950/95 backdrop-blur-2xl flex flex-col p-2 sm:p-5 overflow-hidden animate-in fade-in duration-200">
          <div className="w-full h-full flex flex-col rounded-2xl sm:rounded-3xl border border-cyan-500/40 bg-slate-950/95 shadow-2xl overflow-hidden relative">
            {/* Modal Header Bar */}
            <div className="px-4 py-3 sm:px-6 sm:py-3.5 border-b border-cyan-500/20 bg-[rgba(6,18,45,0.85)] backdrop-blur-xl flex flex-wrap items-center justify-between gap-3 z-30">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-cyan-500/20 border border-cyan-400/40 flex items-center justify-center text-cyan-300 shadow-[0_0_15px_rgba(6,182,212,0.3)]">
                  <Activity className="w-5 h-5 animate-pulse" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h2 className="text-sm sm:text-base font-black text-white tracking-tight">
                      3D Digital Twin &bull; Campus Telemetry
                    </h2>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-cyan-500/25 text-cyan-200 border border-cyan-500/40 shadow-sm">
                      ENLARGED VIEW
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-300 font-medium hidden sm:block">
                    High-definition spatial campus monitor with real-time sector telemetry and wing dispatch
                  </p>
                </div>
              </div>

              {/* View Mode Switcher + Minimize/Close Controls */}
              <div className="flex items-center gap-2">
                <div className="flex items-center p-1 rounded-xl bg-slate-900/90 border border-cyan-500/30 text-xs font-bold">
                  <button
                    onClick={() => setEnlargeMode('interactive')}
                    className={`px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition text-xs font-bold cursor-pointer ${
                      enlargeMode === 'interactive'
                        ? 'bg-cyan-500/25 text-cyan-200 border border-cyan-500/50 shadow-sm'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    <Layers className="w-3.5 h-3.5" />
                    Interactive 3D WebGL
                  </button>
                  <button
                    onClick={() => setEnlargeMode('cinematic')}
                    className={`px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition text-xs font-bold cursor-pointer ${
                      enlargeMode === 'cinematic'
                        ? 'bg-cyan-500/25 text-cyan-200 border border-cyan-500/50 shadow-sm'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    <Eye className="w-3.5 h-3.5" />
                    Cinematic 4K
                  </button>
                </div>

                <button
                  id="dashboard-minimize-btn"
                  onClick={() => setIsEnlarged(false)}
                  title="Minimize (Esc)"
                  aria-label="Minimize View"
                  className="px-3 py-1.5 rounded-xl bg-[rgba(6,18,45,0.7)] hover:bg-cyan-500/20 border border-cyan-500/40 hover:border-cyan-400 text-cyan-300 hover:text-white transition flex items-center gap-1.5 text-xs font-bold cursor-pointer shadow-sm active:scale-95"
                >
                  <Minimize className="w-4 h-4" />
                  <span className="hidden sm:inline">Minimize</span>
                </button>

                <button
                  onClick={() => setIsEnlarged(false)}
                  title="Close (Esc)"
                  aria-label="Close"
                  className="p-1.5 rounded-xl bg-slate-900/80 hover:bg-red-500/20 border border-slate-700 hover:border-red-500/40 text-slate-400 hover:text-red-300 transition flex items-center justify-center cursor-pointer active:scale-95"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Modal Body: Enlarged View */}
            <div className="flex-1 relative w-full h-full overflow-hidden bg-slate-950">
              {enlargeMode === 'interactive' ? (
                <div className="w-full h-full relative">
                  <Hospital3DScene
                    onSelectSection={(secKey) => {
                      setIsEnlarged(false);
                      setActiveTab(secKey as any);
                    }}
                  />
                </div>
              ) : (
                <div className="w-full h-full relative flex items-center justify-center overflow-hidden bg-slate-950">
                  <img
                    src={medisphereHeroBg || hospitalHeroBg}
                    alt="MediSphere 3D Campus Cinematic Architecture"
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover object-center scale-100"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950/85 via-transparent to-slate-950/40 pointer-events-none" />
                  <div className="absolute inset-0 bg-gradient-to-r from-slate-950/70 via-transparent to-slate-950/50 pointer-events-none" />

                  {/* Telemetry HUD badges */}
                  <div className="absolute top-5 left-5 z-10 space-y-2 pointer-events-none">
                    <div className="px-4 py-2 rounded-2xl bg-slate-950/90 border border-cyan-500/50 backdrop-blur-xl shadow-2xl flex items-center gap-2.5">
                      <div className="w-2.5 h-2.5 rounded-full bg-cyan-400 animate-ping" />
                      <span className="text-xs font-mono font-bold text-cyan-300">
                        CAMPUS SPATIAL DIGITAL TWIN &bull; 4K RESOLUTION
                      </span>
                    </div>
                  </div>

                  {/* Sector Callout Wings */}
                  <div className="absolute bottom-5 left-5 right-5 z-10 flex flex-wrap items-center justify-between gap-3 pointer-events-none">
                    <div className="flex flex-wrap items-center gap-2.5 pointer-events-auto">
                      {[
                        { name: 'Emergency Trauma Port', value: '7 Active Cases', color: 'border-red-500/50 text-red-400 bg-red-950/70 hover:bg-red-900/80', tab: 'emergency' },
                        { name: 'ICU Pavilion', value: '12 Occupied / 4 Free', color: 'border-cyan-500/50 text-cyan-300 bg-cyan-950/70 hover:bg-cyan-900/80', tab: 'beds' },
                        { name: 'Diagnostic Pathology', value: 'Hematology Assays Active', color: 'border-purple-500/50 text-purple-300 bg-purple-950/70 hover:bg-purple-900/80', tab: 'operations' },
                        { name: 'Rooftop Helipad', value: 'Medevac Clearance Ready', color: 'border-sky-500/50 text-sky-300 bg-sky-950/70 hover:bg-sky-900/80', tab: 'emergency' },
                      ].map((item, i) => (
                        <button
                          key={i}
                          onClick={() => {
                            setIsEnlarged(false);
                            setActiveTab(item.tab as any);
                          }}
                          className={`px-3.5 py-2 rounded-xl text-xs font-mono border backdrop-blur-xl shadow-lg transition-all cursor-pointer ${item.color}`}
                        >
                          <span className="font-extrabold">{item.name}: </span>
                          <span className="opacity-90">{item.value}</span>
                        </button>
                      ))}
                    </div>
                    <span className="text-xs text-slate-400 font-mono hidden md:inline-block pointer-events-none">
                      Press [Esc] or click Minimize to return
                    </span>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </motion.div>
  );
};
