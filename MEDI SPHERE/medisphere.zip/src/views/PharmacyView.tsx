import React, { useState, useMemo } from 'react';
import { useHospital } from '../context/HospitalContext';
import { Medicine } from '../types';
import {
  Pill,
  Search,
  Filter,
  Plus,
  AlertTriangle,
  CheckCircle2,
  Package,
  Calendar,
  Building,
  RotateCw,
  X,
  DollarSign,
  AlertCircle,
  TrendingDown,
} from 'lucide-react';

export const PharmacyView: React.FC = () => {
  const {
    medicines,
    addMedicine,
    updateMedicineStock,
    issueMedicine,
    patients,
    searchQuery,
  } = useHospital();

  const [localSearch, setLocalSearch] = useState<string>('');
  const [categoryFilter, setCategoryFilter] = useState<string>('ALL');
  const [stockStatusFilter, setStockStatusFilter] = useState<string>('ALL');

  // Modals
  const [showAddModal, setShowAddModal] = useState<boolean>(false);
  const [showIssueModal, setShowIssueModal] = useState<boolean>(false);
  const [selectedMedForIssue, setSelectedMedForIssue] = useState<Medicine | null>(null);
  const [issuePatientId, setIssuePatientId] = useState<string>(patients[0]?.id || '');
  const [issueQuantity, setIssueQuantity] = useState<number>(10);

  // Quick Restock state
  const [selectedMedForRestock, setSelectedMedForRestock] = useState<Medicine | null>(null);
  const [restockQty, setRestockQty] = useState<number>(50);

  // Form
  const [name, setName] = useState<string>('');
  const [category, setCategory] = useState<string>('Antibiotic');
  const [dosageForm, setDosageForm] = useState<'Tablet' | 'Capsule' | 'Syrup' | 'Injection' | 'Inhaler' | 'Ointment'>('Tablet');
  const [stockQuantity, setStockQuantity] = useState<number>(100);
  const [minThreshold, setMinThreshold] = useState<number>(20);
  const [unitPrice, setUnitPrice] = useState<number>(15);
  const [expiryDate, setExpiryDate] = useState<string>('2027-12-31');
  const [manufacturer, setManufacturer] = useState<string>('Cipla Healthcare Ltd');
  const [batchNumber, setBatchNumber] = useState<string>('BATCH-');

  const categories = [
    'Antibiotic',
    'Analgesic',
    'Cardiovascular',
    'Anti-diabetic',
    'Antihistamine',
    'Gastrointestinal',
    'Respiratory',
    'CNS Stimulant',
    'Dermatological',
  ];

  const lowStockCount = (medicines || []).filter(
    (m) => m && m.stockQuantity <= m.minThreshold && m.stockQuantity > 0
  ).length;
  const outOfStockCount = (medicines || []).filter((m) => m && m.stockQuantity === 0).length;

  const filteredMedicines = useMemo(() => {
    const q = (localSearch || searchQuery || '').toLowerCase().trim();
    return (medicines || []).filter((m) => {
      if (!m) return false;
      const name = (m.name || '').toLowerCase();
      const cat = (m.category || '').toLowerCase();
      const mfg = (m.manufacturer || '').toLowerCase();
      const id = (m.id || '').toLowerCase();

      const matchQ =
        !q ||
        name.includes(q) ||
        cat.includes(q) ||
        mfg.includes(q) ||
        id.includes(q);

      const matchCat = categoryFilter === 'ALL' || m.category === categoryFilter;
      const matchStat =
        stockStatusFilter === 'ALL' ||
        (stockStatusFilter === 'Low Stock' && m.stockQuantity <= m.minThreshold && m.stockQuantity > 0) ||
        (stockStatusFilter === 'Out of Stock' && m.stockQuantity === 0) ||
        (stockStatusFilter === 'In Stock' && m.stockQuantity > m.minThreshold);
      return matchQ && matchCat && matchStat;
    });
  }, [medicines, localSearch, searchQuery, categoryFilter, stockStatusFilter]);

  const handleAddMed = (e: React.FormEvent) => {
    e.preventDefault();
    addMedicine({
      name,
      category,
      dosageForm,
      stockQuantity,
      minThreshold,
      unitPrice,
      expiryDate,
      manufacturer,
      batchNumber: batchNumber || `BATCH-${Math.floor(Math.random() * 90000 + 10000)}`,
    });
    setShowAddModal(false);
    setName('');
  };

  const handleIssueSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedMedForIssue) return;
    const pat = patients.find((p) => p.id === issuePatientId);
    if (!pat) return;

    issueMedicine(selectedMedForIssue.id, issueQuantity, pat.name);
    setShowIssueModal(false);
  };

  const handleRestockSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedMedForRestock) return;
    updateMedicineStock(selectedMedForRestock.id, selectedMedForRestock.stockQuantity + restockQty);
    setSelectedMedForRestock(null);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-black text-white tracking-tight">Pharmacy & Formulary</h1>
            <span className="text-xs font-mono px-2.5 py-0.5 rounded-full bg-pink-500/25 text-pink-200 border border-pink-500/40 font-extrabold shadow-[0_0_10px_rgba(244,63,94,0.2)]">
              {medicines.length} Formulations
            </span>
          </div>
          <p className="text-xs text-slate-300 mt-1 font-medium">
            Real-time stock monitoring, automated batch validation, and point-of-care medication dispensing.
          </p>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-pink-500 to-rose-600 hover:from-pink-400 hover:to-rose-500 text-white text-xs font-black transition shadow-[0_0_20px_rgba(244,63,94,0.35)]"
        >
          <Plus className="w-4 h-4" />
          <span>Add Medicine / Drug</span>
        </button>
      </div>

      {/* Low Stock Alert Banner */}
      {(lowStockCount > 0 || outOfStockCount > 0) && (
        <div className="p-4 rounded-2xl glass-card border-amber-500/50 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 text-xs shadow-xl">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/25 border border-amber-500/50 flex items-center justify-center text-amber-300 shadow-[0_0_12px_rgba(245,158,11,0.3)] shrink-0">
              <AlertTriangle className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <span className="font-extrabold text-white block text-sm">
                Automated Inventory Threshold Alert
              </span>
              <p className="text-amber-200 mt-0.5 font-medium">
                {lowStockCount} medication(s) have breached safety buffer (&lt;20 units). {outOfStockCount > 0 ? `${outOfStockCount} critical item(s) are completely exhausted.` : ''}
              </p>
            </div>
          </div>
          <button
            onClick={() => setStockStatusFilter('Low Stock')}
            className="px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-500 text-white text-xs font-bold transition shadow-md whitespace-nowrap"
          >
            Review Reorder List
          </button>
        </div>
      )}

      {/* Search & Filters */}
      <div className="p-4 rounded-2xl glass-card border-pink-500/30 flex flex-col md:flex-row items-center justify-between gap-3 shadow-xl">
        <div className="relative w-full md:w-80">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-300" />
          <input
            type="text"
            placeholder="Search drug name, manufacturer, batch..."
            value={localSearch}
            onChange={(e) => setLocalSearch(e.target.value)}
            className="w-full pl-10 pr-4 py-2 text-xs rounded-xl glass-input text-white placeholder-slate-400"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2 w-full md:w-auto justify-end">
          <div className="flex items-center gap-1.5 text-xs text-slate-300 font-bold">
            <Filter className="w-3.5 h-3.5 text-cyan-300" />
            <span>Category:</span>
            <select
              value={categoryFilter}
              onChange={(e) => setCategoryFilter(e.target.value)}
              className="px-3 py-1.5 rounded-xl glass-input text-xs text-white cursor-pointer"
            >
              <option value="ALL" className="bg-slate-950 text-white">All Categories</option>
              {categories.map((c) => (
                <option key={c} value={c} className="bg-slate-950 text-white">
                  {c}
                </option>
              ))}
            </select>
          </div>

          <div className="flex items-center gap-1.5 text-xs text-slate-300 font-bold">
            <span>Stock Status:</span>
            <select
              value={stockStatusFilter}
              onChange={(e) => setStockStatusFilter(e.target.value)}
              className="px-3 py-1.5 rounded-xl glass-input text-xs text-white cursor-pointer"
            >
              <option value="ALL" className="bg-slate-950 text-white">All Stock Levels</option>
              <option value="In Stock" className="bg-slate-950 text-emerald-300">In Stock (&gt;20)</option>
              <option value="Low Stock" className="bg-slate-950 text-amber-300">Low Stock (&le;20)</option>
              <option value="Out of Stock" className="bg-slate-950 text-red-300">Depleted (0)</option>
            </select>
          </div>
        </div>
      </div>

      {/* Medicines Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredMedicines.map((med) => {
          const isOut = med.stockQuantity === 0;
          const isLow = med.stockQuantity <= med.minThreshold && !isOut;

          return (
            <div
              key={med.id}
              className="p-5 rounded-2xl glass-card border-pink-500/30 hover:border-pink-400/60 transition-all hover:-translate-y-0.5 shadow-xl flex flex-col justify-between"
            >
              <div>
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <span className="text-[10px] font-mono px-2.5 py-0.5 rounded-full bg-[rgba(6,18,45,0.8)] text-pink-200 border border-pink-500/40 font-extrabold">
                      {med.id}
                    </span>
                    <h3 className="text-base font-extrabold text-white mt-2 leading-tight">
                      {med.name}
                    </h3>
                    <span className="text-xs text-slate-300 block mt-1 font-medium">
                      {med.dosageForm} &bull; <span className="text-cyan-300 font-bold">{med.category}</span>
                    </span>
                  </div>

                  <span
                    className={`text-[9px] font-extrabold px-2.5 py-1 rounded-full uppercase tracking-wider ${
                      isOut
                        ? 'bg-red-500/25 text-red-200 border border-red-500/50 animate-pulse shadow-[0_0_10px_rgba(239,68,68,0.3)]'
                        : isLow
                        ? 'bg-amber-500/25 text-amber-200 border border-amber-500/50'
                        : 'bg-emerald-500/25 text-emerald-200 border border-emerald-500/50'
                    }`}
                  >
                    {isOut ? 'Out of Stock' : isLow ? 'Low Stock' : 'In Stock'}
                  </span>
                </div>

                <div className="mt-3 p-3 rounded-xl glass-card-subtle text-xs text-slate-200 space-y-1.5">
                  <div className="flex justify-between">
                    <span className="text-slate-300 font-medium">Available Stock:</span>
                    <span
                      className={`font-mono font-extrabold ${
                        isOut ? 'text-red-300' : isLow ? 'text-amber-300' : 'text-white'
                      }`}
                    >
                      {med.stockQuantity} Units
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-300 font-medium">Unit Tariff:</span>
                    <span className="font-mono font-extrabold text-emerald-300">₹{med.unitPrice}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-300 font-medium">Expiry Date:</span>
                    <span className="font-mono text-slate-200 font-bold">{med.expiryDate}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-300 font-medium">Manufacturer:</span>
                    <span className="text-slate-200 font-medium truncate max-w-[140px]">{med.manufacturer}</span>
                  </div>
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-pink-500/20 flex items-center justify-between gap-2">
                <button
                  disabled={isOut}
                  onClick={() => {
                    setSelectedMedForIssue(med);
                    setIssueQuantity(Math.min(10, med.stockQuantity));
                    setShowIssueModal(true);
                  }}
                  className="flex-1 py-2 rounded-xl text-xs font-black bg-gradient-to-r from-pink-500 to-rose-600 hover:from-pink-400 hover:to-rose-500 disabled:opacity-40 text-white transition flex items-center justify-center gap-1.5 shadow-[0_0_15px_rgba(244,63,94,0.3)]"
                >
                  <Pill className="w-3.5 h-3.5" />
                  <span>Dispense to Patient</span>
                </button>

                <button
                  onClick={() => {
                    setSelectedMedForRestock(med);
                    setRestockQty(50);
                  }}
                  className="p-2 rounded-xl glass-btn-secondary text-slate-300 hover:text-white transition"
                  title="Restock Inventory"
                >
                  <RotateCw className="w-4 h-4 text-cyan-300" />
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Dispense Medicine Modal */}
      {showIssueModal && selectedMedForIssue && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-2xl animate-in fade-in">
          <div className="relative w-full max-w-md rounded-3xl glass-modal border-pink-500/40 p-6 shadow-2xl">
            <button
              onClick={() => setShowIssueModal(false)}
              className="absolute top-5 right-5 p-2 rounded-xl text-slate-300 hover:text-white hover:bg-[rgba(6,18,45,0.7)] border border-cyan-500/20 transition"
            >
              <X className="w-5 h-5" />
            </button>

            <h3 className="text-base font-extrabold text-white mb-1">
              Dispense Medication to Patient
            </h3>
            <p className="text-xs text-slate-300 mb-4 font-medium">
              Drug: <strong className="text-white">{selectedMedForIssue.name}</strong> &bull; Stock: {selectedMedForIssue.stockQuantity} units
            </p>

            <form onSubmit={handleIssueSubmit} className="space-y-4 text-xs">
              <div>
                <label className="text-slate-200 font-bold block mb-1">Select Patient</label>
                <select
                  value={issuePatientId}
                  onChange={(e) => setIssuePatientId(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl glass-input text-white cursor-pointer"
                >
                  {patients.map((p) => (
                    <option key={p.id} value={p.id} className="bg-slate-950 text-white">
                      {p.name} ({p.id})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-slate-200 font-bold block mb-1">Quantity to Dispense (Units)</label>
                <input
                  type="number"
                  required
                  min={1}
                  value={issueQuantity}
                  onChange={(e) => setIssueQuantity(Number(e.target.value))}
                  className="w-full px-3.5 py-2.5 rounded-xl glass-input text-white font-mono"
                />
              </div>

              <div className="p-3.5 rounded-xl glass-card-subtle flex items-center justify-between">
                <span className="text-slate-300 font-medium">Total Prescription Cost:</span>
                <span className="font-mono font-extrabold text-emerald-300 text-base">
                  ₹{issueQuantity * selectedMedForIssue.unitPrice}
                </span>
              </div>

              <div className="pt-2 flex items-center justify-end gap-3 border-t border-pink-500/20">
                <button
                  type="button"
                  onClick={() => setShowIssueModal(false)}
                  className="px-4 py-2.5 rounded-xl glass-btn-secondary text-slate-200 hover:text-white font-bold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-pink-500 to-rose-600 hover:from-pink-400 hover:to-rose-500 text-white font-black shadow-[0_0_15px_rgba(244,63,94,0.35)] transition"
                >
                  Authorize Dispensing
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Restock Modal */}
      {selectedMedForRestock && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-2xl animate-in fade-in">
          <div className="relative w-full max-w-md rounded-3xl glass-modal border-cyan-500/40 p-6 shadow-2xl">
            <button
              onClick={() => setSelectedMedForRestock(null)}
              className="absolute top-5 right-5 p-2 rounded-xl text-slate-300 hover:text-white hover:bg-[rgba(6,18,45,0.7)] border border-cyan-500/20 transition"
            >
              <X className="w-5 h-5" />
            </button>

            <h3 className="text-base font-extrabold text-white mb-1">Restock Medicine Formulary</h3>
            <p className="text-xs text-slate-300 mb-4 font-medium">
              Restocking: <strong className="text-white">{selectedMedForRestock.name}</strong> (Current: {selectedMedForRestock.stockQuantity})
            </p>

            <form onSubmit={handleRestockSubmit} className="space-y-4 text-xs">
              <div>
                <label className="text-slate-200 font-bold block mb-1">Additional Units Received</label>
                <input
                  type="number"
                  required
                  min={1}
                  value={restockQty}
                  onChange={(e) => setRestockQty(Number(e.target.value))}
                  className="w-full px-3.5 py-2.5 rounded-xl glass-input text-white font-mono"
                />
              </div>

              <div className="pt-2 flex items-center justify-end gap-3 border-t border-cyan-500/20">
                <button
                  type="button"
                  onClick={() => setSelectedMedForRestock(null)}
                  className="px-4 py-2.5 rounded-xl glass-btn-secondary text-slate-200 hover:text-white font-bold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-black shadow-[0_0_15px_rgba(6,182,212,0.35)] transition"
                >
                  Confirm Restock
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Add Medicine Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-2xl animate-in fade-in">
          <div className="relative w-full max-w-2xl rounded-3xl glass-modal border-pink-500/40 p-6 shadow-2xl overflow-y-auto max-h-[90vh]">
            <button
              onClick={() => setShowAddModal(false)}
              className="absolute top-5 right-5 p-2 rounded-xl text-slate-300 hover:text-white hover:bg-[rgba(6,18,45,0.7)] border border-cyan-500/20 transition"
            >
              <X className="w-5 h-5" />
            </button>

            <h2 className="text-xl font-black text-white mb-1">Enroll Pharmacological Product</h2>
            <p className="text-xs text-slate-300 mb-6 font-medium">
              Registers medicine item into hospital pharmacy inventory.
            </p>

            <form onSubmit={handleAddMed} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-bold text-slate-200 block mb-1">Medicine Name</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Paracetamol 650mg"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl glass-input text-xs text-white"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-slate-200 block mb-1">Therapeutic Category</label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl glass-input text-xs text-white cursor-pointer"
                  >
                    {categories.map((c) => (
                      <option key={c} value={c} className="bg-slate-950 text-white">
                        {c}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="text-xs font-bold text-slate-200 block mb-1">Dosage Form</label>
                  <select
                    value={dosageForm}
                    onChange={(e) => setDosageForm(e.target.value as any)}
                    className="w-full px-3.5 py-2.5 rounded-xl glass-input text-xs text-white cursor-pointer"
                  >
                    <option value="Tablet" className="bg-slate-950 text-white">Tablet</option>
                    <option value="Capsule" className="bg-slate-950 text-white">Capsule</option>
                    <option value="Syrup" className="bg-slate-950 text-white">Syrup</option>
                    <option value="Injection" className="bg-slate-950 text-white">Injection</option>
                    <option value="Inhaler" className="bg-slate-950 text-white">Inhaler</option>
                    <option value="Ointment" className="bg-slate-950 text-white">Ointment</option>
                  </select>
                </div>
                <div>
                  <label className="text-xs font-bold text-slate-200 block mb-1">Initial Stock</label>
                  <input
                    type="number"
                    required
                    min={0}
                    value={stockQuantity}
                    onChange={(e) => setStockQuantity(Number(e.target.value))}
                    className="w-full px-3.5 py-2.5 rounded-xl glass-input text-xs text-white font-mono"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-slate-200 block mb-1">Unit Tariff (₹)</label>
                  <input
                    type="number"
                    required
                    min={1}
                    value={unitPrice}
                    onChange={(e) => setUnitPrice(Number(e.target.value))}
                    className="w-full px-3.5 py-2.5 rounded-xl glass-input text-xs text-white font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-bold text-slate-200 block mb-1">Manufacturer</label>
                  <input
                    type="text"
                    required
                    value={manufacturer}
                    onChange={(e) => setManufacturer(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl glass-input text-xs text-white"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-slate-200 block mb-1">Expiry Date</label>
                  <input
                    type="date"
                    required
                    value={expiryDate}
                    onChange={(e) => setExpiryDate(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl glass-input text-xs text-white"
                  />
                </div>
              </div>

              <div className="pt-4 flex items-center justify-end gap-3 border-t border-pink-500/20">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2.5 rounded-xl glass-btn-secondary text-xs font-bold text-slate-200"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-pink-500 to-rose-600 hover:from-pink-400 hover:to-rose-500 text-white text-xs font-black shadow-[0_0_20px_rgba(244,63,94,0.35)] transition"
                >
                  Add to Formulary
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
