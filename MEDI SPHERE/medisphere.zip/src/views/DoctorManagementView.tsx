import React, { useState, useMemo } from 'react';
import { useHospital } from '../context/HospitalContext';
import { Doctor, DoctorStatus, DoctorSpecialization } from '../types';
import {
  Search,
  Filter,
  Plus,
  Calendar,
  Clock,
  MapPin,
  Award,
  Stethoscope,
  X,
  CheckCircle2,
  Star,
  Info,
  ChevronRight,
  Activity,
  Users,
  Phone,
  Mail,
} from 'lucide-react';
import { ErrorBoundary } from '../components/ErrorBoundary';
import { BookConsultModal } from '../components/doctors/BookConsultModal';

export const DoctorManagementView: React.FC = () => {
  const {
    doctors = [],
    patients = [],
    addDoctor,
    updateDoctor,
    bookAppointment,
    initiateBookingForDoctor,
    searchQuery = '',
    activeSubTab,
    setActiveNavigation,
    appointments = [],
  } = useHospital();

  const currentTab = ['directory', 'specializations', 'availability', 'schedule', 'assigned'].includes(activeSubTab)
    ? activeSubTab
    : 'directory';

  const [localSearch, setLocalSearch] = useState<string>('');
  const [selectedSpec, setSelectedSpec] = useState<string>('ALL');
  const [selectedStatus, setSelectedStatus] = useState<string>('ALL');

  // Modals & Detail View
  const [showAddModal, setShowAddModal] = useState<boolean>(false);
  const [inspectDoctor, setInspectDoctor] = useState<Doctor | null>(null);

  // Book Consult Modal State
  const [bookConsultDoctor, setBookConsultDoctor] = useState<Doctor | null>(null);

  // Booking Success Toast State
  const [bookingSuccess, setBookingSuccess] = useState<{
    doctor: string;
    patient: string;
    date: string;
    time: string;
    appointmentId: string;
  } | null>(null);

  // Add Doctor Form State
  const [formData, setFormData] = useState({
    name: '',
    specialization: 'General Medicine' as DoctorSpecialization,
    qualification: 'MBBS, MD',
    experienceYears: 12,
    department: 'Department of Internal Medicine',
    contact: '+91 98201 ',
    email: '',
    availableDays: 'Mon, Tue, Wed, Thu, Fri',
    availableTimeSlot: '08:30 AM - 02:30 PM',
    consultationFee: 800,
    roomNumber: 'OPD-101',
    status: 'Available' as DoctorStatus,
    appointmentStatus: 'Available for Booking',
    description: '',
  });

  const specializationsList: DoctorSpecialization[] = [
    'General Medicine',
    'Cardiology',
    'Ophthalmology',
    'ENT',
    'Dermatology',
    'Neurology',
    'Orthopedics',
    'Pediatrics',
    'Gynecology',
    'Psychiatry',
    'Oncology',
    'Pulmonology',
    'Gastroenterology',
    'Dentistry',
    'Endocrinology',
    'Nephrology',
    'Urology',
    'Radiology',
    'Physiotherapy',
    'Anesthesiology',
    'Neurosurgery',
    'Cardiothoracic Surgery',
    'Rheumatology',
    'General Surgery',
    'Emergency Medicine',
  ];

  // Safe accessor helpers
  const getDaysArray = (doc: Doctor): string[] => {
    if (!doc) return ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'];
    if (Array.isArray(doc.availableDays) && doc.availableDays.length > 0) {
      return doc.availableDays;
    }
    if (typeof doc.availableDays === 'string' && (doc.availableDays as string).length > 0) {
      return (doc.availableDays as string).split(',').map((s) => s.trim());
    }
    return ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'];
  };

  const getDaysString = (doc: Doctor): string => {
    return getDaysArray(doc).join(', ');
  };

  const getTimeSlot = (doc: Doctor): string => {
    if (!doc) return '08:30 AM - 02:30 PM';
    return doc.availableTimeSlot || doc.availability || '08:30 AM - 02:30 PM';
  };

  const getContactPhone = (doc: Doctor): string => {
    if (!doc) return '+91 98201 10000';
    return doc.contact || doc.phone || '+91 98201 10000';
  };

  const getDepartmentName = (doc: Doctor): string => {
    if (!doc) return 'Department of Clinical Medicine';
    return doc.department || `Department of ${doc.specialization || 'Clinical Care'}`;
  };

  // Safe search & filter
  const filteredDoctors = useMemo(() => {
    const q = (localSearch || searchQuery || '').toLowerCase().trim();

    return (doctors || []).filter((doc) => {
      if (!doc) return false;

      const name = (doc.name || '').toLowerCase();
      const id = (doc.id || '').toLowerCase();
      const spec = (doc.specialization || '').toLowerCase();
      const dept = getDepartmentName(doc).toLowerCase();
      const room = (doc.roomNumber || '').toLowerCase();
      const qual = (doc.qualification || '').toLowerCase();

      const matchQ =
        !q ||
        name.includes(q) ||
        id.includes(q) ||
        spec.includes(q) ||
        dept.includes(q) ||
        room.includes(q) ||
        qual.includes(q);

      const matchSpec = selectedSpec === 'ALL' || doc.specialization === selectedSpec;
      const matchStat = selectedStatus === 'ALL' || doc.status === selectedStatus;

      return matchQ && matchSpec && matchStat;
    });
  }, [doctors, localSearch, searchQuery, selectedSpec, selectedStatus]);

  const handleOpenAdd = () => {
    setFormData({
      name: 'Dr. ',
      specialization: 'General Medicine',
      qualification: 'MBBS, MD (Internal Medicine)',
      experienceYears: 12,
      department: 'Department of Internal Medicine & Preventive Health',
      contact: '+91 98201 ',
      email: '',
      availableDays: 'Mon, Tue, Wed, Thu, Fri',
      availableTimeSlot: '08:30 AM - 02:30 PM',
      consultationFee: 800,
      roomNumber: 'OPD-101',
      status: 'Available',
      appointmentStatus: 'Available for Booking',
      description: 'Consultant physician specializing in multi-system care and adult preventive healthcare.',
    });
    setShowAddModal(true);
  };

  const handleSaveAdd = (e: React.FormEvent) => {
    e.preventDefault();
    addDoctor({
      ...formData,
      availableDays: formData.availableDays.split(',').map((s) => s.trim()),
      phone: formData.contact,
      availability: formData.availableTimeSlot,
      rating: 4.9,
      activeConsultationsCount: 1,
    });
    setShowAddModal(false);
  };

  return (
    <ErrorBoundary fallbackTitle="Doctor Management Roster">
      <div className="space-y-6 animate-in fade-in duration-300">
        {/* Success Notification Banner */}
        {bookingSuccess && (
          <div className="p-4 rounded-2xl bg-emerald-950/85 border border-emerald-500/50 backdrop-blur-2xl shadow-[0_0_30px_rgba(16,185,129,0.3)] flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-white animate-in fade-in slide-in-from-top duration-300">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-300 shrink-0">
                <CheckCircle2 className="w-5 h-5" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h4 className="text-sm font-black text-white">
                    Appointment booked successfully.
                  </h4>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/30 text-emerald-200 border border-emerald-500/40 font-bold">
                    {bookingSuccess.appointmentId}
                  </span>
                </div>
                <p className="text-xs text-emerald-200/90 mt-0.5 font-medium">
                  Doctor: <strong className="text-white">{bookingSuccess.doctor}</strong> &bull; Patient: <strong className="text-white">{bookingSuccess.patient}</strong> &bull; Date: <strong className="text-white">{bookingSuccess.date}</strong> &bull; Time: <strong className="text-white">{bookingSuccess.time}</strong>
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 self-end sm:self-auto">
              <button
                onClick={() => setActiveNavigation('appointments', 'today')}
                className="px-3.5 py-1.5 rounded-xl bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-500/40 text-emerald-200 text-xs font-bold transition flex items-center gap-1.5 active:scale-95"
              >
                <Calendar className="w-3.5 h-3.5" />
                <span>View in Appointments &rarr;</span>
              </button>
              <button
                onClick={() => setBookingSuccess(null)}
                className="p-1.5 rounded-lg text-emerald-300 hover:text-white hover:bg-white/10 transition"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* Header Banner */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-2xl font-black text-white tracking-tight flex items-center gap-2.5">
                <Stethoscope className="w-6 h-6 text-cyan-400" />
                <span>Physicians & Clinical Specialists</span>
              </h1>
              <span className="text-xs font-mono px-3 py-0.5 rounded-full bg-cyan-500/20 text-cyan-200 border border-cyan-500/40 font-bold shadow-[0_0_10px_rgba(6,182,212,0.2)]">
                {(doctors || []).length} Specialists
              </span>
            </div>
            <p className="text-xs text-slate-300 mt-1 font-medium">
              25 clinical disciplines, 3–5 credentialed doctors per specialty, real-time consultation statuses, and OPD scheduling.
            </p>
          </div>

          <button
            onClick={handleOpenAdd}
            className="glass-btn inline-flex items-center gap-2 px-5 py-2.5 rounded-xl text-white text-xs font-extrabold shadow-[0_0_20px_rgba(6,182,212,0.35)] active:scale-95"
          >
            <Plus className="w-4 h-4" />
            <span>Register Medical Specialist</span>
          </button>
        </div>

        {/* Sub-Options Navigation Bar */}
        <div className="flex flex-wrap items-center gap-2 border-b border-cyan-500/20 pb-3">
          {[
            { id: 'directory', label: 'Doctor Directory' },
            { id: 'specializations', label: 'All 25 Specializations' },
            { id: 'availability', label: 'Real-Time Availability' },
            { id: 'schedule', label: 'OPD Schedule & Cabins' },
            { id: 'assigned', label: 'Assigned Consultations' },
          ].map((sub) => (
            <button
              key={sub.id}
              onClick={() => setActiveNavigation('doctors', sub.id)}
              className={`px-4 py-2 rounded-xl text-xs font-bold transition ${
                currentTab === sub.id
                  ? 'bg-cyan-500/25 text-cyan-200 border border-cyan-400/50 shadow-[0_0_14px_rgba(6,182,212,0.3)]'
                  : 'text-slate-300 hover:text-white bg-[rgba(6,182,212,0.06)] hover:bg-[rgba(6,182,212,0.15)] border border-cyan-500/15'
              }`}
            >
              {sub.label}
            </button>
          ))}
        </div>

        {/* ======================================================== */}
        {/* TAB 1: ALL 25 SPECIALTIES GRID */}
        {/* ======================================================== */}
        {currentTab === 'specializations' && (
          <div className="space-y-4">
            <div className="p-5 rounded-2xl glass-card flex flex-col sm:flex-row sm:items-center justify-between gap-2 shadow-xl">
              <div>
                <h3 className="text-sm font-extrabold text-white mb-0.5">25 Clinical Medical Disciplines</h3>
                <p className="text-xs text-slate-300 font-medium">
                  Select any clinical specialty below to instantly filter credentialed physicians and view consultation timings.
                </p>
              </div>
              <div className="text-xs font-mono text-cyan-200 bg-[rgba(6,18,45,0.6)] px-3.5 py-1.5 rounded-xl border border-cyan-500/40 font-bold">
                25 Departments &bull; 75 Credentialed Doctors
              </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
              {specializationsList.map((spec) => {
                const count = (doctors || []).filter((d) => d && d.specialization === spec).length;
                const isSelected = selectedSpec === spec;
                return (
                  <button
                    key={spec}
                    onClick={() => {
                      setSelectedSpec(spec);
                      setActiveNavigation('doctors', 'directory');
                    }}
                    className={`p-3.5 rounded-2xl text-left transition-all relative overflow-hidden group ${
                      isSelected
                        ? 'bg-cyan-500/25 border-2 border-cyan-400 text-white shadow-[0_0_20px_rgba(6,182,212,0.3)]'
                        : 'glass-card border-cyan-500/20 hover:border-cyan-400/50 text-slate-200 hover:shadow-[0_8px_24px_rgba(0,0,0,0.5)]'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <div className="w-7 h-7 rounded-lg bg-cyan-500/20 border border-cyan-400/30 flex items-center justify-center text-cyan-300 group-hover:scale-110 transition shadow-[0_0_8px_rgba(6,182,212,0.2)]">
                        <Stethoscope className="w-3.5 h-3.5" />
                      </div>
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-[rgba(6,18,45,0.7)] border border-cyan-500/30 text-cyan-200 font-extrabold">
                        {count} {count === 1 ? 'Doctor' : 'Doctors'}
                      </span>
                    </div>
                    <h4 className="text-xs font-bold text-white line-clamp-1 group-hover:text-cyan-200 transition">
                      {spec}
                    </h4>
                    <span className="text-[10px] text-slate-400 mt-1 block flex items-center gap-1 font-medium">
                      <span>View specialists</span>
                      <ChevronRight className="w-3 h-3 group-hover:translate-x-0.5 transition text-cyan-400" />
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* ======================================================== */}
        {/* TAB 2: DOCTOR AVAILABILITY BOARD */}
        {/* ======================================================== */}
        {currentTab === 'availability' && (
          <div className="space-y-4">
            <div className="p-5 rounded-2xl glass-card flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-xl">
              <div>
                <h3 className="text-sm font-extrabold text-white">Real-Time Clinical Availability Roster</h3>
                <p className="text-xs text-slate-300 font-medium">
                  Live occupancy and active consultation statuses across hospital departments.
                </p>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-mono px-3.5 py-1.5 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-200 font-bold shadow-[0_0_10px_rgba(16,185,129,0.2)]">
                  {(doctors || []).filter((d) => d && d.status === 'Available').length} Available
                </span>
                <span className="text-xs font-mono px-3.5 py-1.5 rounded-xl bg-cyan-500/20 border border-cyan-500/40 text-cyan-200 font-bold shadow-[0_0_10px_rgba(6,182,212,0.2)]">
                  {(doctors || []).filter((d) => d && d.status === 'In Consultation').length} In Consultation
                </span>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
              {(doctors || []).map((doc) => {
                if (!doc) return null;
                const status = doc.status || 'Available';
                return (
                  <div
                    key={doc.id}
                    className="p-4 rounded-2xl glass-card hover:border-cyan-400/40 transition flex items-center justify-between gap-3 shadow-md"
                  >
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2">
                        <h4 className="text-xs font-black text-white truncate">{doc.name || 'Doctor'}</h4>
                        {doc.rating && (
                          <span className="text-[10px] text-amber-300 font-mono flex items-center gap-0.5 font-bold">
                            <Star className="w-2.5 h-2.5 fill-current" />
                            {doc.rating}
                          </span>
                        )}
                      </div>
                      <span className="text-[11px] text-cyan-300 font-bold block truncate">{doc.specialization}</span>
                      <span className="text-[10px] text-slate-300 font-medium block mt-0.5 truncate">
                        {doc.roomNumber || 'OPD'} &bull; {getTimeSlot(doc)}
                      </span>
                    </div>

                    <button
                      onClick={() =>
                        updateDoctor(doc.id, {
                          status:
                            status === 'Available'
                              ? 'In Consultation'
                              : status === 'In Consultation'
                              ? 'Unavailable'
                              : 'Available',
                        })
                      }
                      className={`px-3.5 py-1.5 rounded-xl text-xs font-extrabold transition border shrink-0 shadow-sm ${
                        status === 'Available'
                          ? 'bg-emerald-500/25 text-emerald-200 border-emerald-500/50 hover:bg-emerald-500/35'
                          : status === 'In Consultation'
                          ? 'bg-cyan-500/25 text-cyan-200 border-cyan-500/50 hover:bg-cyan-500/35 animate-pulse'
                          : 'bg-amber-500/25 text-amber-200 border-amber-500/50 hover:bg-amber-500/35'
                      }`}
                      title="Click to cycle status: Available -> In Consultation -> Unavailable"
                    >
                      {status}
                    </button>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* ======================================================== */}
        {/* TAB 3: OPD SCHEDULE & CABINS */}
        {/* ======================================================== */}
        {currentTab === 'schedule' && (
          <div className="p-6 rounded-2xl glass-card space-y-4 shadow-xl">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div>
                <h3 className="text-sm font-extrabold text-white">OPD Clinical Roster & Cabin Assignments</h3>
                <p className="text-xs text-slate-300 font-medium">
                  Daily physician rotation schedules, consultation slots, and OPD cabin allocations.
                </p>
              </div>
              <div className="text-xs font-mono text-cyan-200 bg-[rgba(6,18,45,0.6)] px-3 py-1 rounded-xl border border-cyan-500/30 font-bold">
                {(doctors || []).length} Synchronized Cabins
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {(doctors || []).map((doc) => {
                if (!doc) return null;
                return (
                  <div
                    key={doc.id}
                    className="p-4 rounded-xl glass-card-subtle flex items-center justify-between gap-3 shadow-md"
                  >
                    <div className="min-w-0 flex-1">
                      <span className="text-xs font-bold text-white block truncate">
                        {doc.name} &bull; <span className="text-cyan-300">{doc.specialization}</span>
                      </span>
                      <span className="text-[11px] text-slate-300 block mt-0.5 truncate font-medium">
                        Cabin: <strong className="text-white font-mono font-bold">{doc.roomNumber || 'OPD-101'}</strong> &bull; {getDaysString(doc)}
                      </span>
                    </div>
                    <div className="text-right shrink-0">
                      <span className="text-xs font-mono text-cyan-200 font-bold block">
                        {getTimeSlot(doc)}
                      </span>
                      <span className="text-[10px] text-emerald-300 font-mono font-extrabold">
                        ₹{(doc.consultationFee || 800).toLocaleString('en-IN')}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* ======================================================== */}
        {/* TAB 4: ASSIGNED CONSULTATIONS */}
        {/* ======================================================== */}
        {currentTab === 'assigned' && (
          <div className="p-6 rounded-2xl glass-card space-y-4 shadow-xl">
            <div>
              <h3 className="text-sm font-extrabold text-white">Physician Assigned Consultations & Cases</h3>
              <p className="text-xs text-slate-300 font-medium">
                Real-time mapping of scheduled patient appointments and consultations per physician.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {(doctors || []).map((doc) => {
                if (!doc) return null;
                const assignedApts = (appointments || []).filter((a) => a && a.doctorId === doc.id);
                return (
                  <div key={doc.id} className="p-4 rounded-xl glass-card-subtle">
                    <div className="flex items-center justify-between mb-2">
                      <div>
                        <span className="text-xs font-bold text-white block">{doc.name}</span>
                        <span className="text-[11px] text-cyan-300 font-bold">{doc.specialization}</span>
                      </div>
                      <span className="text-[10px] font-mono px-2.5 py-0.5 rounded-full bg-cyan-500/20 text-cyan-200 border border-cyan-500/40 font-bold">
                        {assignedApts.length} {assignedApts.length === 1 ? 'Case' : 'Cases'}
                      </span>
                    </div>

                    <div className="text-[11px] text-slate-300 space-y-1 mt-2">
                      {assignedApts.length === 0 ? (
                        <span className="text-slate-400 text-[11px] italic font-medium">No appointments booked today</span>
                      ) : (
                        assignedApts.map((a) => (
                          <div
                            key={a.id}
                            className="flex items-center justify-between text-slate-200 bg-[rgba(6,18,45,0.6)] px-3 py-1.5 rounded-lg border border-cyan-500/20"
                          >
                            <span className="truncate max-w-[200px] font-semibold text-xs text-white">
                              &bull; {a.patientName || 'Patient'}
                            </span>
                            <span className="font-mono text-cyan-300 text-[11px] shrink-0 font-bold">
                              {a.timeSlot || '09:00 AM'}
                            </span>
                          </div>
                        ))
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* ======================================================== */}
        {/* TAB 5: DOCTOR DIRECTORY (DEFAULT) */}
        {/* ======================================================== */}
        {currentTab === 'directory' && (
          <>
            {/* Filter Toolbar */}
            <div className="p-4 rounded-2xl glass-card flex flex-col md:flex-row items-center justify-between gap-3 shadow-xl">
              <div className="relative w-full md:w-80">
                <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-cyan-300" />
                <input
                  type="text"
                  placeholder="Search doctor name, specialty, cabin, qualification..."
                  value={localSearch}
                  onChange={(e) => setLocalSearch(e.target.value)}
                  className="w-full pl-9 pr-8 py-2.5 text-xs rounded-xl glass-input text-white placeholder-slate-400 font-medium"
                />
                {localSearch && (
                  <button
                    onClick={() => setLocalSearch('')}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-300 hover:text-white"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>

              <div className="flex flex-wrap items-center gap-2 w-full md:w-auto">
                <div className="flex items-center gap-1.5 text-xs text-slate-200 font-bold">
                  <Filter className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Specialty:</span>
                  <select
                    value={selectedSpec}
                    onChange={(e) => setSelectedSpec(e.target.value)}
                    className="px-3 py-1.5 rounded-xl glass-input text-xs text-cyan-200 font-bold cursor-pointer"
                  >
                    <option value="ALL" className="bg-slate-950 text-white">All 25 Specializations</option>
                    {specializationsList.map((spec) => (
                      <option key={spec} value={spec} className="bg-slate-950 text-white">
                        {spec}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="flex items-center gap-1.5 text-xs text-slate-200 font-bold">
                  <span>Status:</span>
                  <select
                    value={selectedStatus}
                    onChange={(e) => setSelectedStatus(e.target.value)}
                    className="px-3 py-1.5 rounded-xl glass-input text-xs text-cyan-200 font-bold cursor-pointer"
                  >
                    <option value="ALL" className="bg-slate-950 text-white">All Statuses</option>
                    <option value="Available" className="bg-slate-950 text-emerald-300">Available</option>
                    <option value="In Consultation" className="bg-slate-950 text-cyan-300">In Consultation</option>
                    <option value="On Leave" className="bg-slate-950 text-amber-300">On Leave</option>
                    <option value="Emergency Duty" className="bg-slate-950 text-red-300">Emergency Duty</option>
                    <option value="Unavailable" className="bg-slate-950 text-slate-400">Unavailable</option>
                  </select>
                </div>

                {(selectedSpec !== 'ALL' || selectedStatus !== 'ALL' || localSearch) && (
                  <button
                    onClick={() => {
                      setSelectedSpec('ALL');
                      setSelectedStatus('ALL');
                      setLocalSearch('');
                    }}
                    className="px-3 py-1.5 rounded-xl glass-btn-secondary text-xs text-slate-300 hover:text-white font-bold transition"
                  >
                    Reset Filters
                  </button>
                )}
              </div>
            </div>

            {/* Filter Stats Bar */}
            <div className="flex items-center justify-between text-xs px-1 text-slate-300">
              <span>
                Showing <strong className="text-white font-bold">{filteredDoctors.length}</strong> of{' '}
                <strong className="text-cyan-300">{(doctors || []).length}</strong> specialists
                {selectedSpec !== 'ALL' && (
                  <span className="text-cyan-300 font-semibold ml-1">in {selectedSpec}</span>
                )}
              </span>
              <span className="text-[11px] font-mono text-cyan-300/80 font-bold">
                Clinical Roster Synchronized &bull; Real-Time OPD
              </span>
            </div>

            {/* Doctors Grid */}
            {filteredDoctors.length === 0 ? (
              <div className="p-12 text-center rounded-3xl glass-card text-slate-300">
                <Stethoscope className="w-10 h-10 mx-auto text-cyan-400 mb-3 opacity-60" />
                <h4 className="text-base font-bold text-white">No doctors match your search filters</h4>
                <p className="text-xs text-slate-300 mt-1 max-w-sm mx-auto">
                  Try adjusting the specialization or keyword search, or click "Reset Filters" above.
                </p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {filteredDoctors.map((doc) => {
                  if (!doc) return null;
                  const status = doc.status || 'Available';
                  const daysStr = getDaysString(doc);
                  const timeSlot = getTimeSlot(doc);
                  const dept = getDepartmentName(doc);

                  return (
                    <div
                      key={doc.id}
                      className="p-5 rounded-2xl glass-card hover:border-cyan-400/50 transition-all hover:-translate-y-0.5 hover:shadow-[0_16px_36px_rgba(0,0,0,0.6),0_0_20px_rgba(6,182,212,0.2)] flex flex-col justify-between group"
                    >
                      <div>
                        {/* Top Header & Avatar */}
                        <div className="flex items-start justify-between gap-2">
                          <div className="flex items-center gap-3">
                            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-cyan-600 to-blue-700 flex items-center justify-center text-white font-extrabold text-base shadow-[0_0_12px_rgba(6,182,212,0.3)] shrink-0 border border-cyan-400/30">
                              {(doc.name || 'D').replace('Dr. ', '').charAt(0)}
                            </div>
                            <div className="min-w-0">
                              <div className="flex items-center gap-1.5">
                                <h3 className="text-base font-extrabold text-white tracking-tight leading-tight truncate group-hover:text-cyan-200 transition">
                                  {doc.name || 'Doctor'}
                                </h3>
                              </div>
                              <div className="flex items-center gap-1.5 mt-0.5">
                                <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-cyan-950/80 text-cyan-200 border border-cyan-500/30 font-bold">
                                  {doc.id}
                                </span>
                                <span className="text-xs font-bold text-cyan-300 truncate">
                                  {doc.specialization}
                                </span>
                              </div>
                              {doc.qualification && (
                                <span className="text-[10px] text-slate-300 block truncate font-mono mt-0.5 font-medium">
                                  {doc.qualification} &bull; {doc.experienceYears || 10} yrs exp
                                </span>
                              )}
                            </div>
                          </div>

                          <span
                            className={`text-[9px] font-extrabold px-2.5 py-1 rounded-full uppercase tracking-wider shrink-0 ${
                              status === 'Available'
                                ? 'bg-emerald-500/25 text-emerald-200 border border-emerald-500/50'
                                : status === 'In Consultation'
                                ? 'bg-cyan-500/25 text-cyan-200 border border-cyan-500/50 animate-pulse'
                                : status === 'Emergency Duty'
                                ? 'bg-red-500/25 text-red-200 border border-red-500/50 shadow-[0_0_8px_rgba(239,68,68,0.3)]'
                                : status === 'On Leave'
                                ? 'bg-amber-500/25 text-amber-200 border border-amber-500/50'
                                : 'bg-slate-800/80 text-slate-300 border border-slate-700'
                            }`}
                          >
                            {status}
                          </span>
                        </div>

                        {/* Specs and Details: Comprehensive 12 Fields */}
                        <div className="mt-4 pt-3 border-t border-cyan-500/20 space-y-1.5 text-xs text-slate-200">
                          <div className="flex items-center justify-between">
                            <span className="text-slate-400 font-medium text-[11px]">Department:</span>
                            <span className="text-cyan-200 font-semibold truncate max-w-[160px] text-[11px]">
                              {dept}
                            </span>
                          </div>

                          <div className="flex items-center justify-between">
                            <span className="text-slate-400 font-medium text-[11px]">OPD Room / Cabin:</span>
                            <span className="font-mono text-white font-bold">{doc.roomNumber || 'OPD-101'}</span>
                          </div>

                          <div className="flex items-center justify-between">
                            <span className="text-slate-400 font-medium text-[11px]">Consultation Fee:</span>
                            <span className="font-mono font-extrabold text-emerald-300">
                              ₹{(doc.consultationFee || 800).toLocaleString('en-IN')}
                            </span>
                          </div>

                          <div className="flex items-center justify-between">
                            <span className="text-slate-400 font-medium text-[11px]">Available Hours:</span>
                            <span className="font-mono text-cyan-200 font-bold text-[11px] truncate max-w-[160px]">
                              {timeSlot}
                            </span>
                          </div>

                          <div className="flex items-center justify-between">
                            <span className="text-slate-400 font-medium text-[11px]">Available Days:</span>
                            <span className="text-slate-200 truncate max-w-[150px] text-[11px] font-medium">
                              {daysStr}
                            </span>
                          </div>

                          <div className="pt-1 border-t border-cyan-500/10 space-y-1">
                            <div className="flex items-center gap-1.5 text-[11px] text-slate-300 truncate">
                              <Phone className="w-3 h-3 text-cyan-400 shrink-0" />
                              <span className="font-mono">{getContactPhone(doc)}</span>
                            </div>
                            <div className="flex items-center gap-1.5 text-[11px] text-slate-300 truncate">
                              <Mail className="w-3 h-3 text-cyan-400 shrink-0" />
                              <span className="truncate">{doc.email || `${doc.id?.toLowerCase()}@medisphere.org`}</span>
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* Bottom Action Buttons: Profile & Book Appointment */}
                      <div className="mt-5 pt-3 border-t border-cyan-500/20 flex items-center gap-2.5">
                        <button
                          onClick={() => setInspectDoctor(doc)}
                          className="w-1/3 py-2.5 rounded-xl text-xs font-bold glass-btn-secondary text-slate-200 hover:text-white transition flex items-center justify-center gap-1.5 active:scale-95"
                          title="View doctor credentials & profile"
                        >
                          <Info className="w-3.5 h-3.5 text-cyan-400" />
                          <span>Profile</span>
                        </button>

                        <button
                          onClick={() => {
                            if (initiateBookingForDoctor) {
                              initiateBookingForDoctor(doc);
                            } else {
                              setBookConsultDoctor(doc);
                            }
                          }}
                          className="flex-1 py-2.5 rounded-xl text-xs font-extrabold glass-btn text-white transition flex items-center justify-center gap-2 shadow-md shadow-cyan-500/25 active:scale-95"
                          title={`Book appointment with ${doc.name}`}
                        >
                          <Calendar className="w-3.5 h-3.5" />
                          <span>Book Appointment</span>
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </>
        )}

        {/* ======================================================== */}
        {/* INSPECT DOCTOR CREDENTIALS MODAL */}
        {/* ======================================================== */}
        {inspectDoctor && (
          <div
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-2xl animate-in fade-in"
            onClick={(e) => {
              if (e.target === e.currentTarget) {
                setInspectDoctor(null);
              }
            }}
          >
            <div className="relative w-full max-w-xl rounded-3xl glass-modal p-6 sm:p-7 overflow-y-auto max-h-[90vh]">
              <button
                onClick={() => setInspectDoctor(null)}
                className="absolute top-5 right-5 p-2 rounded-xl text-slate-300 hover:text-white hover:bg-[rgba(6,18,45,0.7)] border border-cyan-500/20 transition flex items-center gap-1 text-xs"
              >
                <X className="w-4 h-4" />
                <span className="hidden sm:inline text-[11px] font-mono">Close</span>
              </button>

              <div className="flex items-start gap-4 mb-6">
                <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center text-white font-extrabold text-2xl shadow-[0_0_20px_rgba(6,182,212,0.35)] shrink-0 border border-cyan-400/40">
                  {inspectDoctor.name.replace('Dr. ', '').charAt(0)}
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h2 className="text-xl font-extrabold text-white tracking-tight">{inspectDoctor.name}</h2>
                    <span className="text-[10px] font-mono px-2.5 py-0.5 rounded-full bg-cyan-500/20 text-cyan-200 border border-cyan-400/40 font-bold">
                      {inspectDoctor.id}
                    </span>
                  </div>
                  <span className="text-xs font-bold text-cyan-300 block mt-0.5">
                    {inspectDoctor.specialization} &bull; {inspectDoctor.qualification || 'MBBS, MD'}
                  </span>
                  <span className="text-[11px] text-slate-300 font-medium block mt-0.5">
                    {getDepartmentName(inspectDoctor)}
                  </span>
                </div>
              </div>

              {inspectDoctor.description && (
                <div className="p-4 rounded-xl glass-card-subtle text-xs text-slate-200 leading-relaxed mb-5 font-medium">
                  <p>{inspectDoctor.description}</p>
                </div>
              )}

              <div className="grid grid-cols-2 gap-3 text-xs mb-6">
                <div className="p-3.5 rounded-xl glass-card-subtle">
                  <span className="text-slate-300 block text-[10px] font-semibold">Cabin Location</span>
                  <span className="font-mono text-white font-bold mt-0.5 block">{inspectDoctor.roomNumber || 'OPD-101'}</span>
                </div>
                <div className="p-3.5 rounded-xl glass-card-subtle">
                  <span className="text-slate-300 block text-[10px] font-semibold">Consultation Fee</span>
                  <span className="font-mono text-emerald-300 font-extrabold mt-0.5 block">
                    ₹{(inspectDoctor.consultationFee || 800).toLocaleString('en-IN')}
                  </span>
                </div>
                <div className="p-3.5 rounded-xl glass-card-subtle">
                  <span className="text-slate-300 block text-[10px] font-semibold">Timings</span>
                  <span className="font-mono text-cyan-200 font-bold mt-0.5 block">{getTimeSlot(inspectDoctor)}</span>
                </div>
                <div className="p-3.5 rounded-xl glass-card-subtle">
                  <span className="text-slate-300 block text-[10px] font-semibold">Active Consultations</span>
                  <span className="font-mono text-white font-bold mt-0.5 block">
                    {inspectDoctor.activeConsultationsCount || 0} Cases
                  </span>
                </div>
                <div className="p-3.5 rounded-xl glass-card-subtle">
                  <span className="text-slate-300 block text-[10px] font-semibold">Contact</span>
                  <span className="font-mono text-slate-200 text-[11px] mt-0.5 block font-bold">{getContactPhone(inspectDoctor)}</span>
                </div>
                <div className="p-3.5 rounded-xl glass-card-subtle">
                  <span className="text-slate-300 block text-[10px] font-semibold">Email</span>
                  <span className="font-mono text-slate-200 text-[11px] mt-0.5 block truncate font-bold">{inspectDoctor.email || 'N/A'}</span>
                </div>
              </div>

              <div className="flex items-center justify-end gap-3 pt-4 border-t border-cyan-500/20">
                <button
                  onClick={() => setInspectDoctor(null)}
                  className="px-4 py-2.5 rounded-xl glass-btn-secondary text-xs font-bold text-slate-200 hover:text-white"
                >
                  Close
                </button>
                <button
                  onClick={() => {
                    const docToBook = inspectDoctor;
                    setInspectDoctor(null);
                    if (initiateBookingForDoctor) {
                      initiateBookingForDoctor(docToBook);
                    } else {
                      setBookConsultDoctor(docToBook);
                    }
                  }}
                  className="px-5 py-2.5 rounded-xl glass-btn text-white text-xs font-extrabold shadow-[0_0_15px_rgba(6,182,212,0.3)] flex items-center gap-2 active:scale-95"
                >
                  <Calendar className="w-3.5 h-3.5" />
                  <span>Book Appointment</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* ======================================================== */}
        {/* REGISTER SPECIALIST MODAL */}
        {/* ======================================================== */}
        {showAddModal && (
          <div
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-2xl animate-in fade-in"
            onClick={(e) => {
              if (e.target === e.currentTarget) {
                setShowAddModal(false);
              }
            }}
          >
            <div className="relative w-full max-w-2xl rounded-3xl glass-modal p-6 sm:p-8 overflow-y-auto max-h-[90vh]">
              <button
                onClick={() => setShowAddModal(false)}
                className="absolute top-5 right-5 p-2 rounded-xl text-slate-300 hover:text-white hover:bg-[rgba(6,18,45,0.7)] border border-cyan-500/20 transition flex items-center gap-1 text-xs"
              >
                <X className="w-4 h-4" />
                <span className="hidden sm:inline text-[11px] font-mono">Close</span>
              </button>

              <h2 className="text-lg font-extrabold text-white mb-1">
                Register Medical Specialist
              </h2>
              <p className="text-xs text-slate-300 mb-6 font-medium">
                Add a new physician to hospital clinical roster, OPD consultation windows, and hospital specialty registry.
              </p>

              <form onSubmit={handleSaveAdd} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs font-bold text-slate-200 block mb-1">Doctor Full Name</label>
                    <input
                      type="text"
                      required
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      className="w-full px-3.5 py-2 rounded-xl glass-input text-xs text-white"
                      placeholder="Dr. Full Name"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-bold text-slate-200 block mb-1">Specialization (25 Disciplines)</label>
                    <select
                      value={formData.specialization}
                      onChange={(e) => setFormData({ ...formData, specialization: e.target.value as any })}
                      className="w-full px-3.5 py-2 rounded-xl glass-input text-xs text-white cursor-pointer"
                    >
                      {specializationsList.map((s) => (
                        <option key={s} value={s} className="bg-slate-950 text-white">
                          {s}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div>
                    <label className="text-xs font-bold text-slate-200 block mb-1">Qualifications & Degrees</label>
                    <input
                      type="text"
                      required
                      value={formData.qualification}
                      onChange={(e) => setFormData({ ...formData, qualification: e.target.value })}
                      className="w-full px-3.5 py-2 rounded-xl glass-input text-xs text-white"
                      placeholder="MBBS, MD"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-bold text-slate-200 block mb-1">Experience (Years)</label>
                    <input
                      type="number"
                      required
                      min={1}
                      max={60}
                      value={formData.experienceYears}
                      onChange={(e) => setFormData({ ...formData, experienceYears: Number(e.target.value) })}
                      className="w-full px-3.5 py-2 rounded-xl glass-input text-xs text-white"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-bold text-slate-200 block mb-1">Consultation Fee (₹)</label>
                    <input
                      type="number"
                      required
                      step={50}
                      value={formData.consultationFee}
                      onChange={(e) => setFormData({ ...formData, consultationFee: Number(e.target.value) })}
                      className="w-full px-3.5 py-2 rounded-xl glass-input text-xs text-white"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div>
                    <label className="text-xs font-bold text-slate-200 block mb-1">Status</label>
                    <select
                      value={formData.status}
                      onChange={(e) => setFormData({ ...formData, status: e.target.value as any })}
                      className="w-full px-3.5 py-2 rounded-xl glass-input text-xs text-white cursor-pointer"
                    >
                      <option value="Available" className="bg-slate-950 text-white">Available</option>
                      <option value="In Consultation" className="bg-slate-950 text-white">In Consultation</option>
                      <option value="Unavailable" className="bg-slate-950 text-white">Unavailable / On Leave</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-xs font-bold text-slate-200 block mb-1">Cabin / Room Number</label>
                    <input
                      type="text"
                      required
                      value={formData.roomNumber}
                      onChange={(e) => setFormData({ ...formData, roomNumber: e.target.value })}
                      className="w-full px-3.5 py-2 rounded-xl glass-input text-xs text-white"
                      placeholder="OPD-101"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-bold text-slate-200 block mb-1">Department</label>
                    <input
                      type="text"
                      required
                      value={formData.department}
                      onChange={(e) => setFormData({ ...formData, department: e.target.value })}
                      className="w-full px-3.5 py-2 rounded-xl glass-input text-xs text-white"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs font-bold text-slate-200 block mb-1">Available Days (comma-separated)</label>
                    <input
                      type="text"
                      required
                      value={formData.availableDays}
                      onChange={(e) => setFormData({ ...formData, availableDays: e.target.value })}
                      className="w-full px-3.5 py-2 rounded-xl glass-input text-xs text-white"
                      placeholder="Mon, Tue, Wed, Thu, Fri"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-bold text-slate-200 block mb-1">Time Slot Window</label>
                    <input
                      type="text"
                      required
                      value={formData.availableTimeSlot}
                      onChange={(e) => setFormData({ ...formData, availableTimeSlot: e.target.value })}
                      className="w-full px-3.5 py-2 rounded-xl glass-input text-xs text-white"
                      placeholder="08:30 AM - 02:30 PM"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs font-bold text-slate-200 block mb-1">Contact Phone</label>
                    <input
                      type="text"
                      value={formData.contact}
                      onChange={(e) => setFormData({ ...formData, contact: e.target.value })}
                      className="w-full px-3.5 py-2 rounded-xl glass-input text-xs text-white"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-bold text-slate-200 block mb-1">Email Address</label>
                    <input
                      type="email"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      className="w-full px-3.5 py-2 rounded-xl glass-input text-xs text-white"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-200 block mb-1">Doctor Bio & Specializations</label>
                  <textarea
                    rows={2}
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    className="w-full px-3.5 py-2 rounded-xl glass-input text-xs text-white resize-none"
                    placeholder="Clinical highlights, fellowship credentials, procedures..."
                  />
                </div>

                <div className="pt-4 flex items-center justify-end gap-3 border-t border-cyan-500/20">
                  <button
                    type="button"
                    onClick={() => setShowAddModal(false)}
                    className="px-4 py-2.5 rounded-xl glass-btn-secondary text-xs font-bold text-slate-200 hover:text-white"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2.5 rounded-xl glass-btn text-white text-xs font-extrabold shadow-[0_0_15px_rgba(6,182,212,0.3)] active:scale-95"
                  >
                    Register Specialist
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* ======================================================== */}
        {/* BOOK CONSULTATION MODAL */}
        {/* ======================================================== */}
        <BookConsultModal
          isOpen={!!bookConsultDoctor}
          doctor={bookConsultDoctor}
          patients={patients}
          existingAppointments={appointments}
          onClose={() => setBookConsultDoctor(null)}
          onBook={bookAppointment}
          onSuccess={(newAppointment) => {
            setBookingSuccess({
              doctor: newAppointment.doctorName,
              patient: newAppointment.patientName,
              date: newAppointment.date,
              time: newAppointment.timeSlot,
              appointmentId: newAppointment.id,
            });
          }}
        />
      </div>
    </ErrorBoundary>
  );
};
