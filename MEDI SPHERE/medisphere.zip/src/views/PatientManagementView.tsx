import React, { useState, useMemo, useEffect } from 'react';
import { useHospital } from '../context/HospitalContext';
import { Patient, PatientStatus } from '../types';
import {
  Users,
  Search,
  Filter,
  Plus,
  Edit2,
  Trash2,
  Eye,
  Calendar,
  HeartPulse,
  ReceiptText,
  Microscope,
  Phone,
  Mail,
  MapPin,
  AlertCircle,
  X,
  ChevronLeft,
  ChevronRight,
  CheckCircle2,
  Activity,
  FileText,
  ClipboardList,
} from 'lucide-react';
import { MedicalRecordsView } from './MedicalRecordsView';
import { TreatmentView } from './TreatmentView';
import { ALL_SPECIALIZATIONS } from '../data/initialData';

export const PatientManagementView: React.FC = () => {
  const {
    patients,
    addPatient,
    updatePatient,
    deletePatient,
    appointments,
    treatments,
    bills,
    labTests,
    searchQuery,
    activeSubTab,
    setActiveNavigation,
  } = useHospital();

  const currentTab = ['list', 'register', 'profile', 'history', 'prescriptions'].includes(activeSubTab)
    ? activeSubTab
    : 'list';

  // Filter & pagination state
  const [localSearch, setLocalSearch] = useState<string>('');
  const [categoryFilter, setCategoryFilter] = useState<string>('ALL');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [departmentFilter, setDepartmentFilter] = useState<string>('ALL');
  const [ageFilter, setAgeFilter] = useState<string>('ALL');
  const [bloodFilter, setBloodFilter] = useState<string>('ALL');
  const [currentPage, setCurrentPage] = useState<number>(1);
  const itemsPerPage = 6;

  // Modals state
  const [selectedPatient, setSelectedPatient] = useState<Patient | null>(null);
  const [showDetailModal, setShowDetailModal] = useState<boolean>(false);
  const [showAddModal, setShowAddModal] = useState<boolean>(false);
  const [showEditModal, setShowEditModal] = useState<boolean>(false);
  const [patientToDelete, setPatientToDelete] = useState<Patient | null>(null);
  const [activeDetailTab, setActiveDetailTab] = useState<'overview' | 'appointments' | 'treatments' | 'billing' | 'labs'>('overview');

  useEffect(() => {
    if (activeSubTab === 'profile' && patients.length > 0) {
      if (!selectedPatient) {
        setSelectedPatient(patients[0]);
      }
      setShowDetailModal(true);
    }
  }, [activeSubTab, patients, selectedPatient]);

  // Form states
  const [formData, setFormData] = useState({
    name: '',
    age: 30,
    gender: 'Male' as Patient['gender'],
    bloodGroup: 'O+' as Patient['bloodGroup'],
    contact: '',
    email: '',
    address: '',
    emergencyContact: '',
    currentStatus: 'Outpatient' as PatientStatus,
    allergies: '',
  });

  // Filter logic
  const filteredPatients = useMemo(() => {
    const q = (localSearch || searchQuery || '').toLowerCase().trim();
    return (patients || []).filter((p) => {
      if (!p) return false;
      const name = (p.name || '').toLowerCase();
      const id = (p.id || '').toLowerCase();
      const contact = (p.contact || '').toLowerCase();
      const uhid = (p.uhid || '').toLowerCase();
      const doc = (p.assignedDoctorName || '').toLowerCase();
      const dept = (p.department || '').toLowerCase();

      const matchQuery =
        !q ||
        name.includes(q) ||
        id.includes(q) ||
        contact.includes(q) ||
        doc.includes(q) ||
        dept.includes(q) ||
        uhid.includes(q);

      // Category filter (Active, Admitted, Discharged, Emergency, Scheduled)
      let matchCategory = true;
      if (categoryFilter !== 'ALL') {
        if (categoryFilter === 'Active') {
          matchCategory = p.currentStatus === 'Active' || p.currentStatus === 'Admitted' || p.currentStatus === 'Outpatient';
        } else {
          matchCategory = p.currentStatus === categoryFilter;
        }
      }

      // Status filter
      const matchStatus = statusFilter === 'ALL' || p.currentStatus === statusFilter;

      // Department filter
      const matchDept = departmentFilter === 'ALL' || p.department === departmentFilter;

      // Age filter
      let matchAge = true;
      if (ageFilter === 'under18') matchAge = p.age < 18;
      else if (ageFilter === '18-40') matchAge = p.age >= 18 && p.age <= 40;
      else if (ageFilter === '41-60') matchAge = p.age >= 41 && p.age <= 60;
      else if (ageFilter === 'above60') matchAge = p.age > 60;

      // Blood filter
      const matchBlood = bloodFilter === 'ALL' || p.bloodGroup === bloodFilter;

      return matchQuery && matchCategory && matchStatus && matchDept && matchAge && matchBlood;
    });
  }, [patients, localSearch, searchQuery, categoryFilter, statusFilter, departmentFilter, ageFilter, bloodFilter]);

  // Pagination
  const totalPages = Math.ceil(filteredPatients.length / itemsPerPage) || 1;
  const paginatedPatients = filteredPatients.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  const handleOpenAdd = () => {
    setFormData({
      name: '',
      age: 35,
      gender: 'Male',
      bloodGroup: 'O+',
      contact: '+91 ',
      email: '',
      address: '',
      emergencyContact: '',
      currentStatus: 'Outpatient',
      allergies: '',
    });
    setShowAddModal(true);
  };

  const handleOpenEdit = (patient: Patient) => {
    setSelectedPatient(patient);
    setFormData({
      name: patient.name,
      age: patient.age,
      gender: patient.gender,
      bloodGroup: patient.bloodGroup,
      contact: patient.contact,
      email: patient.email,
      address: patient.address,
      emergencyContact: patient.emergencyContact,
      currentStatus: patient.currentStatus,
      allergies: patient.allergies ? patient.allergies.join(', ') : '',
    });
    setShowEditModal(true);
  };

  const handleSaveAdd = (e: React.FormEvent) => {
    e.preventDefault();
    addPatient({
      ...formData,
      allergies: formData.allergies ? formData.allergies.split(',').map((s) => s.trim()) : [],
    });
    setShowAddModal(false);
  };

  const handleSaveEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedPatient) return;
    updatePatient(selectedPatient.id, {
      ...formData,
      allergies: formData.allergies ? formData.allergies.split(',').map((s) => s.trim()) : [],
    });
    setShowEditModal(false);
  };

  const confirmDelete = () => {
    if (patientToDelete) {
      deletePatient(patientToDelete.id);
      setPatientToDelete(null);
    }
  };

  // Associated patient data
  const patientAppointments = useMemo(() => {
    if (!selectedPatient) return [];
    return appointments.filter((a) => a.patientId === selectedPatient.id);
  }, [appointments, selectedPatient]);

  const patientTreatments = useMemo(() => {
    if (!selectedPatient) return [];
    return treatments.filter((t) => t.patientId === selectedPatient.id);
  }, [treatments, selectedPatient]);

  const patientBills = useMemo(() => {
    if (!selectedPatient) return [];
    return bills.filter((b) => b.patientId === selectedPatient.id);
  }, [bills, selectedPatient]);

  const patientLabs = useMemo(() => {
    if (!selectedPatient) return [];
    return labTests.filter((l) => l.patientId === selectedPatient.id);
  }, [labTests, selectedPatient]);

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Header & Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-black text-white tracking-tight drop-shadow-sm">Patient Management</h1>
            <span className="text-xs font-mono px-2.5 py-0.5 rounded-full bg-cyan-500/20 text-cyan-200 border border-cyan-500/40 shadow-[0_0_10px_rgba(6,182,212,0.25)] font-bold">
              {patients.length} Registered
            </span>
          </div>
          <p className="text-xs text-slate-300 mt-1 font-medium">
            Complete demographic, clinical history, diagnostic records, and billing ledger.
          </p>
        </div>

        <button
          onClick={handleOpenAdd}
          className="glass-btn inline-flex items-center gap-2 px-4 py-2.5 rounded-xl text-white text-xs font-bold transition shadow-[0_0_20px_rgba(6,182,212,0.35)]"
        >
          <Plus className="w-4 h-4" />
          Register Patient
        </button>
      </div>

      {/* Sub-Options Nav Tabs */}
      <div className="flex flex-wrap items-center gap-2 border-b border-cyan-500/20 pb-3">
        {[
          { id: 'list', label: 'Patient List' },
          { id: 'register', label: 'Register Patient' },
          { id: 'profile', label: 'Patient Profile' },
          { id: 'history', label: 'Medical History' },
          { id: 'prescriptions', label: 'Prescriptions & Records' },
        ].map((sub) => (
          <button
            key={sub.id}
            onClick={() => {
              if (sub.id === 'register') {
                handleOpenAdd();
              }
              setActiveNavigation('patients', sub.id);
            }}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold transition ${
              currentTab === sub.id
                ? 'bg-cyan-500/25 text-cyan-200 border border-cyan-500/50 shadow-[0_0_15px_rgba(6,182,212,0.3)]'
                : 'text-slate-300 hover:text-white bg-[rgba(6,18,45,0.4)] hover:bg-[rgba(6,18,45,0.7)] border border-cyan-500/15'
            }`}
          >
            {sub.label}
          </button>
        ))}
      </div>

      {/* Sub-option Views */}
      {currentTab === 'history' ? (
        <TreatmentView />
      ) : currentTab === 'prescriptions' ? (
        <MedicalRecordsView />
      ) : (
        <>

      {/* Category Selection Tabs */}
      <div className="flex flex-wrap items-center gap-2 p-2 rounded-2xl glass-card border border-cyan-500/20">
        <span className="text-xs font-bold text-slate-300 px-2 font-mono uppercase tracking-wider">Category:</span>
        {[
          { id: 'ALL', label: 'All Patients' },
          { id: 'Active', label: 'Active' },
          { id: 'Admitted', label: 'Admitted' },
          { id: 'Discharged', label: 'Discharged' },
          { id: 'Emergency', label: 'Emergency' },
          { id: 'Scheduled', label: 'Scheduled' },
        ].map((cat) => {
          const count =
            cat.id === 'ALL'
              ? patients.length
              : cat.id === 'Active'
              ? patients.filter((p) => p.currentStatus === 'Active' || p.currentStatus === 'Admitted' || p.currentStatus === 'Outpatient').length
              : patients.filter((p) => p.currentStatus === cat.id).length;

          return (
            <button
              key={cat.id}
              onClick={() => {
                setCategoryFilter(cat.id);
                setCurrentPage(1);
              }}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
                categoryFilter === cat.id
                  ? 'bg-cyan-500/25 text-cyan-200 border border-cyan-400 shadow-[0_0_12px_rgba(6,182,212,0.35)]'
                  : 'text-slate-300 hover:text-white bg-[rgba(6,18,45,0.4)] border border-cyan-500/10 hover:border-cyan-500/30'
              }`}
            >
              <span>{cat.label}</span>
              <span className="text-[10px] font-mono px-1.5 py-0.2 rounded-full bg-slate-900/80 text-cyan-300">
                {count}
              </span>
            </button>
          );
        })}
      </div>

      {/* Filter & Search Bar */}
      <div className="p-4 rounded-2xl glass-card border border-cyan-500/20 space-y-3">
        <div className="flex flex-col md:flex-row items-center justify-between gap-3">
          <div className="relative w-full md:w-96">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-cyan-400" />
            <input
              type="text"
              placeholder="Search by Name, Patient ID, Phone, Doctor, or Department..."
              value={localSearch}
              onChange={(e) => {
                setLocalSearch(e.target.value);
                setCurrentPage(1);
              }}
              className="w-full pl-9 pr-4 py-2 text-xs rounded-xl glass-input placeholder-slate-400"
            />
          </div>

          <div className="flex flex-wrap items-center gap-2.5 w-full md:w-auto">
            {/* Department Filter */}
            <div className="flex items-center gap-1.5 text-xs text-slate-200 font-medium">
              <span className="text-slate-400">Dept:</span>
              <select
                value={departmentFilter}
                onChange={(e) => {
                  setDepartmentFilter(e.target.value);
                  setCurrentPage(1);
                }}
                className="px-2.5 py-1.5 rounded-lg glass-input text-xs font-medium cursor-pointer"
              >
                <option value="ALL" className="bg-slate-950 text-white">All Departments</option>
                {ALL_SPECIALIZATIONS.map((sp) => (
                  <option key={sp} value={sp} className="bg-slate-950 text-white">
                    {sp}
                  </option>
                ))}
              </select>
            </div>

            {/* Status Filter */}
            <div className="flex items-center gap-1.5 text-xs text-slate-200 font-medium">
              <Filter className="w-3.5 h-3.5 text-cyan-400" />
              <span className="text-slate-400">Status:</span>
              <select
                value={statusFilter}
                onChange={(e) => {
                  setStatusFilter(e.target.value);
                  setCurrentPage(1);
                }}
                className="px-2.5 py-1.5 rounded-lg glass-input text-xs font-medium cursor-pointer"
              >
                <option value="ALL" className="bg-slate-950 text-white">All Statuses</option>
                <option value="Active" className="bg-slate-950 text-white">Active</option>
                <option value="Admitted" className="bg-slate-950 text-white">Admitted</option>
                <option value="Discharged" className="bg-slate-950 text-white">Discharged</option>
                <option value="Emergency" className="bg-slate-950 text-white">Emergency</option>
                <option value="Scheduled" className="bg-slate-950 text-white">Scheduled</option>
                <option value="ICU" className="bg-slate-950 text-white">ICU</option>
                <option value="Outpatient" className="bg-slate-950 text-white">Outpatient</option>
              </select>
            </div>

            {/* Age Filter */}
            <div className="flex items-center gap-1.5 text-xs text-slate-200 font-medium">
              <span className="text-slate-400">Age:</span>
              <select
                value={ageFilter}
                onChange={(e) => {
                  setAgeFilter(e.target.value);
                  setCurrentPage(1);
                }}
                className="px-2.5 py-1.5 rounded-lg glass-input text-xs font-medium cursor-pointer"
              >
                <option value="ALL" className="bg-slate-950 text-white">All Ages</option>
                <option value="under18" className="bg-slate-950 text-white">Under 18</option>
                <option value="18-40" className="bg-slate-950 text-white">18 - 40 yrs</option>
                <option value="41-60" className="bg-slate-950 text-white">41 - 60 yrs</option>
                <option value="above60" className="bg-slate-950 text-white">60+ yrs</option>
              </select>
            </div>

            {/* Blood Group Filter */}
            <div className="flex items-center gap-1.5 text-xs text-slate-200 font-medium">
              <span className="text-slate-400">Blood:</span>
              <select
                value={bloodFilter}
                onChange={(e) => {
                  setBloodFilter(e.target.value);
                  setCurrentPage(1);
                }}
                className="px-2.5 py-1.5 rounded-lg glass-input text-xs font-medium cursor-pointer"
              >
                <option value="ALL" className="bg-slate-950 text-white">All Groups</option>
                {['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'].map((bg) => (
                  <option key={bg} value={bg} className="bg-slate-950 text-white">
                    {bg}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>
      </div>

      {/* Patient Cards / Hybrid Table Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {paginatedPatients.map((patient) => (
          <div
            key={patient.id}
            onClick={() => {
              setSelectedPatient(patient);
              setActiveDetailTab('overview');
              setShowDetailModal(true);
            }}
            className="p-5 rounded-2xl glass-card hover:border-cyan-400/50 hover:shadow-[0_12px_36px_rgba(0,0,0,0.5),0_0_24px_rgba(6,182,212,0.22)] transition-all duration-300 flex flex-col justify-between group cursor-pointer"
          >
            <div>
              <div className="flex items-start justify-between gap-2">
                <div>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-cyan-950/80 text-cyan-200 border border-cyan-400/40 font-bold shadow-[0_0_8px_rgba(6,182,212,0.2)]">
                    {patient.id}
                  </span>
                  <h3 className="text-base font-extrabold text-white mt-1.5 tracking-tight group-hover:text-cyan-200 transition drop-shadow-sm">
                    {patient.name}
                  </h3>
                  <div className="flex items-center gap-2 mt-1 text-xs text-slate-300 font-medium">
                    <span>
                      {patient.age} yrs &bull; {patient.gender}
                    </span>
                    <span className="text-red-300 font-bold px-1.5 py-0.2 rounded bg-red-950/80 border border-red-500/40 text-[10px] shadow-[0_0_6px_rgba(239,68,68,0.2)]">
                      {patient.bloodGroup}
                    </span>
                  </div>
                </div>

                <span
                  className={`text-[10px] font-bold px-2.5 py-1 rounded-full uppercase tracking-wider ${
                    patient.currentStatus === 'ICU'
                      ? 'bg-red-500/25 text-red-300 border border-red-500/50 shadow-[0_0_12px_rgba(239,68,68,0.35)] animate-pulse'
                      : patient.currentStatus === 'Emergency'
                      ? 'bg-amber-500/25 text-amber-300 border border-amber-500/50 shadow-[0_0_12px_rgba(245,158,11,0.3)]'
                      : patient.currentStatus === 'Admitted'
                      ? 'bg-cyan-500/25 text-cyan-200 border border-cyan-500/50 shadow-[0_0_12px_rgba(6,182,212,0.3)]'
                      : patient.currentStatus === 'Discharged'
                      ? 'bg-slate-800 text-slate-300 border border-slate-700'
                      : 'bg-emerald-500/25 text-emerald-200 border border-emerald-500/50 shadow-[0_0_12px_rgba(16,185,129,0.3)]'
                  }`}
                >
                  {patient.currentStatus}
                </span>
              </div>

              {/* Department & Assigned Doctor info */}
              <div className="mt-3 p-2.5 rounded-xl bg-[rgba(6,18,45,0.6)] border border-cyan-500/15 text-xs text-slate-300 space-y-1">
                <div className="flex items-center justify-between">
                  <span className="text-slate-400 text-[11px]">Doctor:</span>
                  <span className="font-bold text-white truncate max-w-[170px]">
                    {patient.assignedDoctorName || 'Dr. Arvind Swaminathan'}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-400 text-[11px]">Dept:</span>
                  <span className="font-semibold text-cyan-300 truncate max-w-[170px]">
                    {patient.department || 'General Medicine'}
                  </span>
                </div>
                <div className="flex items-center justify-between text-[11px] pt-1 border-t border-cyan-500/10 font-mono">
                  <span className="text-slate-400">Last / Next:</span>
                  <span className="text-slate-300">
                    {patient.lastVisit || '2026-03-24'} &bull; {patient.nextAppointment || '04-05'}
                  </span>
                </div>
              </div>

              <div className="mt-3 space-y-1 text-xs text-slate-200">
                <div className="flex items-center gap-2 truncate">
                  <Phone className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                  <span className="truncate font-medium">{patient.contact}</span>
                </div>
                <div className="flex items-center gap-2 truncate">
                  <Mail className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                  <span className="truncate text-slate-300 font-medium">{patient.email}</span>
                </div>
                <div className="flex items-center gap-2 truncate">
                  <MapPin className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                  <span className="truncate text-slate-300 font-medium">{patient.address}</span>
                </div>
              </div>
            </div>

            <div className="mt-4 pt-3 border-t border-cyan-500/15 flex items-center justify-between">
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  setSelectedPatient(patient);
                  setActiveDetailTab('overview');
                  setShowDetailModal(true);
                }}
                className="glass-btn inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs font-bold text-white transition"
              >
                <Eye className="w-3.5 h-3.5 text-cyan-300" />
                Full Profile
              </button>

              <div className="flex items-center gap-1.5" onClick={(e) => e.stopPropagation()}>
                <button
                  onClick={() => handleOpenEdit(patient)}
                  className="p-1.5 rounded-lg text-slate-300 hover:text-cyan-300 bg-[rgba(6,18,45,0.4)] hover:bg-[rgba(6,18,45,0.8)] border border-cyan-500/20 transition"
                  title="Edit Patient Details"
                >
                  <Edit2 className="w-4 h-4" />
                </button>
                <button
                  onClick={() => setPatientToDelete(patient)}
                  className="p-1.5 rounded-lg text-slate-300 hover:text-red-300 bg-[rgba(6,18,45,0.4)] hover:bg-red-950/50 border border-red-500/20 hover:border-red-500/40 transition"
                  title="Discharge / Remove Record"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Pagination Footer */}
      <div className="flex items-center justify-between pt-4 border-t border-cyan-500/20 text-xs text-slate-300">
        <span className="font-medium">
          Showing {(currentPage - 1) * itemsPerPage + 1} -{' '}
          {Math.min(currentPage * itemsPerPage, filteredPatients.length)} of {filteredPatients.length} patients
        </span>

        <div className="flex items-center gap-2">
          <button
            disabled={currentPage === 1}
            onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
            className="p-2 rounded-xl glass-btn-secondary disabled:opacity-30 hover:border-cyan-400"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
          <span className="px-3.5 py-1 rounded-xl bg-[rgba(6,18,45,0.6)] border border-cyan-500/30 font-mono text-cyan-200 font-bold shadow-inner">
            {currentPage} / {totalPages}
          </span>
          <button
            disabled={currentPage === totalPages}
            onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
            className="p-2 rounded-xl glass-btn-secondary disabled:opacity-30 hover:border-cyan-400"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>
      </>
      )}

      {/* View Details Comprehensive Modal */}
      {showDetailModal && selectedPatient && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-2xl animate-in fade-in">
          <div className="relative w-full max-w-4xl max-h-[90vh] rounded-3xl glass-modal flex flex-col overflow-hidden">
            {/* Modal Header */}
            <div className="p-6 border-b border-cyan-500/20 bg-[rgba(3,10,26,0.6)] flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-cyan-500/20 border border-cyan-400/40 flex items-center justify-center text-cyan-300 font-extrabold text-base shadow-[0_0_12px_rgba(6,182,212,0.3)]">
                  {selectedPatient.name.charAt(0)}
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h2 className="text-xl font-black text-white">{selectedPatient.name}</h2>
                    <span className="text-xs font-mono px-2 py-0.5 rounded bg-cyan-950/80 text-cyan-200 border border-cyan-500/40 font-bold">
                      {selectedPatient.id}
                    </span>
                  </div>
                  <p className="text-xs text-slate-300 mt-0.5 font-medium">
                    {selectedPatient.age} yrs &bull; {selectedPatient.gender} &bull; Blood:{' '}
                    <span className="text-red-300 font-bold">{selectedPatient.bloodGroup}</span>
                  </p>
                </div>
              </div>
              <button
                onClick={() => setShowDetailModal(false)}
                className="p-2 rounded-xl text-slate-300 hover:text-white bg-[rgba(6,18,45,0.4)] hover:bg-[rgba(6,18,45,0.8)] border border-cyan-500/20 transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Navigation Tabs Inside Details Modal */}
            <div className="flex items-center gap-2 px-6 pt-3 border-b border-slate-800 bg-slate-950/30 overflow-x-auto">
              {[
                { id: 'overview', label: 'Overview', icon: Users },
                { id: 'appointments', label: `Appointments (${patientAppointments.length})`, icon: Calendar },
                { id: 'treatments', label: `Treatments (${patientTreatments.length})`, icon: HeartPulse },
                { id: 'billing', label: `Billing Ledger (${patientBills.length})`, icon: ReceiptText },
                { id: 'labs', label: `Lab Results (${patientLabs.length})`, icon: Microscope },
              ].map((tab) => {
                const Icon = tab.icon;
                return (
                  <button
                    key={tab.id}
                    onClick={() => setActiveDetailTab(tab.id as any)}
                    className={`flex items-center gap-2 px-4 py-2 text-xs font-semibold rounded-t-xl transition border-b-2 whitespace-nowrap ${
                      activeDetailTab === tab.id
                        ? 'border-cyan-400 text-cyan-300 bg-slate-900'
                        : 'border-transparent text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    <Icon className="w-3.5 h-3.5" />
                    {tab.label}
                  </button>
                );
              })}
            </div>

            {/* Modal Body */}
            <div className="p-6 overflow-y-auto flex-1 space-y-4">
              {activeDetailTab === 'overview' && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* Contact & Demographics */}
                  <div className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800/80 space-y-3">
                    <h4 className="text-xs uppercase font-extrabold text-cyan-400 tracking-wider flex items-center justify-between">
                      <span>Demographics & Contact</span>
                      <span className="text-[10px] font-mono text-slate-400">ID: {selectedPatient.id}</span>
                    </h4>
                    <div className="text-xs space-y-2.5 text-slate-300">
                      <div>
                        <span className="text-slate-500 block text-[11px]">Full Name:</span>
                        <span className="font-bold text-white text-sm">{selectedPatient.name}</span>
                      </div>
                      <div className="grid grid-cols-3 gap-2 py-1 px-2 rounded-xl bg-slate-900/60 border border-slate-800">
                        <div>
                          <span className="text-slate-500 block text-[10px]">Age:</span>
                          <span className="font-semibold text-white">{selectedPatient.age} yrs</span>
                        </div>
                        <div>
                          <span className="text-slate-500 block text-[10px]">Gender:</span>
                          <span className="font-semibold text-white">{selectedPatient.gender}</span>
                        </div>
                        <div>
                          <span className="text-slate-500 block text-[10px]">Blood Group:</span>
                          <span className="font-bold text-red-400">{selectedPatient.bloodGroup}</span>
                        </div>
                      </div>
                      <div>
                        <span className="text-slate-500 block text-[11px]">Phone:</span>
                        <span className="font-semibold text-white">{selectedPatient.contact}</span>
                      </div>
                      <div>
                        <span className="text-slate-500 block text-[11px]">Email:</span>
                        <span className="font-semibold text-white">{selectedPatient.email}</span>
                      </div>
                      <div>
                        <span className="text-slate-500 block text-[11px]">Address:</span>
                        <span className="font-semibold text-white">{selectedPatient.address}</span>
                      </div>
                      <div>
                        <span className="text-slate-500 block text-[11px]">Emergency Contact:</span>
                        <span className="font-bold text-amber-300">
                          {selectedPatient.emergencyContact}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Clinical Care & Doctor Assignment */}
                  <div className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800/80 space-y-3">
                    <h4 className="text-xs uppercase font-extrabold text-cyan-400 tracking-wider">
                      Clinical Status & Appointments
                    </h4>
                    <div className="text-xs space-y-2.5 text-slate-300">
                      <div className="flex items-center justify-between p-2 rounded-xl bg-slate-900/60 border border-slate-800">
                        <div>
                          <span className="text-slate-500 block text-[10px]">Patient Status:</span>
                          <span className="font-bold text-cyan-300 text-xs uppercase tracking-wider">
                            {selectedPatient.currentStatus}
                          </span>
                        </div>
                        <div>
                          <span className="text-slate-500 block text-[10px]">Registration:</span>
                          <span className="font-mono text-xs">{selectedPatient.registeredDate}</span>
                        </div>
                      </div>

                      <div className="p-2.5 rounded-xl bg-[rgba(6,18,45,0.7)] border border-cyan-500/20 space-y-1.5">
                        <div>
                          <span className="text-slate-400 block text-[10px]">Assigned Doctor:</span>
                          <span className="font-bold text-white text-xs">
                            {selectedPatient.assignedDoctorName || 'Dr. Arvind Swaminathan'}
                          </span>
                        </div>
                        <div>
                          <span className="text-slate-400 block text-[10px]">Clinical Department:</span>
                          <span className="font-semibold text-cyan-300 text-xs">
                            {selectedPatient.department || 'Cardiology'}
                          </span>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-2">
                        <div className="p-2 rounded-xl bg-slate-900/60 border border-slate-800">
                          <span className="text-slate-500 block text-[10px]">Last Visit:</span>
                          <span className="font-mono text-xs font-semibold text-slate-200">
                            {selectedPatient.lastVisit || '2026-03-24'}
                          </span>
                        </div>
                        <div className="p-2 rounded-xl bg-slate-900/60 border border-slate-800">
                          <span className="text-slate-500 block text-[10px]">Next Appointment:</span>
                          <span className="font-mono text-xs font-semibold text-emerald-300">
                            {selectedPatient.nextAppointment || '2026-04-05'}
                          </span>
                        </div>
                      </div>

                      <div>
                        <span className="text-slate-500 block text-[11px]">Known Medical Allergies:</span>
                        {selectedPatient.allergies && selectedPatient.allergies.length > 0 ? (
                          <div className="flex flex-wrap gap-1 mt-1">
                            {selectedPatient.allergies.map((alg, i) => (
                              <span
                                key={i}
                                className="px-2 py-0.5 rounded bg-red-950/80 border border-red-500/30 text-red-300 text-[10px]"
                              >
                                {alg}
                              </span>
                            ))}
                          </div>
                        ) : (
                          <span className="text-slate-500">None documented</span>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {activeDetailTab === 'appointments' && (
                <div className="space-y-3">
                  {patientAppointments.length === 0 ? (
                    <p className="text-xs text-slate-400 text-center py-8">No prior appointments logged.</p>
                  ) : (
                    patientAppointments.map((apt) => (
                      <div
                        key={apt.id}
                        className="p-4 rounded-xl bg-slate-950/60 border border-slate-800 flex items-center justify-between"
                      >
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="text-xs font-bold text-white">{apt.appointmentType}</span>
                            <span className="text-[10px] px-2 py-0.5 rounded bg-cyan-500/20 text-cyan-300">
                              {apt.status}
                            </span>
                          </div>
                          <p className="text-xs text-slate-400 mt-1">
                            With {apt.doctorName} ({apt.specialization}) on {apt.date} at {apt.timeSlot}
                          </p>
                        </div>
                        <span className="text-xs font-mono font-bold text-white">₹{apt.fee}</span>
                      </div>
                    ))
                  )}
                </div>
              )}

              {activeDetailTab === 'treatments' && (
                <div className="space-y-3">
                  {patientTreatments.length === 0 ? (
                    <p className="text-xs text-slate-400 text-center py-8">No current active care plans.</p>
                  ) : (
                    patientTreatments.map((trt) => (
                      <div key={trt.id} className="p-4 rounded-xl bg-slate-950/60 border border-slate-800">
                        <div className="flex items-center justify-between">
                          <h4 className="text-xs font-bold text-white">{trt.treatmentName}</h4>
                          <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300">
                            {trt.status}
                          </span>
                        </div>
                        <p className="text-xs text-slate-300 mt-1">Diagnosis: {trt.diagnosis}</p>
                        <p className="text-[11px] text-slate-400 mt-1">{trt.instructions}</p>
                      </div>
                    ))
                  )}
                </div>
              )}

              {activeDetailTab === 'billing' && (
                <div className="space-y-3">
                  {patientBills.length === 0 ? (
                    <p className="text-xs text-slate-400 text-center py-8">No invoice statements found.</p>
                  ) : (
                    patientBills.map((bill) => (
                      <div
                        key={bill.id}
                        className="p-4 rounded-xl bg-slate-950/60 border border-slate-800 flex items-center justify-between"
                      >
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="text-xs font-mono font-bold text-white">{bill.id}</span>
                            <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300">
                              {bill.paymentStatus}
                            </span>
                          </div>
                          <p className="text-xs text-slate-400 mt-0.5">Date: {bill.invoiceDate}</p>
                        </div>
                        <div className="text-right">
                          <span className="text-xs font-mono font-bold text-white block">
                            ₹{bill.totalAmount.toLocaleString('en-IN')}
                          </span>
                          <span className="text-[10px] text-slate-400">Paid: ₹{bill.paidAmount.toLocaleString('en-IN')}</span>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              )}

              {activeDetailTab === 'labs' && (
                <div className="space-y-3">
                  {patientLabs.length === 0 ? (
                    <p className="text-xs text-slate-400 text-center py-8">No diagnostic tests recorded.</p>
                  ) : (
                    patientLabs.map((lab) => (
                      <div key={lab.id} className="p-4 rounded-xl bg-slate-950/60 border border-slate-800">
                        <div className="flex items-center justify-between">
                          <span className="text-xs font-bold text-white">{lab.testType}</span>
                          <span className="text-[10px] px-2 py-0.5 rounded bg-purple-500/20 text-purple-300">
                            {lab.status}
                          </span>
                        </div>
                        <p className="text-xs text-slate-400 mt-1">{lab.technicianNotes}</p>
                      </div>
                    ))
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Register / Edit Patient Modal */}
      {(showAddModal || showEditModal) && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-2xl animate-in fade-in">
          <div className="relative w-full max-w-2xl rounded-3xl glass-modal p-6 sm:p-8 overflow-y-auto max-h-[90vh]">
            <button
              onClick={() => {
                setShowAddModal(false);
                setShowEditModal(false);
              }}
              className="absolute top-5 right-5 p-2 rounded-xl text-slate-300 hover:text-white bg-[rgba(6,18,45,0.4)] hover:bg-[rgba(6,18,45,0.8)] border border-cyan-500/20 transition"
            >
              <X className="w-5 h-5" />
            </button>

            <h2 className="text-xl font-black text-white mb-1 tracking-tight">
              {showAddModal ? 'Register New Patient' : `Update Record: ${selectedPatient?.name}`}
            </h2>
            <p className="text-xs text-slate-300 mb-6 font-medium">
              Persists patient details into MySQL database via JDBC PreparedStatement.
            </p>

            <form onSubmit={showAddModal ? handleSaveAdd : handleSaveEdit} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-bold text-slate-200 block mb-1">Full Name</label>
                  <input
                    type="text"
                    required
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="w-full px-3.5 py-2.5 rounded-xl glass-input text-xs text-white"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-slate-200 block mb-1">Age</label>
                  <input
                    type="number"
                    required
                    min={1}
                    max={120}
                    value={formData.age}
                    onChange={(e) => setFormData({ ...formData, age: Number(e.target.value) })}
                    className="w-full px-3.5 py-2.5 rounded-xl glass-input text-xs text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="text-xs font-bold text-slate-200 block mb-1">Gender</label>
                  <select
                    value={formData.gender}
                    onChange={(e) => setFormData({ ...formData, gender: e.target.value as any })}
                    className="w-full px-3 py-2.5 rounded-xl glass-input text-xs text-white cursor-pointer"
                  >
                    <option value="Male" className="bg-slate-950 text-white">Male</option>
                    <option value="Female" className="bg-slate-950 text-white">Female</option>
                    <option value="Other" className="bg-slate-950 text-white">Other</option>
                  </select>
                </div>
                <div>
                  <label className="text-xs font-bold text-slate-200 block mb-1">Blood Group</label>
                  <select
                    value={formData.bloodGroup}
                    onChange={(e) => setFormData({ ...formData, bloodGroup: e.target.value as any })}
                    className="w-full px-3 py-2.5 rounded-xl glass-input text-xs text-white cursor-pointer"
                  >
                    {['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'].map((bg) => (
                      <option key={bg} value={bg} className="bg-slate-950 text-white">
                        {bg}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="text-xs font-bold text-slate-200 block mb-1">Status</label>
                  <select
                    value={formData.currentStatus}
                    onChange={(e) => setFormData({ ...formData, currentStatus: e.target.value as any })}
                    className="w-full px-3 py-2.5 rounded-xl glass-input text-xs text-white cursor-pointer"
                  >
                    <option value="Outpatient" className="bg-slate-950 text-white">Outpatient</option>
                    <option value="Admitted" className="bg-slate-950 text-white">Admitted</option>
                    <option value="ICU" className="bg-slate-950 text-white">ICU</option>
                    <option value="Emergency" className="bg-slate-950 text-white">Emergency</option>
                    <option value="Discharged" className="bg-slate-950 text-white">Discharged</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-bold text-slate-200 block mb-1">Contact Phone</label>
                  <input
                    type="text"
                    required
                    value={formData.contact}
                    onChange={(e) => setFormData({ ...formData, contact: e.target.value })}
                    className="w-full px-3.5 py-2.5 rounded-xl glass-input text-xs text-white"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-slate-200 block mb-1">Email</label>
                  <input
                    type="email"
                    required
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="w-full px-3.5 py-2.5 rounded-xl glass-input text-xs text-white"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-200 block mb-1">Address</label>
                <input
                  type="text"
                  required
                  value={formData.address}
                  onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                  className="w-full px-3.5 py-2.5 rounded-xl glass-input text-xs text-white"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-200 block mb-1">
                  Emergency Contact Kin (Name & Phone)
                </label>
                <input
                  type="text"
                  required
                  value={formData.emergencyContact}
                  onChange={(e) => setFormData({ ...formData, emergencyContact: e.target.value })}
                  className="w-full px-3.5 py-2.5 rounded-xl glass-input text-xs text-white"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-200 block mb-1">
                  Medical Allergies (comma-separated)
                </label>
                <input
                  type="text"
                  placeholder="e.g. Penicillin, Aspirin, Sulfa"
                  value={formData.allergies}
                  onChange={(e) => setFormData({ ...formData, allergies: e.target.value })}
                  className="w-full px-3.5 py-2.5 rounded-xl glass-input text-xs text-white placeholder-slate-400"
                />
              </div>

              <div className="pt-4 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => {
                    setShowAddModal(false);
                    setShowEditModal(false);
                  }}
                  className="px-4 py-2.5 rounded-xl glass-btn-secondary text-xs font-bold text-slate-200 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="glass-btn px-5 py-2.5 rounded-xl text-white text-xs font-extrabold shadow-[0_0_20px_rgba(6,182,212,0.35)]"
                >
                  {showAddModal ? 'Save & Register' : 'Save Changes'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation Dialog */}
      {patientToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-2xl animate-in fade-in">
          <div className="relative w-full max-w-md rounded-3xl glass-modal border-red-500/40 p-6 sm:p-7 shadow-[0_25px_65px_rgba(0,0,0,0.8),0_0_30px_rgba(239,68,68,0.25)]">
            <div className="w-12 h-12 rounded-2xl bg-red-500/20 border border-red-500/40 flex items-center justify-center text-red-400 mb-4 shadow-[0_0_15px_rgba(239,68,68,0.3)]">
              <AlertCircle className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-black text-white tracking-tight">Discharge / Delete Patient Record?</h3>
            <p className="text-xs text-slate-300 mt-2 leading-relaxed font-medium">
              Are you sure you want to remove <span className="text-white font-extrabold">{patientToDelete.name}</span> ({patientToDelete.id})? This will archive their file from active inpatient/outpatient registries.
            </p>
            <div className="mt-6 flex items-center justify-end gap-3">
              <button
                onClick={() => setPatientToDelete(null)}
                className="px-4 py-2.5 rounded-xl glass-btn-secondary text-xs font-bold text-slate-200 hover:text-white"
              >
                Cancel
              </button>
              <button
                onClick={confirmDelete}
                className="px-5 py-2.5 rounded-xl bg-red-600 hover:bg-red-500 text-white text-xs font-extrabold transition shadow-lg shadow-red-500/35 border border-red-400/50 active:scale-95"
              >
                Confirm Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
