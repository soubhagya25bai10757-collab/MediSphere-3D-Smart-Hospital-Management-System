import React, { useState, useMemo, useEffect } from 'react';
import { useHospital } from '../context/HospitalContext';
import {
  Appointment,
  AppointmentStatus,
  AppointmentType,
  MedicalSpecialization,
} from '../types';
import {
  Calendar as CalendarIcon,
  Clock,
  User,
  Stethoscope,
  Filter,
  Plus,
  CheckCircle2,
  AlertCircle,
  X,
  ChevronRight,
  ChevronLeft,
  Lock,
  Search,
  RotateCcw,
  Check,
  Calendar,
  Building,
  RotateCw,
} from 'lucide-react';
import { ALL_SPECIALIZATIONS } from '../data/initialData';

export const AppointmentManagementView: React.FC = () => {
  const {
    appointments = [],
    doctors = [],
    patients = [],
    bookAppointment,
    updateAppointmentStatus,
    selectedDoctorForBooking,
    setSelectedDoctorForBooking,
    rescheduleAppointment,
    searchQuery,
    activeSubTab,
    setActiveNavigation,
  } = useHospital();

  const currentTab = ['today', 'upcoming', 'book', 'history', 'schedule', 'all', 'completed', 'cancelled'].includes(activeSubTab)
    ? activeSubTab
    : 'today';

  const [localSearch, setLocalSearch] = useState<string>('');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [departmentFilter, setDepartmentFilter] = useState<string>('ALL');
  const [doctorFilter, setDoctorFilter] = useState<string>('ALL');

  // Reschedule state & modal
  const [rescheduleAppointmentData, setRescheduleAppointmentData] = useState<Appointment | null>(null);
  const [rescheduleDate, setRescheduleDate] = useState<string>('2026-03-30');
  const [rescheduleSlot, setRescheduleSlot] = useState<string>('10:00 AM');

  // Multi-step booking wizard modal
  const [showWizard, setShowWizard] = useState<boolean>(false);
  const [wizardStep, setWizardStep] = useState<number>(1);

  // Wizard state
  const [selectedPatientId, setSelectedPatientId] = useState<string>('');
  const [selectedSpecialization, setSelectedSpecialization] = useState<MedicalSpecialization>('Cardiology');
  const [selectedDoctorId, setSelectedDoctorId] = useState<string>('');
  const [appointmentType, setAppointmentType] = useState<AppointmentType>('General Consultation');
  const [selectedDate, setSelectedDate] = useState<string>('2026-03-29');
  const [selectedTimeSlot, setSelectedTimeSlot] = useState<string>('10:00 AM');
  const [notes, setNotes] = useState<string>('');
  const [isCheckingSlot, setIsCheckingSlot] = useState<boolean>(false);
  const [slotCheckPassed, setSlotCheckPassed] = useState<boolean | null>(null);

  // Pre-select doctor when initiated from Doctor Management module
  useEffect(() => {
    if (selectedDoctorForBooking) {
      setSelectedDoctorId(selectedDoctorForBooking.id);
      setSelectedSpecialization(selectedDoctorForBooking.specialization as MedicalSpecialization);
      if (patients.length > 0) setSelectedPatientId(patients[0].id);
      setShowWizard(true);
      setWizardStep(1);
      if (setSelectedDoctorForBooking) {
        setSelectedDoctorForBooking(null);
      }
    }
  }, [selectedDoctorForBooking, setSelectedDoctorForBooking, patients]);

  const timeSlots = [
    '09:00 AM',
    '09:30 AM',
    '10:00 AM',
    '10:30 AM',
    '11:00 AM',
    '11:30 AM',
    '02:00 PM',
    '02:30 PM',
    '03:00 PM',
    '03:30 PM',
    '04:00 PM',
    '04:30 PM',
  ];

  const appointmentTypes: AppointmentType[] = [
    'General Check-up',
    'Specialist Consultation',
    'Follow-up',
    'Diagnostic Check-up',
    'Emergency Appointment',
    'Pre-Surgery Consultation',
    'Post-Surgery Follow-up',
    'Health Screening',
    'Vaccination',
    'Physiotherapy',
  ];

  // Filtered doctors by specialization for wizard
  const doctorsInSpecialization = useMemo(() => {
    return doctors.filter((d) => d.specialization === selectedSpecialization);
  }, [doctors, selectedSpecialization]);

  // Selected doctor details
  const currentDoctor = useMemo(() => {
    return doctors.find((d) => d.id === selectedDoctorId);
  }, [doctors, selectedDoctorId]);

  // Filtered appointments with Department & Doctor filters
  const filteredAppointments = useMemo(() => {
    const q = (localSearch || searchQuery || '').toLowerCase().trim();
    return (appointments || []).filter((apt) => {
      if (!apt) return false;
      const patientName = (apt.patientName || '').toLowerCase();
      const doctorName = (apt.doctorName || '').toLowerCase();
      const id = (apt.id || '').toLowerCase();
      const spec = (apt.specialization || '').toLowerCase();

      const matchQ =
        !q ||
        patientName.includes(q) ||
        doctorName.includes(q) ||
        id.includes(q) ||
        spec.includes(q);

      const matchStatus = statusFilter === 'ALL' || apt.status === statusFilter;
      const matchDept = departmentFilter === 'ALL' || apt.specialization === departmentFilter;
      const matchDoc = doctorFilter === 'ALL' || apt.doctorId === doctorFilter || apt.doctorName === doctorFilter;

      let matchSubTab = true;
      if (currentTab === 'today') {
        matchSubTab = apt.date === '2026-03-29' || apt.status === 'Scheduled';
      } else if (currentTab === 'upcoming') {
        matchSubTab = apt.status === 'Scheduled' || apt.status === 'Confirmed';
      } else if (currentTab === 'completed') {
        matchSubTab = apt.status === 'Completed';
      } else if (currentTab === 'cancelled') {
        matchSubTab = apt.status === 'Cancelled';
      } else if (currentTab === 'history') {
        matchSubTab = apt.status === 'Completed' || apt.status === 'Cancelled';
      }

      return matchQ && matchStatus && matchDept && matchDoc && matchSubTab;
    });
  }, [appointments, localSearch, searchQuery, statusFilter, departmentFilter, doctorFilter, currentTab]);

  const handleOpenWizard = () => {
    if (patients.length > 0) setSelectedPatientId(patients[0].id);
    setSelectedSpecialization('Cardiology');
    const firstDoc = doctors.find((d) => d.specialization === 'Cardiology') || doctors[0];
    if (firstDoc) setSelectedDoctorId(firstDoc.id);
    setWizardStep(1);
    setSlotCheckPassed(null);
    setShowWizard(true);
  };

  const handlePerformAvailabilityCheck = () => {
    setIsCheckingSlot(true);
    setTimeout(() => {
      // Check if another appointment already exists for this doctor, date, and slot
      const conflict = appointments.some(
        (a) =>
          a.doctorId === selectedDoctorId &&
          a.date === selectedDate &&
          a.timeSlot === selectedTimeSlot &&
          a.status !== 'Cancelled'
      );
      setSlotCheckPassed(!conflict);
      setIsCheckingSlot(false);
    }, 450);
  };

  const handleConfirmBooking = () => {
    const p = patients.find((pat) => pat.id === selectedPatientId);
    const d = doctors.find((doc) => doc.id === selectedDoctorId);
    if (!p || !d) return;

    const success = bookAppointment({
      patientId: p.id,
      doctorId: d.id,
      appointmentType,
      date: selectedDate,
      timeSlot: selectedTimeSlot,
      notes: notes || 'Standard consultation scheduled via multi-step wizard.',
    });

    if (success) {
      setShowWizard(false);
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Header & Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-black text-white tracking-tight flex items-center gap-2.5">
              <CalendarIcon className="w-6 h-6 text-cyan-400" />
              <span>Appointment Scheduling</span>
            </h1>
            <span className="text-xs font-mono px-3 py-0.5 rounded-full bg-cyan-500/20 text-cyan-200 border border-cyan-500/40 font-bold shadow-[0_0_10px_rgba(6,182,212,0.2)]">
              Mutex Protected
            </span>
          </div>
          <p className="text-xs text-slate-300 mt-1 font-medium">
            Real-time multi-specialty OPD calendar with atomic slot validation and double-booking prevention.
          </p>
        </div>

        <button
          onClick={handleOpenWizard}
          className="glass-btn inline-flex items-center gap-2 px-5 py-2.5 rounded-xl text-white text-xs font-extrabold shadow-[0_0_20px_rgba(6,182,212,0.35)]"
        >
          <Plus className="w-4 h-4" />
          <span>Book Consultation Wizard</span>
        </button>
      </div>

      {/* Sub-Options Nav Tabs */}
      <div className="flex flex-wrap items-center gap-2 border-b border-cyan-500/20 pb-3">
        {[
          { id: 'today', label: "Today's Appointments" },
          { id: 'upcoming', label: 'Upcoming' },
          { id: 'completed', label: 'Completed' },
          { id: 'cancelled', label: 'Cancelled' },
          { id: 'all', label: 'All Appointments' },
          { id: 'book', label: 'Book Appointment' },
        ].map((sub) => (
          <button
            key={sub.id}
            onClick={() => {
              if (sub.id === 'book') {
                handleOpenWizard();
              }
              setActiveNavigation('appointments', sub.id);
            }}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition ${
              currentTab === sub.id
                ? 'bg-cyan-500/25 text-cyan-200 border border-cyan-400/50 shadow-[0_0_14px_rgba(6,182,212,0.3)]'
                : 'text-slate-300 hover:text-white bg-[rgba(6,18,45,0.4)] hover:bg-[rgba(6,18,45,0.7)] border border-cyan-500/15'
            }`}
          >
            {sub.label}
          </button>
        ))}
      </div>

      {/* Filter & Search Bar */}
      <div className="p-4 rounded-2xl glass-card flex flex-col lg:flex-row items-center justify-between gap-3 shadow-xl">
        <div className="relative w-full lg:w-72">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-cyan-300" />
          <input
            type="text"
            placeholder="Search appointment, patient, doctor..."
            value={localSearch}
            onChange={(e) => setLocalSearch(e.target.value)}
            className="w-full pl-9 pr-4 py-2.5 text-xs rounded-xl glass-input text-white placeholder-slate-400 font-medium"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2.5 w-full lg:w-auto">
          {/* Filter by Department */}
          <div className="flex items-center gap-1.5 text-xs text-slate-200 font-bold">
            <Building className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
            <span>Dept:</span>
            <select
              value={departmentFilter}
              onChange={(e) => setDepartmentFilter(e.target.value)}
              className="px-2.5 py-1.5 rounded-xl glass-input text-xs text-cyan-200 font-bold cursor-pointer"
            >
              <option value="ALL" className="bg-slate-950 text-white">All Departments</option>
              {ALL_SPECIALIZATIONS.map((spec) => (
                <option key={spec} value={spec} className="bg-slate-950 text-white">
                  {spec}
                </option>
              ))}
            </select>
          </div>

          {/* Filter by Doctor */}
          <div className="flex items-center gap-1.5 text-xs text-slate-200 font-bold">
            <Stethoscope className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
            <span>Doctor:</span>
            <select
              value={doctorFilter}
              onChange={(e) => setDoctorFilter(e.target.value)}
              className="px-2.5 py-1.5 rounded-xl glass-input text-xs text-cyan-200 font-bold cursor-pointer max-w-[160px]"
            >
              <option value="ALL" className="bg-slate-950 text-white">All Doctors</option>
              {doctors.map((doc) => (
                <option key={doc.id} value={doc.id} className="bg-slate-950 text-white">
                  {doc.name}
                </option>
              ))}
            </select>
          </div>

          {/* Filter by Status */}
          <div className="flex items-center gap-1.5 text-xs text-slate-200 font-bold">
            <Filter className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
            <span>Status:</span>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="px-2.5 py-1.5 rounded-xl glass-input text-xs text-cyan-200 font-bold cursor-pointer"
            >
              <option value="ALL" className="bg-slate-950 text-white">All Statuses</option>
              <option value="Scheduled" className="bg-slate-950 text-white">Scheduled</option>
              <option value="Confirmed" className="bg-slate-950 text-white">Confirmed</option>
              <option value="In Consultation" className="bg-slate-950 text-white">In Consultation</option>
              <option value="Completed" className="bg-slate-950 text-white">Completed</option>
              <option value="Cancelled" className="bg-slate-950 text-white">Cancelled</option>
            </select>
          </div>

          {(departmentFilter !== 'ALL' || doctorFilter !== 'ALL' || statusFilter !== 'ALL' || localSearch) && (
            <button
              onClick={() => {
                setDepartmentFilter('ALL');
                setDoctorFilter('ALL');
                setStatusFilter('ALL');
                setLocalSearch('');
              }}
              className="px-3 py-1.5 rounded-xl glass-btn-secondary text-xs text-slate-300 hover:text-white font-bold transition"
            >
              Reset
            </button>
          )}
        </div>
      </div>

      {/* Filter summary */}
      <div className="flex items-center justify-between text-xs px-1 text-slate-300">
        <span>
          Showing <strong className="text-white font-bold">{filteredAppointments.length}</strong> of{' '}
          <strong className="text-cyan-300">{appointments.length}</strong> appointments
          {departmentFilter !== 'ALL' && <span className="text-cyan-300 ml-1">in {departmentFilter}</span>}
        </span>
        <span className="text-[11px] font-mono text-cyan-300/80 font-bold">
          Active Concurrency Lock: Slot Mutex Active
        </span>
      </div>

      {/* Book Appointment Direct Interface tab if requested */}
      {currentTab === 'book' && (
        <div className="p-6 rounded-3xl glass-card border border-cyan-400/40 shadow-2xl mb-6 animate-in fade-in">
          <div className="flex items-center justify-between pb-4 mb-4 border-b border-cyan-500/20">
            <div>
              <h3 className="text-lg font-extrabold text-white flex items-center gap-2">
                <Calendar className="w-5 h-5 text-cyan-400" />
                <span>Book Hospital Consultation</span>
              </h3>
              <p className="text-xs text-slate-300 mt-0.5">
                Schedule patient appointments with department specialists in real-time.
              </p>
            </div>
            <button
              onClick={handleOpenWizard}
              className="px-4 py-2 rounded-xl glass-btn text-xs font-bold text-white shadow-md flex items-center gap-1.5"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Launch 6-Step Wizard</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 text-xs">
            {/* Field: Select Patient */}
            <div>
              <label className="text-slate-300 font-bold block mb-1.5">Select Patient</label>
              <select
                value={selectedPatientId}
                onChange={(e) => setSelectedPatientId(e.target.value)}
                className="w-full p-2.5 rounded-xl glass-input text-white text-xs font-medium cursor-pointer"
              >
                {patients.map((p) => (
                  <option key={p.id} value={p.id} className="bg-slate-950 text-white">
                    {p.name} ({p.id}) - {p.gender}, {p.age}y
                  </option>
                ))}
              </select>
            </div>

            {/* Field: Select Department */}
            <div>
              <label className="text-slate-300 font-bold block mb-1.5">Select Department</label>
              <select
                value={selectedSpecialization}
                onChange={(e) => {
                  const spec = e.target.value as MedicalSpecialization;
                  setSelectedSpecialization(spec);
                  const firstDoc = doctors.find((d) => d.specialization === spec);
                  if (firstDoc) setSelectedDoctorId(firstDoc.id);
                }}
                className="w-full p-2.5 rounded-xl glass-input text-cyan-200 text-xs font-medium cursor-pointer"
              >
                {Array.from(new Set(doctors.map((d) => d.specialization))).map((spec) => (
                  <option key={spec} value={spec} className="bg-slate-950 text-white">
                    {spec}
                  </option>
                ))}
              </select>
            </div>

            {/* Field: Select Doctor */}
            <div>
              <label className="text-slate-300 font-bold block mb-1.5">Select Doctor</label>
              <select
                value={selectedDoctorId}
                onChange={(e) => setSelectedDoctorId(e.target.value)}
                className="w-full p-2.5 rounded-xl glass-input text-white text-xs font-medium cursor-pointer"
              >
                {doctorsInSpecialization.map((doc) => (
                  <option key={doc.id} value={doc.id} className="bg-slate-950 text-white">
                    {doc.name} - {doc.roomNumber} (₹{doc.consultationFee})
                  </option>
                ))}
              </select>
            </div>

            {/* Field: Select Date */}
            <div>
              <label className="text-slate-300 font-bold block mb-1.5">Select Date</label>
              <input
                type="date"
                value={selectedDate}
                onChange={(e) => setSelectedDate(e.target.value)}
                className="w-full p-2.5 rounded-xl glass-input text-white text-xs font-medium cursor-pointer"
              />
            </div>

            {/* Field: Select Time Slot */}
            <div>
              <label className="text-slate-300 font-bold block mb-1.5">Select Time Slot</label>
              <select
                value={selectedTimeSlot}
                onChange={(e) => setSelectedTimeSlot(e.target.value)}
                className="w-full p-2.5 rounded-xl glass-input text-cyan-200 text-xs font-mono font-bold cursor-pointer"
              >
                {timeSlots.map((slot) => (
                  <option key={slot} value={slot} className="bg-slate-950 text-white">
                    {slot}
                  </option>
                ))}
              </select>
            </div>

            {/* Field: Appointment Type */}
            <div>
              <label className="text-slate-300 font-bold block mb-1.5">Appointment Type</label>
              <select
                value={appointmentType}
                onChange={(e) => setAppointmentType(e.target.value as AppointmentType)}
                className="w-full p-2.5 rounded-xl glass-input text-white text-xs font-medium cursor-pointer"
              >
                <option value="General Consultation" className="bg-slate-950 text-white">General Consultation</option>
                <option value="Follow-up" className="bg-slate-950 text-white">Follow-up</option>
                <option value="Emergency Appointment" className="bg-slate-950 text-white">Emergency Appointment</option>
                <option value="Diagnostic Check-up" className="bg-slate-950 text-white">Diagnostic Check-up</option>
                <option value="Specialist Consultation" className="bg-slate-950 text-white">Specialist Consultation</option>
              </select>
            </div>
          </div>

          {/* Notes / Symptoms */}
          <div className="mt-4">
            <label className="text-slate-300 font-bold block mb-1.5 text-xs">Notes / Symptoms</label>
            <textarea
              rows={2}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Enter patient symptoms, reason for consultation, or referral notes..."
              className="w-full p-3 rounded-xl glass-input text-xs text-white placeholder-slate-400 outline-none resize-none"
            />
          </div>

          <div className="mt-4 pt-4 border-t border-cyan-500/20 flex items-center justify-end gap-3">
            <button
              onClick={handleConfirmBooking}
              className="px-6 py-2.5 rounded-xl glass-btn text-white text-xs font-extrabold shadow-[0_0_16px_rgba(6,182,212,0.35)] flex items-center gap-2 active:scale-95"
            >
              <Check className="w-4 h-4" />
              <span>Confirm & Book Appointment</span>
            </button>
          </div>
        </div>
      )}

      {/* Appointment Timeline / Card List */}
      {filteredAppointments.length === 0 ? (
        <div className="p-12 text-center rounded-3xl glass-card text-slate-300">
          <CalendarIcon className="w-10 h-10 mx-auto text-cyan-400 mb-3 opacity-60" />
          <h4 className="text-base font-bold text-white">No appointments match the selected filters</h4>
          <p className="text-xs text-slate-300 mt-1 max-w-sm mx-auto">
            Try adjusting status, department, or doctor filters, or click "Book Consultation Wizard" to schedule one.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredAppointments.map((apt) => {
            const parts = (apt.timeSlot || '09:00 AM').split(' ');
            const timeNum = parts[0] || '09:00';
            const timePeriod = parts[1] || 'AM';

            return (
              <div
                key={apt.id}
                className="p-5 rounded-2xl glass-card hover:border-cyan-400/50 transition-all hover:-translate-y-0.5 hover:shadow-[0_16px_36px_rgba(0,0,0,0.6),0_0_20px_rgba(6,182,212,0.2)] flex flex-col justify-between group"
              >
                <div>
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center gap-3">
                      <div className="w-11 h-11 rounded-xl bg-[rgba(6,18,45,0.7)] border border-cyan-500/40 flex flex-col items-center justify-center text-cyan-200 font-mono shadow-[0_0_10px_rgba(6,182,212,0.2)]">
                        <span className="text-xs font-black leading-none">{timeNum}</span>
                        <span className="text-[8px] text-slate-300 uppercase leading-none mt-0.5 font-bold">
                          {timePeriod}
                        </span>
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <h3 className="text-base font-extrabold text-white tracking-tight">{apt.patientName || 'Patient'}</h3>
                          <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-cyan-950/80 text-cyan-300 border border-cyan-500/30 font-bold">
                            {apt.id}
                          </span>
                        </div>
                        <span className="text-xs text-slate-300 block font-medium mt-0.5">
                          {apt.doctorName || 'Doctor'} &bull; <span className="text-cyan-300 font-bold">{apt.specialization || 'General'}</span>
                        </span>
                      </div>
                    </div>

                    <span
                      className={`text-[9px] font-extrabold px-2.5 py-1 rounded-full uppercase tracking-wider shrink-0 ${
                        apt.status === 'In Consultation'
                          ? 'bg-cyan-500/25 text-cyan-200 border border-cyan-500/50 animate-pulse'
                          : apt.status === 'Confirmed'
                          ? 'bg-emerald-500/25 text-emerald-200 border border-emerald-500/50'
                          : apt.status === 'Cancelled'
                          ? 'bg-red-500/25 text-red-200 border border-red-500/50'
                          : apt.status === 'Completed'
                          ? 'bg-slate-800/80 text-slate-300 border border-slate-700'
                          : 'bg-blue-500/25 text-blue-200 border border-blue-500/50'
                      }`}
                    >
                      {apt.status}
                    </span>
                  </div>

                  {/* 6 Core Appointment Details */}
                  <div className="mt-4 pt-3 border-t border-cyan-500/20 space-y-1.5 text-xs text-slate-200">
                    <div className="flex items-center justify-between">
                      <span className="text-slate-400 font-medium">Department:</span>
                      <span className="text-cyan-200 font-semibold">{apt.specialization}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-slate-400 font-medium">Date & Time:</span>
                      <span className="font-mono text-white font-bold">
                        {apt.date} at {apt.timeSlot}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-slate-400 font-medium">Consultation Type:</span>
                      <span className="text-slate-100 font-medium">{apt.appointmentType}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-slate-400 font-medium">Consultation Fee:</span>
                      <span className="font-mono font-extrabold text-emerald-300">₹{apt.fee}</span>
                    </div>
                    {apt.notes && (
                      <div className="pt-1">
                        <span className="text-slate-400 text-[11px] block">Notes:</span>
                        <p className="text-[11px] text-slate-300 italic font-medium">&ldquo;{apt.notes}&rdquo;</p>
                      </div>
                    )}
                  </div>
                </div>

                {/* Actions: Confirm, Reschedule, Cancel, Start Consult, Mark Completed */}
                <div className="mt-5 pt-3 border-t border-cyan-500/20 flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-1.5 flex-wrap">
                    {apt.status === 'Scheduled' && (
                      <button
                        onClick={() => updateAppointmentStatus(apt.id, 'Confirmed')}
                        className="px-3 py-1.5 rounded-lg text-[10px] font-extrabold bg-emerald-500/25 text-emerald-200 border border-emerald-500/50 hover:bg-emerald-500/35 transition shadow-sm active:scale-95 flex items-center gap-1"
                        title="Confirm Appointment"
                      >
                        <CheckCircle2 className="w-3 h-3" />
                        <span>Confirm Appointment</span>
                      </button>
                    )}

                    {(apt.status === 'Confirmed' || apt.status === 'Scheduled') && (
                      <button
                        onClick={() => updateAppointmentStatus(apt.id, 'In Consultation')}
                        className="px-3 py-1.5 rounded-lg text-[10px] font-extrabold bg-cyan-500/25 text-cyan-200 border border-cyan-500/50 hover:bg-cyan-500/35 transition shadow-sm active:scale-95 flex items-center gap-1"
                      >
                        <Stethoscope className="w-3 h-3" />
                        <span>Start Consult</span>
                      </button>
                    )}

                    {apt.status === 'In Consultation' && (
                      <button
                        onClick={() => updateAppointmentStatus(apt.id, 'Completed')}
                        className="px-3 py-1.5 rounded-lg text-[10px] font-extrabold bg-emerald-500/25 text-emerald-200 border border-emerald-500/50 hover:bg-emerald-500/35 transition shadow-sm active:scale-95 flex items-center gap-1"
                      >
                        <CheckCircle2 className="w-3 h-3" />
                        <span>Mark Completed</span>
                      </button>
                    )}

                    {apt.status !== 'Completed' && apt.status !== 'Cancelled' && (
                      <button
                        onClick={() => {
                          setRescheduleAppointmentData(apt);
                          setRescheduleDate(apt.date || '2026-03-30');
                          setRescheduleSlot(apt.timeSlot || '10:00 AM');
                        }}
                        className="px-3 py-1.5 rounded-lg text-[10px] font-extrabold bg-amber-500/20 text-amber-200 border border-amber-500/40 hover:bg-amber-500/30 transition shadow-sm active:scale-95 flex items-center gap-1"
                        title="Reschedule Date & Time"
                      >
                        <RotateCw className="w-3 h-3" />
                        <span>Reschedule</span>
                      </button>
                    )}
                  </div>

                  {apt.status !== 'Cancelled' && apt.status !== 'Completed' && (
                    <button
                      onClick={() => updateAppointmentStatus(apt.id, 'Cancelled')}
                      className="text-[11px] font-bold text-red-400/80 hover:text-red-300 transition py-1 px-2 hover:bg-red-500/10 rounded-lg active:scale-95"
                    >
                      Cancel Appointment
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Reschedule Appointment Modal */}
      {rescheduleAppointmentData && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-2xl animate-in fade-in"
          onClick={(e) => {
            if (e.target === e.currentTarget) {
              setRescheduleAppointmentData(null);
            }
          }}
        >
          <div className="relative w-full max-w-md rounded-3xl glass-modal p-6 shadow-2xl">
            <button
              onClick={() => setRescheduleAppointmentData(null)}
              className="absolute top-5 right-5 p-2 rounded-xl text-slate-300 hover:text-white border border-cyan-500/20 transition"
            >
              <X className="w-4 h-4" />
            </button>

            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-300">
                <RotateCw className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-extrabold text-white">Reschedule Appointment</h3>
                <span className="text-xs font-mono text-cyan-300">
                  {rescheduleAppointmentData.id} &bull; {rescheduleAppointmentData.patientName}
                </span>
              </div>
            </div>

            <div className="p-3.5 rounded-xl glass-card-subtle text-xs text-slate-200 mb-4 space-y-1">
              <div>
                <span className="text-slate-400">Doctor:</span>{' '}
                <strong className="text-white font-bold">{rescheduleAppointmentData.doctorName}</strong> (
                {rescheduleAppointmentData.specialization})
              </div>
              <div>
                <span className="text-slate-400">Current Slot:</span>{' '}
                <span className="font-mono text-amber-300">
                  {rescheduleAppointmentData.date} at {rescheduleAppointmentData.timeSlot}
                </span>
              </div>
            </div>

            <div className="space-y-3 text-xs mb-5">
              <div>
                <label className="text-slate-300 font-bold block mb-1">New Consultation Date</label>
                <input
                  type="date"
                  value={rescheduleDate}
                  onChange={(e) => setRescheduleDate(e.target.value)}
                  className="w-full p-2.5 rounded-xl glass-input text-white font-medium"
                />
              </div>

              <div>
                <label className="text-slate-300 font-bold block mb-1">New Time Slot</label>
                <select
                  value={rescheduleSlot}
                  onChange={(e) => setRescheduleSlot(e.target.value)}
                  className="w-full p-2.5 rounded-xl glass-input text-cyan-200 font-mono font-bold"
                >
                  {timeSlots.map((slot) => (
                    <option key={slot} value={slot} className="bg-slate-950 text-white">
                      {slot}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="flex items-center justify-end gap-3 pt-3 border-t border-cyan-500/20">
              <button
                onClick={() => setRescheduleAppointmentData(null)}
                className="px-4 py-2 rounded-xl glass-btn-secondary text-xs font-bold text-slate-300 hover:text-white"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  const ok = rescheduleAppointment(rescheduleAppointmentData.id, rescheduleDate, rescheduleSlot);
                  if (ok) {
                    setRescheduleAppointmentData(null);
                  }
                }}
                className="px-5 py-2 rounded-xl glass-btn text-xs font-extrabold text-white shadow-md active:scale-95"
              >
                Confirm Reschedule
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Multi-Step Booking Wizard Modal */}
      {showWizard && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-2xl animate-in fade-in">
          <div className="relative w-full max-w-2xl rounded-3xl glass-modal p-6 overflow-y-auto max-h-[90vh]">
            <button
              onClick={() => setShowWizard(false)}
              className="absolute top-5 right-5 p-2 rounded-xl text-slate-300 hover:text-white hover:bg-[rgba(6,18,45,0.7)] border border-cyan-500/20 transition"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Stepper Indicator */}
            <div className="mb-6">
              <span className="text-[10px] font-mono text-cyan-300 uppercase font-extrabold tracking-wider">
                Step {wizardStep} of 6 &bull; Mutex Synchronized Scheduler
              </span>
              <h2 className="text-xl font-extrabold text-white mt-1">
                {wizardStep === 1 && '1. Select Patient'}
                {wizardStep === 2 && '2. Select Specialization'}
                {wizardStep === 3 && '3. Choose Physician / Surgeon'}
                {wizardStep === 4 && '4. Consultation Type & Notes'}
                {wizardStep === 5 && '5. Select Date & Slot'}
                {wizardStep === 6 && '6. Slot Validation & Lock'}
              </h2>
              <div className="w-full h-1.5 bg-[rgba(6,18,45,0.8)] border border-cyan-500/20 rounded-full mt-3 overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-cyan-400 to-blue-500 shadow-[0_0_10px_rgba(6,182,212,0.5)] transition-all duration-300"
                  style={{ width: `${(wizardStep / 6) * 100}%` }}
                />
              </div>
            </div>

            {/* Step 1: Select Patient */}
            {wizardStep === 1 && (
              <div className="space-y-3">
                <p className="text-xs text-slate-300 font-medium">
                  Select an enrolled patient from the directory:
                </p>
                <div className="max-h-60 overflow-y-auto space-y-2">
                  {patients.map((p) => (
                    <div
                      key={p.id}
                      onClick={() => setSelectedPatientId(p.id)}
                      className={`p-3.5 rounded-xl border transition cursor-pointer flex items-center justify-between text-xs ${
                        selectedPatientId === p.id
                          ? 'bg-cyan-500/25 border-cyan-400 text-white font-bold shadow-[0_0_15px_rgba(6,182,212,0.25)]'
                          : 'glass-card-subtle text-slate-200 hover:border-cyan-400/40'
                      }`}
                    >
                      <div>
                        <span className="font-extrabold block text-white">{p.name}</span>
                        <span className="text-[10px] text-slate-300 mt-0.5 block font-medium">
                          {p.id} &bull; {p.age} yrs &bull; {p.gender} &bull; Blood: <strong className="text-cyan-300">{p.bloodGroup}</strong>
                        </span>
                      </div>
                      {selectedPatientId === p.id && <CheckCircle2 className="w-4 h-4 text-cyan-300" />}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Step 2: Select Specialization */}
            {wizardStep === 2 && (
              <div className="space-y-3">
                <p className="text-xs text-slate-300 font-medium">
                  Select clinical department / specialization:
                </p>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 max-h-64 overflow-y-auto">
                  {Array.from(new Set(doctors.map((d) => d.specialization))).map((spec) => (
                    <button
                      key={spec}
                      onClick={() => {
                        setSelectedSpecialization(spec);
                        const firstDoc = doctors.find((d) => d.specialization === spec);
                        if (firstDoc) setSelectedDoctorId(firstDoc.id);
                      }}
                      className={`p-3 rounded-xl border text-xs text-left transition ${
                        selectedSpecialization === spec
                          ? 'bg-cyan-500/25 border-cyan-400 text-cyan-200 font-bold shadow-[0_0_12px_rgba(6,182,212,0.25)]'
                          : 'glass-card-subtle text-slate-200 hover:border-cyan-400/40'
                      }`}
                    >
                      {spec}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Step 3: Select Doctor */}
            {wizardStep === 3 && (
              <div className="space-y-3">
                <p className="text-xs text-slate-300 font-medium">
                  Select physician in <span className="text-cyan-300 font-bold">{selectedSpecialization}</span>:
                </p>
                <div className="space-y-2 max-h-60 overflow-y-auto">
                  {doctorsInSpecialization.length === 0 ? (
                    <p className="text-xs text-amber-300 py-4 text-center font-bold">
                      No doctors currently on duty for this specialization.
                    </p>
                  ) : (
                    doctorsInSpecialization.map((doc) => (
                      <div
                        key={doc.id}
                        onClick={() => setSelectedDoctorId(doc.id)}
                        className={`p-3.5 rounded-xl border transition cursor-pointer flex items-center justify-between text-xs ${
                          selectedDoctorId === doc.id
                            ? 'bg-cyan-500/25 border-cyan-400 text-white font-bold shadow-[0_0_15px_rgba(6,182,212,0.25)]'
                            : 'glass-card-subtle text-slate-200 hover:border-cyan-400/40'
                        }`}
                      >
                        <div>
                          <span className="font-extrabold block text-white">{doc.name}</span>
                          <span className="text-[10px] text-slate-300 font-medium mt-0.5 block">
                            {doc.experienceYears} yrs exp &bull; {doc.roomNumber} &bull; Fee: <strong className="text-emerald-300 font-bold">₹{doc.consultationFee}</strong>
                          </span>
                        </div>
                        {selectedDoctorId === doc.id && (
                          <CheckCircle2 className="w-4 h-4 text-cyan-300" />
                        )}
                      </div>
                    ))
                  )}
                </div>
              </div>
            )}

            {/* Step 4: Appointment Type & Notes */}
            {wizardStep === 4 && (
              <div className="space-y-4">
                <div>
                  <label className="text-xs font-bold text-slate-200 block mb-2">
                    Consultation Type
                  </label>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {appointmentTypes.map((type) => (
                      <button
                        key={type}
                        type="button"
                        onClick={() => setAppointmentType(type)}
                        className={`p-3 rounded-xl border text-xs text-left transition ${
                          appointmentType === type
                            ? 'bg-cyan-500/25 border-cyan-400 text-cyan-200 font-bold shadow-[0_0_12px_rgba(6,182,212,0.25)]'
                            : 'glass-card-subtle text-slate-200 hover:border-cyan-400/40'
                        }`}
                      >
                        {type}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-200 block mb-1">
                    Clinical Notes or Chief Complaint (Optional)
                  </label>
                  <textarea
                    rows={3}
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    placeholder="Describe specific symptoms or reason for visit..."
                    className="w-full p-3.5 rounded-xl glass-input text-xs text-white outline-none resize-none"
                  />
                </div>
              </div>
            )}

            {/* Step 5: Date & Slot Selection */}
            {wizardStep === 5 && (
              <div className="space-y-4">
                <div>
                  <label className="text-xs font-bold text-slate-200 block mb-1">
                    Select Consultation Date
                  </label>
                  <input
                    type="date"
                    value={selectedDate}
                    onChange={(e) => {
                      setSelectedDate(e.target.value);
                      setSlotCheckPassed(null);
                    }}
                    className="w-full px-3.5 py-2.5 rounded-xl glass-input text-xs text-white cursor-pointer"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-200 block mb-2">
                    Available Time Slots
                  </label>
                  <div className="grid grid-cols-3 sm:grid-cols-4 gap-2">
                    {timeSlots.map((slot) => (
                      <button
                        key={slot}
                        type="button"
                        onClick={() => {
                          setSelectedTimeSlot(slot);
                          setSlotCheckPassed(null);
                        }}
                        className={`py-2 px-1 rounded-xl border text-xs font-mono text-center transition ${
                          selectedTimeSlot === slot
                            ? 'bg-cyan-500/25 border-cyan-400 text-cyan-200 font-bold shadow-[0_0_10px_rgba(6,182,212,0.25)]'
                            : 'glass-card-subtle text-slate-300 hover:text-white hover:border-cyan-400/40'
                        }`}
                      >
                        {slot}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {/* Step 6: Mutex Validation & Confirmation */}
            {wizardStep === 6 && (
              <div className="space-y-4">
                <div className="p-4 rounded-2xl glass-card-subtle space-y-2 text-xs">
                  <div className="flex justify-between">
                    <span className="text-slate-300 font-medium">Patient:</span>
                    <span className="font-extrabold text-white">
                      {patients.find((p) => p.id === selectedPatientId)?.name}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-300 font-medium">Doctor:</span>
                    <span className="font-extrabold text-white">{currentDoctor?.name}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-300 font-medium">Specialization:</span>
                    <span className="text-cyan-300 font-bold">{selectedSpecialization}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-300 font-medium">Date & Slot:</span>
                    <span className="font-mono text-white font-bold">
                      {selectedDate} at {selectedTimeSlot}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-300 font-medium">Consultation Fee:</span>
                    <span className="font-mono font-extrabold text-emerald-300">
                      ₹{currentDoctor?.consultationFee}
                    </span>
                  </div>
                </div>

                {/* Mutex Slot Checker Button */}
                <div className="p-4 rounded-2xl bg-[rgba(30,27,75,0.5)] border border-indigo-500/40">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Lock className="w-4 h-4 text-indigo-300" />
                      <span className="text-xs font-bold text-white">
                        Concurrency Mutex Lock Check
                      </span>
                    </div>
                    <button
                      onClick={handlePerformAvailabilityCheck}
                      disabled={isCheckingSlot}
                      className="px-3.5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold transition disabled:opacity-50 shadow-[0_0_12px_rgba(99,102,241,0.3)]"
                    >
                      {isCheckingSlot ? 'Locking Mutex...' : 'Verify Availability'}
                    </button>
                  </div>

                  {slotCheckPassed === true && (
                    <div className="mt-3 flex items-center gap-2 text-xs text-emerald-200 bg-emerald-950/60 p-2.5 rounded-xl border border-emerald-500/40 font-bold">
                      <Check className="w-4 h-4" />
                      Slot available! ReentrantLock acquired without collision.
                    </div>
                  )}

                  {slotCheckPassed === false && (
                    <div className="mt-3 flex items-center gap-2 text-xs text-red-200 bg-red-950/60 p-2.5 rounded-xl border border-red-500/40 font-bold">
                      <AlertCircle className="w-4 h-4" />
                      Conflict detected! Throws AppointmentSlotBookedException.
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* Stepper Navigation Buttons */}
            <div className="mt-6 pt-4 border-t border-cyan-500/20 flex items-center justify-between">
              <button
                type="button"
                disabled={wizardStep === 1}
                onClick={() => setWizardStep((s) => s - 1)}
                className="px-4 py-2.5 rounded-xl glass-btn-secondary text-xs font-bold text-slate-200 disabled:opacity-40"
              >
                Back
              </button>

              {wizardStep < 6 ? (
                <button
                  type="button"
                  onClick={() => setWizardStep((s) => s + 1)}
                  className="px-5 py-2.5 rounded-xl glass-btn text-white text-xs font-extrabold shadow-[0_0_15px_rgba(6,182,212,0.3)] flex items-center gap-1.5"
                >
                  <span>Next Step</span>
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>
              ) : (
                <button
                  type="button"
                  onClick={handleConfirmBooking}
                  className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-white text-xs font-black shadow-[0_0_20px_rgba(16,185,129,0.35)] transition flex items-center gap-1.5"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Confirm & Commit Booking</span>
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
