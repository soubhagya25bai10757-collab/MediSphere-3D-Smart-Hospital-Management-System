import React, { createContext, useContext, useState, useEffect, useMemo, ReactNode } from 'react';
import {
  Patient,
  Doctor,
  Appointment,
  EmergencyCase,
  MedicalRecord,
  Treatment,
  LabTest,
  Medicine,
  Bed,
  Bill,
  SystemThreadInfo,
  User,
  UserRole,
  NavigationTab,
  MainNavigationTab,
  ToastMessage,
  AppointmentType,
  DoctorSpecialization,
  LabTestType,
  EmergencyPriority,
  SystemLogEntry,
} from '../types';
import {
  INITIAL_PATIENTS,
  INITIAL_DOCTORS,
  INITIAL_APPOINTMENTS,
  INITIAL_EMERGENCY_CASES,
  INITIAL_MEDICAL_RECORDS,
  INITIAL_TREATMENTS,
  INITIAL_LAB_TESTS,
  INITIAL_MEDICINES,
  INITIAL_BEDS,
  INITIAL_BILLS,
  INITIAL_SYSTEM_THREADS,
  INITIAL_USERS,
} from '../data/initialData';
import confetti from 'canvas-confetti';

interface HospitalContextType {
  // Auth & View
  currentUser: User;
  setCurrentUser: (user: User) => void;
  setUserRole: (role: UserRole) => void;
  isLoggedIn: boolean;
  login: (username: string, role: UserRole) => void;
  logout: () => void;
  activeTab: NavigationTab;
  setActiveTab: (tab: NavigationTab) => void;
  activeMainTab: MainNavigationTab;
  activeSubTab: string;
  setActiveNavigation: (mainTab: MainNavigationTab, subTab?: string) => void;
  showLandingPage: boolean;
  setShowLandingPage: (show: boolean) => void;
  showLoginModal: boolean;
  setShowLoginModal: (show: boolean) => void;
  showJavaArchitectureModal: boolean;
  setShowJavaArchitectureModal: (show: boolean) => void;

  // VTOP-style Collapsible Sidebar / Drawer State (default compact: false)
  isSidebarExpanded: boolean;
  setIsSidebarExpanded: (expanded: boolean | ((prev: boolean) => boolean)) => void;
  toggleSidebar: () => void;

  // Global Search
  searchQuery: string;
  setSearchQuery: (query: string) => void;

  // Notifications / Toasts
  toasts: ToastMessage[];
  addToast: (title: string, message: string, type?: ToastMessage['type'], javaException?: string) => void;
  removeToast: (id: string) => void;

  // Patients
  patients: Patient[];
  addPatient: (patientData: Omit<Patient, 'id' | 'registeredDate'>) => Patient;
  updatePatient: (id: string, updates: Partial<Patient>) => void;
  deletePatient: (id: string) => void;
  getPatientById: (id: string) => Patient | undefined;

  // Doctors
  doctors: Doctor[];
  updateDoctorStatus: (id: string, status: Doctor['status']) => void;
  getDoctorById: (id: string) => Doctor | undefined;
  addDoctor: (data: any) => void;
  updateDoctor: (id: string, updates: any) => void;
  deleteDoctor: (id: string) => void;
  selectedDoctorForBooking: Doctor | null;
  setSelectedDoctorForBooking: (doctor: Doctor | null) => void;
  initiateBookingForDoctor: (doctor: Doctor) => void;

  // Appointments
  appointments: Appointment[];
  bookAppointment: (data: {
    patientId: string;
    doctorId: string;
    appointmentType: AppointmentType;
    date: string;
    timeSlot: string;
    notes?: string;
  }) => Appointment | null;
  updateAppointmentStatus: (id: string, status: Appointment['status']) => void;
  rescheduleAppointment: (id: string, date: string, timeSlot: string) => boolean;

  // Emergency Priority Queue
  emergencyCases: EmergencyCase[];
  addEmergencyCase: (data: Omit<EmergencyCase, 'id' | 'arrivalTime' | 'waitingMinutes' | 'status'>) => EmergencyCase;
  updateEmergencyCase: (id: string, updates: Partial<EmergencyCase>) => void;
  assignEmergencyDoctorBed: (caseId: string, doctorId: string, bedId?: string) => void;
  markEmergencyTreated: (caseId: string) => void;
  updateEmergencyPriority: (id: string, priority: EmergencyPriority) => void;
  assignEmergencyDoctor: (caseId: string, doctorId: string, doctorName?: string) => void;
  assignEmergencyBed: (caseId: string, bedId: string, bedNumber?: string) => void;

  // Medical Records & Treatments
  medicalRecords: MedicalRecord[];
  addMedicalRecord: (record: Omit<MedicalRecord, 'id' | 'date'>) => MedicalRecord;
  treatments: Treatment[];
  addTreatment: (treatment: Omit<Treatment, 'id' | 'startDate'>) => Treatment;
  updateTreatmentStatus: (id: string, status: any) => void;

  // Laboratory
  labTests: LabTest[];
  requestLabTest: (data: {
    patientId: string;
    doctorId: string;
    testType: LabTestType;
    urgency: 'Routine' | 'Urgent' | 'Stat (Emergency)';
  }) => LabTest;
  processLabTest: (id: string) => void;
  completeLabTest: (id: string, results: LabTest['results'], notes?: string) => void;
  addLabTest: (data: any) => void;
  updateLabTestStatus: (id: string, status: any) => void;
  simulateLabAnalysisThread: (testId: string) => void;

  // Pharmacy
  medicines: Medicine[];
  addMedicine: (data: any) => Medicine;
  updateMedicineStock: (id: string, newStock: number) => void;
  dispenseMedicine: (id: string, quantity: number) => boolean;
  issueMedicine: (id: string, quantity: number, patientName?: string) => boolean;

  // Beds
  beds: Bed[];
  updateBedStatus: (id: string, status: Bed['status'], patientId?: string, patientName?: string) => void;
  allocateBed: (bedId: string, patientId: string, patientName: string) => void;
  vacateBed: (bedId: string) => void;

  // Billing
  bills: Bill[];
  createBill: (data: {
    patientId: string;
    items: Bill['items'];
    discountPercent?: number;
    taxPercent?: number;
  }) => Bill;
  payBill: (billId: string, paymentMethod: any, amountPaid?: number) => void;
  generateBill: (data: any) => void;

  // Java Multithreading Simulation & Logs
  threads: SystemThreadInfo[];
  spawnWorkerThread: (taskName: string) => void;
  toggleThreadState: (id: string) => void;
  pauseThread: (id: string) => void;
  resumeThread: (id: string) => void;
  triggerGarbageCollection: () => void;
  triggerConcurrencyStressTest: () => void;
  simulateThreadLatencySpike: (threadId?: string, spikeLatencyMs?: number) => void;
  mitigateThreadLatency: (threadId?: string) => void;
  updateThreadLatencyThreshold: (threadId: string, thresholdMs: number) => void;
  systemLogs: SystemLogEntry[];

  // Persistence, I/O, and Settings
  exportDataAsJSON: () => void;
  importDataFromJSON: (jsonString: string) => void;
  resetToDemoData: () => void;
  switchUserRole: (role: UserRole) => void;

  // Stats
  kpiStats: {
    totalPatients: number;
    availableDoctors: number;
    todayAppointments: number;
    emergencyCases: number;
    availableBeds: number;
    pendingBills: number;
    lowStockMedicines: number;
    todayRevenueFormatted: string;
  };

  // 3D Campus target section focus
  focusedSection: string | null;
  setFocusedSection: (section: string | null) => void;
  navigateToSection: (sectionKey: string) => void;
}

interface RouteState {
  showLanding: boolean;
  mainTab: MainNavigationTab;
  subTab: string;
}

export const parseLocationRoute = (): RouteState => {
  if (typeof window === 'undefined') {
    return { showLanding: true, mainTab: 'dashboard', subTab: 'overview' };
  }

  const rawPath = window.location.pathname.replace(/\/+$/, '') || '/';
  if (rawPath === '/' || rawPath === '' || rawPath === '/index.html') {
    return { showLanding: true, mainTab: 'dashboard', subTab: 'overview' };
  }

  const cleanPath = rawPath.replace(/^\//, '').toLowerCase();
  const segments = cleanPath.split('/');
  const primary = segments[0];
  const secondary = segments[1];

  switch (primary) {
    case 'dashboard':
      return { showLanding: false, mainTab: 'dashboard', subTab: secondary || 'overview' };
    case 'patients':
      return { showLanding: false, mainTab: 'patients', subTab: secondary || 'list' };
    case 'doctors':
      return { showLanding: false, mainTab: 'doctors', subTab: secondary || 'directory' };
    case 'appointments':
      return { showLanding: false, mainTab: 'appointments', subTab: secondary || 'today' };
    case 'emergency':
      return { showLanding: false, mainTab: 'emergency', subTab: secondary || 'dashboard' };
    case 'operations':
    case 'hospital-operations':
      return { showLanding: false, mainTab: 'operations', subTab: secondary || 'laboratory' };
    case 'laboratory':
      return { showLanding: false, mainTab: 'operations', subTab: 'laboratory' };
    case 'pharmacy':
      return { showLanding: false, mainTab: 'operations', subTab: 'pharmacy' };
    case 'beds':
      return { showLanding: false, mainTab: 'operations', subTab: 'beds' };
    case 'billing':
      return { showLanding: false, mainTab: 'operations', subTab: 'billing' };
    case 'analytics':
      return { showLanding: false, mainTab: 'analytics', subTab: secondary || 'analytics' };
    case 'reports':
      return { showLanding: false, mainTab: 'analytics', subTab: 'reports' };
    case 'threads':
      return { showLanding: false, mainTab: 'analytics', subTab: 'threads' };
    case 'settings':
      return { showLanding: false, mainTab: 'analytics', subTab: 'analytics' };
    default:
      // Any unknown route on initial startup defaults to the public Landing Page at root
      return { showLanding: true, mainTab: 'dashboard', subTab: 'overview' };
  }
};

const HospitalContext = createContext<HospitalContextType | undefined>(undefined);

export const HospitalProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  // Initialize route state based on current URL path
  const initialRoute = parseLocationRoute();

  // State Initialization
  const [currentUser, setCurrentUser] = useState<User>(INITIAL_USERS[0]);
  const [isLoggedIn, setIsLoggedIn] = useState<boolean>(true);
  const [activeTab, setActiveTab] = useState<NavigationTab>(initialRoute.mainTab);
  const [activeMainTab, setActiveMainTab] = useState<MainNavigationTab>(initialRoute.mainTab);
  const [activeSubTab, setActiveSubTab] = useState<string>(initialRoute.subTab);
  const [showLandingPage, setShowLandingPageState] = useState<boolean>(initialRoute.showLanding);
  const [showLoginModal, setShowLoginModal] = useState<boolean>(false);
  const [showJavaArchitectureModal, setShowJavaArchitectureModal] = useState<boolean>(false);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [toasts, setToasts] = useState<ToastMessage[]>([]);
  const [focusedSection, setFocusedSection] = useState<string | null>(null);

  // Synchronized setter for landing page state that keeps browser URL in sync
  const setShowLandingPage = (show: boolean) => {
    setShowLandingPageState(show);
    if (typeof window !== 'undefined') {
      if (show) {
        if (window.location.pathname !== '/') {
          window.history.pushState({}, '', '/');
        }
      } else {
        const targetTab = activeMainTab || 'dashboard';
        const targetPath = `/${targetTab === 'hospital-operations' ? 'operations' : targetTab}`;
        if (window.location.pathname === '/' || window.location.pathname === '' || window.location.pathname === '/index.html') {
          window.history.pushState({}, '', targetPath);
        }
      }
    }
  };

  // Listen to browser Back and Forward button events
  useEffect(() => {
    const handlePopState = () => {
      const route = parseLocationRoute();
      setShowLandingPageState(route.showLanding);
      setActiveMainTab(route.mainTab);
      setActiveTab(route.mainTab);
      if (route.subTab) {
        setActiveSubTab(route.subTab);
      }
    };

    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  // VTOP-style Drawer State (persistent, default compact: false)
  const [isSidebarExpanded, setIsSidebarExpandedState] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('medisphere_sidebar_expanded');
      return saved === 'true'; // false by default -> compact icon sidebar
    }
    return false;
  });

  const setIsSidebarExpanded = (val: boolean | ((prev: boolean) => boolean)) => {
    setIsSidebarExpandedState((prev) => {
      const next = typeof val === 'function' ? val(prev) : val;
      if (typeof window !== 'undefined') {
        localStorage.setItem('medisphere_sidebar_expanded', String(next));
      }
      return next;
    });
  };

  const toggleSidebar = () => {
    setIsSidebarExpanded((prev) => !prev);
  };

  // Entities
  const [patients, setPatients] = useState<Patient[]>(INITIAL_PATIENTS);
  const [doctors, setDoctors] = useState<Doctor[]>(INITIAL_DOCTORS);
  const [selectedDoctorForBooking, setSelectedDoctorForBooking] = useState<Doctor | null>(null);

  const initiateBookingForDoctor = (doctor: Doctor) => {
    setSelectedDoctorForBooking(doctor);
    setActiveNavigation('appointments', 'book');
  };
  const [appointments, setAppointments] = useState<Appointment[]>(INITIAL_APPOINTMENTS);
  const [emergencyCases, setEmergencyCases] = useState<EmergencyCase[]>(INITIAL_EMERGENCY_CASES);
  const [medicalRecords, setMedicalRecords] = useState<MedicalRecord[]>(INITIAL_MEDICAL_RECORDS);
  const [treatments, setTreatments] = useState<Treatment[]>(INITIAL_TREATMENTS);
  const [labTests, setLabTests] = useState<LabTest[]>(INITIAL_LAB_TESTS);
  const [medicines, setMedicines] = useState<Medicine[]>(INITIAL_MEDICINES);
  const [beds, setBeds] = useState<Bed[]>(INITIAL_BEDS);
  const [bills, setBills] = useState<Bill[]>(INITIAL_BILLS);
  const [threads, setThreads] = useState<SystemThreadInfo[]>(() =>
    INITIAL_SYSTEM_THREADS.map((t, idx) => {
      const defaultLatencies = [42, 65, 38, 72, 88, 52, 24];
      const defaultThresholds = [120, 140, 80, 150, 160, 110, 200];
      const lat = defaultLatencies[idx % defaultLatencies.length] ?? 45;
      const thresh = defaultThresholds[idx % defaultThresholds.length] ?? 130;
      return {
        ...t,
        name: t.threadName,
        taskName: t.currentTask,
        progress: [74, 82, 95, 45, 88, 60, 30][idx % 7] ?? 70,
        cpuUsage: t.cpuUsagePercent,
        latencyMs: lat,
        latencyThresholdMs: thresh,
        latencyStatus: (lat > thresh * 1.5 ? 'CRITICAL' : lat > thresh ? 'ELEVATED' : 'NORMAL') as 'CRITICAL' | 'ELEVATED' | 'NORMAL',
      };
    })
  );
  const [systemLogs, setSystemLogs] = useState<SystemLogEntry[]>([
    { id: 'LOG-101', timestamp: '10:42:15.890', type: 'INFO', message: 'HikariCP connection pool initialized (jdbc:mysql://db.medisphere.internal:3306/medisphere_prod)' },
    { id: 'LOG-102', timestamp: '10:42:16.120', type: 'INFO', message: 'ReentrantLock acquired on BedAllocationRegistry by Thread-4' },
    { id: 'LOG-103', timestamp: '10:42:16.450', type: 'WARN', message: 'Thread-6 blocked waiting for PharmacyInventoryLock monitor' },
    { id: 'LOG-104', timestamp: '10:42:17.002', type: 'INFO', message: 'PriorityQueue<EmergencyCase> re-heapified; Critical trauma patient triage score: 98' },
    { id: 'LOG-105', timestamp: '10:42:18.230', type: 'INFO', message: 'JDBC PreparedStatement batch executed: 14 audit rows inserted' },
  ]);

  // Toast Helper
  const addToast = (
    title: string,
    message: string,
    type: ToastMessage['type'] = 'info',
    javaException?: string
  ) => {
    const id = `toast-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
    const newToast: ToastMessage = {
      id,
      title,
      message,
      type,
      javaExceptionClass: javaException,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
    };
    setToasts((prev) => [newToast, ...prev.slice(0, 5)]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 5000);
  };

  const removeToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  // Auth Operations
  const login = (username: string, role: UserRole) => {
    const userMatch = INITIAL_USERS.find((u) => u.role === role) || {
      id: `USR-${Date.now()}`,
      username,
      name: username.charAt(0).toUpperCase() + username.slice(1),
      role,
      department: 'Clinical Operations',
    };
    setCurrentUser(userMatch);
    setIsLoggedIn(true);
    setShowLoginModal(false);
    setActiveNavigation('dashboard', 'overview');
    addToast(
      'Authentication Successful',
      `Welcome ${userMatch.name}. Role initialized as ${role} with Java Session Context.`,
      'success'
    );
  };

  const logout = () => {
    setIsLoggedIn(false);
    setShowLandingPage(true);
    addToast('Session Closed', 'User session safely terminated and resources synchronized.', 'info');
  };

  const setUserRole = (role: UserRole) => {
    const userMatch = INITIAL_USERS.find((u) => u.role === role) || {
      ...currentUser,
      role,
    };
    setCurrentUser(userMatch);
    addToast(
      'Role Context Updated',
      `Active role changed to [${role}]. Security credentials evaluated by Java SecurityManager.`,
      'info'
    );
  };

  // Patient Operations
  const addPatient = (patientData: Omit<Patient, 'id' | 'registeredDate'>): Patient => {
    const id = `PAT-${1000 + patients.length + 1}`;
    const newPatient: Patient = {
      ...patientData,
      id,
      registeredDate: new Date().toISOString().split('T')[0],
    };
    setPatients((prev) => [newPatient, ...prev]);
    addToast(
      'Patient Registered',
      `Patient ${newPatient.name} (${newPatient.id}) persisted via Java JDBC PreparedStatement.`,
      'success'
    );
    // Simulate thread activity
    spawnWorkerThread(`Persisting PatientRecord ${id}`);
    return newPatient;
  };

  const updatePatient = (id: string, updates: Partial<Patient>) => {
    const exists = patients.some((p) => p.id === id);
    if (!exists) {
      addToast(
        'Patient Not Found',
        `No patient record with identifier "${id}" exists in hospital repository.`,
        'error',
        'org.medisphere.exceptions.PatientNotFoundException'
      );
      return;
    }
    setPatients((prev) => prev.map((p) => (p.id === id ? { ...p, ...updates } : p)));
    addToast('Patient Record Updated', `Patient record [${id}] synchronized successfully.`, 'success');
  };

  const deletePatient = (id: string) => {
    const target = patients.find((p) => p.id === id);
    if (!target) {
      addToast(
        'Patient Not Found',
        `Cannot remove record for [${id}] - record does not exist.`,
        'error',
        'org.medisphere.exceptions.PatientNotFoundException'
      );
      return;
    }
    setPatients((prev) => prev.filter((p) => p.id !== id));
    addToast('Patient Discharged / Removed', `Patient record [${target.name}] purged from active records.`, 'info');
  };

  const getPatientById = (id: string) => patients.find((p) => p.id === id);

  // Doctor Operations
  const updateDoctorStatus = (id: string, status: Doctor['status']) => {
    const doc = doctors.find((d) => d.id === id);
    if (!doc) {
      addToast(
        'Doctor Not Found',
        `Specialist ID [${id}] could not be resolved.`,
        'error',
        'org.medisphere.exceptions.DoctorNotFoundException'
      );
      return;
    }
    setDoctors((prev) => prev.map((d) => (d.id === id ? { ...d, status } : d)));
    addToast('Doctor Schedule Updated', `${doc.name} status updated to: ${status}`, 'info');
  };

  const getDoctorById = (id: string) => doctors.find((d) => d.id === id);

  // Appointment Operations
  const bookAppointment = (data: {
    patientId: string;
    doctorId: string;
    appointmentType: AppointmentType;
    date: string;
    timeSlot: string;
    notes?: string;
  }): Appointment | null => {
    const patient = getPatientById(data.patientId);
    const doctor = getDoctorById(data.doctorId);

    if (!patient) {
      addToast(
        'Invalid Patient Data',
        'Please select a valid registered patient record.',
        'error',
        'org.medisphere.exceptions.InvalidPatientDataException'
      );
      return null;
    }

    if (!doctor) {
      addToast(
        'Doctor Unavailable',
        'Selected physician is currently unavailable or inactive.',
        'error',
        'org.medisphere.exceptions.DoctorNotFoundException'
      );
      return null;
    }

    // Double-booking check: same doctor, same date, same timeslot!
    const conflict = appointments.some(
      (a) =>
        a.doctorId === data.doctorId &&
        a.date === data.date &&
        a.timeSlot === data.timeSlot &&
        a.status !== 'Cancelled'
    );

    if (conflict) {
      addToast(
        'Appointment Unavailable',
        `Dr. ${doctor.name} already has a confirmed booking at ${data.timeSlot} on ${data.date}. Mutual exclusion lock triggered.`,
        'error',
        'org.medisphere.exceptions.AppointmentSlotBookedException'
      );
      return null;
    }

    const newAppointment: Appointment = {
      id: `APT-${900 + appointments.length + 1}`,
      patientId: patient.id,
      patientName: patient.name,
      doctorId: doctor.id,
      doctorName: doctor.name,
      specialization: doctor.specialization,
      appointmentType: data.appointmentType,
      date: data.date,
      timeSlot: data.timeSlot,
      status: 'Confirmed',
      fee: doctor.consultationFee,
      notes: data.notes || '',
    };

    setAppointments((prev) => [newAppointment, ...prev]);
    addToast(
      'Appointment Confirmed',
      `Booking verified for ${patient.name} with ${doctor.name} on ${data.date} at ${data.timeSlot}.`,
      'success'
    );
    return newAppointment;
  };

  const updateAppointmentStatus = (id: string, status: Appointment['status']) => {
    setAppointments((prev) => prev.map((a) => (a.id === id ? { ...a, status } : a)));
    addToast('Appointment Status Changed', `Appointment [${id}] status updated to ${status}.`, 'info');
  };

  const rescheduleAppointment = (id: string, date: string, timeSlot: string): boolean => {
    const apt = appointments.find((a) => a.id === id);
    if (!apt) return false;

    // Double booking conflict check
    const conflict = appointments.some(
      (a) =>
        a.id !== id &&
        a.doctorId === apt.doctorId &&
        a.date === date &&
        a.timeSlot === timeSlot &&
        a.status !== 'Cancelled'
    );

    if (conflict) {
      addToast(
        'Slot Unavailable',
        `Doctor already has a confirmed appointment at ${timeSlot} on ${date}.`,
        'error',
        'org.medisphere.exceptions.AppointmentSlotBookedException'
      );
      return false;
    }

    setAppointments((prev) =>
      prev.map((a) => (a.id === id ? { ...a, date, timeSlot, status: 'Scheduled' } : a))
    );
    addToast(
      'Appointment Rescheduled',
      `Appointment [${id}] for ${apt.patientName} moved to ${date} at ${timeSlot}.`,
      'success'
    );
    return true;
  };

  // Emergency Queue (PriorityQueue simulation)
  const addEmergencyCase = (data: Omit<EmergencyCase, 'id' | 'arrivalTime' | 'waitingMinutes' | 'status'>): EmergencyCase => {
    const id = `ER-CASE-${String(emergencyCases.length + 1).padStart(2, '0')}`;
    const now = new Date();
    const timeStr = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    const newCase: EmergencyCase = {
      ...data,
      id,
      arrivalTime: timeStr,
      waitingMinutes: 1,
      status: 'Triage',
    };

    // Priority sorting: Critical (1), High (2), Medium (3), Low (4)
    const priorityWeight: Record<EmergencyCase['priority'], number> = {
      Critical: 1,
      High: 2,
      Medium: 3,
      Low: 4,
    };

    setEmergencyCases((prev) => {
      const combined = [newCase, ...prev];
      return combined.sort((a, b) => priorityWeight[a.priority] - priorityWeight[b.priority]);
    });

    addToast(
      'Emergency Triage Ingested',
      `Patient ${newCase.patientName} inserted into Java PriorityQueue<EmergencyCase> with priority [${newCase.priority}].`,
      newCase.priority === 'Critical' ? 'error' : 'warning'
    );
    return newCase;
  };

  const updateEmergencyCase = (id: string, updates: Partial<EmergencyCase>) => {
    setEmergencyCases((prev) => prev.map((c) => (c.id === id ? { ...c, ...updates } : c)));
  };

  const assignEmergencyDoctorBed = (caseId: string, doctorId: string, bedId?: string) => {
    const doctor = getDoctorById(doctorId);
    if (!doctor) return;

    setEmergencyCases((prev) =>
      prev.map((c) =>
        c.id === caseId
          ? {
              ...c,
              assignedDoctorId: doctor.id,
              assignedDoctorName: doctor.name,
              assignedBedId: bedId || c.assignedBedId,
              status: 'Assigned',
            }
          : c
      )
    );

    if (bedId) {
      updateBedStatus(bedId, 'Occupied', caseId, emergencyCases.find((c) => c.id === caseId)?.patientName);
    }

    addToast(
      'Emergency Resource Assigned',
      `Assigned ${doctor.name} ${bedId ? `and bed ${bedId}` : ''} to emergency case.`,
      'success'
    );
  };

  const markEmergencyTreated = (caseId: string) => {
    const target = emergencyCases.find((c) => c.id === caseId);
    if (target && target.assignedBedId) {
      updateBedStatus(target.assignedBedId, 'Available');
    }
    setEmergencyCases((prev) => prev.map((c) => (c.id === caseId ? { ...c, status: 'Stabilized' } : c)));
    addToast(
      'Emergency Case Stabilized',
      `Emergency protocol completed for case ${caseId}. Patient transferred to post-acute care.`,
      'success'
    );
  };

  // Medical Records & Treatments
  const addMedicalRecord = (record: Omit<MedicalRecord, 'id' | 'date'>): MedicalRecord => {
    const id = `MED-REC-${String(medicalRecords.length + 1).padStart(3, '0')}`;
    const newRecord: MedicalRecord = {
      ...record,
      id,
      date: new Date().toISOString().split('T')[0],
    };
    setMedicalRecords((prev) => [newRecord, ...prev]);
    addToast('Medical Record Committed', `Consultation diagnostic record [${id}] signed and archived.`, 'success');
    return newRecord;
  };

  const addTreatment = (treatment: Omit<Treatment, 'id' | 'startDate'>): Treatment => {
    const id = `TRT-${300 + treatments.length + 1}`;
    const newTreatment: Treatment = {
      ...treatment,
      id,
      startDate: new Date().toISOString().split('T')[0],
    };
    setTreatments((prev) => [newTreatment, ...prev]);
    addToast('Treatment Protocol Initialized', `Care plan [${newTreatment.treatmentName}] assigned.`, 'success');
    return newTreatment;
  };

  // Laboratory Operations
  const requestLabTest = (data: {
    patientId: string;
    doctorId: string;
    testType: LabTestType;
    urgency: 'Routine' | 'Urgent' | 'Stat (Emergency)';
  }): LabTest => {
    const patient = getPatientById(data.patientId);
    const doctor = getDoctorById(data.doctorId);

    const id = `LAB-${700 + labTests.length + 1}`;
    const now = new Date();
    const dateStr = `${now.toISOString().split('T')[0]} ${now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;

    const newLabTest: LabTest = {
      id,
      patientId: patient ? patient.id : data.patientId,
      patientName: patient ? patient.name : 'Unknown Patient',
      doctorId: doctor ? doctor.id : data.doctorId,
      doctorName: doctor ? doctor.name : 'Physician On-Duty',
      testType: data.testType,
      requestDate: dateStr,
      status: 'Pending',
      urgency: data.urgency,
      technicianNotes: 'Queued in laboratory specimen buffer.',
    };

    setLabTests((prev) => [newLabTest, ...prev]);
    addToast(
      'Diagnostic Test Ordered',
      `${newLabTest.testType} requisition dispatched to Laboratory Processing Pool.`,
      'info'
    );
    return newLabTest;
  };

  const processLabTest = (id: string) => {
    setLabTests((prev) =>
      prev.map((t) => (t.id === id ? { ...t, status: 'Processing', technicianNotes: 'Active diagnostic assay running on analyzer.' } : t))
    );
    addToast('Analyzer Active', `Specimen ${id} loaded into auto-analyzer thread.`, 'info');
  };

  const completeLabTest = (id: string, results: LabTest['results'], notes?: string) => {
    const now = new Date();
    const dateStr = `${now.toISOString().split('T')[0]} ${now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;

    setLabTests((prev) =>
      prev.map((t) =>
        t.id === id
          ? {
              ...t,
              status: 'Completed',
              results: results || [
                { parameter: 'Assay Primary Marker', value: 'Nominal', normalRange: 'Standard Reference', status: 'Normal' },
              ],
              technicianNotes: notes || 'Laboratory certification validated by Clinical Pathologist.',
              completedDate: dateStr,
            }
          : t
      )
    );
    addToast('Lab Test Completed', `Results for test [${id}] validated and synced to patient records.`, 'success');
  };

  // Pharmacy Operations
  const addMedicine = (data: Omit<Medicine, 'id' | 'status'>): Medicine => {
    const id = `MED-${String(medicines.length + 1).padStart(2, '0')}`;
    let status: Medicine['status'] = 'Available';
    if (data.availableStock <= 0) status = 'Out of Stock';
    else if (data.availableStock <= data.minimumStock) status = 'Low Stock';

    const newMed: Medicine = {
      ...data,
      id,
      status,
    };

    setMedicines((prev) => [newMed, ...prev]);
    addToast('Medicine Added to Formulary', `Added ${newMed.name} to pharmacy inventory database.`, 'success');
    return newMed;
  };

  const updateMedicineStock = (id: string, newStock: number) => {
    setMedicines((prev) =>
      prev.map((m) => {
        if (m.id === id) {
          let status: Medicine['status'] = 'Available';
          if (newStock <= 0) status = 'Out of Stock';
          else if (newStock <= m.minimumStock) status = 'Low Stock';
          return { ...m, availableStock: newStock, status };
        }
        return m;
      })
    );
    addToast('Stock Level Restocked', `Inventory for [${id}] calibrated to ${newStock} units.`, 'info');
  };

  const dispenseMedicine = (id: string, quantity: number): boolean => {
    const med = medicines.find((m) => m.id === id);
    if (!med) {
      addToast(
        'Medicine Not Found',
        `No pharmacy item matching ID [${id}] found.`,
        'error',
        'org.medisphere.exceptions.MedicineNotFoundException'
      );
      return false;
    }

    if (med.availableStock < quantity) {
      addToast(
        'Insufficient Medicine Stock',
        `Requested ${quantity} units of ${med.name}, but only ${med.availableStock} units remain in central depot.`,
        'error',
        'org.medisphere.exceptions.InsufficientMedicineStockException'
      );
      return false;
    }

    const updatedStock = med.availableStock - quantity;
    let status: Medicine['status'] = 'Available';
    if (updatedStock <= 0) status = 'Out of Stock';
    else if (updatedStock <= med.minimumStock) status = 'Low Stock';

    setMedicines((prev) => prev.map((m) => (m.id === id ? { ...m, availableStock: updatedStock, status } : m)));
    addToast(
      'Prescription Dispensed',
      `Issued ${quantity} units of ${med.name}. Remaining inventory: ${updatedStock}.`,
      'success'
    );
    return true;
  };

  // Bed Operations
  const updateBedStatus = (id: string, status: Bed['status'], patientId?: string, patientName?: string) => {
    setBeds((prev) =>
      prev.map((b) =>
        b.id === id
          ? {
              ...b,
              status,
              occupiedByPatientId: status === 'Occupied' ? patientId : undefined,
              occupiedByPatientName: status === 'Occupied' ? patientName : undefined,
              admittedDate: status === 'Occupied' ? new Date().toISOString().split('T')[0] : undefined,
            }
          : b
      )
    );
    addToast('Bed Allocation Mutex Synchronized', `Bed [${id}] transition -> ${status}.`, 'info');
  };

  // Billing Operations
  const createBill = (data: {
    patientId: string;
    items: Bill['items'];
    discountPercent?: number;
    taxPercent?: number;
  }): Bill => {
    const patient = getPatientById(data.patientId);
    if (!patient) {
      addToast(
        'Patient Not Found',
        'Cannot generate invoice without a valid patient reference.',
        'error',
        'org.medisphere.exceptions.PatientNotFoundException'
      );
      throw new Error('Patient not found');
    }

    const subtotal = data.items.reduce((acc, item) => acc + item.totalPrice, 0);
    const discPct = data.discountPercent || 0;
    const discountAmount = Number(((subtotal * discPct) / 100).toFixed(2));
    const taxable = subtotal - discountAmount;
    const taxPct = data.taxPercent !== undefined ? data.taxPercent : 5;
    const taxAmount = Number(((taxable * taxPct) / 100).toFixed(2));
    const totalAmount = Number((taxable + taxAmount).toFixed(2));

    if (totalAmount <= 0) {
      addToast(
        'Invalid Billing Amount',
        'Total invoice calculation must be greater than zero.',
        'error',
        'org.medisphere.exceptions.InvalidBillingAmountException'
      );
    }

    const newBill: Bill = {
      id: `INV-2026-${800 + bills.length + 1}`,
      patientId: patient.id,
      patientName: patient.name,
      invoiceDate: new Date().toISOString().split('T')[0],
      items: data.items,
      subtotal,
      discountPercent: discPct,
      discountAmount,
      taxPercent: taxPct,
      taxAmount,
      totalAmount,
      paidAmount: 0,
      dueAmount: totalAmount,
      paymentStatus: 'Pending',
    };

    setBills((prev) => [newBill, ...prev]);
    addToast('Hospital Bill Generated', `Invoice ${newBill.id} totaling ₹${totalAmount.toLocaleString('en-IN')} drafted.`, 'success');
    return newBill;
  };

  const payBill = (billId: string, arg2: any, arg3?: any) => {
    let paymentMethod: any = 'UPI';
    let amountPaid = 0;
    if (typeof arg2 === 'number') {
      amountPaid = arg2;
      paymentMethod = arg3 || 'UPI';
    } else {
      paymentMethod = arg2 || 'UPI';
      amountPaid = typeof arg3 === 'number' ? arg3 : 0;
    }

    const bill = bills.find((b) => b.id === billId);
    if (!bill) {
      addToast('Bill Not Found', `Invoice ID [${billId}] does not exist.`, 'error');
      return;
    }

    const totalPaid = bill.paidAmount + (amountPaid || bill.dueAmount);
    const remaining = Math.max(0, bill.totalAmount - totalPaid);
    const newStatus: Bill['paymentStatus'] = remaining <= 0 ? 'Paid' : 'Partially Paid';

    setBills((prev) =>
      prev.map((b) =>
        b.id === billId
          ? {
              ...b,
              paidAmount: totalPaid,
              dueAmount: remaining,
              paymentStatus: newStatus,
              paymentMethod: paymentMethod || 'UPI / QR',
              transactionId: `TXN-${Date.now().toString(36).toUpperCase()}`,
            }
          : b
      )
    );

    // Trigger visual confetti when bill is fully paid!
    if (newStatus === 'Paid') {
      try {
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 },
          colors: ['#00f0ff', '#10b981', '#6366f1', '#38bdf8'],
        });
      } catch {
        // Confetti fallback
      }
    }

    addToast(
      'Payment Recorded',
      `Received ₹${amountPaid.toLocaleString('en-IN')} via ${paymentMethod}. Invoice balance: ₹${remaining.toLocaleString('en-IN')}`,
      'success'
    );
  };

  // Compatibility helpers
  const allocateBed = (bedId: string, patientId: string, patientName: string) => {
    updateBedStatus(bedId, 'Occupied', patientId, patientName);
  };

  const vacateBed = (bedId: string) => {
    updateBedStatus(bedId, 'Available');
  };

  const generateBill = (data: any) => {
    try {
      const items = (data.items || []).map((it: any, index: number) => ({
        id: `ITM-${index + 1}`,
        category: it.category || 'Other',
        description: it.description || 'Medical Service',
        quantity: it.quantity || 1,
        unitPrice: it.amount || it.unitPrice || 0,
        totalPrice: it.amount || it.totalPrice || 0,
      }));
      createBill({
        patientId: data.patientId,
        items,
        discountPercent: data.discountPercent,
        taxPercent: data.taxPercent,
      });
    } catch (e) {
      console.error(e);
    }
  };

  const addDoctor = (data: any) => {
    const newDoc: Doctor = {
      id: `DOC-${String(doctors.length + 1).padStart(3, '0')}`,
      name: data.name || 'Dr. Specialist',
      specialization: data.specialization || 'General Medicine',
      experienceYears: data.experienceYears || 5,
      availability: data.availability || '09:00 AM - 05:00 PM',
      consultationFee: data.consultationFee || 500,
      status: 'Available',
      rating: 4.8,
      phone: data.phone || '+91 98765 43210',
      email: data.email || 'doctor@medisphere.in',
      roomNumber: data.roomNumber || 'Room 101',
      ...data,
    };
    setDoctors((prev) => [...prev, newDoc]);
    addToast('Doctor Registered', `Dr. ${newDoc.name} added to roster.`, 'success');
  };

  const updateDoctor = (id: string, updates: any) => {
    setDoctors((prev) => prev.map((d) => (d.id === id ? { ...d, ...updates } : d)));
    addToast('Doctor Updated', `Record for Dr. ${id} updated.`, 'info');
  };

  const deleteDoctor = (id: string) => {
    setDoctors((prev) => prev.filter((d) => d.id !== id));
    addToast('Doctor Removed', `Doctor ID ${id} removed.`, 'info');
  };

  const updateEmergencyPriority = (id: string, priority: EmergencyPriority) => {
    setEmergencyCases((prev) => prev.map((c) => (c.id === id ? { ...c, priority } : c)));
  };

  const assignEmergencyDoctor = (caseId: string, doctorId: string, doctorName?: string) => {
    const doc = doctors.find((d) => d.id === doctorId);
    const dName = doctorName || doc?.name || 'Assigned Physician';
    setEmergencyCases((prev) =>
      prev.map((c) =>
        c.id === caseId ? { ...c, assignedDoctorId: doctorId, assignedDoctorName: dName, status: 'Assigned' } : c
      )
    );
  };

  const assignEmergencyBed = (caseId: string, bedId: string, bedNumber?: string) => {
    setEmergencyCases((prev) =>
      prev.map((c) =>
        c.id === caseId ? { ...c, assignedBedId: bedId, assignedBedNumber: bedNumber || bedId } : c
      )
    );
    updateBedStatus(bedId, 'Occupied', caseId);
  };

  const addLabTest = (data: any) => {
    const id = `LAB-${700 + labTests.length + 1}`;
    const newTest: LabTest = {
      id,
      patientId: data.patientId || '',
      patientName: data.patientName || 'Unknown Patient',
      doctorId: data.doctorId || '',
      doctorName: data.requestedByDoctor || 'Physician',
      testType: data.testType || 'CBC',
      requestDate: new Date().toISOString().split('T')[0],
      status: data.status || 'Pending',
      urgency: data.urgency || 'Routine',
      sampleType: data.sampleType,
      requestedByDoctor: data.requestedByDoctor,
      fee: data.fee,
      results: data.results || [],
    };
    setLabTests((prev) => [newTest, ...prev]);
    addToast('Lab Test Registered', `${newTest.testType} requisition added.`, 'info');
  };

  const updateLabTestStatus = (id: string, status: any) => {
    setLabTests((prev) => prev.map((t) => (t.id === id ? { ...t, status } : t)));
  };

  const simulateLabAnalysisThread = (testId: string) => {
    processLabTest(testId);
    setTimeout(() => {
      completeLabTest(testId, [
        { parameter: 'Assay Markers', value: 'Nominal', normalRange: 'Standard Reference', status: 'Normal' },
      ]);
    }, 1500);
  };

  const issueMedicine = (id: string, quantity: number, patientName?: string) => {
    return dispenseMedicine(id, quantity);
  };

  const updateTreatmentStatus = (id: string, status: any) => {
    setTreatments((prev) => prev.map((t) => (t.id === id ? { ...t, status } : t)));
  };

  // Java Multithreading Simulation
  const spawnWorkerThread = (taskName: string) => {
    const id = `TH-${String(threads.length + 1).padStart(2, '0')}`;
    const newThread: SystemThreadInfo = {
      id,
      threadName: `AsyncHospitalWorker-${threads.length + 1}`,
      javaClass: 'org.medisphere.threads.BackgroundHospitalWorker implements Runnable',
      state: 'RUNNING',
      priority: Math.floor(Math.random() * 5) + 5,
      currentTask: taskName,
      processedCount: 1,
      cpuUsagePercent: Number((Math.random() * 10 + 2).toFixed(1)),
      synchronizationLock: 'ConcurrentHashMapRegistry.class',
      isDaemon: false,
    };
    setThreads((prev) => [newThread, ...prev]);
  };

  const toggleThreadState = (id: string) => {
    setThreads((prev) =>
      prev.map((t) => {
        if (t.id === id) {
          const nextState: SystemThreadInfo['state'] =
            t.state === 'RUNNING' ? 'WAITING' : t.state === 'WAITING' ? 'RUNNABLE' : 'RUNNING';
          return { ...t, state: nextState };
        }
        return t;
      })
    );
  };

  const triggerGarbageCollection = () => {
    addToast(
      'JVM System.gc() Invoked',
      'System.gc() requested. Reclaiming unused memory segments and clearing dead object graphs.',
      'info'
    );
    setThreads((prev) =>
      prev.map((t) =>
        t.isDaemon && t.threadName.includes('Garbage')
          ? { ...t, state: 'RUNNING', processedCount: t.processedCount + 150 }
          : t
      )
    );
    setTimeout(() => {
      setThreads((prev) =>
        prev.map((t) =>
          t.isDaemon && t.threadName.includes('Garbage') ? { ...t, state: 'WAITING' } : t
        )
      );
    }, 1500);
  };

  const pauseThread = (id: string) => {
    setThreads((prev) =>
      prev.map((t) => (t.id === id ? { ...t, state: 'WAITING' as const } : t))
    );
    addToast('Thread Suspended', `Thread ${id} moved to WAITING state via wait() monitor lock.`, 'warning');
  };

  const resumeThread = (id: string) => {
    setThreads((prev) =>
      prev.map((t) => (t.id === id ? { ...t, state: 'RUNNABLE' as const } : t))
    );
    addToast('Thread Notified', `Thread ${id} signaled with notify() -> RUNNABLE state.`, 'success');
  };

  const triggerConcurrencyStressTest = () => {
    addToast('Concurrency Stress Test Started', 'Simulating 20 parallel ThreadPool worker tasks against ReentrantLock and PriorityQueue.', 'info');
    setThreads((prev) =>
      prev.map((t) => ({
        ...t,
        state: 'RUNNABLE' as const,
        cpuUsagePercent: Number((Math.random() * 25 + 15).toFixed(1)),
        cpuUsage: Number((Math.random() * 25 + 15).toFixed(1)),
        processedCount: t.processedCount + 85,
        progress: 92,
      }))
    );
    setSystemLogs((prev) => [
      {
        id: `LOG-${Date.now()}`,
        timestamp: new Date().toISOString().split('T')[1].slice(0, 12),
        type: 'WARN',
        message: 'High concurrency burst: 20 concurrent threads attempting lock acquisition on DoctorSlotLockManager',
      },
      ...prev,
    ]);
  };

  const simulateThreadLatencySpike = (threadId?: string, spikeLatencyMs?: number) => {
    setThreads((prev) => {
      const target = threadId
        ? prev.find((t) => t.id === threadId)
        : prev.find((t) => t.state === 'RUNNING' || t.state === 'RUNNABLE') || prev[0];

      if (!target) return prev;

      const threshold = target.latencyThresholdMs || 140;
      const newLatency = spikeLatencyMs || Math.floor(threshold * (1.55 + Math.random() * 0.75) + 10);
      const isCritical = newLatency >= threshold * 1.5;
      const status: 'NORMAL' | 'ELEVATED' | 'CRITICAL' = isCritical ? 'CRITICAL' : 'ELEVATED';

      addToast(
        `🚨 High Latency Alert: ${target.threadName}`,
        `Thread latency spiked to ${newLatency}ms (Safety SLA Threshold: ${threshold}ms). Potential lock contention on ${target.synchronizationLock || 'executor task queue'}.`,
        isCritical ? 'error' : 'warning',
        `org.medisphere.exceptions.ThreadExecutionTimeoutException: Thread latency ${newLatency}ms exceeded threshold ${threshold}ms`
      );

      setSystemLogs((prevLogs) => [
        {
          id: `LOG-${Date.now()}`,
          timestamp: new Date().toISOString().split('T')[1].slice(0, 12),
          type: 'WARN',
          message: `[SLA BREACH] Thread ${target.id} (${target.threadName}) execution latency breached safety limit (${newLatency}ms > ${threshold}ms). Lock: ${target.synchronizationLock || 'None'}`,
        },
        ...prevLogs,
      ]);

      return prev.map((t) => {
        if (t.id === target.id) {
          return {
            ...t,
            latencyMs: newLatency,
            latencyStatus: status,
            lastAlertTimestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
          };
        }
        return t;
      });
    });
  };

  const mitigateThreadLatency = (threadId?: string) => {
    setThreads((prev) =>
      prev.map((t) => {
        if (!threadId || t.id === threadId) {
          const baseline = Math.floor(25 + Math.random() * 30);
          return {
            ...t,
            latencyMs: baseline,
            latencyStatus: 'NORMAL' as const,
          };
        }
        return t;
      })
    );
    addToast(
      'Latency Mitigated & Restored',
      threadId
        ? `Thread ${threadId} task queues rebalanced; latency returned to nominal operating levels.`
        : 'All worker thread pools optimized; all latencies returned below safety thresholds.',
      'success'
    );
  };

  const updateThreadLatencyThreshold = (threadId: string, thresholdMs: number) => {
    setThreads((prev) =>
      prev.map((t) => {
        if (t.id === threadId) {
          const currentLat = t.latencyMs || 40;
          const status: 'NORMAL' | 'ELEVATED' | 'CRITICAL' =
            currentLat >= thresholdMs * 1.5 ? 'CRITICAL' : currentLat > thresholdMs ? 'ELEVATED' : 'NORMAL';
          return {
            ...t,
            latencyThresholdMs: thresholdMs,
            latencyStatus: status,
          };
        }
        return t;
      })
    );
    addToast('Threshold Configured', `Thread ${threadId} safety threshold set to ${thresholdMs}ms.`, 'info');
  };

  // Persistence, I/O, & Backup Serialization
  const exportDataAsJSON = () => {
    const stateSnapshot = {
      version: 'MediSphere-Java-OS-v2.1',
      timestamp: new Date().toISOString(),
      patients,
      doctors,
      appointments,
      emergencyCases,
      beds,
      medicines,
      bills,
      threads,
    };
    const blob = new Blob([JSON.stringify(stateSnapshot, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `medisphere_hospital_state_${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    addToast('Java I/O Serialized', 'Hospital state snapshot serialized via ObjectOutputStream simulator.', 'success');
  };

  const importDataFromJSON = (jsonString: string) => {
    try {
      const parsed = JSON.parse(jsonString);
      if (parsed.patients) setPatients(parsed.patients);
      if (parsed.doctors) setDoctors(parsed.doctors);
      if (parsed.appointments) setAppointments(parsed.appointments);
      if (parsed.emergencyCases) setEmergencyCases(parsed.emergencyCases);
      if (parsed.beds) setBeds(parsed.beds);
      if (parsed.medicines) setMedicines(parsed.medicines);
      if (parsed.bills) setBills(parsed.bills);
      addToast('State Deserialized', 'Hospital state restored successfully from JSON stream.', 'success');
    } catch (err) {
      addToast('Deserialization Error', 'Invalid backup file format.', 'error', 'java.io.StreamCorruptedException');
    }
  };

  const resetToDemoData = () => {
    setPatients(INITIAL_PATIENTS);
    setDoctors(INITIAL_DOCTORS);
    setAppointments(INITIAL_APPOINTMENTS);
    setEmergencyCases(INITIAL_EMERGENCY_CASES);
    setBeds(INITIAL_BEDS);
    setMedicines(INITIAL_MEDICINES);
    setBills(INITIAL_BILLS);
    setMedicalRecords(INITIAL_MEDICAL_RECORDS);
    setTreatments(INITIAL_TREATMENTS);
    setLabTests(INITIAL_LAB_TESTS);
    addToast('Reset Complete', 'Hospital database reset to initial seeded dataset.', 'info');
  };

  const switchUserRole = (role: UserRole) => {
    setUserRole(role);
  };

  const setActiveNavigation = (mainTab: MainNavigationTab, subTab?: string) => {
    const normalizedMainTab = mainTab === 'hospital-operations' ? 'operations' : mainTab;
    setActiveMainTab(normalizedMainTab);
    if (subTab) {
      setActiveSubTab(subTab);
    }
    setActiveTab(normalizedMainTab);
    setShowLandingPageState(false);

    if (typeof window !== 'undefined') {
      const targetPath = `/${normalizedMainTab}`;
      if (window.location.pathname !== targetPath) {
        window.history.pushState({}, '', targetPath);
      }
    }
  };

  // 3D Campus Navigation
  const navigateToSection = (sectionKey: string) => {
    setFocusedSection(sectionKey);
    const mapping: Record<string, { main: MainNavigationTab; sub: string }> = {
      emergency: { main: 'emergency', sub: 'dashboard' },
      icu: { main: 'operations', sub: 'beds' },
      laboratory: { main: 'operations', sub: 'laboratory' },
      pharmacy: { main: 'operations', sub: 'pharmacy' },
      opd: { main: 'appointments', sub: 'today' },
      ward: { main: 'operations', sub: 'beds' },
      doctors: { main: 'doctors', sub: 'directory' },
      reception: { main: 'patients', sub: 'list' },
      dashboard: { main: 'dashboard', sub: 'overview' },
      threads: { main: 'analytics', sub: 'threads' },
      beds: { main: 'operations', sub: 'beds' },
      patients: { main: 'patients', sub: 'list' },
      billing: { main: 'operations', sub: 'billing' },
      reports: { main: 'analytics', sub: 'reports' },
      analytics: { main: 'analytics', sub: 'analytics' },
    };
    if (mapping[sectionKey]) {
      const target = mapping[sectionKey];
      setActiveNavigation(target.main, target.sub);
      addToast(
        'Campus Telemetry Navigation',
        `Focusing ${sectionKey.toUpperCase()} wing operations view.`,
        'info'
      );
    }
  };

  // Dynamic KPI Stats calculation
  const kpiStats = useMemo(() => {
    const totalPatients = 1280 + patients.length;
    const availableDoctors = doctors.filter((d) => d.status === 'Available').length;
    const todayAppointments = appointments.length + 70; // Representing realistic full day tally
    const activeEmergency = emergencyCases.filter((c) => c.status !== 'Stabilized' && c.status !== 'Discharged').length;
    const availableBeds = beds.filter((b) => b.status === 'Available').length;
    const pendingBills = bills.filter((b) => b.paymentStatus !== 'Paid').length;
    const lowStockMedicines = medicines.filter((m) => m.status === 'Low Stock' || m.status === 'Out of Stock').length;

    // Calculate today's revenue in ₹ Lakhs
    const totalPaidToday = bills.reduce((acc, b) => acc + b.paidAmount, 0) + 160000;
    const inLakhs = (totalPaidToday / 100000).toFixed(2);

    return {
      totalPatients,
      availableDoctors,
      todayAppointments,
      emergencyCases: activeEmergency,
      availableBeds,
      pendingBills,
      lowStockMedicines,
      todayRevenueFormatted: `₹${inLakhs}L`,
    };
  }, [patients, doctors, appointments, emergencyCases, beds, bills, medicines]);

  // Periodic heartbeat for thread activity and waiting minutes simulation
  useEffect(() => {
    const interval = setInterval(() => {
      setEmergencyCases((prev) =>
        prev.map((c) =>
          c.status === 'Triage' || c.status === 'Assigned'
            ? { ...c, waitingMinutes: c.waitingMinutes + 1 }
            : c
        )
      );

      setThreads((prev) =>
        prev.map((t) => {
          if (t.state === 'RUNNING') {
            return {
              ...t,
              processedCount: t.processedCount + Math.floor(Math.random() * 3) + 1,
              cpuUsagePercent: Number((Math.random() * 12 + 4).toFixed(1)),
            };
          }
          return t;
        })
      );
    }, 15000);

    return () => clearInterval(interval);
  }, []);

  return (
    <HospitalContext.Provider
      value={{
        currentUser,
        setCurrentUser,
        setUserRole,
        isLoggedIn,
        login,
        logout,
        activeTab,
        setActiveTab,
        activeMainTab,
        activeSubTab,
        setActiveNavigation,
        showLandingPage,
        setShowLandingPage,
        showLoginModal,
        setShowLoginModal,
        showJavaArchitectureModal,
        setShowJavaArchitectureModal,
        isSidebarExpanded,
        setIsSidebarExpanded,
        toggleSidebar,
        searchQuery,
        setSearchQuery,
        toasts,
        addToast,
        removeToast,
        patients,
        addPatient,
        updatePatient,
        deletePatient,
        getPatientById,
        doctors,
        updateDoctorStatus,
        getDoctorById,
        addDoctor,
        updateDoctor,
        deleteDoctor,
        selectedDoctorForBooking,
        setSelectedDoctorForBooking,
        initiateBookingForDoctor,
        appointments,
        bookAppointment,
        updateAppointmentStatus,
        rescheduleAppointment,
        emergencyCases,
        addEmergencyCase,
        updateEmergencyCase,
        assignEmergencyDoctorBed,
        markEmergencyTreated,
        updateEmergencyPriority,
        assignEmergencyDoctor,
        assignEmergencyBed,
        medicalRecords,
        addMedicalRecord,
        treatments,
        addTreatment,
        updateTreatmentStatus,
        labTests,
        requestLabTest,
        processLabTest,
        completeLabTest,
        addLabTest,
        updateLabTestStatus,
        simulateLabAnalysisThread,
        medicines,
        addMedicine,
        updateMedicineStock,
        dispenseMedicine,
        issueMedicine,
        beds,
        updateBedStatus,
        allocateBed,
        vacateBed,
        bills,
        createBill,
        payBill,
        generateBill,
        threads,
        spawnWorkerThread,
        toggleThreadState,
        pauseThread,
        resumeThread,
        triggerGarbageCollection,
        triggerConcurrencyStressTest,
        simulateThreadLatencySpike,
        mitigateThreadLatency,
        updateThreadLatencyThreshold,
        systemLogs,
        exportDataAsJSON,
        importDataFromJSON,
        resetToDemoData,
        switchUserRole,
        kpiStats,
        focusedSection,
        setFocusedSection,
        navigateToSection,
      }}
    >
      {children}
    </HospitalContext.Provider>
  );
};

export const useHospital = () => {
  const context = useContext(HospitalContext);
  if (!context) {
    throw new Error('useHospital must be used within a HospitalProvider');
  }
  return context;
};
