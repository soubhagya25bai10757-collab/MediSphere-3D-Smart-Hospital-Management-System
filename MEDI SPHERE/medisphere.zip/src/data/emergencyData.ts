import { EmergencyPriority, EmergencyHistoryRecord } from '../types';

export interface EmergencyDoctor {
  id: string;
  name: string;
  specialist:
    | 'Emergency Medicine'
    | 'Cardiology'
    | 'Neurology'
    | 'Orthopedics'
    | 'General Surgery'
    | 'Anesthesiology'
    | 'Pulmonology'
    | 'Neurosurgery';
  qualification: string;
  experience: string;
  currentStatus: 'AVAILABLE' | 'ON CASE' | 'ON CALL' | 'OFF DUTY';
  emergencyCasesAssigned: number;
  department: string;
  currentAvailability: string;
  consultationStatus: string;
  phone: string;
  roomNumber: string;
}

export interface AmbulanceUnit {
  id: string;
  callSign: string;
  type: 'Advanced Life Support (ALS)' | 'Basic Life Support (BLS)' | 'Neonatal Emergency (MICU)';
  status: 'Available' | 'En Route' | 'On Scene' | 'Returning' | 'Maintenance';
  location: string;
  paramedicInCharge: string;
  driverName: string;
  eta: string;
  equipment: string[];
}

export interface EmergencyActivityEvent {
  id: string;
  time: string;
  type: 'CODE_RED' | 'CODE_BLUE' | 'TRIAGE_INGEST' | 'STABILIZED' | 'BED_ASSIGNED' | 'DISPATCH';
  title: string;
  description: string;
  actor: string;
  priority?: EmergencyPriority;
}

export const EMERGENCY_SPECIALISTS: EmergencyDoctor['specialist'][] = [
  'Emergency Medicine',
  'Cardiology',
  'Neurology',
  'Orthopedics',
  'General Surgery',
  'Anesthesiology',
  'Pulmonology',
  'Neurosurgery',
];

export const EMERGENCY_TYPES = [
  'Cardiac Emergency',
  'Road Traffic Accident',
  'Severe Injury',
  'Respiratory Distress',
  'Neurological Emergency',
  'Allergic Reaction',
  'Fracture',
  'Acute Abdominal Pain',
] as const;

export const INITIAL_EMERGENCY_DOCTORS: EmergencyDoctor[] = [
  {
    id: 'DOC-025',
    name: 'Dr. Raghavendra Pratap',
    specialist: 'Emergency Medicine',
    qualification: 'MBBS, MD (Emergency Medicine), FACEM, FCLS',
    experience: '14 Years',
    currentStatus: 'AVAILABLE',
    emergencyCasesAssigned: 1,
    department: 'Trauma & Emergency Resuscitation',
    currentAvailability: 'Immediate (Resus Bay 1-4)',
    consultationStatus: 'Fast-Track Dispatch Ready',
    phone: '+91 98112 30491',
    roomNumber: 'Trauma Bay Command - Room 101',
  },
  {
    id: 'DOC-002',
    name: 'Dr. Rajesh Sharma',
    specialist: 'Cardiology',
    qualification: 'MBBS, MD, DM (Cardiology), FACC, FSCAI',
    experience: '18 Years',
    currentStatus: 'ON CASE',
    emergencyCasesAssigned: 2,
    department: 'Interventional Cardiology & STEMI Care',
    currentAvailability: 'In Cath Lab Bay 2 (Finishing Angioplasty)',
    consultationStatus: 'Active Emergency Procedure',
    phone: '+91 98234 56702',
    roomNumber: 'Cath Lab Complex - Unit 2B',
  },
  {
    id: 'DOC-008',
    name: 'Dr. Shalini Kulkarni',
    specialist: 'Neurology',
    qualification: 'MBBS, MD (Medicine), DM (Neurology), FINR',
    experience: '12 Years',
    currentStatus: 'AVAILABLE',
    emergencyCasesAssigned: 0,
    department: 'Stroke & Acute Neurotrauma',
    currentAvailability: 'Immediate (Stroke Unit)',
    consultationStatus: 'Rapid IV-tPA Protocol Ready',
    phone: '+91 98451 90284',
    roomNumber: 'Neuro ICU Neuro-Bay 4',
  },
  {
    id: 'DOC-007',
    name: 'Dr. Harish Chandran',
    specialist: 'Orthopedics',
    qualification: 'MBBS, MS (Orthopedics), MCh (Trauma Surgery)',
    experience: '15 Years',
    currentStatus: 'ON CASE',
    emergencyCasesAssigned: 1,
    department: 'Orthopedic Trauma & Polytrauma Care',
    currentAvailability: 'Operating in Emergency OT 2',
    consultationStatus: 'Active Fracture Reduction',
    phone: '+91 98319 84501',
    roomNumber: 'Ortho Trauma Care - OT 2',
  },
  {
    id: 'DOC-026',
    name: 'Dr. Vikramaditya Sen',
    specialist: 'General Surgery',
    qualification: 'MBBS, MS (General Surgery), DNB, FACS (Trauma)',
    experience: '16 Years',
    currentStatus: 'ON CALL',
    emergencyCasesAssigned: 0,
    department: 'Emergency Acute Care Surgery',
    currentAvailability: 'Standby on Campus (4 min ETA)',
    consultationStatus: 'Available via Emergency Pager #941',
    phone: '+91 98220 18492',
    roomNumber: 'Surgical ICU Hub - Desk 3',
  },
  {
    id: 'DOC-022',
    name: 'Dr. Natasha Mehta',
    specialist: 'Anesthesiology',
    qualification: 'MBBS, MD (Anesthesiology), EDIC (Critical Care)',
    experience: '11 Years',
    currentStatus: 'AVAILABLE',
    emergencyCasesAssigned: 0,
    department: 'Emergency Resuscitation & Critical Care',
    currentAvailability: 'Immediate (Airway Rapid Response)',
    consultationStatus: 'Advanced Airway Cart Ready',
    phone: '+91 98110 47291',
    roomNumber: 'Resuscitation Control Room B',
  },
  {
    id: 'DOC-027',
    name: 'Dr. Arvind Swaminathan',
    specialist: 'Pulmonology',
    qualification: 'MBBS, MD (Pulmonary Medicine), FCCP, FAPSR',
    experience: '13 Years',
    currentStatus: 'AVAILABLE',
    emergencyCasesAssigned: 0,
    department: 'Respiratory Critical Care & ARDS Unit',
    currentAvailability: 'Immediate (Trauma Bay 3)',
    consultationStatus: 'NIV & Ventilator Optimization Ready',
    phone: '+91 98402 77190',
    roomNumber: 'Respiratory Step-down Bay 1',
  },
  {
    id: 'DOC-028',
    name: 'Dr. Pooja Nair',
    specialist: 'Neurosurgery',
    qualification: 'MBBS, MS (General Surgery), MCh (Neurosurgery)',
    experience: '17 Years',
    currentStatus: 'ON CALL',
    emergencyCasesAssigned: 0,
    department: 'Emergency Cranio-Spinal Trauma',
    currentAvailability: 'Campus Quarters (8 min ETA)',
    consultationStatus: 'Available via Emergency Pager #412',
    phone: '+91 98199 50123',
    roomNumber: 'Neurotrauma OR 1 Desk',
  },
];

export const INITIAL_AMBULANCES: AmbulanceUnit[] = [
  {
    id: 'AMB-01',
    callSign: 'LifeLine-Alpha',
    type: 'Advanced Life Support (ALS)',
    status: 'En Route',
    location: 'Western Ring Road (4.2 km away)',
    paramedicInCharge: 'Rohan Deshmukh, EMT-P',
    driverName: 'Mohan Lal',
    eta: '4 mins',
    equipment: ['Defibrillator (Zoll X)', 'Ventilator (Hamilton T1)', 'Syringe Pumps', 'Spinal Board'],
  },
  {
    id: 'AMB-02',
    callSign: 'LifeLine-Bravo',
    type: 'Advanced Life Support (ALS)',
    status: 'Available',
    location: 'Emergency Bay Dock 1',
    paramedicInCharge: 'Sunita Verma, EMT-P',
    driverName: 'Vikram Singh',
    eta: 'Immediate (On Standby)',
    equipment: ['Zoll Defibrillator', 'Oxygen Bank 4000L', 'Infusion Warmers', 'Trauma Pack Alpha'],
  },
  {
    id: 'AMB-03',
    callSign: 'LifeLine-Charlie',
    type: 'Advanced Life Support (ALS)',
    status: 'On Scene',
    location: 'NH-48 Flyover, Sector 14',
    paramedicInCharge: 'Aditya Kulkarni, EMT-CC',
    driverName: 'Harpreet Singh',
    eta: 'Triage in progress',
    equipment: ['Telemetry Transmitter', 'FAST Ultrasound', 'Suction Unit', 'Hemostatic Gauze'],
  },
  {
    id: 'AMB-04',
    callSign: 'LifeLine-Delta',
    type: 'Basic Life Support (BLS)',
    status: 'Available',
    location: 'Emergency Bay Dock 3',
    paramedicInCharge: 'Farhan Akhtar, EMT-B',
    driverName: 'Kishore Patil',
    eta: 'Immediate (On Standby)',
    equipment: ['Automated External Defibrillator', 'Portable O2', 'Splints & Cervical Collars'],
  },
  {
    id: 'AMB-05',
    callSign: 'LifeLine-Echo (MICU)',
    type: 'Neonatal Emergency (MICU)',
    status: 'Returning',
    location: 'City Suburb Link Road',
    paramedicInCharge: 'Dr. Nidhi Chopra (Pediatric EMT)',
    driverName: 'Devraj Rao',
    eta: '11 mins',
    equipment: ['Transport Incubator', 'Nitric Oxide Unit', 'Neonatal Resuscitator'],
  },
];

export const INITIAL_EMERGENCY_ACTIVITIES: EmergencyActivityEvent[] = [
  {
    id: 'ACT-01',
    time: '11:46 AM',
    type: 'CODE_RED',
    title: 'Code Red Trauma Inbound via LifeLine-Alpha',
    description: 'Polytrauma victim with pelvic fracture and unstable vitals inbound. ETA 4 mins. Resus Bay 1 mobilized.',
    actor: 'Paramedic Rohan Deshmukh',
    priority: 'Critical',
  },
  {
    id: 'ACT-02',
    time: '11:38 AM',
    type: 'STABILIZED',
    title: 'Suresh Raina Stabilized in Cath Lab Bay 2',
    description: 'Coronary stent deployed successfully by Dr. Rajesh Sharma. Post-op vitals: BP 130/84, HR 74, SpO2 98%.',
    actor: 'Dr. Rajesh Sharma',
    priority: 'Critical',
  },
  {
    id: 'ACT-03',
    time: '11:25 AM',
    type: 'BED_ASSIGNED',
    title: 'Trauma Bay ER-01 Allocated to Ananya Deshmukh',
    description: 'Blunt abdominal trauma protocol initiated with immediate FAST scan and blood crossmatch.',
    actor: 'Nurse Supervisor Reena Roy',
    priority: 'Critical',
  },
  {
    id: 'ACT-04',
    time: '11:12 AM',
    type: 'TRIAGE_INGEST',
    title: 'Nandini Joshi Enqueued - Acute Stroke Protocol',
    description: 'Sudden right-sided hemiparesis. Priority HIGH assigned. Non-contrast CT Brain requisitioned.',
    actor: 'Triage Officer Dr. R. Pratap',
    priority: 'High',
  },
  {
    id: 'ACT-05',
    time: '10:58 AM',
    type: 'DISPATCH',
    title: 'LifeLine-Charlie Dispatched to NH-48 Collision',
    description: '2-vehicle collision reported with entrapped driver. Extrication equipment activated.',
    actor: 'Emergency Central Dispatch',
    priority: 'Critical',
  },
];

export const INITIAL_EMERGENCY_HISTORY: EmergencyHistoryRecord[] = [
  {
    id: 'ER-HIST-101',
    patientName: 'Kavita Sundaram',
    patientId: 'PAT-1089',
    emergencyType: 'Cardiac Emergency',
    priority: 'Critical',
    arrivalTime: '07:15 AM',
    treatmentStart: '07:20 AM',
    treatmentEnd: '09:45 AM',
    assignedDoctor: 'Dr. Rajesh Sharma',
    doctorId: 'DOC-002',
    finalStatus: 'Stabilized',
    disposition: 'Admitted to CCU Ward 4A',
    date: 'Today',
    summary: 'Inferior wall STEMI with complete heart block. Emergency temporary pacing wire and DES to RCA placed.',
    dischargeVitals: {
      bloodPressure: '124/78',
      heartRate: 72,
      oxygenSaturation: 98,
      temperature: 98.4,
      respiratoryRate: 16,
    },
    interventions: [
      'Primary PCI with Drug-Eluting Stent',
      'Temporary Transvenous Cardiac Pacing',
      'Dual Antiplatelet Therapy (DAPT)',
      'Heparin Anticoagulation Bolus',
    ],
  },
  {
    id: 'ER-HIST-102',
    patientName: 'Arjun Bhardwaj',
    patientId: 'PAT-1072',
    emergencyType: 'Road Traffic Accident',
    priority: 'Critical',
    arrivalTime: '06:30 AM',
    treatmentStart: '06:36 AM',
    treatmentEnd: '09:10 AM',
    assignedDoctor: 'Dr. Raghavendra Pratap',
    doctorId: 'DOC-025',
    finalStatus: 'Admitted',
    disposition: 'Transferred to Trauma Surgery ICU',
    date: 'Today',
    summary: 'Motorcycle collision with grade III splenic laceration and hemoperitoneum. Managed conservatively after angiographic embolization.',
    dischargeVitals: {
      bloodPressure: '116/74',
      heartRate: 84,
      oxygenSaturation: 97,
      temperature: 98.2,
      respiratoryRate: 18,
    },
    interventions: [
      'FAST Ultrasound Bedside',
      'Splenic Artery Angioembolization',
      '4 Units Packed RBC Transfusion',
      'Pelvic Binder Application',
    ],
  },
  {
    id: 'ER-HIST-103',
    patientName: 'Meera Nambiar',
    patientId: 'PAT-1054',
    emergencyType: 'Allergic Reaction',
    priority: 'Critical',
    arrivalTime: '08:10 AM',
    treatmentStart: '08:12 AM',
    treatmentEnd: '09:30 AM',
    assignedDoctor: 'Dr. Natasha Mehta',
    doctorId: 'DOC-022',
    finalStatus: 'Stabilized',
    disposition: 'Discharged Home with Epipen & Meds',
    date: 'Today',
    summary: 'Severe anaphylactic shock triggered by shellfish ingestion. Stridor, generalized urticaria, and profound hypotension rapidly resolved post-IM adrenaline.',
    dischargeVitals: {
      bloodPressure: '118/76',
      heartRate: 78,
      oxygenSaturation: 99,
      temperature: 98.6,
      respiratoryRate: 15,
    },
    interventions: [
      'IM Adrenaline 0.5mg 1:1000',
      'IV Hydrocortisone 200mg & Chlorpheniramine',
      'High-Flow O2 via Non-Rebreather',
      'IV Normal Saline 2000ml Challenge',
    ],
  },
  {
    id: 'ER-HIST-104',
    patientName: 'Devendra Singhal',
    patientId: 'PAT-1038',
    emergencyType: 'Neurological Emergency',
    priority: 'High',
    arrivalTime: '05:45 AM',
    treatmentStart: '05:52 AM',
    treatmentEnd: '08:40 AM',
    assignedDoctor: 'Dr. Shalini Kulkarni',
    doctorId: 'DOC-008',
    finalStatus: 'Admitted',
    disposition: 'Admitted to Acute Stroke Care Unit',
    date: 'Today',
    summary: 'Acute ischemic stroke presenting with left hemiplegia at 90 mins onset. Successfully thrombolyzed with IV Tenecteplase. NIHSS score reduced from 14 to 3.',
    dischargeVitals: {
      bloodPressure: '138/82',
      heartRate: 76,
      oxygenSaturation: 98,
      temperature: 98.4,
      respiratoryRate: 16,
    },
    interventions: [
      'Emergency Non-Contrast Brain CT',
      'IV Tenecteplase (TNK-tPA) Bolus',
      'Neuro-Telemetry Continuous Monitoring',
      'Strict Blood Pressure Regulation',
    ],
  },
  {
    id: 'ER-HIST-105',
    patientName: 'Rajeshwari Iyer',
    patientId: 'PAT-1025',
    emergencyType: 'Respiratory Distress',
    priority: 'High',
    arrivalTime: '11:20 PM',
    treatmentStart: '11:26 PM',
    treatmentEnd: '03:15 AM',
    assignedDoctor: 'Dr. Arvind Swaminathan',
    doctorId: 'DOC-027',
    finalStatus: 'Discharged',
    disposition: 'Discharged with Inhaler Regimen',
    date: 'Yesterday',
    summary: 'Acute severe exacerbation of COPD with hypercapnic respiratory acidosis. Responded excellently to BiPAP non-invasive ventilation and nebulization.',
    dischargeVitals: {
      bloodPressure: '130/84',
      heartRate: 80,
      oxygenSaturation: 95,
      temperature: 98.2,
      respiratoryRate: 18,
    },
    interventions: [
      'BiPAP Non-Invasive Ventilation (IPAP 14 / EPAP 6)',
      'Salbutamol & Ipratropium Nebulization',
      'IV Methylprednisolone 40mg',
      'Serial Arterial Blood Gas (ABG) Monitoring',
    ],
  },
  {
    id: 'ER-HIST-106',
    patientName: 'Karan Malhotra',
    patientId: 'PAT-1019',
    emergencyType: 'Fracture',
    priority: 'Medium',
    arrivalTime: '08:40 PM',
    treatmentStart: '08:55 PM',
    treatmentEnd: '11:20 PM',
    assignedDoctor: 'Dr. Harish Chandran',
    doctorId: 'DOC-007',
    finalStatus: 'Discharged',
    disposition: 'Discharged with Above-Knee Cast & Follow-up',
    date: 'Yesterday',
    summary: 'Closed bimalleolar ankle fracture following football tackle. Closed reduction under hematoma block and backslab application performed.',
    dischargeVitals: {
      bloodPressure: '122/80',
      heartRate: 74,
      oxygenSaturation: 100,
      temperature: 98.6,
      respiratoryRate: 16,
    },
    interventions: [
      'Digital X-Ray Ankle Mortise View',
      'Closed Reduction under Hematoma Block',
      'Above-Knee Below-Knee POP Splinting',
      'Analgesia & Neurovascular Check Protocol',
    ],
  },
  {
    id: 'ER-HIST-107',
    patientName: 'Farida Bano',
    patientId: 'PAT-1061',
    emergencyType: 'Acute Abdominal Pain',
    priority: 'High',
    arrivalTime: '04:15 PM',
    treatmentStart: '04:25 PM',
    treatmentEnd: '08:00 PM',
    assignedDoctor: 'Dr. Vikramaditya Sen',
    doctorId: 'DOC-026',
    finalStatus: 'Transferred',
    disposition: 'Transferred to OT for Emergency Appendectomy',
    date: 'Yesterday',
    summary: 'Acute suppurative appendicitis with localized peritonitis. Ultrasound confirmed 9mm blind-ending non-compressible tubular structure.',
    dischargeVitals: {
      bloodPressure: '114/72',
      heartRate: 88,
      oxygenSaturation: 99,
      temperature: 100.4,
      respiratoryRate: 17,
    },
    interventions: [
      'Abdominal Ultrasound Sonography',
      'Pre-Op IV Ceftriaxone & Metronidazole',
      'NPO Status & Fluid Resuscitation',
      'Surgical Pre-Anesthesia Clearance',
    ],
  },
  {
    id: 'ER-HIST-108',
    patientName: 'Sunil Gopinath',
    patientId: 'PAT-1049',
    emergencyType: 'Severe Injury',
    priority: 'Critical',
    arrivalTime: '01:10 PM',
    treatmentStart: '01:15 PM',
    treatmentEnd: '04:45 PM',
    assignedDoctor: 'Dr. Pooja Nair',
    doctorId: 'DOC-028',
    finalStatus: 'Referred',
    disposition: 'Referred to National Neurosciences Center',
    date: 'Previous 7 Days',
    summary: 'Severe traumatic brain injury (GCS 6) with expanding epidural hematoma. Emergency burr hole decompression performed prior to tertiary transfer.',
    dischargeVitals: {
      bloodPressure: '142/90',
      heartRate: 68,
      oxygenSaturation: 99,
      temperature: 97.9,
      respiratoryRate: 14,
    },
    interventions: [
      'Endotracheal Rapid Sequence Intubation',
      'Stat CT Brain - Non Contrast',
      'Emergency Bedside Burr Hole Evacuation',
      'Mannitol 20% & Hypertonic Saline Infusion',
    ],
  },
];
