# MediSphere 3D - Java Core Module

> **Programming in Java — Six Core Concepts Implementation**  
> MediSphere 3D Smart Hospital Management System  
> Vit Bhopal University Syllabus Alignment

---

## 📋 Overview

This module provides a **genuine, compilable Java SE implementation** representing the clinical logic of the MediSphere 3D Smart Hospital Management System. It strictly demonstrates the six core concepts of object-oriented programming in Java without requiring external dependencies, frameworks, or database drivers.

---

## 🏛️ Six Core Java Concepts Implemented

| # | Java Concept | MediSphere Implementation | Key Files |
|---|---|---|---|
| **1** | **Classes & Objects** | Real hospital entities (`Patient`, `Doctor`, `Appointment`, `EmergencyCase`) instantiated using constructors with explicit hospital parameters. | `model/Patient.java`<br>`model/Doctor.java`<br>`model/Appointment.java`<br>`model/EmergencyCase.java` |
| **2** | **Encapsulation** | All entity fields are `private`. Access is granted strictly through public getters and setters with defensive validation (e.g., negative ages or fees rejected, empty names prevented). | `model/Patient.java`<br>`model/Doctor.java` |
| **3** | **Inheritance** | Superclass `Doctor` is extended by specialized child classes (`Cardiologist`, `Dentist`, `Neurologist`, `OrthopedicDoctor`) via `extends Doctor` and constructor chaining via `super(...)`. | `model/Doctor.java`<br>`model/Cardiologist.java`<br>`model/Dentist.java`<br>`model/Neurologist.java`<br>`model/OrthopedicDoctor.java` |
| **4** | **Polymorphism** | Superclass `Doctor` defines `consultationDetails()`. Each specialist child overrides this method. At runtime, calls to `doctorRef.consultationDetails()` dispatch dynamically to the concrete specialist implementation. | `model/Doctor.java`<br>Specialist subclasses |
| **5** | **Exception Handling** | Custom checked exception `AppointmentException` enforces clinical rules with `try`, `catch`, `throw`, and `throws` (rejects null appointments, unregistered patients, slot conflicts, unavailable doctors). | `exception/AppointmentException.java`<br>`service/HospitalService.java` |
| **6** | **Collections / ArrayList** | Dynamic in-memory registries using `ArrayList<Patient>`, `ArrayList<Doctor>`, `ArrayList<Appointment>`, and `ArrayList<EmergencyCase>` with search, filter, and display loops. | `service/HospitalService.java` |

---

## 📂 Package & File Structure

```
MediSphere-3D/
│
├── java/
│   ├── README.md
│   └── src/
│       ├── model/
│       │   ├── Patient.java               # Entity with encapsulation & validation
│       │   ├── Doctor.java                # Parent superclass with polymorphism base
│       │   ├── Cardiologist.java          # Subclass extending Doctor (Inheritance)
│       │   ├── Dentist.java               # Subclass extending Doctor (Inheritance)
│       │   ├── Neurologist.java           # Subclass extending Doctor (Inheritance)
│       │   ├── OrthopedicDoctor.java      # Subclass extending Doctor (Inheritance)
│       │   ├── Appointment.java           # Composite appointment linking Patient & Doctor
│       │   └── EmergencyCase.java         # Acute triage case entity
│       │
│       ├── exception/
│       │   └── AppointmentException.java  # Custom checked exception (Exception Handling)
│       │
│       ├── service/
│       │   └── HospitalService.java       # Central coordinator using ArrayList collections
│       │
│       └── Main.java                      # Complete executable test harness
│
└── (existing React/TypeScript frontend)
```

---

## 🚀 How to Compile and Run

### Prerequisites
- Any Java Development Kit (JDK 8, 11, 17, or 21+)
- Terminal / Command Prompt

### Step 1: Open Terminal in the `java` directory
```bash
cd java
```

### Step 2: Compile the Java Source Files
Create an output directory (e.g. `bin/`) and compile all packages:

**On Linux / macOS:**
```bash
mkdir -p bin
javac -d bin src/model/*.java src/exception/*.java src/service/*.java src/Main.java
```

**On Windows (Command Prompt / PowerShell):**
```cmd
mkdir bin
javac -d bin src\model\*.java src\exception\*.java src\service\*.java src\Main.java
```

Or compile with standard wildcard:
```bash
javac -d bin -sourcepath src src/Main.java
```

### Step 3: Run the Main Application
```bash
java -cp bin Main
```

---

## 🧪 Expected Terminal Output

When you run `Main`, the test runner outputs formatted sections validating each of the six concepts:

```text
================================================================================
=== MEDISPHERE 3D SMART HOSPITAL MANAGEMENT SYSTEM ===
Programming in Java - Six Core Concepts Verification
================================================================================

--- [STEP 1] Creating Patient Objects (Classes & Objects, Encapsulation) ---
  Created Patient: Eleanor Vance (Age: 34, Blood: A+)
  Created Patient: Marcus Sterling (Age: 58, Blood: O-)
  Created Patient: Sophia Chen (Age: 27, Blood: B+)
  Created Patient: Devon Miller (Age: 45, Blood: AB+)

  [Encapsulation Test] Testing defensive validation in setter (negative age):
  Attempting p1.setAge(-15) -> CAUGHT EXPECTED EXCEPTION: Patient age must be between 0 and 140. Given: -15

--- [STEP 2] Creating Specialist Doctor Objects (Inheritance: extends Doctor) ---
  Created Cardiologist (Dr. Aria Thorne)       [extends Doctor]
  Created Dentist (Dr. Julian Ross)            [extends Doctor]
  Created Neurologist (Dr. Samantha Reed)      [extends Doctor]
  Created OrthopedicDoctor (Dr. David Kalu)    [extends Doctor]

=== CONSULTATION DETAILS ===
Invoking consultationDetails() dynamically via Doctor parent references:
  [Cardiology Consultation] Dr. Aria Thorne conducts 12-lead ECG analysis...
  [Dental Consultation] Dr. Julian Ross performs oral cavity inspection...
  [Neurology Consultation] Dr. Samantha Reed conducts cranial nerve evaluation...
  [Orthopedic Consultation] Dr. David Kalu conducts musculoskeletal biomechanical gait...

--- [STEP 4] Adding Entities to ArrayList Collections ---
  [Registry] Patient registered successfully: Eleanor Vance (ID: 101)
  [Registry] Patient registered successfully: Marcus Sterling (ID: 102)
  [Registry] Patient registered successfully: Sophia Chen (ID: 103)
  [Registry] Patient registered successfully: Devon Miller (ID: 104)
  [Staffing] Doctor enlisted: Dr. Aria Thorne (Cardiology)
  [Staffing] Doctor enlisted: Dr. Julian Ross (Dentistry)
  [Staffing] Doctor enlisted: Dr. Samantha Reed (Neurology)
  [Staffing] Doctor enlisted: Dr. David Kalu (Orthopedics)
  [ArrayList Search] Query Patient ID 102: Marcus Sterling
  [ArrayList Search] Query Doctor 'Aria Thorne': Cardiology

=== APPOINTMENT MANAGEMENT ===
Booking appointment for Eleanor Vance with Dr. Aria Thorne...
  [Scheduling] Appointment #501 successfully booked for Eleanor Vance with Dr. Aria Thorne on 2026-09-15 at 10:00 AM
Booking appointment for Marcus Sterling with Dr. Samantha Reed...
  [Scheduling] Appointment #502 successfully booked for Marcus Sterling with Dr. Samantha Reed on 2026-09-15 at 11:30 AM

=== EXCEPTION HANDLING ===
Testing hospital business validation rules using try / catch / throw / throws:

  Test 6A: Attempting double-booking on Dr. Aria Thorne on 2026-09-15 at 10:00 AM...
  ✓ CAUGHT EXPECTED AppointmentException: [SLOT_UNAVAILABLE] Consultation slot conflict: Dr. Aria Thorne is already scheduled on 2026-09-15 at 10:00 AM (#501).

  Test 6B: Attempting booking for unregistered patient (ID: 999)...
  ✓ CAUGHT EXPECTED AppointmentException: [PATIENT_UNREGISTERED] Patient ID 999 is not registered in the MediSphere EHR census.

  Test 6C: Attempting booking with null appointment payload...
  ✓ CAUGHT EXPECTED AppointmentException: [APPT_NULL] Appointment payload cannot be null.

=== PATIENT DIRECTORY (4 Records) ===
  1. Patient [ID=101, Name='Eleanor Vance', Age=34, BloodGroup='A+', Phone='+1-555-0192']
  2. Patient [ID=102, Name='Marcus Sterling', Age=58, BloodGroup='O-', Phone='+1-555-0144']
  3. Patient [ID=103, Name='Sophia Chen', Age=27, BloodGroup='B+', Phone='+1-555-0188']
  4. Patient [ID=104, Name='Devon Miller', Age=45, BloodGroup='AB+', Phone='+1-555-0177']

=== DOCTOR DIRECTORY (4 Specialists) ===
  1. Cardiologist [Doctor [ID=201, Name='Aria Thorne', Specialization='Cardiology', Experience=14 yrs, Fee=$250.00], ECG-Certified=true, Surgeries=310]
  2. Dentist [Doctor [ID=202, Name='Julian Ross', Specialization='Dentistry', Experience=9 yrs, Fee=$140.00], SubSpecialty='Maxillofacial Prosthodontics', SurgeryPermit=true]
  3. Neurologist [Doctor [ID=203, Name='Samantha Reed', Specialization='Neurology', Experience=18 yrs, Fee=$300.00], EEG-Qualified=true, SubField='Neurovascular Stroke Intervention']
  4. OrthopedicDoctor [Doctor [ID=204, Name='David Kalu', Specialization='Orthopedics', Experience=12 yrs, Fee=$220.00], ArthroplastyCertified=true, PrimaryFocus='Joint Replacement & Arthroplasty']

=== APPOINTMENT DIRECTORY (2 Bookings) ===
  1. Appointment #501 [2026-09-15 | 10:00 AM] Patient: 'Eleanor Vance' (ID:101) -> Doctor: Dr. 'Aria Thorne' (Cardiology) | Status: CONFIRMED | Type: Cardiology Screening
  2. Appointment #502 [2026-09-15 | 11:30 AM] Patient: 'Marcus Sterling' (ID:102) -> Doctor: Dr. 'Samantha Reed' (Neurology) | Status: CONFIRMED | Type: Neuro-Vascular Consult

================================================================================
  ALL SIX JAVA CONCEPTS VERIFIED SUCCESSFULLY IN MEDISPHERE 3D
  1. Classes and Objects  2. Encapsulation      3. Inheritance
  4. Polymorphism         5. Exception Handling 6. Collections / ArrayList
================================================================================
```

---

## 🔗 Connection to MediSphere 3D Web Application

The React/TypeScript frontend and the Java source files live together in the repository:
- **Web App**: Provides the interactive 3D futuristic glassmorphism hospital operations, appointment flows, bed assignments, and telemetry.
- **Java Module**: Provides the standalone, certified OOP clinical service kernel.
- **In-App Java Implementation & Architecture View**: Inside the **Analytics & System Intelligence** section, a dedicated glassmorphism panel documents these six concepts and displays the architecture diagram, with interactive source code inspector and compiler command guides.
