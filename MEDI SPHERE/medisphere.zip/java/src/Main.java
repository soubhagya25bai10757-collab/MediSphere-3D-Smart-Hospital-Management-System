import model.Patient;
import model.Doctor;
import model.Cardiologist;
import model.Dentist;
import model.Neurologist;
import model.OrthopedicDoctor;
import model.Appointment;
import model.EmergencyCase;
import exception.AppointmentException;
import service.HospitalService;

/**
 * Main Demonstration Driver for MediSphere 3D Smart Hospital
 * 
 * Genuinely demonstrates ONLY the six required Java OOP concepts:
 * 1. Classes and Objects
 * 2. Encapsulation
 * 3. Inheritance
 * 4. Polymorphism
 * 5. Exception Handling
 * 6. Collections / ArrayList
 * 
 * Execution Steps:
 * 1. Create patients.
 * 2. Create different specialist doctors.
 * 3. Demonstrate polymorphism.
 * 4. Add patients/doctors to ArrayLists.
 * 5. Create and book an appointment.
 * 6. Demonstrate exception handling.
 * 7. Display patients.
 * 8. Display doctors.
 * 9. Display appointments.
 */
public class Main {
    public static void main(String[] args) {
        System.out.println("================================================================================");
        System.out.println("=== MEDISPHERE 3D SMART HOSPITAL MANAGEMENT SYSTEM ===");
        System.out.println("Programming in Java - Six Core Concepts Verification");
        System.out.println("================================================================================\n");

        HospitalService hospital = new HospitalService("MediSphere 3D Central Hospital Command");

        // ====================================================================
        // STEP 1: CREATE PATIENTS (Classes & Objects, Encapsulation)
        // ====================================================================
        System.out.println("--- [STEP 1] Creating Patient Objects (Classes & Objects, Encapsulation) ---");
        Patient p1 = new Patient(101, "Eleanor Vance", 34, "A+", "+1-555-0192");
        Patient p2 = new Patient(102, "Marcus Sterling", 58, "O-", "+1-555-0144");
        Patient p3 = new Patient(103, "Sophia Chen", 27, "B+", "+1-555-0188");
        Patient p4 = new Patient(104, "Devon Miller", 45, "AB+", "+1-555-0177");

        System.out.println("  Created Patient: " + p1.getName() + " (Age: " + p1.getAge() + ", Blood: " + p1.getBloodGroup() + ")");
        System.out.println("  Created Patient: " + p2.getName() + " (Age: " + p2.getAge() + ", Blood: " + p2.getBloodGroup() + ")");
        System.out.println("  Created Patient: " + p3.getName() + " (Age: " + p3.getAge() + ", Blood: " + p3.getBloodGroup() + ")");
        System.out.println("  Created Patient: " + p4.getName() + " (Age: " + p4.getAge() + ", Blood: " + p4.getBloodGroup() + ")");

        // Encapsulation validation test: private fields protected with defensive setters
        System.out.println("\n  [Encapsulation Test] Testing defensive validation in setter (negative age):");
        try {
            System.out.print("  Attempting p1.setAge(-15) -> ");
            p1.setAge(-15);
        } catch (IllegalArgumentException ex) {
            System.out.println("CAUGHT EXPECTED EXCEPTION: " + ex.getMessage());
        }

        // ====================================================================
        // STEP 2: CREATE SPECIALIST DOCTORS (Inheritance)
        // ====================================================================
        System.out.println("\n--- [STEP 2] Creating Specialist Doctor Objects (Inheritance: extends Doctor) ---");
        Doctor doctor1 = new Cardiologist(201, "Aria Thorne", 14, 250.00, true, 310);
        Doctor doctor2 = new Dentist(202, "Julian Ross", 9, 140.00, "Maxillofacial Prosthodontics", true);
        Doctor doctor3 = new Neurologist(203, "Samantha Reed", 18, 300.00, true, "Neurovascular Stroke Intervention");
        Doctor doctor4 = new OrthopedicDoctor(204, "David Kalu", 12, 220.00, true, "Joint Replacement & Arthroplasty");

        System.out.println("  Created Cardiologist (Dr. Aria Thorne)       [extends Doctor]");
        System.out.println("  Created Dentist (Dr. Julian Ross)            [extends Doctor]");
        System.out.println("  Created Neurologist (Dr. Samantha Reed)      [extends Doctor]");
        System.out.println("  Created OrthopedicDoctor (Dr. David Kalu)    [extends Doctor]");

        // ====================================================================
        // STEP 3: DEMONSTRATE POLYMORPHISM (Runtime Dynamic Dispatch)
        // ====================================================================
        System.out.println("\n=== CONSULTATION DETAILS ===");
        System.out.println("Invoking consultationDetails() dynamically via Doctor parent references:");
        System.out.println("  " + doctor1.consultationDetails());
        System.out.println("  " + doctor2.consultationDetails());
        System.out.println("  " + doctor3.consultationDetails());
        System.out.println("  " + doctor4.consultationDetails());

        // ====================================================================
        // STEP 4: ADD PATIENTS & DOCTORS TO ARRAYLISTS (Collections / ArrayList)
        // ====================================================================
        System.out.println("\n--- [STEP 4] Adding Entities to ArrayList Collections ---");
        hospital.addPatient(p1);
        hospital.addPatient(p2);
        hospital.addPatient(p3);
        hospital.addPatient(p4);

        hospital.addDoctor(doctor1);
        hospital.addDoctor(doctor2);
        hospital.addDoctor(doctor3);
        hospital.addDoctor(doctor4);

        // Search in ArrayList demonstration
        Patient foundP = hospital.searchPatient(102);
        System.out.println("  [ArrayList Search] Query Patient ID 102: " + (foundP != null ? foundP.getName() : "Not found"));
        Doctor foundD = hospital.searchDoctorByName("Aria Thorne");
        System.out.println("  [ArrayList Search] Query Doctor 'Aria Thorne': " + (foundD != null ? foundD.getSpecialization() : "Not found"));

        // ====================================================================
        // STEP 5: CREATE AND BOOK AN APPOINTMENT (Classes, Objects, Composition)
        // ====================================================================
        System.out.println("\n=== APPOINTMENT MANAGEMENT ===");
        try {
            System.out.println("Booking appointment for Eleanor Vance with Dr. Aria Thorne...");
            Appointment a1 = new Appointment(501, p1, doctor1, "2026-09-15", "10:00 AM", "Cardiology Screening");
            hospital.bookAppointment(a1);

            System.out.println("\nBooking appointment for Marcus Sterling with Dr. Samantha Reed...");
            Appointment a2 = new Appointment(502, p2, doctor3, "2026-09-15", "11:30 AM", "Neuro-Vascular Consult");
            hospital.bookAppointment(a2);
        } catch (AppointmentException ex) {
            System.out.println("  Unexpected AppointmentException: " + ex.getMessage());
        }

        // ====================================================================
        // STEP 6: DEMONSTRATE EXCEPTION HANDLING (Custom AppointmentException)
        // ====================================================================
        System.out.println("\n=== EXCEPTION HANDLING ===");
        System.out.println("Testing hospital business validation rules using try / catch / throw / throws:\n");

        // Test 6A: Slot Conflict Exception (Double Booking)
        try {
            System.out.println("  Test 6A: Attempting double-booking on Dr. Aria Thorne on 2026-09-15 at 10:00 AM...");
            Appointment conflictingAppt = new Appointment(503, p3, doctor1, "2026-09-15", "10:00 AM", "Cardiology Checkup");
            hospital.bookAppointment(conflictingAppt);
            System.out.println("  FAILED: Double booking was allowed!");
        } catch (AppointmentException ex) {
            System.out.println("  ✓ CAUGHT EXPECTED AppointmentException: " + ex.getMessage());
        }

        // Test 6B: Unregistered Patient Exception
        try {
            System.out.println("\n  Test 6B: Attempting booking for unregistered patient (ID: 999)...");
            Patient unregisteredPatient = new Patient(999, "Phantom Guest", 42, "O+", "+1-555-0999");
            Appointment ghostAppt = new Appointment(504, unregisteredPatient, doctor2, "2026-09-16", "02:00 PM", "Dental Scaling");
            hospital.bookAppointment(ghostAppt);
            System.out.println("  FAILED: Unregistered patient booking was allowed!");
        } catch (AppointmentException ex) {
            System.out.println("  ✓ CAUGHT EXPECTED AppointmentException: " + ex.getMessage());
        }

        // Test 6C: Null Appointment Payload Exception
        try {
            System.out.println("\n  Test 6C: Attempting booking with null appointment payload...");
            hospital.bookAppointment(null);
            System.out.println("  FAILED: Null appointment was allowed!");
        } catch (AppointmentException ex) {
            System.out.println("  ✓ CAUGHT EXPECTED AppointmentException: " + ex.getMessage());
        }

        // ====================================================================
        // STEP 7: DISPLAY PATIENTS
        // ====================================================================
        hospital.showPatients();

        // ====================================================================
        // STEP 8: DISPLAY DOCTORS
        // ====================================================================
        hospital.showDoctors();

        // ====================================================================
        // STEP 9: DISPLAY APPOINTMENTS
        // ====================================================================
        hospital.showAppointments();

        System.out.println("\n================================================================================");
        System.out.println("  ALL SIX JAVA CONCEPTS VERIFIED SUCCESSFULLY IN MEDISPHERE 3D");
        System.out.println("  1. Classes and Objects  2. Encapsulation      3. Inheritance");
        System.out.println("  4. Polymorphism         5. Exception Handling 6. Collections / ArrayList");
        System.out.println("================================================================================\n");
    }
}

