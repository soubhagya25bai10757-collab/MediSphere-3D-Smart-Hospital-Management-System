package service;

import model.Patient;
import model.Doctor;
import model.Appointment;
import model.EmergencyCase;
import exception.AppointmentException;

import java.util.ArrayList;

/**
 * HospitalService Implementation
 * Demonstrates:
 * 1. Classes and Objects: Central service manager coordinating hospital entities
 * 2. Encapsulation: Private collection state with public accessor workflows
 * 4. Polymorphism: Polymorphic execution of consultationDetails() across specialist doctors
 * 5. Exception Handling: Meaningful validation with throw / throws AppointmentException
 * 6. Collections / ArrayList: Managing dynamic patient, doctor, and appointment registries
 */
public class HospitalService {
    private String hospitalName;
    private ArrayList<Patient> patients;
    private ArrayList<Doctor> doctors;
    private ArrayList<Appointment> appointments;
    private ArrayList<EmergencyCase> emergencyCases;

    // Constructor initializing collections
    public HospitalService(String hospitalName) {
        this.hospitalName = (hospitalName != null) ? hospitalName : "MediSphere 3D Smart Hospital";
        this.patients = new ArrayList<>();
        this.doctors = new ArrayList<>();
        this.appointments = new ArrayList<>();
        this.emergencyCases = new ArrayList<>();
    }

    public String getHospitalName() {
        return hospitalName;
    }

    // ==========================================================
    // 6. COLLECTIONS / ARRAYLIST: PATIENT OPERATIONS
    // ==========================================================

    /**
     * Adds a new patient into the hospital registry.
     */
    public void addPatient(Patient patient) {
        if (patient == null) {
            throw new IllegalArgumentException("Cannot register null patient.");
        }
        // Check for duplicate ID using a loop
        for (Patient p : patients) {
            if (p.getPatientId() == patient.getPatientId()) {
                throw new IllegalArgumentException("Patient with ID " + patient.getPatientId() + " already exists.");
            }
        }
        patients.add(patient);
        System.out.println("  [Registry] Patient registered successfully: " + patient.getName() + " (ID: " + patient.getPatientId() + ")");
    }

    /**
     * Search patient by ID using iteration.
     */
    public Patient searchPatient(int patientId) {
        for (int i = 0; i < patients.size(); i++) {
            Patient p = patients.get(i);
            if (p.getPatientId() == patientId) {
                return p;
            }
        }
        return null;
    }

    /**
     * Search patient by Name (case-insensitive substring match).
     */
    public Patient searchPatientByName(String name) {
        if (name == null) return null;
        for (Patient p : patients) {
            if (p.getName().equalsIgnoreCase(name.trim())) {
                return p;
            }
        }
        return null;
    }

    /**
     * Displays all registered patients using an enhanced for-loop.
     */
    public void showPatients() {
        System.out.println("\n=== PATIENT DIRECTORY (" + patients.size() + " Records) ===");
        if (patients.isEmpty()) {
            System.out.println("  No patients currently registered.");
            return;
        }
        for (int i = 0; i < patients.size(); i++) {
            System.out.println("  " + (i + 1) + ". " + patients.get(i).toString());
        }
    }

    // ==========================================================
    // 6. COLLECTIONS / ARRAYLIST: DOCTOR OPERATIONS
    // ==========================================================

    /**
     * Adds a doctor into the medical specialist directory.
     */
    public void addDoctor(Doctor doctor) {
        if (doctor == null) {
            throw new IllegalArgumentException("Cannot register null doctor.");
        }
        for (Doctor d : doctors) {
            if (d.getDoctorId() == doctor.getDoctorId()) {
                throw new IllegalArgumentException("Doctor with ID " + doctor.getDoctorId() + " already registered.");
            }
        }
        doctors.add(doctor);
        System.out.println("  [Staffing] Doctor enlisted: Dr. " + doctor.getName() + " (" + doctor.getSpecialization() + ")");
    }

    /**
     * Search doctor by ID using iteration.
     */
    public Doctor searchDoctor(int doctorId) {
        for (Doctor d : doctors) {
            if (d.getDoctorId() == doctorId) {
                return d;
            }
        }
        return null;
    }

    /**
     * Search doctor by Name.
     */
    public Doctor searchDoctorByName(String name) {
        if (name == null) return null;
        for (Doctor d : doctors) {
            if (d.getName().equalsIgnoreCase(name.trim())) {
                return d;
            }
        }
        return null;
    }

    /**
     * Displays all registered doctors using an enhanced for-loop.
     */
    public void showDoctors() {
        System.out.println("\n=== DOCTOR DIRECTORY (" + doctors.size() + " Specialists) ===");
        if (doctors.isEmpty()) {
            System.out.println("  No doctors currently on roster.");
            return;
        }
        for (int i = 0; i < doctors.size(); i++) {
            System.out.println("  " + (i + 1) + ". " + doctors.get(i).toString());
        }
    }

    // ==========================================================
    // 5. EXCEPTION HANDLING: APPOINTMENT BOOKING WITH VALIDATION
    // ==========================================================

    /**
     * Books an appointment with rigorous clinical validation.
     * Demonstrates checked exception throwing: throws AppointmentException
     */
    public void bookAppointment(Appointment appointment) throws AppointmentException {
        // Validation 1: Null check
        if (appointment == null) {
            throw new AppointmentException("APPT_NULL", "Appointment payload cannot be null.");
        }

        // Validation 2: Patient validation
        if (appointment.getPatient() == null) {
            throw new AppointmentException("PATIENT_MISSING", "Appointment rejected: Patient information cannot be null.");
        }

        Patient registeredPatient = searchPatient(appointment.getPatient().getPatientId());
        if (registeredPatient == null) {
            throw new AppointmentException("PATIENT_UNREGISTERED",
                "Patient ID " + appointment.getPatient().getPatientId() + " is not registered in the MediSphere EHR census.");
        }

        // Validation 3: Doctor validation & availability
        if (appointment.getDoctor() == null) {
            throw new AppointmentException("DOCTOR_UNASSIGNED", "Appointment rejected: Specialist doctor must be assigned.");
        }

        Doctor assignedDoc = searchDoctor(appointment.getDoctor().getDoctorId());
        if (assignedDoc == null) {
            throw new AppointmentException("DOCTOR_UNAVAILABLE",
                "Doctor ID " + appointment.getDoctor().getDoctorId() + " is not currently active on the hospital medical roster.");
        }

        // Validation 4: Date & time format validation
        if (appointment.getDate() == null || appointment.getDate().trim().isEmpty()) {
            throw new AppointmentException("INVALID_DATE", "Appointment scheduling requires a valid non-empty calendar date.");
        }
        if (appointment.getTime() == null || appointment.getTime().trim().isEmpty()) {
            throw new AppointmentException("INVALID_TIME", "Appointment scheduling requires a valid time slot.");
        }

        // Validation 5: Slot conflict detection across ArrayList<Appointment>
        for (Appointment existing : appointments) {
            boolean sameDoctor = existing.getDoctor().getDoctorId() == appointment.getDoctor().getDoctorId();
            boolean sameDate = existing.getDate().equalsIgnoreCase(appointment.getDate());
            boolean sameTime = existing.getTime().equalsIgnoreCase(appointment.getTime());

            if (sameDoctor && sameDate && sameTime && !"CANCELLED".equalsIgnoreCase(existing.getStatus())) {
                throw new AppointmentException("SLOT_UNAVAILABLE",
                    String.format("Consultation slot conflict: Dr. %s is already scheduled on %s at %s (#%d).",
                        existing.getDoctor().getName(), existing.getDate(), existing.getTime(), existing.getAppointmentId())
                );
            }
        }

        // All clinical checks satisfied: record into ArrayList
        appointments.add(appointment);
        System.out.println("  [Scheduling] Appointment #" + appointment.getAppointmentId() + " successfully booked for "
                + appointment.getPatient().getName() + " with Dr. " + appointment.getDoctor().getName()
                + " on " + appointment.getDate() + " at " + appointment.getTime());
    }

    /**
     * Displays all scheduled appointments.
     */
    public void showAppointments() {
        System.out.println("\n=== APPOINTMENT DIRECTORY (" + appointments.size() + " Bookings) ===");
        if (appointments.isEmpty()) {
            System.out.println("  No appointments currently booked.");
            return;
        }
        for (int i = 0; i < appointments.size(); i++) {
            System.out.println("  " + (i + 1) + ". " + appointments.get(i).toString());
        }
    }

    // ==========================================================
    // 4. POLYMORPHISM DEMONSTRATION
    // ==========================================================

    /**
     * Demonstrates runtime polymorphism (dynamic method dispatch).
     * Iterates through Doctor references and invokes overridden consultationDetails().
     */
    public void conductAllConsultations() {
        System.out.println("\n--- [Runtime Polymorphism in Action: Dynamic Consultation Dispatch] ---");
        for (Doctor doc : doctors) {
            // Polymorphic call: resolution occurs dynamically at runtime based on actual object type
            System.out.println("  * " + doc.consultationDetails());
        }
    }

    // ==========================================================
    // EMERGENCY CASE OPERATIONS
    // ==========================================================

    public void registerEmergencyCase(EmergencyCase emergencyCase) {
        if (emergencyCase == null) {
            throw new IllegalArgumentException("Emergency case cannot be null.");
        }
        emergencyCases.add(emergencyCase);
        System.out.println("  [Emergency Triage] Case #" + emergencyCase.getCaseId() + " triaged for "
                + emergencyCase.getPatient().getName() + " -> " + emergencyCase.getSeverityLevel());
    }

    public void showEmergencyCases() {
        System.out.println("\n--- [MediSphere 3D Emergency & Trauma Cases] (" + emergencyCases.size() + " cases) ---");
        for (EmergencyCase ec : emergencyCases) {
            System.out.println("  " + ec.toString());
        }
    }

    // Getters for lists
    public ArrayList<Patient> getPatients() {
        return patients;
    }

    public ArrayList<Doctor> getDoctors() {
        return doctors;
    }

    public ArrayList<Appointment> getAppointments() {
        return appointments;
    }

    public ArrayList<EmergencyCase> getEmergencyCases() {
        return emergencyCases;
    }
}
