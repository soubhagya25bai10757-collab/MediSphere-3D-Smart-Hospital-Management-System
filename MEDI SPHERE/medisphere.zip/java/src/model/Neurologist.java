package model;

/**
 * Neurologist Subclass
 * Demonstrates:
 * 3. Inheritance (extends Doctor, calls super(...))
 * 4. Polymorphism (overrides consultationDetails())
 */
public class Neurologist extends Doctor {
    private boolean eegQualified;
    private String neuroSubField; // e.g. Neuro-oncology, Stroke Intervention, Epilepsy

    public Neurologist(int doctorId, String name, int experience, double consultationFee,
                       boolean eegQualified, String neuroSubField) {
        super(doctorId, name, "Neurology", experience, consultationFee);
        this.eegQualified = eegQualified;
        this.neuroSubField = (neuroSubField != null) ? neuroSubField : "General Neurology";
    }

    public boolean isEegQualified() {
        return eegQualified;
    }

    public void setEegQualified(boolean eegQualified) {
        this.eegQualified = eegQualified;
    }

    public String getNeuroSubField() {
        return neuroSubField;
    }

    public void setNeuroSubField(String neuroSubField) {
        this.neuroSubField = neuroSubField;
    }

    /**
     * Polymorphic method override for Neurology.
     */
    @Override
    public String consultationDetails() {
        return String.format(
            "[Neurology Consultation] Dr. %s conducts cranial nerve evaluation, brain MRI review, EEG rhythm mapping (EEG Qualified: %b), and cognitive response test for %s. Fee: $%.2f",
            getName(), eegQualified, neuroSubField, getConsultationFee()
        );
    }

    @Override
    public String toString() {
        return String.format("Neurologist [%s, EEG-Qualified=%b, SubField='%s']",
                super.toString(), eegQualified, neuroSubField);
    }
}
