package model;

/**
 * Dentist Subclass
 * Demonstrates:
 * 3. Inheritance (extends Doctor, calls super(...))
 * 4. Polymorphism (overrides consultationDetails())
 */
public class Dentist extends Doctor {
    private String dentalSubSpecialty; // e.g., Orthodontics, Periodontics, Endodontics
    private boolean maxillaSurgeryPermit;

    public Dentist(int doctorId, String name, int experience, double consultationFee,
                   String dentalSubSpecialty, boolean maxillaSurgeryPermit) {
        super(doctorId, name, "Dentistry", experience, consultationFee);
        this.dentalSubSpecialty = (dentalSubSpecialty != null) ? dentalSubSpecialty : "General Dentistry";
        this.maxillaSurgeryPermit = maxillaSurgeryPermit;
    }

    public String getDentalSubSpecialty() {
        return dentalSubSpecialty;
    }

    public void setDentalSubSpecialty(String dentalSubSpecialty) {
        this.dentalSubSpecialty = dentalSubSpecialty;
    }

    public boolean isMaxillaSurgeryPermit() {
        return maxillaSurgeryPermit;
    }

    public void setMaxillaSurgeryPermit(boolean maxillaSurgeryPermit) {
        this.maxillaSurgeryPermit = maxillaSurgeryPermit;
    }

    /**
     * Polymorphic method override for Dentistry.
     */
    @Override
    public String consultationDetails() {
        return String.format(
            "[Dental Consultation] Dr. %s performs oral cavity inspection, panoramic dental radiography, periodontal evaluation, and %s procedure plan (Surgery Permit: %b). Fee: $%.2f",
            getName(), dentalSubSpecialty, maxillaSurgeryPermit, getConsultationFee()
        );
    }

    @Override
    public String toString() {
        return String.format("Dentist [%s, SubSpecialty='%s', SurgeryPermit=%b]",
                super.toString(), dentalSubSpecialty, maxillaSurgeryPermit);
    }
}
