package model;

/**
 * Appointment Entity Class
 * Demonstrates:
 * 1. Classes and Objects (Composition: associates Patient and Doctor)
 * 2. Encapsulation with private fields and validation
 */
public class Appointment {
    private int appointmentId;
    private Patient patient;
    private Doctor doctor;
    private String date; // YYYY-MM-DD
    private String time; // e.g., 09:30 AM
    private String consultationType; // e.g. In-Person, Video Telehealth, Follow-up
    private String status; // CONFIRMED, COMPLETED, CANCELLED

    // Parameterized Constructor
    public Appointment(int appointmentId, Patient patient, Doctor doctor,
                       String date, String time, String consultationType) {
        setAppointmentId(appointmentId);
        setPatient(patient);
        setDoctor(doctor);
        setDate(date);
        setTime(time);
        setConsultationType(consultationType);
        this.status = "CONFIRMED";
    }

    // Encapsulation: Getters and Setters with Validation
    public int getAppointmentId() {
        return appointmentId;
    }

    public void setAppointmentId(int appointmentId) {
        if (appointmentId <= 0) {
            throw new IllegalArgumentException("Appointment ID must be positive.");
        }
        this.appointmentId = appointmentId;
    }

    public Patient getPatient() {
        return patient;
    }

    public void setPatient(Patient patient) {
        if (patient == null) {
            throw new IllegalArgumentException("Appointment patient cannot be null.");
        }
        this.patient = patient;
    }

    public Doctor getDoctor() {
        return doctor;
    }

    public void setDoctor(Doctor doctor) {
        if (doctor == null) {
            throw new IllegalArgumentException("Appointment doctor cannot be null.");
        }
        this.doctor = doctor;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        if (date == null || date.trim().isEmpty()) {
            throw new IllegalArgumentException("Appointment date cannot be null or empty.");
        }
        this.date = date.trim();
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        if (time == null || time.trim().isEmpty()) {
            throw new IllegalArgumentException("Appointment time cannot be null or empty.");
        }
        this.time = time.trim();
    }

    public String getConsultationType() {
        return consultationType;
    }

    public void setConsultationType(String consultationType) {
        this.consultationType = (consultationType != null) ? consultationType.trim() : "Standard Consultation";
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = (status != null) ? status.toUpperCase() : "CONFIRMED";
    }

    @Override
    public String toString() {
        return String.format(
            "Appointment #%d [%s | %s] Patient: '%s' (ID:%d) -> Doctor: Dr. '%s' (%s) | Status: %s | Type: %s",
            appointmentId, date, time,
            patient != null ? patient.getName() : "None",
            patient != null ? patient.getPatientId() : 0,
            doctor != null ? doctor.getName() : "None",
            doctor != null ? doctor.getSpecialization() : "None",
            status, consultationType
        );
    }
}
