package model;

/**
 * Patient Entity Class
 * Demonstrates:
 * 1. Classes and Objects
 * 2. Encapsulation with private attributes and validated getters/setters
 */
public class Patient {
    private int patientId;
    private String name;
    private int age;
    private String bloodGroup;
    private String phone;

    // Parameterized Constructor
    public Patient(int patientId, String name, int age, String bloodGroup, String phone) {
        setPatientId(patientId);
        setName(name);
        setAge(age);
        setBloodGroup(bloodGroup);
        setPhone(phone);
    }

    // Encapsulation: Getters and Setters with Validation
    public int getPatientId() {
        return patientId;
    }

    public void setPatientId(int patientId) {
        if (patientId <= 0) {
            throw new IllegalArgumentException("Patient ID must be a positive integer.");
        }
        this.patientId = patientId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        if (name == null || name.trim().isEmpty()) {
            throw new IllegalArgumentException("Patient name cannot be null or empty.");
        }
        this.name = name.trim();
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        if (age < 0 || age > 140) {
            throw new IllegalArgumentException("Patient age must be between 0 and 140. Given: " + age);
        }
        this.age = age;
    }

    public String getBloodGroup() {
        return bloodGroup;
    }

    public void setBloodGroup(String bloodGroup) {
        if (bloodGroup == null || bloodGroup.trim().isEmpty()) {
            this.bloodGroup = "Unknown";
        } else {
            this.bloodGroup = bloodGroup.trim().toUpperCase();
        }
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = (phone != null) ? phone.trim() : "N/A";
    }

    @Override
    public String toString() {
        return String.format("Patient [ID=%d, Name='%s', Age=%d, BloodGroup='%s', Phone='%s']",
                patientId, name, age, bloodGroup, phone);
    }
}
