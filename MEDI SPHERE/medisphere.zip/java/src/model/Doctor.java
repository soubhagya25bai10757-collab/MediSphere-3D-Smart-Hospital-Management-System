package model;

/**
 * Doctor Superclass
 * Demonstrates:
 * 1. Classes and Objects
 * 2. Encapsulation with private fields and validation
 * 3. Base class for Inheritance (extended by Cardiologist, Dentist, Neurologist, OrthopedicDoctor)
 * 4. Polymorphism target (provides base implementation of consultationDetails() overridden by subclasses)
 */
public class Doctor {
    private int doctorId;
    private String name;
    private String specialization;
    private int experience; // in years
    private double consultationFee;

    // Parameterized Constructor
    public Doctor(int doctorId, String name, String specialization, int experience, double consultationFee) {
        setDoctorId(doctorId);
        setName(name);
        setSpecialization(specialization);
        setExperience(experience);
        setConsultationFee(consultationFee);
    }

    // Encapsulation: Getters and Setters with Validation
    public int getDoctorId() {
        return doctorId;
    }

    public void setDoctorId(int doctorId) {
        if (doctorId <= 0) {
            throw new IllegalArgumentException("Doctor ID must be a positive integer.");
        }
        this.doctorId = doctorId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        if (name == null || name.trim().isEmpty()) {
            throw new IllegalArgumentException("Doctor name cannot be null or empty.");
        }
        this.name = name.trim();
    }

    public String getSpecialization() {
        return specialization;
    }

    public void setSpecialization(String specialization) {
        if (specialization == null || specialization.trim().isEmpty()) {
            throw new IllegalArgumentException("Specialization cannot be null or empty.");
        }
        this.specialization = specialization.trim();
    }

    public int getExperience() {
        return experience;
    }

    public void setExperience(int experience) {
        if (experience < 0 || experience > 75) {
            throw new IllegalArgumentException("Doctor experience years cannot be negative or over 75.");
        }
        this.experience = experience;
    }

    public double getConsultationFee() {
        return consultationFee;
    }

    public void setConsultationFee(double consultationFee) {
        if (consultationFee < 0.0) {
            throw new IllegalArgumentException("Consultation fee cannot be negative. Given: " + consultationFee);
        }
        this.consultationFee = consultationFee;
    }

    /**
     * Polymorphic method to be overridden in specialist child classes.
     * Demonstrates runtime polymorphism when invoked via Doctor reference.
     */
    public String consultationDetails() {
        return String.format(
            "[General Medical Consultation] Dr. %s conducts standard vitals triage, differential diagnosis, and basic prescription regimen. Fee: $%.2f",
            name, consultationFee
        );
    }

    @Override
    public String toString() {
        return String.format("Doctor [ID=%d, Name='%s', Specialization='%s', Experience=%d yrs, Fee=$%.2f]",
                doctorId, name, specialization, experience, consultationFee);
    }
}
