package model;

/**
 * OrthopedicDoctor Subclass
 * Demonstrates:
 * 3. Inheritance (extends Doctor, calls super(...))
 * 4. Polymorphism (overrides consultationDetails())
 */
public class OrthopedicDoctor extends Doctor {
    private boolean jointReplacementCertified;
    private String primaryFocus; // e.g. Knee & Hip Arthroplasty, Sports Medicine, Spine

    public OrthopedicDoctor(int doctorId, String name, int experience, double consultationFee,
                            boolean jointReplacementCertified, String primaryFocus) {
        super(doctorId, name, "Orthopedics", experience, consultationFee);
        this.jointReplacementCertified = jointReplacementCertified;
        this.primaryFocus = (primaryFocus != null) ? primaryFocus : "Musculoskeletal Surgery";
    }

    public boolean isJointReplacementCertified() {
        return jointReplacementCertified;
    }

    public void setJointReplacementCertified(boolean jointReplacementCertified) {
        this.jointReplacementCertified = jointReplacementCertified;
    }

    public String getPrimaryFocus() {
        return primaryFocus;
    }

    public void setPrimaryFocus(String primaryFocus) {
        this.primaryFocus = primaryFocus;
    }

    /**
     * Polymorphic method override for Orthopedics.
     */
    @Override
    public String consultationDetails() {
        return String.format(
            "[Orthopedic Consultation] Dr. %s conducts musculoskeletal biomechanical gait assessment, joint stress testing, digital X-ray bone scan, and %s evaluation (Arthroplasty Certified: %b). Fee: $%.2f",
            getName(), primaryFocus, jointReplacementCertified, getConsultationFee()
        );
    }

    @Override
    public String toString() {
        return String.format("OrthopedicDoctor [%s, ArthroplastyCertified=%b, PrimaryFocus='%s']",
                super.toString(), jointReplacementCertified, primaryFocus);
    }
}
