package model;

/**
 * Cardiologist Subclass
 * Demonstrates:
 * 3. Inheritance (extends Doctor, calls super(...))
 * 4. Polymorphism (overrides consultationDetails())
 */
public class Cardiologist extends Doctor {
    private boolean ecgCertified;
    private int cardiacSurgeriesPerformed;

    public Cardiologist(int doctorId, String name, int experience, double consultationFee,
                        boolean ecgCertified, int cardiacSurgeriesPerformed) {
        super(doctorId, name, "Cardiology", experience, consultationFee);
        this.ecgCertified = ecgCertified;
        this.cardiacSurgeriesPerformed = cardiacSurgeriesPerformed;
    }

    public boolean isEcgCertified() {
        return ecgCertified;
    }

    public void setEcgCertified(boolean ecgCertified) {
        this.ecgCertified = ecgCertified;
    }

    public int getCardiacSurgeriesPerformed() {
        return cardiacSurgeriesPerformed;
    }

    public void setCardiacSurgeriesPerformed(int cardiacSurgeriesPerformed) {
        if (cardiacSurgeriesPerformed < 0) {
            throw new IllegalArgumentException("Surgeries performed count cannot be negative.");
        }
        this.cardiacSurgeriesPerformed = cardiacSurgeriesPerformed;
    }

    /**
     * Polymorphic method override for Cardiology.
     */
    @Override
    public String consultationDetails() {
        return String.format(
            "[Cardiology Consultation] Dr. %s conducts 12-lead ECG analysis, echocardiogram scan, coronary artery flow assessment, and hypertension management (Surgeries: %d, ECG-Certified: %b). Fee: $%.2f",
            getName(), cardiacSurgeriesPerformed, ecgCertified, getConsultationFee()
        );
    }

    @Override
    public String toString() {
        return String.format("Cardiologist [%s, ECG-Certified=%b, Surgeries=%d]",
                super.toString(), ecgCertified, cardiacSurgeriesPerformed);
    }
}
