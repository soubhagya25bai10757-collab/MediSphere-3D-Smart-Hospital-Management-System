package model;

/**
 * EmergencyCase Entity Class
 * Demonstrates:
 * 1. Classes and Objects in acute care workflow
 * 2. Encapsulation with triage priority validation
 */
public class EmergencyCase {
    private int caseId;
    private Patient patient;
    private String severityLevel; // PRIORITY-1 CRITICAL, PRIORITY-2 URGENT, PRIORITY-3 STABLE
    private String triageNotes;
    private Doctor assignedDoctor;

    public EmergencyCase(int caseId, Patient patient, String severityLevel, String triageNotes, Doctor assignedDoctor) {
        setCaseId(caseId);
        setPatient(patient);
        setSeverityLevel(severityLevel);
        setTriageNotes(triageNotes);
        setAssignedDoctor(assignedDoctor);
    }

    public int getCaseId() {
        return caseId;
    }

    public void setCaseId(int caseId) {
        if (caseId <= 0) {
            throw new IllegalArgumentException("Emergency case ID must be positive.");
        }
        this.caseId = caseId;
    }

    public Patient getPatient() {
        return patient;
    }

    public void setPatient(Patient patient) {
        if (patient == null) {
            throw new IllegalArgumentException("Emergency patient cannot be null.");
        }
        this.patient = patient;
    }

    public String getSeverityLevel() {
        return severityLevel;
    }

    public void setSeverityLevel(String severityLevel) {
        if (severityLevel == null || severityLevel.trim().isEmpty()) {
            this.severityLevel = "PRIORITY-2 URGENT";
        } else {
            this.severityLevel = severityLevel.trim().toUpperCase();
        }
    }

    public String getTriageNotes() {
        return triageNotes;
    }

    public void setTriageNotes(String triageNotes) {
        this.triageNotes = (triageNotes != null) ? triageNotes.trim() : "Acute intake triage";
    }

    public Doctor getAssignedDoctor() {
        return assignedDoctor;
    }

    public void setAssignedDoctor(Doctor assignedDoctor) {
        this.assignedDoctor = assignedDoctor;
    }

    @Override
    public String toString() {
        return String.format(
            "EmergencyCase [CaseID=%d, Patient='%s', Severity='%s', Doctor='%s', Triage='%s']",
            caseId,
            patient != null ? patient.getName() : "Unknown",
            severityLevel,
            assignedDoctor != null ? assignedDoctor.getName() : "Pending Assignment",
            triageNotes
        );
    }
}
