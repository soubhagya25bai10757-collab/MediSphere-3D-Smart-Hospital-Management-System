package exception;

/**
 * Custom Exception for Hospital Appointment Operations
 * Demonstrates:
 * 5. Exception Handling: Custom Checked Exception used with throw and throws
 */
public class AppointmentException extends Exception {
    private String errorCode;

    public AppointmentException(String message) {
        super(message);
        this.errorCode = "APPT_ERR_GENERIC";
    }

    public AppointmentException(String errorCode, String message) {
        super(String.format("[%s] %s", errorCode, message));
        this.errorCode = errorCode;
    }

    public AppointmentException(String message, Throwable cause) {
        super(message, cause);
        this.errorCode = "APPT_ERR_CHAINED";
    }

    public String getErrorCode() {
        return errorCode;
    }
}
